"""Strict immutable contracts for pre-randomization confirmation protocols."""

from __future__ import annotations

from collections.abc import Mapping
from enum import Enum
import hashlib
import json
import re
from typing import Any, ClassVar, Literal, NoReturn, Self

from pydantic import BaseModel, ConfigDict, Field, StrictInt, field_validator, model_validator

from secaware.schema.common import (
    MAX_MODEL_ID_CHARS,
    SafeValidationMixin,
    StrictModel,
    is_valid_model_id,
)
from secaware.schema.features import FeatureFamily, FeatureOperation, FeatureState


_SHA256_PATTERN = r"^[0-9a-f]{64}$"
_HYPOTHESIS_ID_PATTERN = r"^hypothesis_[0-9a-f]{64}$"
_TARGET_ID_PATTERN = r"^target_[0-9a-f]{64}$"
_TARGET_INSTANCE_ID_PATTERN = r"^target_instance_[0-9a-f]{64}$"
_PROTOCOL_ID_PATTERN = r"^arm_protocol_[0-9a-f]{64}$"
_PROTOCOL_INSTANCE_ID_PATTERN = r"^protocol_instance_[0-9a-f]{64}$"
_CONTRACT_ID_PATTERN = r"^functional_contract_[0-9a-f]{64}$"
_DELTA_ID_PATTERN = r"^delta_[0-9a-f]{64}$"
_VARIANT_ID_PATTERN = r"^variant_[0-9a-f]{64}$"
_VARIANT_PROMPT_ID_PATTERN = r"^variant_prompt_[0-9a-f]{64}$"
_LENGTH_MATCH_ID_PATTERN = r"^length_match_[0-9a-f]{64}$"
_EXCLUSION_ID_PATTERN = r"^pre_randomization_exclusion_[0-9a-f]{64}$"
_PROPOSAL_ID_PATTERN = r"^proposal_[0-9a-f]{64}$"
_ASSIGNMENT_ID_PATTERN = r"^assignment_[0-9a-f]{64}$"
_BLOCK_ID_PATTERN = r"^block_[0-9a-f]{64}$"
_RANDOMIZATION_ID_PATTERN = r"^randomization_[0-9a-f]{64}$"
_EXECUTION_ID_PATTERN = r"^assignment_execution_[0-9a-f]{64}$"
_REQUEST_ID_PATTERN = r"^req_[0-9a-f]{64}$"
_CODE_ID_PATTERN = r"^code_[0-9a-f]{64}$"
_MULTIPLICITY_ID_RE = re.compile(r"^multiplicity_[0-9a-f]{64}$")
_IDENTIFIER_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,255}$")
_OUTCOME_ID_RE = re.compile(r"^y_[a-z0-9][a-z0-9_]{0,126}$")
_OUTCOME_VARIABLE_RE = re.compile(r"^y\.[a-z0-9][a-z0-9_.-]{0,126}$")
_FAMILY_ORDER = {family: index for index, family in enumerate(FeatureFamily)}
_STATE_ORDER = {state: index for index, state in enumerate(FeatureState)}
_RESERVED_FUNCTIONAL_OUTCOMES = frozenset(
    {
        "y_secure_functional",
        "y_cwe_secure",
        "y_cwe_insecure",
        "y_cwe_unknown",
        "y_oracle_evaluable",
        "y_parse_ok",
        "y_functional_ok",
    }
)

# M4B intentionally observes every intervenable Prompt feature, including the
# generic reminder. M5 applies this narrower, immutable target gate: the reminder
# remains available as a randomized arm control but can never become the target.
CONFIRMATION_CONTROL_ONLY_FEATURE_IDS = ("safety.generic_security_reminder",)
CONFIRMATION_TARGET_FEATURE_IDS = (
    "task.input_consumption",
    "task.file_read",
    "task.database_query",
    "task.process_launch",
    "task.privileged_action",
    "task.object_deserialization",
    "task.message_hashing",
    "task.security_random_generation",
    "safety.input_validation",
    "safety.path_normalization",
    "safety.sql_parameterization",
    "safety.safe_subprocess",
    "safety.authorization_check",
    "safety.safe_deserialization",
    "safety.collision_resistant_hash",
    "safety.cryptographic_randomness",
    "presentation.noop_rewrite",
    "presentation.length_matched_placebo",
    "presentation.sham_edit",
    "presentation.matched_control",
)


def is_confirmation_target_feature(
    feature_id: object,
    operation: object,
) -> bool:
    """Return whether one exact catalog operation may be an M5 target."""
    return (
        type(feature_id) is str
        and type(operation) is FeatureOperation
        and feature_id in CONFIRMATION_TARGET_FEATURE_IDS
        and operation in (FeatureOperation.ADD, FeatureOperation.REMOVE)
    )


def _jsonable(value: object) -> object:
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json")
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_jsonable(item) for item in value]
    return value


def _digest(value: object) -> str:
    return hashlib.sha256(
        json.dumps(
            _jsonable(value),
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
    ).hexdigest()


def _content(model: StrictModel, *derived_fields: str) -> dict[str, Any]:
    return model.model_dump(mode="json", exclude=set(derived_fields))


def _snapshot_json_arrays(value: object) -> object:
    if type(value) is dict:
        return {key: _snapshot_json_arrays(item) for key, item in value.items()}
    if type(value) in {list, tuple}:
        return tuple(_snapshot_json_arrays(item) for item in value)
    return value


def _exact_enum(value: object, enum_type: type[Enum]) -> object:
    if isinstance(value, enum_type):
        return value
    if type(value) is str:
        for member in enum_type:
            if value == member.value:
                return member
    return value


def _valid_identifier(value: str) -> bool:
    return (
        bool(_IDENTIFIER_RE.fullmatch(value))
        and value == value.strip()
        and not any(ord(character) < 0x20 or ord(character) == 0x7F for character in value)
    )


def _raise_contract_validation_error(
    model_type: type[SafeValidationMixin],
) -> NoReturn:
    """Raise from a frame that never receives raw contract values."""
    raise model_type._safe_error()


class _ExperimentContract(SafeValidationMixin, StrictModel):
    _safe_validation_message: ClassVar[str] = "experiment contract failed validation"

    model_config = ConfigDict(
        extra="forbid",
        frozen=True,
        hide_input_in_errors=True,
        revalidate_instances="always",
        strict=True,
    )

    @model_validator(mode="before")
    @classmethod
    def snapshot_json_arrays(cls, value: object) -> object:
        return _snapshot_json_arrays(value)

    def __repr__(self) -> str:
        return f"{type(self).__name__}()"

    def __str__(self) -> str:
        return f"{type(self).__name__}()"


class _ExperimentVersionedContract(_ExperimentContract):
    schema_version: Literal["1.0"]


class PromptRole(str, Enum):
    NEUTRAL_BASELINE = "neutral_baseline"
    POSITIVE_SAFETY_CONTROL = "positive_safety_control"
    TASK_FUNCTION_BASELINE = "task_function_baseline"
    TASK_FUNCTION_VARIANT = "task_function_variant"
    PRESENTATION_BASELINE = "presentation_baseline"
    PRESENTATION_VARIANT = "presentation_variant"


class InterventionMode(str, Enum):
    TEXT_NATIVE = "text_native"
    GRAPH_NATIVE = "graph_native"


class InterventionExecutorKind(str, Enum):
    DETERMINISTIC = "deterministic"
    LLM = "llm"


class ArmRole(str, Enum):
    TARGET_PATCH = "target_patch"
    NOOP_REWRITE = "noop_rewrite"
    LENGTH_MATCHED_PLACEBO = "length_matched_placebo"
    GENERIC_SECURITY_REMINDER = "generic_security_reminder"
    TARGET_REMOVE = "target_remove"
    NOOP_RETAIN = "noop_retain"
    LENGTH_MATCHED_SHAM_EDIT = "length_matched_sham_edit"
    GENERIC_SECURITY_REPLACEMENT = "generic_security_replacement"
    TASK_TARGET = "task_target"
    TASK_NOOP = "task_noop"
    TASK_LENGTH_PLACEBO = "task_length_placebo"
    TASK_GENERIC_CONTROL = "task_generic_control"
    PRESENTATION_TARGET = "presentation_target"
    PRESENTATION_NOOP = "presentation_noop"
    PRESENTATION_MATCHED_CONTROL = "presentation_matched_control"


class AssignmentExecutionStatus(str, Enum):
    GENERATED = "generated"
    TERMINAL_NO_CODE = "terminal_no_code"


class ExperimentalUnit(_ExperimentContract):
    """A seed-slot unit fixed before an arm role is assigned."""

    task_id: str
    hypothesis_id: str = Field(pattern=_HYPOTHESIS_ID_PATTERN)
    target_spec_id: str = Field(pattern=_TARGET_ID_PATTERN)
    model_id: str = Field(min_length=1, max_length=MAX_MODEL_ID_CHARS, strict=True)
    seed_slot: int = Field(ge=0, le=99_999, strict=True)

    @model_validator(mode="after")
    def validate_identifiers(self) -> Self:
        if (
            not _valid_identifier(self.task_id)
            or not _valid_identifier(self.model_id)
            or not is_valid_model_id(self.model_id)
        ):
            raise ValueError(self._safe_validation_message)
        return self


class AssignmentRecord(_ExperimentVersionedContract):
    """One immutable, content-addressed randomized arm assignment."""

    schema_version: Literal["1.0"]
    assignment_id: str = Field(pattern=_ASSIGNMENT_ID_PATTERN)
    block_id: str = Field(pattern=_BLOCK_ID_PATTERN)
    experimental_unit: ExperimentalUnit
    target_spec_id: str = Field(pattern=_TARGET_ID_PATTERN)
    target_instance_id: str = Field(pattern=_TARGET_INSTANCE_ID_PATTERN)
    arm_protocol_id: str = Field(pattern=_PROTOCOL_ID_PATTERN)
    protocol_instance_id: str = Field(pattern=_PROTOCOL_INSTANCE_ID_PATTERN)
    variant_id: str = Field(pattern=_VARIANT_ID_PATTERN)
    arm_role: ArmRole
    seed_id: int = Field(ge=-(2**63), le=2**63 - 1, strict=True)
    rng_version: Literal["sha256-rejection-fisher-yates-v1"]
    randomization_plan_sha256: str = Field(pattern=_SHA256_PATTERN)

    @field_validator("arm_role", mode="before")
    @classmethod
    def parse_arm_role(cls, value: object) -> object:
        return _exact_enum(value, ArmRole)

    @staticmethod
    def block_id_from_key(
        task_id: str,
        hypothesis_id: str,
        target_spec_id: str,
        arm_protocol_id: str,
        model_id: str,
    ) -> str:
        if not is_valid_model_id(model_id):
            raise ValueError("experiment contract failed validation")
        return "block_" + _digest(
            {
                "block_key_version": "confirmation-block-key-v1",
                "task_id": task_id,
                "hypothesis_id": hypothesis_id,
                "target_spec_id": target_spec_id,
                "arm_protocol_id": arm_protocol_id,
                "model_id": model_id,
            }
        )

    @classmethod
    def from_content(cls, **content: Any) -> Self:
        payload: dict[str, Any] | None = None
        try:
            payload = {"schema_version": "1.0", **content}
            return cls(**payload, assignment_id=f"assignment_{_digest(payload)}")
        except (MemoryError, KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            content.clear()
            if payload is not None:
                payload.clear()
            _raise_contract_validation_error(cls)

    @model_validator(mode="after")
    def validate_semantics_and_digest(self) -> Self:
        unit = self.experimental_unit
        expected_block_id = self.block_id_from_key(
            unit.task_id,
            unit.hypothesis_id,
            unit.target_spec_id,
            self.arm_protocol_id,
            unit.model_id,
        )
        if (
            self.target_spec_id != unit.target_spec_id
            or self.block_id != expected_block_id
            or self.assignment_id != f"assignment_{_digest(_content(self, 'assignment_id'))}"
        ):
            raise ValueError(self._safe_validation_message)
        return self


class RandomizationManifestRecord(_ExperimentVersionedContract):
    """Content-addressed commitment to one acyclic randomization plan."""

    schema_version: Literal["1.0"]
    manifest_id: str = Field(pattern=_RANDOMIZATION_ID_PATTERN)
    global_seed: int = Field(ge=-(2**63), le=2**63 - 1, strict=True)
    rng_version: Literal["sha256-rejection-fisher-yates-v1"]
    randomization_plan_sha256: str = Field(pattern=_SHA256_PATTERN)
    block_ids: tuple[str, ...]
    assignment_ids: tuple[str, ...]
    assignments_sha256: str = Field(pattern=_SHA256_PATTERN)

    @classmethod
    def from_content(cls, **content: Any) -> Self:
        payload: dict[str, Any] | None = None
        try:
            payload = {"schema_version": "1.0", **content}
            return cls(**payload, manifest_id=f"randomization_{_digest(payload)}")
        except (MemoryError, KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            content.clear()
            if payload is not None:
                payload.clear()
            _raise_contract_validation_error(cls)

    @model_validator(mode="after")
    def validate_semantics_and_digest(self) -> Self:
        if (
            not self.block_ids
            or not self.assignment_ids
            or any(re.fullmatch(_BLOCK_ID_PATTERN, item) is None for item in self.block_ids)
            or any(
                re.fullmatch(_ASSIGNMENT_ID_PATTERN, item) is None for item in self.assignment_ids
            )
            or self.block_ids != tuple(sorted(self.block_ids))
            or len(self.block_ids) != len(set(self.block_ids))
            or len(self.assignment_ids) != len(set(self.assignment_ids))
            or self.manifest_id != f"randomization_{_digest(_content(self, 'manifest_id'))}"
        ):
            raise ValueError(self._safe_validation_message)
        return self


class AssignmentExecutionRecord(_ExperimentVersionedContract):
    """One terminal, content-addressed execution outcome per assignment."""

    schema_version: Literal["1.0"]
    execution_id: str = Field(pattern=_EXECUTION_ID_PATTERN)
    assignment_id: str = Field(pattern=_ASSIGNMENT_ID_PATTERN)
    request_id: str = Field(pattern=_REQUEST_ID_PATTERN)
    status: AssignmentExecutionStatus
    provider_result_sha256: str = Field(pattern=_SHA256_PATTERN)
    provider_provenance_sha256: str = Field(pattern=_SHA256_PATTERN)
    provider_runtime_sha256: str = Field(pattern=_SHA256_PATTERN)
    provider_policy_sha256: str = Field(pattern=_SHA256_PATTERN)
    usage_sha256: str = Field(pattern=_SHA256_PATTERN)
    attempt_count: StrictInt = Field(ge=1, le=10)
    code_id: str | None = Field(default=None, pattern=_CODE_ID_PATTERN)
    code_sha256: str | None = Field(default=None, pattern=_SHA256_PATTERN)
    terminal_reason: Literal["content_filter"] | None = None

    @field_validator("status", mode="before")
    @classmethod
    def parse_status(cls, value: object) -> object:
        return _exact_enum(value, AssignmentExecutionStatus)

    @classmethod
    def from_content(cls, **content: Any) -> Self:
        payload = {"schema_version": "1.0", **content}
        try:
            return cls(
                **payload,
                execution_id=f"assignment_execution_{_digest(payload)}",
            )
        except (MemoryError, KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            content.clear()
            payload.clear()
            _raise_contract_validation_error(cls)

    @model_validator(mode="after")
    def validate_semantics_and_digest(self) -> Self:
        generated = self.status is AssignmentExecutionStatus.GENERATED
        if (
            generated != (self.code_id is not None and self.code_sha256 is not None)
            or (self.code_id is None) != (self.code_sha256 is None)
            or generated == (self.terminal_reason is not None)
            or self.execution_id
            != f"assignment_execution_{_digest(_content(self, 'execution_id'))}"
        ):
            raise ValueError(self._safe_validation_message)
        return self


class PreRandomizationFailureCode(str, Enum):
    SOURCE_PROVENANCE_MISMATCH = "source_provenance_mismatch"
    EXECUTOR_POLICY_MISMATCH = "executor_policy_mismatch"
    EXECUTION_FAILED = "execution_failed"
    EXTRACTOR_POLICY_MISMATCH = "extractor_policy_mismatch"
    EXTRACTION_FAILED = "extraction_failed"
    GRAPH_ROUNDTRIP_FAILED = "graph_roundtrip_failed"
    ALLOWED_DELTA_VIOLATION = "allowed_delta_violation"
    FIXED_PROJECTION_UNRESOLVED = "fixed_projection_unresolved"
    SECURITY_NEUTRALITY_VIOLATION = "security_neutrality_violation"
    LENGTH_MISMATCH = "length_mismatch"
    PROTOCOL_COVERAGE_INVALID = "protocol_coverage_invalid"


class TargetSpecRecord(_ExperimentVersionedContract):
    schema_version: Literal["1.0"]
    target_spec_id: str = Field(pattern=_TARGET_ID_PATTERN)
    hypothesis_id: str = Field(pattern=_HYPOTHESIS_ID_PATTERN)
    frozen_hypothesis_sha256: str = Field(pattern=_SHA256_PATTERN)
    feature_family: FeatureFamily
    feature_id: str
    operation: FeatureOperation
    hypothesis_outcome_variable_id: str
    hypothesis_outcome_estimand_id: str
    expected_hypothesis_contrast_sign: Literal["positive", "negative", "null", "two_sided"]

    @field_validator("feature_family", mode="before")
    @classmethod
    def parse_family(cls, value: object) -> object:
        return _exact_enum(value, FeatureFamily)

    @field_validator("operation", mode="before")
    @classmethod
    def parse_operation(cls, value: object) -> object:
        return _exact_enum(value, FeatureOperation)

    @classmethod
    def from_content(cls, **content: Any) -> Self:
        payload: dict[str, Any] | None = None
        result: Self | None = None
        failed = False
        try:
            payload = {"schema_version": "1.0", **content}
            result = cls(**payload, target_spec_id=f"target_{_digest(payload)}")
        except (MemoryError, KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            failed = True
        if failed:
            content.clear()
            content = None
            if payload is not None:
                payload.clear()
            payload = None
            result = None
            _raise_contract_validation_error(cls)
        return result

    @model_validator(mode="after")
    def validate_semantics_and_digest(self) -> Self:
        prefix = {
            FeatureFamily.TASK_FUNCTION: "task.",
            FeatureFamily.SAFETY_CONTROL: "safety.",
            FeatureFamily.PRESENTATION_CONTROL: "presentation.",
        }[self.feature_family]
        expected_estimand = {
            "y.secure_functional": "y_secure_functional",
            "y.cwe_security": "y_cwe_secure",
        }.get(self.hypothesis_outcome_variable_id)
        expected = _digest(_content(self, "target_spec_id"))
        if (
            not _valid_identifier(self.feature_id)
            or not self.feature_id.startswith(prefix)
            or not is_confirmation_target_feature(self.feature_id, self.operation)
            or expected_estimand != self.hypothesis_outcome_estimand_id
            or self.target_spec_id != f"target_{expected}"
        ):
            raise ValueError(self._safe_validation_message)
        return self


class TargetInstanceRecord(_ExperimentVersionedContract):
    schema_version: Literal["1.0"]
    target_instance_id: str = Field(pattern=_TARGET_INSTANCE_ID_PATTERN)
    target_spec_id: str = Field(pattern=_TARGET_ID_PATTERN)
    task_id: str
    source_prompt_id: str
    source_prompt_sha256: str = Field(pattern=_SHA256_PATTERN)
    counterpart_prompt_id: str | None
    counterpart_prompt_sha256: str | None
    source_prompt_role: PromptRole
    counterpart_required: bool

    @field_validator("source_prompt_role", mode="before")
    @classmethod
    def parse_prompt_role(cls, value: object) -> object:
        return _exact_enum(value, PromptRole)

    @classmethod
    def from_content(cls, **content: Any) -> Self:
        payload: dict[str, Any] | None = None
        result: Self | None = None
        failed = False
        try:
            payload = {"schema_version": "1.0", **content}
            result = cls(
                **payload,
                target_instance_id=f"target_instance_{_digest(payload)}",
            )
        except (MemoryError, KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            failed = True
        if failed:
            content.clear()
            content = None
            if payload is not None:
                payload.clear()
            payload = None
            result = None
            _raise_contract_validation_error(cls)
        return result

    @model_validator(mode="after")
    def validate_semantics_and_digest(self) -> Self:
        has_counterpart = (
            self.counterpart_prompt_id is not None and self.counterpart_prompt_sha256 is not None
        )
        expected = _digest(_content(self, "target_instance_id"))
        if (
            not _valid_identifier(self.task_id)
            or not _valid_identifier(self.source_prompt_id)
            or (
                self.counterpart_prompt_id is not None
                and not _valid_identifier(self.counterpart_prompt_id)
            )
            or (self.counterpart_prompt_id is None) != (self.counterpart_prompt_sha256 is None)
            or has_counterpart != self.counterpart_required
            or self.target_instance_id != f"target_instance_{expected}"
        ):
            raise ValueError(self._safe_validation_message)
        return self


class FeatureTransition(_ExperimentContract):
    feature_id: str
    from_states: tuple[FeatureState, ...]
    to_states: tuple[FeatureState, ...]

    @field_validator("from_states", "to_states", mode="before")
    @classmethod
    def parse_states(cls, value: object) -> object:
        snapshot = _snapshot_json_arrays(value)
        if type(snapshot) is not tuple:
            return snapshot
        return tuple(_exact_enum(item, FeatureState) for item in snapshot)

    @model_validator(mode="after")
    def validate_transition(self) -> Self:
        allowed_states = set(FeatureState)
        if (
            not _valid_identifier(self.feature_id)
            or not self.from_states
            or not self.to_states
            or set(self.from_states) - allowed_states
            or set(self.to_states) - allowed_states
            or set(self.from_states) & set(self.to_states)
            or len(self.from_states) != len(set(self.from_states))
            or len(self.to_states) != len(set(self.to_states))
            or self.from_states
            != tuple(sorted(self.from_states, key=lambda item: _STATE_ORDER[item]))
            or self.to_states != tuple(sorted(self.to_states, key=lambda item: _STATE_ORDER[item]))
        ):
            raise ValueError(self._safe_validation_message)
        try:
            from secaware.tsg.feature_catalog import prompt_feature_spec

            spec = prompt_feature_spec(self.feature_id)
            if not spec.intervenable:
                raise ValueError
        except (MemoryError, KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            raise ValueError(self._safe_validation_message) from None
        return self


class AllowedDeltaRecord(_ExperimentContract):
    allowed_transitions: tuple[FeatureTransition, ...]
    fixed_families: tuple[FeatureFamily, ...]
    fixed_feature_ids: tuple[str, ...]

    @field_validator("fixed_families", mode="before")
    @classmethod
    def parse_families(cls, value: object) -> object:
        snapshot = _snapshot_json_arrays(value)
        if type(snapshot) is not tuple:
            return snapshot
        return tuple(_exact_enum(item, FeatureFamily) for item in snapshot)

    @model_validator(mode="after")
    def validate_delta(self) -> Self:
        transition_ids = tuple(item.feature_id for item in self.allowed_transitions)
        intervention_states = {FeatureState.ABSENT, FeatureState.PRESENT}
        if (
            transition_ids != tuple(sorted(transition_ids))
            or len(transition_ids) != len(set(transition_ids))
            or self.fixed_families
            != tuple(sorted(self.fixed_families, key=lambda item: _FAMILY_ORDER[item]))
            or len(self.fixed_families) != len(set(self.fixed_families))
            or self.fixed_feature_ids != tuple(sorted(self.fixed_feature_ids))
            or len(self.fixed_feature_ids) != len(set(self.fixed_feature_ids))
            or set(transition_ids) & set(self.fixed_feature_ids)
            or any(
                set(item.from_states) - intervention_states
                or set(item.to_states) - intervention_states
                for item in self.allowed_transitions
            )
        ):
            raise ValueError(self._safe_validation_message)
        try:
            from secaware.tsg.feature_catalog import prompt_feature_spec

            transition_specs = tuple(prompt_feature_spec(item) for item in transition_ids)
            fixed_specs = tuple(prompt_feature_spec(item) for item in self.fixed_feature_ids)
            if any(item.feature_family in self.fixed_families for item in transition_specs) or any(
                item.feature_family in self.fixed_families for item in fixed_specs
            ):
                raise ValueError
        except (MemoryError, KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            raise ValueError(self._safe_validation_message) from None
        return self


class ArmSpecRecord(_ExperimentContract):
    role: ArmRole
    allowed_delta: AllowedDeltaRecord

    @field_validator("role", mode="before")
    @classmethod
    def parse_role(cls, value: object) -> object:
        return _exact_enum(value, ArmRole)


class PreRegisteredContrastSpec(_ExperimentContract):
    contrast_id: str
    arm_contrast_id: str
    treatment_arm: ArmRole
    control_arm: ArmRole
    source_outcome_variable_id: str
    outcome_id: str
    priority: Literal["primary", "secondary", "diagnostic"]
    expected_sign: Literal["positive", "negative", "null", "two_sided"]
    multiplicity_family_id: str

    @field_validator("treatment_arm", "control_arm", mode="before")
    @classmethod
    def parse_arm_role(cls, value: object) -> object:
        return _exact_enum(value, ArmRole)

    @model_validator(mode="after")
    def validate_contrast(self) -> Self:
        if (
            not _valid_identifier(self.contrast_id)
            or not _valid_identifier(self.arm_contrast_id)
            or self.contrast_id != f"{self.arm_contrast_id}.{self.outcome_id}"
            or self.treatment_arm is self.control_arm
            or _OUTCOME_VARIABLE_RE.fullmatch(self.source_outcome_variable_id) is None
            or _OUTCOME_ID_RE.fullmatch(self.outcome_id) is None
            or _MULTIPLICITY_ID_RE.fullmatch(self.multiplicity_family_id) is None
        ):
            raise ValueError(self._safe_validation_message)
        return self


class ConfirmationProtocolRecord(_ExperimentVersionedContract):
    schema_version: Literal["1.0"]
    arm_protocol_id: str = Field(pattern=_PROTOCOL_ID_PATTERN)
    hypothesis_id: str = Field(pattern=_HYPOTHESIS_ID_PATTERN)
    frozen_hypothesis_sha256: str = Field(pattern=_SHA256_PATTERN)
    target_spec_id: str = Field(pattern=_TARGET_ID_PATTERN)
    feature_family: FeatureFamily
    operation: FeatureOperation
    arms: tuple[ArmSpecRecord, ...]
    hypothesis_outcome_variable_id: str
    hypothesis_outcome_estimand_id: str
    expected_hypothesis_contrast_sign: Literal["positive", "negative", "null", "two_sided"]
    contrasts: tuple[PreRegisteredContrastSpec, ...]
    contrast_set_sha256: str = Field(pattern=_SHA256_PATTERN)
    functional_outcome_contract_id: str | None = Field(
        default=None,
        pattern=_CONTRACT_ID_PATTERN,
    )

    @field_validator("feature_family", mode="before")
    @classmethod
    def parse_family(cls, value: object) -> object:
        return _exact_enum(value, FeatureFamily)

    @field_validator("operation", mode="before")
    @classmethod
    def parse_operation(cls, value: object) -> object:
        return _exact_enum(value, FeatureOperation)

    @property
    def arm_roles(self) -> tuple[ArmRole, ...]:
        return tuple(arm.role for arm in self.arms)

    @property
    def preregistered_contrast_ids(self) -> tuple[str, ...]:
        return tuple(item.contrast_id for item in self.contrasts)

    @staticmethod
    def contrast_digest(contrasts: tuple[PreRegisteredContrastSpec, ...]) -> str:
        return _digest(
            {
                "schema_version": "1.0",
                "contrast_catalog_id": "confirmation-contrast-catalog-v1",
                "contrasts": contrasts,
            }
        )

    @classmethod
    def from_content(cls, **content: Any) -> Self:
        payload: dict[str, Any] | None = None
        complete: dict[str, Any] | None = None
        contrasts: tuple[object, ...] = ()
        result: Self | None = None
        failed = False
        try:
            payload = {"schema_version": "1.0", **content}
            contrasts = tuple(payload["contrasts"])
            contrast_set_sha256 = cls.contrast_digest(contrasts)
            complete = {**payload, "contrast_set_sha256": contrast_set_sha256}
            result = cls(
                **complete,
                arm_protocol_id=f"arm_protocol_{_digest(complete)}",
            )
        except (MemoryError, KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            failed = True
        if failed:
            content.clear()
            content = None
            if payload is not None:
                payload.clear()
            payload = None
            if complete is not None:
                complete.clear()
            complete = None
            contrasts = ()
            result = None
            _raise_contract_validation_error(cls)
        return result

    @model_validator(mode="after")
    def validate_semantics_and_digest(self) -> Self:
        expected_contrast_sha256 = self.contrast_digest(self.contrasts)
        expected_protocol_sha256 = _digest(_content(self, "arm_protocol_id"))
        role_ids = self.arm_roles
        contrast_ids = self.preregistered_contrast_ids
        if (
            not self.arms
            or not self.contrasts
            or len(role_ids) != len(set(role_ids))
            or len(contrast_ids) != len(set(contrast_ids))
            or any(
                contrast.treatment_arm not in role_ids or contrast.control_arm not in role_ids
                for contrast in self.contrasts
            )
            or self.contrast_set_sha256 != expected_contrast_sha256
            or self.arm_protocol_id != f"arm_protocol_{expected_protocol_sha256}"
        ):
            raise ValueError(self._safe_validation_message)
        try:
            from secaware.intervention.arm_catalog import _validate_materialized_protocol

            _validate_materialized_protocol(self)
        except (MemoryError, KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            raise ValueError(self._safe_validation_message) from None
        return self


class ConfirmationProtocolInstanceRecord(_ExperimentVersionedContract):
    schema_version: Literal["1.0"]
    protocol_instance_id: str = Field(pattern=_PROTOCOL_INSTANCE_ID_PATTERN)
    arm_protocol_id: str = Field(pattern=_PROTOCOL_ID_PATTERN)
    target_instance_id: str = Field(pattern=_TARGET_INSTANCE_ID_PATTERN)
    task_id: str
    source_prompt_id: str
    source_prompt_sha256: str = Field(pattern=_SHA256_PATTERN)
    counterpart_prompt_id: str | None
    counterpart_prompt_sha256: str | None

    @classmethod
    def from_content(cls, **content: Any) -> Self:
        payload: dict[str, Any] | None = None
        result: Self | None = None
        failed = False
        try:
            payload = {"schema_version": "1.0", **content}
            result = cls(
                **payload,
                protocol_instance_id=f"protocol_instance_{_digest(payload)}",
            )
        except (MemoryError, KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            failed = True
        if failed:
            content.clear()
            content = None
            if payload is not None:
                payload.clear()
            payload = None
            result = None
            _raise_contract_validation_error(cls)
        return result

    @model_validator(mode="after")
    def validate_semantics_and_digest(self) -> Self:
        expected = _digest(_content(self, "protocol_instance_id"))
        if (
            not _valid_identifier(self.task_id)
            or not _valid_identifier(self.source_prompt_id)
            or (
                self.counterpart_prompt_id is not None
                and not _valid_identifier(self.counterpart_prompt_id)
            )
            or (self.counterpart_prompt_id is None) != (self.counterpart_prompt_sha256 is None)
            or self.protocol_instance_id != f"protocol_instance_{expected}"
        ):
            raise ValueError(self._safe_validation_message)
        return self


class FunctionalOutcomeContractRecord(_ExperimentVersionedContract):
    schema_version: Literal["1.0"]
    contract_id: str = Field(pattern=_CONTRACT_ID_PATTERN)
    task_feature_id: str
    outcome_id: str
    expected_add_sign: Literal["positive", "negative", "two_sided"]
    expected_remove_sign: Literal["positive", "negative", "two_sided"]
    generic_control_feature_id: str | None
    evaluator_policy_sha256: str = Field(pattern=_SHA256_PATTERN)

    @classmethod
    def from_content(cls, **content: Any) -> Self:
        payload: dict[str, Any] | None = None
        result: Self | None = None
        failed = False
        try:
            payload = {"schema_version": "1.0", **content}
            result = cls(
                **payload,
                contract_id=f"functional_contract_{_digest(payload)}",
            )
        except (MemoryError, KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            failed = True
        if failed:
            content.clear()
            content = None
            if payload is not None:
                payload.clear()
            payload = None
            result = None
            _raise_contract_validation_error(cls)
        return result

    @model_validator(mode="after")
    def validate_semantics_and_digest(self) -> Self:
        expected = _digest(_content(self, "contract_id"))
        try:
            from secaware.tsg.feature_catalog import prompt_feature_spec

            target = prompt_feature_spec(self.task_feature_id)
            generic = (
                prompt_feature_spec(self.generic_control_feature_id)
                if self.generic_control_feature_id is not None
                else None
            )
            if (
                target.feature_family is not FeatureFamily.TASK_FUNCTION
                or not target.intervenable
                or (
                    generic is not None
                    and (
                        generic.feature_family is not FeatureFamily.TASK_FUNCTION
                        or not generic.intervenable
                        or generic.feature_id == target.feature_id
                    )
                )
            ):
                raise ValueError
        except (MemoryError, KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            raise ValueError(self._safe_validation_message) from None
        if (
            _OUTCOME_ID_RE.fullmatch(self.outcome_id) is None
            or self.outcome_id in _RESERVED_FUNCTIONAL_OUTCOMES
            or self.contract_id != f"functional_contract_{expected}"
        ):
            raise ValueError(self._safe_validation_message)
        return self


_MATCHED_ROLE_REFERENCE = {
    ArmRole.LENGTH_MATCHED_PLACEBO: ArmRole.TARGET_PATCH,
    ArmRole.LENGTH_MATCHED_SHAM_EDIT: ArmRole.TARGET_REMOVE,
    ArmRole.TASK_LENGTH_PLACEBO: ArmRole.TASK_TARGET,
    ArmRole.PRESENTATION_MATCHED_CONTROL: ArmRole.PRESENTATION_TARGET,
}


def _validate_sorted_unique_feature_transitions(
    transitions: tuple[FeatureTransition, ...],
) -> None:
    feature_ids = tuple(item.feature_id for item in transitions)
    if feature_ids != tuple(sorted(feature_ids)) or len(feature_ids) != len(set(feature_ids)):
        raise ValueError("experiment contract failed validation")


class LengthMatchRecord(_ExperimentVersionedContract):
    schema_version: Literal["1.0"]
    length_match_id: str = Field(pattern=_LENGTH_MATCH_ID_PATTERN)
    arm_protocol_id: str = Field(pattern=_PROTOCOL_ID_PATTERN)
    protocol_instance_id: str = Field(pattern=_PROTOCOL_INSTANCE_ID_PATTERN)
    reference_arm_role: ArmRole
    matched_arm_role: ArmRole
    metric: Literal["canonical_changed_span_utf8_bytes_v1"]
    reference_delta_bytes: int = Field(ge=0, strict=True)
    matched_delta_bytes: int = Field(ge=0, strict=True)
    tolerance_bytes: int = Field(ge=4, strict=True)
    within_tolerance: Literal[True]

    @field_validator("reference_arm_role", "matched_arm_role", mode="before")
    @classmethod
    def parse_arm_role(cls, value: object) -> object:
        return _exact_enum(value, ArmRole)

    @classmethod
    def from_content(cls, **content: Any) -> Self:
        payload = {"schema_version": "1.0", **content}
        try:
            return cls(
                **payload,
                length_match_id=f"length_match_{_digest(payload)}",
            )
        except (MemoryError, KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            content.clear()
            payload.clear()
            _raise_contract_validation_error(cls)

    @model_validator(mode="after")
    def validate_semantics_and_digest(self) -> Self:
        expected_reference = _MATCHED_ROLE_REFERENCE.get(self.matched_arm_role)
        expected_tolerance = max(4, (self.reference_delta_bytes + 19) // 20)
        if (
            expected_reference is not self.reference_arm_role
            or self.tolerance_bytes != expected_tolerance
            or abs(self.reference_delta_bytes - self.matched_delta_bytes) > self.tolerance_bytes
            or self.length_match_id != f"length_match_{_digest(_content(self, 'length_match_id'))}"
        ):
            raise ValueError(self._safe_validation_message)
        return self


class GraphDeltaRecord(_ExperimentVersionedContract):
    schema_version: Literal["1.0"]
    delta_id: str = Field(pattern=_DELTA_ID_PATTERN)
    target_spec_id: str = Field(pattern=_TARGET_ID_PATTERN)
    target_instance_id: str = Field(pattern=_TARGET_INSTANCE_ID_PATTERN)
    arm_protocol_id: str = Field(pattern=_PROTOCOL_ID_PATTERN)
    protocol_instance_id: str = Field(pattern=_PROTOCOL_INSTANCE_ID_PATTERN)
    arm_role: ArmRole
    before_graph_sha256: str = Field(pattern=_SHA256_PATTERN)
    after_graph_sha256: str = Field(pattern=_SHA256_PATTERN)
    actual_transitions: tuple[FeatureTransition, ...]
    target_changed: bool | None
    semantic_compliance: bool | None
    permissible_non_target_drift: tuple[str, ...]
    length_match_id: str | None = Field(default=None, pattern=_LENGTH_MATCH_ID_PATTERN)

    @field_validator("arm_role", mode="before")
    @classmethod
    def parse_arm_role(cls, value: object) -> object:
        return _exact_enum(value, ArmRole)

    @classmethod
    def from_content(cls, **content: Any) -> Self:
        payload = {"schema_version": "1.0", **content}
        try:
            return cls(**payload, delta_id=f"delta_{_digest(payload)}")
        except (MemoryError, KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            content.clear()
            payload.clear()
            _raise_contract_validation_error(cls)

    @model_validator(mode="after")
    def validate_semantics_and_digest(self) -> Self:
        _validate_sorted_unique_feature_transitions(self.actual_transitions)
        matched = self.arm_role in _MATCHED_ROLE_REFERENCE
        if (
            self.permissible_non_target_drift != tuple(sorted(self.permissible_non_target_drift))
            or len(self.permissible_non_target_drift) != len(set(self.permissible_non_target_drift))
            or any(
                item not in {transition.feature_id for transition in self.actual_transitions}
                for item in self.permissible_non_target_drift
            )
            or matched != (self.length_match_id is not None)
            or self.delta_id != f"delta_{_digest(_content(self, 'delta_id'))}"
        ):
            raise ValueError(self._safe_validation_message)
        return self


class PromptVariantRecord(_ExperimentVersionedContract):
    schema_version: Literal["1.0"]
    variant_id: str = Field(pattern=_VARIANT_ID_PATTERN)
    task_id: str
    source_prompt_id: str
    language: str = Field(min_length=1, max_length=128)
    variant_prompt_id: str = Field(pattern=_VARIANT_PROMPT_ID_PATTERN)
    hypothesis_id: str = Field(pattern=_HYPOTHESIS_ID_PATTERN)
    target_spec_id: str = Field(pattern=_TARGET_ID_PATTERN)
    target_instance_id: str = Field(pattern=_TARGET_INSTANCE_ID_PATTERN)
    arm_protocol_id: str = Field(pattern=_PROTOCOL_ID_PATTERN)
    protocol_instance_id: str = Field(pattern=_PROTOCOL_INSTANCE_ID_PATTERN)
    arm_role: ArmRole
    prompt_sha256: str = Field(pattern=_SHA256_PATTERN)
    prompt_text: str = Field(min_length=1, max_length=262_144, repr=False)
    proposal_id: str = Field(pattern=_PROPOSAL_ID_PATTERN)
    graph_id: str
    delta_id: str = Field(pattern=_DELTA_ID_PATTERN)
    executor_policy_sha256: str = Field(pattern=_SHA256_PATTERN)
    extractor_policy_sha256: str = Field(pattern=_SHA256_PATTERN)
    length_match_id: str | None = Field(default=None, pattern=_LENGTH_MATCH_ID_PATTERN)

    @field_validator("arm_role", mode="before")
    @classmethod
    def parse_arm_role(cls, value: object) -> object:
        return _exact_enum(value, ArmRole)

    @classmethod
    def from_content(cls, **content: Any) -> Self:
        payload = {"schema_version": "1.0", **content}
        try:
            return cls(**payload, variant_id=f"variant_{_digest(payload)}")
        except (MemoryError, KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            content.clear()
            payload.clear()
            _raise_contract_validation_error(cls)

    @model_validator(mode="after")
    def validate_semantics_and_digest(self) -> Self:
        matched = self.arm_role in _MATCHED_ROLE_REFERENCE
        try:
            prompt_sha256 = hashlib.sha256(self.prompt_text.encode("utf-8")).hexdigest()
        except (MemoryError, KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            raise ValueError(self._safe_validation_message) from None
        if (
            not _valid_identifier(self.task_id)
            or not _valid_identifier(self.source_prompt_id)
            or not _valid_identifier(self.graph_id)
            or self.language != self.language.strip()
            or prompt_sha256 != self.prompt_sha256
            or matched != (self.length_match_id is not None)
            or self.variant_id != f"variant_{_digest(_content(self, 'variant_id'))}"
        ):
            raise ValueError(self._safe_validation_message)
        return self


class PreRandomizationExclusionRecord(_ExperimentVersionedContract):
    schema_version: Literal["1.0"]
    exclusion_id: str = Field(pattern=_EXCLUSION_ID_PATTERN)
    hypothesis_id: str = Field(pattern=_HYPOTHESIS_ID_PATTERN)
    target_spec_id: str = Field(pattern=_TARGET_ID_PATTERN)
    target_instance_id: str = Field(pattern=_TARGET_INSTANCE_ID_PATTERN)
    arm_protocol_id: str = Field(pattern=_PROTOCOL_ID_PATTERN)
    protocol_instance_id: str = Field(pattern=_PROTOCOL_INSTANCE_ID_PATTERN)
    task_id: str
    failed_arm_roles: tuple[ArmRole, ...]
    failure_codes: tuple[PreRandomizationFailureCode, ...]
    detail_sha256: str = Field(pattern=_SHA256_PATTERN)

    @field_validator("failed_arm_roles", mode="before")
    @classmethod
    def parse_arm_roles(cls, value: object) -> object:
        snapshot = _snapshot_json_arrays(value)
        if type(snapshot) is not tuple:
            return snapshot
        return tuple(_exact_enum(item, ArmRole) for item in snapshot)

    @field_validator("failure_codes", mode="before")
    @classmethod
    def parse_failure_codes(cls, value: object) -> object:
        snapshot = _snapshot_json_arrays(value)
        if type(snapshot) is not tuple:
            return snapshot
        return tuple(_exact_enum(item, PreRandomizationFailureCode) for item in snapshot)

    @classmethod
    def from_content(cls, **content: Any) -> Self:
        payload = {"schema_version": "1.0", **content}
        try:
            return cls(
                **payload,
                exclusion_id=f"pre_randomization_exclusion_{_digest(payload)}",
            )
        except (MemoryError, KeyboardInterrupt, SystemExit):
            raise
        except Exception:
            content.clear()
            payload.clear()
            _raise_contract_validation_error(cls)

    @model_validator(mode="after")
    def validate_semantics_and_digest(self) -> Self:
        if (
            not _valid_identifier(self.task_id)
            or not self.failed_arm_roles
            or not self.failure_codes
            or len(self.failed_arm_roles) != len(self.failure_codes)
            or len(self.failed_arm_roles) != len(set(self.failed_arm_roles))
            or self.exclusion_id
            != f"pre_randomization_exclusion_{_digest(_content(self, 'exclusion_id'))}"
        ):
            raise ValueError(self._safe_validation_message)
        return self


__all__ = [
    "AllowedDeltaRecord",
    "AssignmentRecord",
    "ArmRole",
    "ArmSpecRecord",
    "CONFIRMATION_CONTROL_ONLY_FEATURE_IDS",
    "CONFIRMATION_TARGET_FEATURE_IDS",
    "ConfirmationProtocolInstanceRecord",
    "ConfirmationProtocolRecord",
    "ExperimentalUnit",
    "FeatureTransition",
    "FunctionalOutcomeContractRecord",
    "GraphDeltaRecord",
    "InterventionExecutorKind",
    "InterventionMode",
    "LengthMatchRecord",
    "PreRandomizationExclusionRecord",
    "PreRandomizationFailureCode",
    "is_confirmation_target_feature",
    "PreRegisteredContrastSpec",
    "PromptRole",
    "PromptVariantRecord",
    "RandomizationManifestRecord",
    "TargetInstanceRecord",
    "TargetSpecRecord",
]
