"""Archival direct-graph extraction for frozen pre-contract artifacts only.

Not an active execution path. Use prompt_contract_extract for new annotations.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Callable, Mapping, Sequence
from pathlib import Path
from typing import Any

from prompt_mechanism_study.artifact_io import read_json, write_bundle
from prompt_mechanism_study.functional_judge import bailian_complete
from prompt_mechanism_study.prompt_tsg import (
    PromptTSG,
    PromptTSGError,
    build_prompt_tsg,
    catalog_sha256,
    load_catalog,
    prompt_tsg_record,
)
from prompt_mechanism_study.records import canonical_json, content_hash


Provider = Callable[[dict[str, Any], Mapping[str, Any], str], bytes]

_MODEL_FACT_KEYS = (
    "local_id",
    "semantic_id",
    "evidence_text",
    "occurrence",
    "attributes",
)
_PATH_AUTHORITY_PROTOCOL = "explicit_path_base_authority_v1"
_PATH_AUTHORITY_SEMANTICS = frozenset(
    {
        "constraint.trusted_path_base",
        "constraint.caller_supplied_path_base",
    }
)
_PATH_AUTHORITY_STATES = frozenset(
    {
        "application_configured",
        "caller_supplied",
        "unspecified",
        "no_bounding_base",
    }
)


class PromptTSGExtractionError(ValueError):
    """The frozen extraction request or the model's fact proposal is invalid."""

    def __init__(
        self,
        message: str,
        *,
        request: dict[str, Any] | None = None,
        raw: bytes | None = None,
    ) -> None:
        super().__init__(message)
        self.request = request
        self.raw = raw


def extraction_request(task: Mapping[str, Any], catalog: Mapping[str, Any]) -> dict[str, Any]:
    """Expose only the catalog slice relevant to frozen task-side coordinates."""

    required = {"task_id", "prompt", "cwe", "task_family"}
    if not required <= set(task) or any(
        not isinstance(task[field], str) or not task[field].strip() for field in required
    ):
        raise PromptTSGExtractionError("task lacks Prompt TSG extraction coordinates")
    queries = [
        query
        for query in catalog["queries"]
        if query["cwe_id"] == task["cwe"] and query["task_family"] == task["task_family"]
    ]
    if not queries:
        raise PromptTSGExtractionError("task has no catalog query")
    semantic_ids = {
        "task.requirement",
        "task.operation",
        "data.object",
        "control.generic_security",
        "control.code_style",
    }
    for query in queries:
        semantic_ids.update(query["required_semantics"])
        semantic_ids.update(query["forbidden_semantics"])
        semantic_ids.add(query["actionable_feature_id"])
    semantics = {
        semantic_id: {
            "node_type": catalog["semantics"][semantic_id],
            "guidance": catalog["semantic_guidance"].get(
                semantic_id, "Use only when directly supported by the source prompt."
            ),
        }
        for semantic_id in sorted(semantic_ids)
    }
    node_types = {value["node_type"] for value in semantics.values()}
    allowed_relations = [
        item
        for item in catalog["allowed_edges"]
        if item[0] in node_types and item[2] in node_types and item[1] != "contains"
    ]
    return {
        "schema_version": "2.0",
        "task_id": task["task_id"],
        "cwe_id": task["cwe"],
        "task_family": task["task_family"],
        "source_prompt": task["prompt"],
        "candidate_semantics": semantics,
        "allowed_attributes": list(catalog["attribute_names"]),
        "allowed_relation_type_matrix": allowed_relations,
        "context_queries": [
            {
                "query_id": query["query_id"],
                "required_semantics": query["required_semantics"],
                "forbidden_semantics": query["forbidden_semantics"],
                "required_relations": query["required_relations"],
                "actionable_feature_id": query["actionable_feature_id"],
            }
            for query in queries
        ],
        "arms_or_outcomes_included": False,
        "output_contract": {
            "top_level_keys": ["facts", "relations", "unresolved_semantics"],
            "fact_keys": list(_MODEL_FACT_KEYS),
            "local_id_type": "string",
            "relation_keys": ["edge_type", "source", "target"],
            "relation_endpoints": "string_local_ids",
        },
    }


def extract_prompt_tsg(
    task: Mapping[str, Any],
    *,
    catalog: Mapping[str, Any],
    evaluator: Mapping[str, Any],
    system_prompt: str,
    reviewer_evaluator: Mapping[str, Any] | None = None,
    reviewer_prompt: str | None = None,
    path_authority_annotation: Mapping[str, Any] | None = None,
    provider: Provider = bailian_complete,
) -> tuple[PromptTSG, dict[str, Any], bytes, dict[str, Any]]:
    """Propose evidence-bound facts, optionally review them blindly, then build one TSG."""

    if (reviewer_evaluator is None) != (reviewer_prompt is None):
        raise PromptTSGExtractionError(
            "semantic reviewer evaluator and prompt must be supplied together"
        )

    authority = (
        _validate_path_authority_annotation(task, path_authority_annotation)
        if path_authority_annotation is not None
        else None
    )
    request = extraction_request(task, catalog)
    raw = provider(request, evaluator, system_prompt)
    try:
        proposal = _proposal(raw)
        facts, rejected_facts, normalized_evidence_occurrences = _project_facts(
            proposal["facts"], request["source_prompt"], catalog
        )
        offered = set(request["candidate_semantics"])
        returned = {
            fact["semantic_id"] for fact in proposal["facts"]
        } | set(proposal["unresolved_semantics"])
        if not returned <= offered:
            raise PromptTSGExtractionError(
                "extractor returned a semantic outside its task slice"
            )
        relations, rejected_relations = _project_relations(
            facts, proposal["relations"], catalog
        )
        proposed_unresolved = proposal["unresolved_semantics"]
        authority_override: dict[str, Any] | None = None
        if authority is not None:
            (
                facts,
                relations,
                proposed_unresolved,
                authority_override,
            ) = _strip_model_path_authority(
                facts,
                relations,
                proposed_unresolved,
            )
        review_projection: dict[str, Any] | None = None
        extractor_id = evaluator["candidate_id"]
        if reviewer_evaluator is not None and reviewer_prompt is not None:
            ignored_before_review = [
                semantic_id
                for semantic_id in proposed_unresolved
                if catalog["semantics"].get(semantic_id)
                in {"safety_requirement", "presentation_control"}
            ]
            facts, relations, review_projection = _review_catalog_facts(
                task,
                facts=facts,
                relations=relations,
                proposed_unresolved=[
                    semantic_id
                    for semantic_id in proposed_unresolved
                    if semantic_id not in ignored_before_review
                ],
                catalog=catalog,
                evaluator=reviewer_evaluator,
                system_prompt=reviewer_prompt,
                provider=provider,
                excluded_semantics=(
                    _PATH_AUTHORITY_SEMANTICS if authority is not None else ()
                ),
            )
            rejected_facts.extend(review_projection["rejected_facts"])
            rejected_relations.extend(review_projection["rejected_relations"])
            extractor_id = (
                f"{evaluator['candidate_id']}+{reviewer_evaluator['candidate_id']}"
            )
            proposed_unresolved = [
                *review_projection["unresolved_semantics"],
                *ignored_before_review,
            ]
        else:
            proposed_unresolved = list(proposed_unresolved)
        ignored_unresolved_features = sorted(
            semantic_id
            for semantic_id in proposed_unresolved
            if catalog["semantics"].get(semantic_id)
            in {"safety_requirement", "presentation_control"}
        )
        unresolved_semantics = sorted(set(
            semantic_id
            for semantic_id in proposed_unresolved
            if semantic_id not in ignored_unresolved_features
        ))
        authority_projection: dict[str, Any] | None = None
        if authority is not None:
            facts, relations, unresolved_semantics, authority_projection = (
                _apply_path_authority(
                    task,
                    facts=facts,
                    relations=relations,
                    unresolved_semantics=unresolved_semantics,
                    annotation=authority,
                    catalog=catalog,
                    model_override=authority_override or {},
                )
            )
            extractor_id = f"{extractor_id}+{_PATH_AUTHORITY_PROTOCOL}"
        graph = build_prompt_tsg(
            task_id=task["task_id"],
            prompt=task["prompt"],
            extractor_id=extractor_id,
            catalog=catalog,
            facts=facts,
            relations=relations,
            unresolved_semantics=unresolved_semantics,
        )
    except PromptTSGExtractionError as error:
        if error.request is not None or error.raw is not None:
            raise
        raise PromptTSGExtractionError(str(error), request=request, raw=raw) from None
    except PromptTSGError as error:
        raise PromptTSGExtractionError(str(error), request=request, raw=raw) from None
    projection = {
        "rejected_facts": rejected_facts,
        "rejected_relations": rejected_relations,
        "ignored_unresolved_features": ignored_unresolved_features,
    }
    if normalized_evidence_occurrences:
        projection["normalized_evidence_occurrences"] = (
            normalized_evidence_occurrences
        )
    if review_projection is not None:
        projection["semantic_review"] = review_projection
    if authority_projection is not None:
        projection["path_authority"] = authority_projection
    return graph, request, raw, projection


def extract_task_file(
    tasks_path: Path,
    catalog_path: Path,
    evaluator_path: Path,
    prompt_path: Path,
    output: Path,
    *,
    start: int = 0,
    limit: int | None = None,
    task_selection_path: Path | None = None,
    reviewer_evaluator_path: Path | None = None,
    reviewer_prompt_path: Path | None = None,
    path_authority_annotations_path: Path | None = None,
    provider: Provider = bailian_complete,
) -> dict[str, Any]:
    """Extract a small frozen task file into one reviewable, content-addressed bundle."""

    if output.exists():
        raise FileExistsError(output)
    source_tasks = _json_lines(tasks_path)
    if type(start) is not int or start < 0:
        raise ValueError("start must be a non-negative integer")
    if limit is not None:
        if type(limit) is not int or limit <= 0:
            raise ValueError("limit must be a positive integer")
    selection_sha256 = None
    if task_selection_path is not None:
        if start != 0 or limit is not None:
            raise ValueError("task selection cannot be combined with start or limit")
        selection = read_json(task_selection_path)
        required = {
            "schema_version",
            "source_tasks_sha256",
            "selection_rule",
            "task_ids",
            "arms_or_outcomes_used",
        }
        if (
            not isinstance(selection, dict)
            or set(selection) != required
            or selection["schema_version"] != "1.0"
            or selection["source_tasks_sha256"]
            != hashlib.sha256(tasks_path.read_bytes()).hexdigest()
            or not isinstance(selection["selection_rule"], str)
            or not selection["selection_rule"].strip()
            or selection["arms_or_outcomes_used"] is not False
            or not isinstance(selection["task_ids"], list)
            or not selection["task_ids"]
            or any(
                not isinstance(task_id, str) or not task_id
                for task_id in selection["task_ids"]
            )
            or len(selection["task_ids"]) != len(set(selection["task_ids"]))
        ):
            raise PromptTSGExtractionError("task selection is invalid or stale")
        by_id = {task.get("task_id"): task for task in source_tasks}
        if len(by_id) != len(source_tasks) or not set(selection["task_ids"]) <= set(by_id):
            raise PromptTSGExtractionError("task selection is outside the source population")
        tasks = [by_id[task_id] for task_id in selection["task_ids"]]
        selection_sha256 = hashlib.sha256(task_selection_path.read_bytes()).hexdigest()
    else:
        tasks = source_tasks[start:] if limit is None else source_tasks[start : start + limit]
    if not tasks or len({task.get("task_id") for task in tasks}) != len(tasks):
        raise PromptTSGExtractionError("task extraction population is empty or duplicated")
    path_authority_annotations = (
        _load_path_authority_annotations(
            path_authority_annotations_path,
            tasks_path=tasks_path,
            tasks=tasks,
        )
        if path_authority_annotations_path is not None
        else {}
    )
    catalog = load_catalog(catalog_path)
    evaluator = _evaluator(read_json(evaluator_path))
    system_prompt = prompt_path.read_text(encoding="utf-8").strip()
    if not system_prompt:
        raise PromptTSGExtractionError("extractor prompt is empty")
    if (reviewer_evaluator_path is None) != (reviewer_prompt_path is None):
        raise PromptTSGExtractionError(
            "semantic reviewer evaluator and prompt paths must be supplied together"
        )
    reviewer_evaluator = (
        _evaluator(read_json(reviewer_evaluator_path))
        if reviewer_evaluator_path is not None
        else None
    )
    reviewer_prompt = (
        reviewer_prompt_path.read_text(encoding="utf-8").strip()
        if reviewer_prompt_path is not None
        else None
    )
    if reviewer_prompt_path is not None and not reviewer_prompt:
        raise PromptTSGExtractionError("semantic reviewer prompt is empty")
    graphs = []
    requests = []
    responses = []
    failed: tuple[dict[str, Any], PromptTSGExtractionError] | None = None
    for task in tasks:
        try:
            graph, request, raw, projection = extract_prompt_tsg(
                task,
                catalog=catalog,
                evaluator=evaluator,
                system_prompt=system_prompt,
                reviewer_evaluator=reviewer_evaluator,
                reviewer_prompt=reviewer_prompt,
                path_authority_annotation=path_authority_annotations.get(
                    task["task_id"]
                ),
                provider=provider,
            )
        except PromptTSGExtractionError as error:
            failed = (task, error)
            if error.request is not None:
                requests.append(error.request)
            if error.raw is not None:
                responses.append(
                    {
                        "task_id": task["task_id"],
                        "response_sha256": hashlib.sha256(error.raw).hexdigest(),
                        "response_text": error.raw.decode("utf-8", errors="replace"),
                    }
                )
            break
        graphs.append(prompt_tsg_record(graph))
        stored_projection = dict(projection)
        review = stored_projection.pop("semantic_review", None)
        request_record = {**request, "deterministic_projection": stored_projection}
        response_record = {
            "task_id": task["task_id"],
            "response_sha256": hashlib.sha256(raw).hexdigest(),
            "response_text": raw.decode("utf-8", errors="strict"),
        }
        if review is not None:
            request_record["semantic_review_request"] = review["request"]
            request_record["semantic_review_projection"] = {
                key: value
                for key, value in review.items()
                if key not in {"request", "response_text"}
            }
            response_record["semantic_review_response_sha256"] = review[
                "response_sha256"
            ]
            response_record["semantic_review_response_text"] = review[
                "response_text"
            ]
        requests.append(request_record)
        responses.append(response_record)
    report = {
        "schema_version": "1.0",
        "status": (
            "PROMPT_TSG_EXTRACTION_COMPLETE"
            if failed is None
            else "PROMPT_TSG_EXTRACTION_ERROR"
        ),
        "tasks": len(tasks),
        "source_tasks": len(source_tasks),
        "selection_start": start,
        "task_selection_sha256": selection_sha256,
        "graphs": len(graphs),
        "unresolved_tasks": sum(bool(graph["unresolved_semantics"]) for graph in graphs),
        "task_file_sha256": hashlib.sha256(tasks_path.read_bytes()).hexdigest(),
        "selected_task_ids_sha256": content_hash([task["task_id"] for task in tasks]),
        "catalog_sha256": catalog_sha256(catalog),
        "evaluator_sha256": hashlib.sha256(evaluator_path.read_bytes()).hexdigest(),
        "prompt_sha256": hashlib.sha256(prompt_path.read_bytes()).hexdigest(),
        "semantic_reviewer_evaluator_sha256": (
            hashlib.sha256(reviewer_evaluator_path.read_bytes()).hexdigest()
            if reviewer_evaluator_path is not None
            else None
        ),
        "semantic_reviewer_prompt_sha256": (
            hashlib.sha256(reviewer_prompt_path.read_bytes()).hexdigest()
            if reviewer_prompt_path is not None
            else None
        ),
        "semantic_reviewed_tasks": len(graphs) if reviewer_evaluator is not None else 0,
        "semantic_reviewer_provider_calls": sum(
            request.get("semantic_review_projection", {}).get("provider_called") is True
            for request in requests
        ),
        "path_authority_annotation_sha256": (
            hashlib.sha256(path_authority_annotations_path.read_bytes()).hexdigest()
            if path_authority_annotations_path is not None
            else None
        ),
        "path_authority_protocol_id": (
            _PATH_AUTHORITY_PROTOCOL if path_authority_annotations else None
        ),
        "path_authority_annotated_tasks": len(path_authority_annotations),
        "path_authority_state_counts": {
            state: sum(
                annotation["authority_state"] == state
                for annotation in path_authority_annotations.values()
            )
            for state in sorted(_PATH_AUTHORITY_STATES)
            if any(
                annotation["authority_state"] == state
                for annotation in path_authority_annotations.values()
            )
        },
        "extractor_implementation_sha256": hashlib.sha256(
            Path(__file__).read_bytes()
        ).hexdigest(),
        "provider_adapter_sha256": hashlib.sha256(
            Path(provider.__code__.co_filename).read_bytes()
        ).hexdigest(),
        "arms_or_outcomes_used": False,
    }
    if failed is not None:
        report["failed_task_id"] = failed[0]["task_id"]
        report["error_type"] = type(failed[1]).__name__
        report["error_reason"] = str(failed[1])
    write_bundle(
        output,
        {
            "report.json": report,
            "graphs.json": graphs,
            "requests.json": requests,
            "responses.json": responses,
        },
    )
    return report


def _load_path_authority_annotations(
    path: Path,
    *,
    tasks_path: Path,
    tasks: Sequence[Mapping[str, Any]],
) -> dict[str, dict[str, Any]]:
    """Load one outcome-blind task-side authority annotation bundle."""

    value = read_json(path)
    required = {
        "schema_version",
        "annotation_protocol_id",
        "source_tasks_sha256",
        "review_completed_before_extraction",
        "arms_or_outcomes_used",
        "annotations",
    }
    if (
        not isinstance(value, dict)
        or set(value) != required
        or value["schema_version"] != "1.0"
        or value["annotation_protocol_id"] != _PATH_AUTHORITY_PROTOCOL
        or value["source_tasks_sha256"]
        != hashlib.sha256(tasks_path.read_bytes()).hexdigest()
        or value["review_completed_before_extraction"] is not True
        or value["arms_or_outcomes_used"] is not False
        or not isinstance(value["annotations"], list)
    ):
        raise PromptTSGExtractionError("path-authority annotation bundle is invalid or stale")
    expected = {
        task.get("task_id")
        for task in tasks
        if task.get("cwe") == "CWE-22" and task.get("task_family") == "path_access"
    }
    if not expected:
        raise PromptTSGExtractionError(
            "path-authority annotations require at least one selected path-access task"
        )
    annotations: dict[str, dict[str, Any]] = {}
    raw_fields = {
        "task_id",
        "prompt_sha256",
        "authority_state",
        "evidence_text",
        "occurrence",
        "rationale",
    }
    tasks_by_id = {task.get("task_id"): task for task in tasks}
    for raw in value["annotations"]:
        if not isinstance(raw, dict) or set(raw) != raw_fields:
            raise PromptTSGExtractionError("path-authority annotation fields are invalid")
        task_id = raw.get("task_id")
        if task_id in annotations or task_id not in expected:
            raise PromptTSGExtractionError(
                "path-authority annotation population is duplicated or out of scope"
            )
        annotations[task_id] = _validate_path_authority_annotation(
            tasks_by_id[task_id],
            {"annotation_protocol_id": _PATH_AUTHORITY_PROTOCOL, **raw},
        )
    if set(annotations) != expected:
        raise PromptTSGExtractionError(
            "path-authority annotations do not cover the selected path-access tasks"
        )
    return annotations


def _validate_path_authority_annotation(
    task: Mapping[str, Any], value: Mapping[str, Any]
) -> dict[str, Any]:
    fields = {
        "annotation_protocol_id",
        "task_id",
        "prompt_sha256",
        "authority_state",
        "evidence_text",
        "occurrence",
        "rationale",
    }
    if (
        not isinstance(value, Mapping)
        or set(value) != fields
        or value["annotation_protocol_id"] != _PATH_AUTHORITY_PROTOCOL
        or task.get("cwe") != "CWE-22"
        or task.get("task_family") != "path_access"
        or value["task_id"] != task.get("task_id")
        or value["prompt_sha256"] != content_hash(task.get("prompt"))
        or value["authority_state"] not in _PATH_AUTHORITY_STATES
        or not isinstance(value["rationale"], str)
        or not value["rationale"].strip()
        or value["rationale"] != value["rationale"].strip()
    ):
        raise PromptTSGExtractionError("path-authority annotation is invalid or stale")
    evidence = value["evidence_text"]
    occurrence = value["occurrence"]
    state = value["authority_state"]
    if state == "no_bounding_base":
        if evidence is not None or occurrence is not None:
            raise PromptTSGExtractionError(
                "no-bounding-base annotation cannot cite base evidence"
            )
    elif (
        not isinstance(evidence, str)
        or not evidence
        or len(evidence.encode("utf-8")) > 2048
        or type(occurrence) is not int
        or occurrence <= 0
        or not _has_occurrence(task["prompt"], evidence, occurrence)
    ):
        raise PromptTSGExtractionError(
            "path-authority annotation evidence is not an exact prompt occurrence"
        )
    return dict(value)


def _has_occurrence(prompt: str, evidence: str, occurrence: int) -> bool:
    offset = -1
    for _ in range(occurrence):
        offset = prompt.find(evidence, offset + 1)
        if offset < 0:
            return False
    return True


def _strip_model_path_authority(
    facts: Sequence[Mapping[str, Any]],
    relations: Sequence[Mapping[str, Any]],
    unresolved_semantics: Sequence[str],
) -> tuple[
    list[Mapping[str, Any]],
    list[Mapping[str, Any]],
    list[str],
    dict[str, Any],
]:
    """Remove model opinions for the independently annotated authority coordinate."""

    if isinstance(unresolved_semantics, (str, bytes)) or any(
        not isinstance(semantic_id, str) for semantic_id in unresolved_semantics
    ):
        raise PromptTSGExtractionError("extractor unresolved semantics are invalid")

    removed_facts = [
        fact for fact in facts if fact["semantic_id"] in _PATH_AUTHORITY_SEMANTICS
    ]
    removed_ids = {fact["local_id"] for fact in removed_facts}
    removed_relations = [
        relation
        for relation in relations
        if relation["source"] in removed_ids or relation["target"] in removed_ids
    ]
    removed_unresolved = [
        semantic_id
        for semantic_id in unresolved_semantics
        if semantic_id in _PATH_AUTHORITY_SEMANTICS
    ]
    return (
        [fact for fact in facts if fact["local_id"] not in removed_ids],
        [relation for relation in relations if relation not in removed_relations],
        [
            semantic_id
            for semantic_id in unresolved_semantics
            if semantic_id not in _PATH_AUTHORITY_SEMANTICS
        ],
        {
            "model_facts_removed": [
                {"local_id": fact["local_id"], "semantic_id": fact["semantic_id"]}
                for fact in removed_facts
            ],
            "model_relations_removed": removed_relations,
            "model_unresolved_removed": sorted(set(removed_unresolved)),
        },
    )


def _apply_path_authority(
    task: Mapping[str, Any],
    *,
    facts: Sequence[Mapping[str, Any]],
    relations: Sequence[Mapping[str, Any]],
    unresolved_semantics: Sequence[str],
    annotation: Mapping[str, Any],
    catalog: Mapping[str, Any],
    model_override: Mapping[str, Any],
) -> tuple[
    list[Mapping[str, Any]],
    list[Mapping[str, Any]],
    list[str],
    dict[str, Any],
]:
    """Project a frozen four-state authority annotation into one Prompt TSG."""

    kept_facts, kept_relations, kept_unresolved, late_override = (
        _strip_model_path_authority(facts, relations, unresolved_semantics)
    )
    local_ids = {fact["local_id"] for fact in kept_facts}
    local_id = "path_authority"
    while local_id in local_ids:
        local_id = "_" + local_id
    state = annotation["authority_state"]
    injected_semantic = None
    projection_status = "applied"
    if state in {"application_configured", "caller_supplied"}:
        injected_semantic = (
            "constraint.trusted_path_base"
            if state == "application_configured"
            else "constraint.caller_supplied_path_base"
        )
        fact = {
            "local_id": local_id,
            "semantic_id": injected_semantic,
            "evidence_text": annotation["evidence_text"],
            "occurrence": annotation["occurrence"],
            "attributes": (
                {"fixed": True, "caller_controlled": False}
                if state == "application_configured"
                else {"fixed": False, "caller_controlled": True}
            ),
        }
        projected, _, _ = _project_facts([fact], task["prompt"], catalog)
        kept_facts.extend(projected)
        if state == "application_configured":
            sinks = [
                item
                for item in kept_facts
                if item["semantic_id"] == "sink.file_access"
            ]
            if len(sinks) == 1:
                kept_relations.append(
                    {
                        "edge_type": "qualifies",
                        "source": local_id,
                        "target": sinks[0]["local_id"],
                    }
                )
            else:
                kept_facts.pop()
                injected_semantic = None
                kept_unresolved.append("constraint.trusted_path_base")
                projection_status = "unresolved_file_sink_binding"
    elif state == "unspecified":
        kept_unresolved.extend(sorted(_PATH_AUTHORITY_SEMANTICS))

    projection = {
        "annotation_protocol_id": annotation["annotation_protocol_id"],
        "annotation_sha256": content_hash(annotation),
        "authority_state": state,
        "evidence_text": annotation["evidence_text"],
        "occurrence": annotation["occurrence"],
        "projection_status": projection_status,
        "injected_semantic": injected_semantic,
        "file_access_sink_count": sum(
            fact["semantic_id"] == "sink.file_access" for fact in kept_facts
        ),
        **model_override,
    }
    if any(late_override.values()):
        projection["late_model_override"] = late_override
    return (
        list(kept_facts),
        list(kept_relations),
        sorted(set(kept_unresolved)),
        projection,
    )


def _review_catalog_facts(
    task: Mapping[str, Any],
    *,
    facts: Sequence[Mapping[str, Any]],
    relations: Sequence[Mapping[str, Any]],
    proposed_unresolved: Sequence[str],
    catalog: Mapping[str, Any],
    evaluator: Mapping[str, Any],
    system_prompt: str,
    provider: Provider,
    excluded_semantics: Sequence[str] = (),
) -> tuple[list[Mapping[str, Any]], list[Mapping[str, Any]], dict[str, Any]]:
    """Independently annotate the complete catalog slice for this task family."""

    if not system_prompt:
        raise PromptTSGExtractionError("semantic reviewer prompt is empty")
    descriptive = {"task.requirement", "task.operation", "data.object"}
    descriptions = [fact for fact in facts if fact["semantic_id"] in descriptive]
    proposed = [fact for fact in facts if fact["semantic_id"] not in descriptive]
    proposed_semantics = {fact["semantic_id"] for fact in proposed}
    if (
        isinstance(proposed_unresolved, (str, bytes))
        or any(
            not isinstance(item, str)
            or item not in catalog["semantics"]
            or item in proposed_semantics
            for item in proposed_unresolved
        )
        or len(proposed_unresolved) != len(set(proposed_unresolved))
    ):
        raise PromptTSGExtractionError("proposer unresolved semantics are invalid")
    task_slice = set(extraction_request(task, catalog)["candidate_semantics"])
    candidate_semantics = task_slice - descriptive - set(excluded_semantics)
    required_relations = {
        tuple(relation)
        for query in catalog["queries"]
        if query["cwe_id"] == task["cwe"]
        and query["task_family"] == task["task_family"]
        for relation in query["required_relations"]
        if relation[0] in candidate_semantics and relation[2] in candidate_semantics
    }
    request = {
        "schema_version": "2.0",
        "request_kind": "prompt_tsg_bounded_ambiguity_adjudication",
        "task_id": task["task_id"],
        "source_prompt": task["prompt"],
        "candidate_semantics": {
            semantic_id: {
                "node_type": catalog["semantics"][semantic_id],
                "guidance": catalog["semantic_guidance"].get(
                    semantic_id,
                    "Accept only when the source prompt directly entails this role.",
                ),
                "proposer_status": (
                    "asserted"
                    if semantic_id in proposed_semantics
                    else "unresolved"
                    if semantic_id in proposed_unresolved
                    else "omitted"
                ),
                "proposed_evidence": [
                    fact["evidence_text"]
                    for fact in proposed
                    if fact["semantic_id"] == semantic_id
                ],
            }
            for semantic_id in sorted(candidate_semantics)
        },
        "allowed_relations": [list(item) for item in sorted(required_relations)],
        "evidence_binding_policy": {
            "asserted_candidate": "reuse validated proposer evidence and occurrence",
            "proposer_unresolved_candidate": "require new exact prompt evidence",
            "proposer_omitted_candidate": "require new exact prompt evidence",
        },
        "arms_or_outcomes_included": False,
        "output_contract": {
            "top_level_keys": ["facts", "relations", "unresolved_semantics"],
            "fact_keys": list(_MODEL_FACT_KEYS),
            "relation_keys": ["edge_type", "source", "target"],
            "semantic_scope": "candidate_semantics only",
        },
    }
    if not candidate_semantics:
        raw = canonical_json(
            {"facts": [], "relations": [], "unresolved_semantics": []}
        ).encode("utf-8")
        return descriptions, [], {
            "request": request,
            "response_sha256": hashlib.sha256(raw).hexdigest(),
            "response_text": raw.decode("utf-8"),
            "provider_called": False,
            "accepted_semantics": [],
            "unresolved_semantics": [],
            "unsupported_proposer_ambiguities": [],
            "rejected_facts": [],
            "rejected_relations": [
                {**relation, "reason": "empty_catalog_candidate_scope"}
                for relation in relations
            ],
        }
    raw = provider(request, evaluator, system_prompt)
    if not isinstance(raw, bytes):
        raise PromptTSGExtractionError(
            "semantic reviewer response is not bytes", request=request
        )
    try:
        review = _proposal(raw)
        unresolved = review["unresolved_semantics"]
        if (
            any(not isinstance(item, str) or not item for item in unresolved)
            or len(unresolved) != len(set(unresolved))
        ):
            raise PromptTSGExtractionError("semantic reviewer ambiguity is invalid")
        stable_review_facts, reused_proposer_evidence = _reuse_proposer_evidence(
            review["facts"], proposed
        )
        (
            reviewed_facts,
            rejected_review_facts,
            normalized_review_occurrences,
        ) = _project_facts(
            stable_review_facts,
            task["prompt"],
            catalog,
        )
        returned_semantics = {
            fact["semantic_id"] for fact in reviewed_facts
        } | set(unresolved)
        if (
            not returned_semantics <= candidate_semantics
            or {fact["semantic_id"] for fact in reviewed_facts} & set(unresolved)
        ):
            raise PromptTSGExtractionError(
                "semantic reviewer widened or contradicted its candidate scope"
            )
        reviewed_relations, rejected_review_relations = _project_relations(
            reviewed_facts, review["relations"], catalog
        )
        semantic_by_local_id = {
            fact["local_id"]: fact["semantic_id"] for fact in reviewed_facts
        }
        query_relations = []
        for relation in reviewed_relations:
            semantic_triple = (
                semantic_by_local_id[relation["source"]],
                relation["edge_type"],
                semantic_by_local_id[relation["target"]],
            )
            if semantic_triple in required_relations:
                query_relations.append(relation)
            else:
                rejected_review_relations.append(
                    {**relation, "reason": "non_query_relation"}
                )
        reviewed_relations = query_relations
    except PromptTSGExtractionError as error:
        raise PromptTSGExtractionError(str(error), request=request, raw=raw) from None

    used_ids = {fact["local_id"] for fact in descriptions}
    local_id_map = {}
    normalized_facts = []
    for index, fact in enumerate(reviewed_facts, start=1):
        local_id = f"adjudicated_{index}"
        while local_id in used_ids:
            local_id = "_" + local_id
        used_ids.add(local_id)
        local_id_map[fact["local_id"]] = local_id
        normalized_facts.append({**fact, "local_id": local_id})
    normalized_relations = [
        {
            "edge_type": relation["edge_type"],
            "source": local_id_map[relation["source"]],
            "target": local_id_map[relation["target"]],
        }
        for relation in reviewed_relations
    ]
    accepted_semantics = {fact["semantic_id"] for fact in normalized_facts}
    rejected_facts = [
        {
            "local_id": fact["local_id"],
            "semantic_id": fact["semantic_id"],
            "reason": (
                "semantic_reviewer_unresolved"
                if fact["semantic_id"] in unresolved
                else "semantic_reviewer_rejected"
            ),
        }
        for fact in proposed
        if fact["semantic_id"] not in accepted_semantics
    ]
    proposed_semantic_by_id = {
        fact["local_id"]: fact["semantic_id"] for fact in proposed
    }
    accepted_relation_semantics = {
        (
            semantic_by_local_id[relation["source"]],
            relation["edge_type"],
            semantic_by_local_id[relation["target"]],
        )
        for relation in reviewed_relations
    }
    rejected_relations = [
        {**relation, "reason": "semantic_reviewer_rejected"}
        for relation in relations
        if (
            proposed_semantic_by_id.get(relation["source"]),
            relation["edge_type"],
            proposed_semantic_by_id.get(relation["target"]),
        )
        not in accepted_relation_semantics
    ]
    projection = {
        "request": request,
        "response_sha256": hashlib.sha256(raw).hexdigest(),
        "response_text": raw.decode("utf-8", errors="strict"),
        "provider_called": True,
        "accepted_semantics": sorted(accepted_semantics),
        "reviewer_recovered_semantics": sorted(
            accepted_semantics - proposed_semantics
        ),
        "unresolved_semantics": sorted(unresolved),
        "unsupported_proposer_ambiguities": sorted(
            set(proposed_unresolved) - accepted_semantics - set(unresolved)
        ),
        "rejected_facts": rejected_facts + rejected_review_facts,
        "rejected_relations": rejected_relations + rejected_review_relations,
    }
    if normalized_review_occurrences:
        projection["normalized_evidence_occurrences"] = (
            normalized_review_occurrences
        )
    if reused_proposer_evidence:
        projection["reused_proposer_evidence"] = reused_proposer_evidence
    return descriptions + normalized_facts, normalized_relations, projection


def _reuse_proposer_evidence(
    reviewed_facts: Sequence[Mapping[str, Any]],
    proposed_facts: Sequence[Mapping[str, Any]],
) -> tuple[list[Mapping[str, Any]], list[dict[str, Any]]]:
    """Keep evidence binding in stage one when stage two accepts its semantic role."""

    by_semantic: dict[str, list[Mapping[str, Any]]] = {}
    for fact in proposed_facts:
        by_semantic.setdefault(fact["semantic_id"], []).append(fact)
    normalized = []
    reused = []
    for fact in reviewed_facts:
        if not isinstance(fact, Mapping):
            normalized.append(fact)
            continue
        candidates = by_semantic.get(fact.get("semantic_id"), [])
        exact_text = [
            candidate
            for candidate in candidates
            if candidate["evidence_text"] == fact.get("evidence_text")
        ]
        source = (
            exact_text[0]
            if len(exact_text) == 1
            else candidates[0]
            if len(candidates) == 1
            else None
        )
        if source is None:
            normalized.append(fact)
            continue
        stable = {
            **fact,
            "evidence_text": source["evidence_text"],
            "occurrence": source["occurrence"],
        }
        normalized.append(stable)
        if (
            fact.get("evidence_text") != source["evidence_text"]
            or fact.get("occurrence") != source["occurrence"]
        ):
            reused.append(
                {
                    "local_id": fact.get("local_id"),
                    "semantic_id": fact.get("semantic_id"),
                    "reviewed_evidence_text": fact.get("evidence_text"),
                    "reviewed_occurrence": fact.get("occurrence"),
                    "proposer_evidence_text": source["evidence_text"],
                    "proposer_occurrence": source["occurrence"],
                }
            )
    return normalized, reused


def _proposal(raw: bytes) -> dict[str, Any]:
    try:
        value = json.loads(raw)
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise PromptTSGExtractionError("extractor response is not JSON") from None
    if not isinstance(value, dict) or set(value) != {
        "facts",
        "relations",
        "unresolved_semantics",
    }:
        raise PromptTSGExtractionError("extractor response fields are invalid")
    if any(not isinstance(value[field], list) for field in value):
        raise PromptTSGExtractionError("extractor response collections are invalid")
    return value


def _project_facts(
    facts: Sequence[Mapping[str, Any]],
    prompt: str,
    catalog: Mapping[str, Any],
) -> tuple[
    list[Mapping[str, Any]],
    list[dict[str, Any]],
    list[dict[str, Any]],
]:
    """Drop only invalid local-description facts; never repair security facts.

    The three evidence-bound local semantics below are descriptive annotations
    and never participate in a context query or actionable-feature state.  A
    model-proposed annotation whose quoted span is not literally present can
    therefore be rejected without changing any scientific variable.  All
    other facts remain fail-closed so this projection cannot manufacture or
    erase support for an intervention candidate.
    """

    descriptive = {"task.requirement", "task.operation", "data.object"}
    accepted = []
    rejected = []
    normalized_occurrences = []
    seen_local_ids: set[str] = set()
    for fact in facts:
        if not isinstance(fact, Mapping) or set(fact) != set(_MODEL_FACT_KEYS):
            raise PromptTSGExtractionError("extractor fact fields are invalid")
        local_id = fact.get("local_id")
        semantic_id = fact.get("semantic_id")
        node_type = (
            catalog["semantics"].get(semantic_id)
            if isinstance(semantic_id, str)
            else None
        )
        evidence = fact.get("evidence_text")
        occurrence = fact.get("occurrence")
        attributes = fact.get("attributes")
        if (
            not isinstance(local_id, str)
            or not local_id.strip()
            or local_id in seen_local_ids
            or not isinstance(semantic_id, str)
            or not semantic_id.strip()
            or not isinstance(node_type, str)
            or semantic_id == "task.root"
            or not isinstance(evidence, str)
            or not evidence
            or len(evidence.encode("utf-8")) > 2048
            or type(occurrence) is not int
            or occurrence <= 0
            or not isinstance(attributes, Mapping)
            or any(
                key not in catalog["attribute_names"] or type(value) is not bool
                for key, value in attributes.items()
            )
        ):
            raise PromptTSGExtractionError("extractor fact value is invalid")
        seen_local_ids.add(local_id)
        catalog_typed_fact = {**fact, "node_type": node_type}
        offset = -1
        for _ in range(occurrence):
            offset = prompt.find(evidence, offset + 1)
            if offset < 0:
                break
        if offset >= 0:
            accepted.append(catalog_typed_fact)
            continue
        first_offset = prompt.find(evidence)
        if first_offset >= 0 and prompt.find(evidence, first_offset + 1) < 0:
            accepted.append({**catalog_typed_fact, "occurrence": 1})
            normalized_occurrences.append(
                {
                    "local_id": local_id,
                    "semantic_id": semantic_id,
                    "provided_occurrence": occurrence,
                    "normalized_occurrence": 1,
                    "reason": "unique_exact_evidence_span",
                }
            )
            continue
        if semantic_id not in descriptive:
            raise PromptTSGExtractionError(
                "catalog-bound Prompt TSG evidence does not exactly match the prompt"
            )
        rejected.append(
            {
                "local_id": local_id,
                "semantic_id": semantic_id,
                "reason": "noncontiguous_or_nonverbatim_descriptive_evidence",
            }
        )
    return accepted, rejected, normalized_occurrences


def _project_relations(
    facts: Sequence[Mapping[str, Any]],
    relations: Sequence[Mapping[str, Any]],
    catalog: Mapping[str, Any],
) -> tuple[list[Mapping[str, Any]], list[dict[str, Any]]]:
    """Drop and disclose only well-formed edges that violate the frozen type matrix."""

    node_types = {}
    for fact in facts:
        if not isinstance(fact, Mapping) or not isinstance(fact.get("local_id"), str):
            raise PromptTSGExtractionError("extractor fact identity is invalid")
        node_types[fact["local_id"]] = fact.get("node_type")
    allowed = {tuple(item) for item in catalog["allowed_edges"]}
    accepted = []
    rejected = []
    for relation in relations:
        if not isinstance(relation, Mapping) or set(relation) != {
            "edge_type",
            "source",
            "target",
        }:
            raise PromptTSGExtractionError("extractor relation fields are invalid")
        triple = (
            node_types.get(relation["source"]),
            relation["edge_type"],
            node_types.get(relation["target"]),
        )
        if triple in allowed:
            accepted.append(relation)
        else:
            rejected.append({**relation, "reason": "edge_type_matrix_violation"})
    return accepted, rejected


def _evaluator(value: Any) -> dict[str, Any]:
    fields = {
        "schema_version",
        "candidate_id",
        "provider",
        "model_id",
        "base_url",
        "api_key_env",
        "temperature",
        "top_p",
        "seed",
        "enable_thinking",
        "timeout_seconds",
        "max_response_bytes",
        "max_attempts",
    }
    if (
        not isinstance(value, dict)
        or set(value) != fields
        or value["schema_version"] != "1.0"
        or value["max_attempts"] != 1
        or value["api_key_env"] != "ALI_BAILIAN_API_KEY"
        or value["temperature"] != 0.0
    ):
        raise PromptTSGExtractionError("extractor evaluator is invalid")
    return value


def _json_lines(path: Path) -> list[dict[str, Any]]:
    try:
        if path.suffix == ".jsonl":
            rows = [
                json.loads(line)
                for line in path.read_text(encoding="utf-8").splitlines()
                if line.strip()
            ]
        else:
            rows = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        raise PromptTSGExtractionError("task file is unreadable") from None
    if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
        raise PromptTSGExtractionError("task file must contain a list of objects")
    return rows


__all__ = [
    "PromptTSGExtractionError",
    "extract_prompt_tsg",
    "extract_task_file",
    "extraction_request",
]
