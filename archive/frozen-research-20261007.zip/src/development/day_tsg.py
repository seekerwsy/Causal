"""Bounded author-prepared Prompt TSG information and policy-selection ablation.

Graph/Flat carry the same facts; only information availability changes the
selector. This cannot establish automatic extraction or an inherent graph gain.
"""
from __future__ import annotations

import json
import hashlib
import sys
from collections import defaultdict
from pathlib import Path


ARMS = ("N", "P", "H")
MIN_MATCHED_TASKS = 2
MIN_GAIN = .05


def graph_and_flat(task):
    semantic = task['semantic']
    nodes = [dict(id='operation', kind='operation', value=semantic['operation']),
             dict(id='contract', kind='non_target', value=semantic['non_target_contract']),
             dict(id='evidence', kind='source_evidence', value=semantic['source_evidence'])]
    edges = [dict(source='operation', relation='preserves', target='contract'),
             dict(source='operation', relation='supported_by', target='evidence')]
    for i, role in enumerate(semantic['target_roles']):
        identifier=f'role{i}'
        nodes.append(dict(id=identifier, kind='target_role', value=role))
        edges.append(dict(source='operation', relation='acts_on', target=identifier))
    for i, condition in enumerate(semantic['conditions']):
        identifier=f'condition{i}'
        nodes.append(dict(id=identifier, kind='condition', value=condition))
        edges.append(dict(source='operation', relation='when', target=identifier))
    for field in ('family','target_count','lifecycle'):
        nodes.append(dict(id=field, kind='attribute', value=semantic[field]))
        edges.append(dict(source='operation', relation='has_attribute', target=field))
    graph = dict(nodes=nodes, edges=edges)
    flat = dict(node_records=[(n['id'],n['kind'],n['value']) for n in nodes],
                relation_records=[(e['source'],e['relation'],e['target']) for e in edges])
    restored = dict(nodes=[dict(id=i,kind=k,value=v) for i,k,v in flat['node_records']],
                    edges=[dict(source=s,relation=r,target=t) for s,r,t in flat['relation_records']])
    assert graph == restored
    return graph, flat


def feature(task, information):
    attrs=task['cross_task_attributes']
    if information=='full_semantics':
        return (attrs['policy_family'],attrs['conditional'],attrs['multiple_targets'],attrs['lifecycle'])
    if information=='relation_removed':
        return (attrs['policy_family'],attrs['lifecycle'])
    if information=='surface_metadata':
        return ('natural' if task['origin'].startswith('exposed_natural') else 'synthetic',)
    raise ValueError(information)


def select(task, training, yields, information):
    key=feature(task,information)
    matched=[other for other in training if feature(other,information)==key]
    if len(matched)<MIN_MATCHED_TASKS:
        return dict(action='N',support=len(matched),reason='unsupported_attribute_cell')
    mean={arm:sum(yields[other['id']][arm] for other in matched)/len(matched) for arm in ARMS}
    candidate=max(ARMS, key=lambda arm:(mean[arm],-ARMS.index(arm)))
    action=candidate if candidate!='N' and mean[candidate]-mean['N']>MIN_GAIN else 'N'
    return dict(action=action,support=len(matched),reason='trained_policy',training_means=mean)


def run(panel: Path, generation: Path, out: Path):
    tasks=json.loads((panel/'tasks.json').read_text(encoding='utf-8'))
    assignments=json.loads((panel/'assignments.json').read_text(encoding='utf-8'))
    outcomes=json.loads((generation/'summary/results.json').read_text(encoding='utf-8'))
    assert len(outcomes)==len(assignments)==96
    by_slot={row['slot']:row for row in outcomes}
    yields=defaultdict(lambda:defaultdict(list))
    for slot in assignments:
        row=by_slot[slot['slot']]
        if row['status']!='returned':
            raise RuntimeError('missing assigned outcome blocks selector evaluation')
        measurement=row['measurement']
        if measurement.get('status')!='measured':
            raise RuntimeError('measurement infrastructure failed')
        if 'file_lifecycle' in next(t for t in tasks if t['id']==slot['task_unit_id'])['measurement']:
            label=measurement['security_label']
            valid=measurement['code_valid']
        else:
            label=measurement['task_bound_witness_label']
            valid=measurement['code_valid']
        yields[slot['task_unit_id']][slot['arm']].append(int(valid and label=='secure'))
    mean={key:{arm:sum(values)/len(values) for arm,values in arm_rows.items()}
          for key,arm_rows in yields.items()}
    training=[t for t in tasks if t['split']=='development']
    holdout=[t for t in tasks if t['split']!='development']
    report=[]
    for task in holdout:
        for information in ('full_semantics','relation_removed','surface_metadata'):
            choice=select(task,training,mean,information)
            report.append(dict(task_unit_id=task['id'],split=task['split'],information=information,
                               observed_yield=mean[task['id']][choice['action']],**choice))
    equivalence=[]
    for task in tasks:
        graph,flat=graph_and_flat(task)
        equivalence.append(dict(task_unit_id=task['id'],nodes=len(graph['nodes']),edges=len(graph['edges']),
                                roundtrip_equal=True))
    out.mkdir(parents=True,exist_ok=False)
    (out/'decisions.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    (out/'task-yields.json').write_text(json.dumps(mean,indent=2),encoding='utf-8')
    (out/'representation-checks.json').write_text(json.dumps(equivalence,indent=2),encoding='utf-8')
    print(json.dumps(dict(tasks=len(tasks),training=len(training),heldout=len(holdout),
                          selector_decisions=len(report),graph_flat_equal=len(equivalence))))


def support_audit(repo: Path, out: Path):
    """Post-hoc mapping audit for a possible next study, not fitted-policy evaluation."""
    inputs = repo / 'data/method/day-research-20260926/frozen'
    results = repo / 'results/day-research-20260926'
    paths = [inputs/'code-panel/tasks.json', inputs/'file-followup/tasks_json',
             results/'code-panel/summary/results.json', results/'version-diagnostic/summary/results.json']
    panel, followup, panel_rows, repeat_rows = [json.loads(path.read_text(encoding='utf-8')) for path in paths]
    tasks = panel + followup
    assert len(tasks) == len({task['id'] for task in tasks}) == 12
    for task in followup:
        task['cross_task_attributes'] = dict(policy_family='file_lifecycle', conditional=False,
            multiple_targets=task['semantic']['target_count'] > 1,
            lifecycle=task['semantic']['lifecycle'])
    file_ids = {task['id'] for task in tasks if task['family'] == 'file_lifecycle'}
    retained = [row for row in panel_rows if row['task_unit_id'] not in file_ids] + repeat_rows
    collected = defaultdict(lambda: defaultdict(list))
    for row in retained:
        if row['arm'] not in ARMS:
            continue
        assert row['status'] == 'returned' and row['measurement']['status'] == 'measured'
        observed = row['measurement']
        label = observed.get('security_label', observed.get('task_bound_witness_label'))
        collected[row['task_unit_id']][row['arm']].append(int(observed['code_valid'] and label == 'secure'))
    means = {key: {arm: sum(values)/len(values) for arm, values in arms.items()}
             for key, arms in collected.items()}
    assert set(means) == {task['id'] for task in tasks}
    assert all(set(arms) == set(ARMS) for arms in means.values())
    mappings = []
    for name in ('literal_stored_lifecycle', 'canonical_policy_lifecycle'):
        mapped = json.loads(json.dumps(tasks))
        if name == 'canonical_policy_lifecycle':
            for task in mapped:
                if task['family'] == 'file_lifecycle':
                    task['cross_task_attributes']['lifecycle'] = 'first_new_byte_through_later_mode_changes'
        rows = []
        for task in mapped:
            choices = {view: select(task, mapped, means, view)
                       for view in ('full_semantics', 'relation_removed', 'surface_metadata')}
            rows.append(dict(task_unit_id=task['id'], name=task['name'],
                source_attributes=next(t['cross_task_attributes'] for t in tasks if t['id'] == task['id']),
                mapped_attributes=task['cross_task_attributes'], choices=choices))
        mappings.append(dict(mapping=name, rows=rows,
            full_vs_relation_action_differences=sum(r['choices']['full_semantics']['action'] !=
                r['choices']['relation_removed']['action'] for r in rows),
            full_unsupported=sum(r['choices']['full_semantics']['reason'] == 'unsupported_attribute_cell' for r in rows),
            relation_unsupported=sum(r['choices']['relation_removed']['reason'] == 'unsupported_attribute_cell' for r in rows)))
    report = dict(status='POSTHOC_TRAINING_SUPPORT_AND_ACTION_MAP_ONLY', tasks=12, file_tasks=5,
        source_files={str(path.relative_to(repo)): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths},
        training_rule='Seven command tasks use original two versions; all five file tasks use the already observed 16 matched draws per arm. Task means are equally weighted.',
        exposure='Every task and outcome is already observed; former holdouts are development material for any next study only.',
        mapping_definition='Canonical mapping equates the policy temporal boundary, not operation mode or initial existence. Followup operations are unconditional; possible file existence is not an execution guard.',
        prohibition='No fitted-policy yield, holdout gain, natural generalization, or causal effect is estimated by this audit.',
        mappings=mappings)
    out.mkdir(parents=True, exist_ok=False)
    (out/'support-and-actions.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps([dict(mapping=m['mapping'], full_vs_relation_action_differences=m['full_vs_relation_action_differences'],
        full_unsupported=m['full_unsupported'], relation_unsupported=m['relation_unsupported']) for m in mappings]))


if __name__=='__main__':
    if sys.argv[1] == 'support-audit':
        support_audit(Path(sys.argv[2]).resolve(), Path(sys.argv[3]))
    else:
        run(Path(sys.argv[1]),Path(sys.argv[2]),Path(sys.argv[3]))
