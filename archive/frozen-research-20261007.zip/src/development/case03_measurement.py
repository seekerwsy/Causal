import hashlib
from pathlib import Path
import sys

from prompt_mechanism_study.artifact_io import read_json, verify_bundle, write_bundle


IMAGE = 'phase-graph-guided-measurement:20260930'
IMAGE_ID = 'sha256:8aecee8021686e322655c7c73b318a89d753404241fdc2e5a0626aad1d8e90f5'
EXPECTED = {
    'secure': ('secure', 'pass', True),
    'numeric_entities': ('secure', 'pass', True),
    'vulnerable': ('insecure', 'pass', False),
    'reject_all': ('unknown', 'fail', False),
    'overrestrictive': ('unknown', 'fail', False),
    'omitted_inputs': ('unknown', 'fail', False),
    'double_encoded': ('unknown', 'fail', False),
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def locations(repo):
    method = repo / 'data/method/graph-guided-20260930'
    return (method / 'panel-preparation-inputs/case-03',
            method / 'measurement/panel',
            repo / 'results/graph-guided-20260930/panel-case03-qualification-v2')


def freeze(repo):
    source_root, measurement, _ = locations(repo)
    verify_bundle(source_root)
    source = read_json(source_root / 'source.json')
    design = read_json(source_root.parents[1] / 'panel-execution-design.json')
    design_case = next(row for row in design['tasks'] if row['audit_position'] == 3)
    if (source['index'] != 3 or source['generated_code_visible'] is not False
            or source['measurement_scope']['endpoint'] != 'html_attribute_markup_injection'
            or design_case['measurement']['endpoint'] != source['measurement_scope']['endpoint']):
        raise ValueError('Case 03 source or design identity differs')
    controls = measurement / 'case-03-controls.py'
    observer = measurement / 'case-03-observer.py'
    controls_code = controls.read_text(encoding='utf-8')
    observer_code = observer.read_text(encoding='utf-8')
    requests = {f'{name}.json': dict(code=controls_code, entry_point=name,
        tests={'security': observer_code}, trace_assertions=False,
        channel_timeout_seconds=15) for name in EXPECTED}
    write_bundle(measurement / 'case-03-qualification-inputs-v2', requests)
    write_bundle(measurement / 'case-03-qualification-freeze-v2', {
        'identity.json': dict(status='FROZEN_PROSPECTIVE_CASE03_OBSERVER_QUALIFICATION',
            task_unit_id=source['task_unit_id'], endpoint=source['measurement_scope']['endpoint'],
            source_manifest_sha256=digest(source_root / 'manifest.json'),
            design_sha256=digest(source_root.parents[1] / 'panel-execution-design.json'),
            source_prompt_sha256=hashlib.sha256(source['source_prompt'].encode()).hexdigest(),
            design_prompt_sha256=design_case['prompt_sha256'],
            observer_sha256=digest(observer), controls_sha256=digest(controls),
            request_manifest_sha256=digest(measurement / 'case-03-qualification-inputs-v2/manifest.json'),
            expected={name: list(row) for name, row in EXPECTED.items()},
            parser='lxml.html.fragments_fromstring and lxml.etree.HTML',
            lxml_version='6.0.2', libxml_version='2.14.6',
            image=IMAGE, image_id=IMAGE_ID, model_calls=0),
    })


def verify(repo):
    source_root, measurement, observed = locations(repo)
    verify_bundle(source_root)
    verify_bundle(measurement / 'case-03-qualification-inputs-v2')
    verify_bundle(measurement / 'case-03-qualification-freeze-v2')
    identity = read_json(measurement / 'case-03-qualification-freeze-v2/identity.json')
    if (identity['source_manifest_sha256'] != digest(source_root / 'manifest.json')
            or identity['observer_sha256'] != digest(measurement / 'case-03-observer.py')
            or identity['controls_sha256'] != digest(measurement / 'case-03-controls.py')
            or identity['request_manifest_sha256'] != digest(measurement / 'case-03-qualification-inputs-v2/manifest.json')):
        raise ValueError('Frozen Case 03 identity differs')
    rows = []
    for name, expected in identity['expected'].items():
        path = observed / f'{name}.json'
        result = read_json(path)
        channel = result['channels']['security']
        if result['status'] != 'measured' or channel['status'] != 'passed':
            raise ValueError(f'Incomplete real control observation: {name}')
        value = channel['observation']
        actual = (value['security_label'], value['functionality'], value['probe_literal_text_fidelity'])
        if actual != tuple(expected):
            raise ValueError(f'Control differs from frozen expectation: {name}: {actual}')
        if len(value['ordinary']) != 3 or len(value['probes']) != 8:
            raise ValueError(f'Incomplete ordinary/probe coverage: {name}')
        if name == 'vulnerable' and not value['structure_injection']:
            raise ValueError('Vulnerable control lacks parsed injection evidence')
        if name in ('secure', 'numeric_entities') and not all(
                row['parser_agreement'] and row['literal_text_fidelity']
                for row in value['ordinary'] + value['probes']):
            raise ValueError(f'Positive control lacks DOM agreement or decoded text fidelity: {name}')
        rows.append(dict(control=name, security_label=actual[0], functionality=actual[1],
            probe_literal_text_fidelity=actual[2], observation_sha256=digest(path),
            structure_injection=value['structure_injection'],
            ordinary_witness=value['ordinary_witness']))
    write_bundle(observed / 'qualified', {'controls.json': rows,
        'summary.json': dict(status='QUALIFIED_FINITE_CASE03_ENDPOINT', endpoint=identity['endpoint'],
            task_unit_id=identity['task_unit_id'], controls=len(rows),
            qualification_freeze_sha256=digest(measurement / 'case-03-qualification-freeze-v2/manifest.json'),
            image=identity['image'], image_id=identity['image_id'],
            parser=identity['parser'], lxml_version=identity['lxml_version'],
            libxml_version=identity['libxml_version'],
            limitation='Only fixed name/default probes, single-form fragments and common ordinary witnesses are qualified; complete functionality and browser execution remain unknown.')})


if __name__ == '__main__':
    command = sys.argv[1]
    repo = Path(__file__).resolve().parents[2]
    if command == 'freeze':
        freeze(repo)
    elif command == 'verify':
        verify(repo)
    else:
        raise ValueError(command)
