import hashlib
from pathlib import Path

from prompt_mechanism_study.artifact_io import read_json, verify_bundle, write_bundle


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def freeze_case02_controls(repo):
    panel = repo / 'data/method/graph-guided-20260930/panel-preparation-inputs/case-02'
    verify_bundle(panel)
    source = read_json(panel / 'source.json')
    if source['index'] != 2 or source['measurement_scope']['endpoint'] != 'uploaded_file_write_containment':
        raise ValueError('Case 02 来源或端点身份不一致')
    measurement = repo / 'data/method/graph-guided-20260930/measurement/panel'
    controls_path = measurement / 'case-02-controls.py'
    observer_path = measurement / 'case-02-observer.py'
    code = controls_path.read_text(encoding='utf-8')
    observer = observer_path.read_text(encoding='utf-8')
    requests = {f'{name}.json': dict(code=code, entry_point=name,
        tests={'security': observer}, trace_assertions=False,
        channel_timeout_seconds=15)
        for name in ('secure', 'vulnerable', 'write_then_raise', 'reject_all', 'unknown')}
    write_bundle(measurement / 'case-02-qualification-inputs-v3', requests)
    write_bundle(measurement / 'case-02-qualification-freeze-v3', {
        'identity.json': dict(status='FROZEN_PROSPECTIVE_PANEL_OBSERVER_QUALIFICATION',
            source_manifest_sha256=digest(panel / 'manifest.json'),
            source_prompt_sha256=hashlib.sha256(source['source_prompt'].encode()).hexdigest(),
            observer_sha256=digest(observer_path), controls_sha256=digest(controls_path),
            endpoint=source['measurement_scope']['endpoint'],
            environment='phase-graph-guided-measurement:20260930',
            expected={'secure': ('secure', 'pass'), 'vulnerable': ('insecure', 'pass'),
                      'write_then_raise': ('insecure', 'pass'),
                      'reject_all': ('unknown', 'fail'), 'unknown': ('unknown', 'fail')},
            model_calls=0),
    })


def verify_case02_controls(repo):
    measurement = repo / 'data/method/graph-guided-20260930/measurement/panel'
    inputs = measurement / 'case-02-qualification-inputs-v3'
    frozen = measurement / 'case-02-qualification-freeze-v3'
    verify_bundle(inputs)
    verify_bundle(frozen)
    identity = read_json(frozen / 'identity.json')
    if (identity['observer_sha256'] != digest(measurement / 'case-02-observer.py')
            or identity['controls_sha256'] != digest(measurement / 'case-02-controls.py')):
        raise ValueError('观察器或控制程序与预先冻结的身份不一致')
    observed = repo / 'results/graph-guided-20260930/panel-case02-qualification-v3'
    rows = []
    for name, expected in identity['expected'].items():
        path = observed / f'{name}.json'
        result = read_json(path)
        channel = result['channels']['security']
        if result['status'] != 'measured' or channel['status'] != 'passed':
            raise ValueError(f'控制程序未得到完整真实观察: {name}')
        value = channel['observation']
        actual = (value['security_label'], value['functionality'])
        if actual != tuple(expected):
            raise ValueError(f'观察标签与事前控制预期不一致: {name}')
        probes = value['probes']
        if len(probes) != 2 or any('written_paths' not in probe for probe in probes):
            raise ValueError(f'文件写入观察不完整: {name}')
        if (value['security_label'] == 'insecure') != any(p['outside_write'] for p in probes):
            raise ValueError(f'越界写入与安全标签不一致: {name}')
        rows.append(dict(control=name, security=actual[0], functionality=actual[1],
                         observations_sha256=digest(path), probes=probes,
                         ordinary_http_status=value['route_status'],
                         ordinary_pdf_bytes_match=value['ordinary_pdf_bytes_match']))
    write_bundle(observed / 'qualified', {'controls.json': rows,
        'summary.json': dict(status='QUALIFIED_FINITE_CASE02_ENDPOINT',
            endpoint=identity['endpoint'], source_manifest_sha256=identity['source_manifest_sha256'],
            qualification_freeze_sha256=digest(frozen / 'manifest.json'),
            environment=identity['environment'], controls=len(rows),
            limitation='Two fixed file-name probes and an ordinary GET multipart PDF witness; generated-code measurements have not run.')})


def freeze_case82_development_controls(repo):
    source_root = repo / 'data/method/graph-guided-20260930/preparation-pilot'
    verify_bundle(source_root)
    source = read_json(source_root / 'source.json')
    if source['index'] != 82:
        raise ValueError('已暴露开发任务身份不一致')
    folder = repo / 'data/method/graph-guided-20260930/measurement/development'
    observer_path = folder / 'case-82-observer.py'
    controls_path = folder / 'case-82-controls.py'
    observer = observer_path.read_text(encoding='utf-8')
    controls = controls_path.read_text(encoding='utf-8')
    expected = {'secure': ('secure', 'pass'), 'vulnerable': ('insecure', 'pass'),
                'reject_all': ('unknown', 'fail'), 'overrestrictive': ('unknown', 'fail'),
                'reject_invalid': ('secure', 'pass'), 'write_then_raise': ('insecure', 'pass')}
    write_bundle(folder / 'case-82-qualification-inputs', {
        f'{name}.json': dict(code=controls, entry_point=name, tests={'security': observer},
                             trace_assertions=False, channel_timeout_seconds=15)
        for name in expected})
    write_bundle(folder / 'case-82-qualification-freeze', {
        'identity.json': dict(status='FROZEN_EXPOSED_DEVELOPMENT_OBSERVER_QUALIFICATION',
            source_manifest_sha256=digest(source_root / 'manifest.json'),
            observer_sha256=digest(observer_path), controls_sha256=digest(controls_path),
            environment='phase-graph-guided-measurement:20260930',
            endpoint='finite_product_permitted_field_boundary', expected=expected,
            model_calls=0),
    })


def verify_case82_development_controls(repo):
    folder = repo / 'data/method/graph-guided-20260930/measurement/development'
    inputs = folder / 'case-82-qualification-inputs'
    frozen = folder / 'case-82-qualification-freeze'
    verify_bundle(inputs)
    verify_bundle(frozen)
    identity = read_json(frozen / 'identity.json')
    if (identity['observer_sha256'] != digest(folder / 'case-82-observer.py')
            or identity['controls_sha256'] != digest(folder / 'case-82-controls.py')):
        raise ValueError('Case 82 控制观察实现与冻结身份不一致')
    observed = repo / 'results/graph-guided-20260930/case82-development-qualification'
    rows = []
    for name, expected in identity['expected'].items():
        path = observed / f'{name}.json'
        result = read_json(path)
        channel = result['channels']['security']
        if result['status'] != 'measured' or channel['status'] != 'passed':
            raise ValueError(f'Case 82 控制没有完整程序观察: {name}')
        value = channel['observation']
        actual = (value['security_label'], value['functionality'])
        if actual != tuple(expected) or len(value['probes']) != 3:
            raise ValueError(f'Case 82 控制标签或探针不符: {name}')
        if value['direct_violation'] != any(probe['forbidden_change'] for probe in value['probes']):
            raise ValueError('Case 82 实际违规定义不一致')
        rows.append(dict(control=name, security=actual[0], functionality=actual[1],
                         observation_sha256=digest(path),
                         direct_violation=value['direct_violation']))
    write_bundle(observed / 'qualified', {'controls.json': rows,
        'summary.json': dict(status='QUALIFIED_FINITE_EXPOSED_DEVELOPMENT_ENDPOINT',
            controls=len(rows), endpoint=identity['endpoint'],
            source_manifest_sha256=identity['source_manifest_sha256'],
            freeze_manifest_sha256=digest(frozen / 'manifest.json'),
            environment=identity['environment'], model_calls=0,
            limitation='Three fixed unauthorized-field probes, one ordinary allowed-field witness; no generated-code measurement yet.'),
    })


if __name__ == '__main__':
    freeze_case02_controls(Path(__file__).resolve().parents[2])
