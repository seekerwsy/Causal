from __future__ import annotations

import argparse
import hashlib
import json
import platform
import subprocess
import time
from importlib.metadata import version
from importlib.resources import files
from pathlib import Path

import numpy as np
import pandas as pd
import jpype
from pytetrad.tools.TetradSearch import TetradSearch

from prompt_mechanism_study.artifact_io import file_sha256, read_json, verify_bundle, write_bundle


SCENARIOS = ('soft_direct', 'soft_latent', 'edit_direct', 'edit_latent')
SIZES = (33, 72, 200, 1000)
SEEDS = tuple(range(2026092801, 2026092821))
LABELS = ('C', 'X', 'Z', 'Y')
RSCRIPT = Path('D:/R/R-4.3.1/bin/x64/Rscript.exe')
RWORKER = Path('docs/experiments/2026-09-28-context-search.R')


def make_rows(scenario: str, n: int, seed: int) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    c, z, u = (rng.binomial(1, .5, n) for _ in range(3))
    xlogit = -1 + 2*c if scenario.startswith('soft') else -.5 + u
    if scenario == 'soft_latent':
        xlogit = xlogit + 1.5*u
    x = (rng.random(n) < 1 / (1 + np.exp(-xlogit))).astype(int)
    if scenario == 'soft_direct':
        ylogit = -2 + 2*x + 1.2*z
    elif scenario == 'soft_latent':
        ylogit = -2 + 1.8*u + 1.2*z
    elif scenario == 'edit_direct':
        ylogit = -2 + 1.5*c + 1.5*x + 1.2*z
    elif scenario == 'edit_latent':
        ylogit = -2 + 1.5*c + 1.8*u + 1.2*z
    else:
        raise ValueError(scenario)
    y = (rng.random(n) < 1 / (1 + np.exp(-ylogit))).astype(int)
    return pd.DataFrame({'C': c, 'X': x, 'Z': z, 'Y': y})


def truth(scenario: str) -> list[list[str]]:
    first = ['C', 'TAIL', 'ARROW', 'X' if scenario.startswith('soft') else 'Y']
    second = ['X', 'ARROW' if scenario.endswith('latent') else 'TAIL', 'ARROW', 'Y']
    return [first, second, ['Z', 'TAIL', 'ARROW', 'Y']]


def freeze(destination: Path) -> None:
    matrices = []
    for seed in SEEDS:
        for n in SIZES:
            for scenario in SCENARIOS:
                rows = make_rows(scenario, n, seed)
                matrices.append(dict(identity=f'{scenario}-{n}-{seed}', scenario=scenario,
                                     n=n, seed=seed, labels=list(LABELS),
                                     rows=rows.values.tolist(), truth=truth(scenario)))
    jar = files('pytetrad').joinpath('resources', 'tetrad-current.jar')
    with jar.open('rb') as stream:
        jar_digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    write_bundle(destination, {'matrices.json': matrices, 'protocol.json': {
        'status': 'FROZEN_SYNTHETIC_DEVELOPMENT', 'matrices': 320, 'searches': 1280,
        'methods': ['FCI_JCI0', 'FCI_JCI1', 'FCI_JCI12', 'GFCI'],
        'sizes': SIZES, 'seeds': SEEDS, 'alpha': .05, 'ESS': 10,
        'structure_prior': 0, 'independence_test': 'G2', 'maximum_seconds': 4*3600,
        'python_implementation_sha256': file_sha256(Path(__file__)),
        'r_implementation_sha256': file_sha256(RWORKER),
        'python': platform.python_version(), 'platform': platform.platform(),
        'packages': {k: version(k) for k in ('numpy', 'pandas', 'py-tetrad')},
        'tetrad_jar_sha256': jar_digest,
        'row_policy': 'identical independent simulated rows for all four methods',
        'endpoint_policy': 'unresolved circles are not false fixed endpoints',
    }})
    verify_bundle(destination)
    print(json.dumps({'frozen_matrices': len(matrices), 'searches': 4*len(matrices)}))


def gfci(frame: pd.DataFrame) -> list[list[str]]:
    search = TetradSearch(frame)
    search.set_verbose(False)
    search.use_bdeu(sample_prior=10, structure_prior=0)
    search.use_g_square(alpha=.05)
    search.run_gfci(depth=-1, max_degree=-1, max_disc_path_length=-1)
    return sorted([[str(e.getNode1().getName()), str(e.getEndpoint1()),
                    str(e.getEndpoint2()), str(e.getNode2().getName())]
                   for e in search.get_java().getEdges()])


def gfci_temporal(frame: pd.DataFrame) -> list[list[str]]:
    assert list(frame.columns) == ['C', 'X', 'Y']
    search = TetradSearch(frame)
    search.set_verbose(False)
    search.use_bdeu(sample_prior=10, structure_prior=0)
    search.use_g_square(alpha=.05)
    for source, target in (('C', 'X'), ('X', 'C'), ('Y', 'X'), ('Y', 'C')):
        search.set_forbidden(source, target)
    search.run_gfci(depth=-1, max_degree=-1, max_disc_path_length=-1)
    graph = search.get_java()
    c, y = graph.getNode('C'), graph.getNode('Y')
    if graph.isAdjacentTo(c, y):
        # 随机C没有潜在共同原因；只定向已存在的邻接。
        knowledge = jpype.JClass('edu.cmu.tetrad.data.Knowledge')(search.knowledge)
        knowledge.setRequired('C', 'Y')
        test = search.TEST.getTest(search.data, search.params)
        strategy = jpype.JClass('edu.cmu.tetrad.search.utils.R0R4StrategyTestBased').defaultConfiguration(test, knowledge)
        orient = jpype.JClass('edu.cmu.tetrad.search.utils.FciOrient')(strategy)
        orient.setKnowledge(knowledge)
        orient.setCompleteRuleSetUsed(True)
        orient.setVerbose(False)
        orient.fciOrientbk(knowledge, graph, graph.getNodes(), False)
        orient.finalOrientation(graph)
    edges = sorted([[str(e.getNode1().getName()), str(e.getEndpoint1()),
                     str(e.getEndpoint2()), str(e.getNode2().getName())] for e in graph.getEdges()])
    for a, left, right, b in edges:
        assert {a, b} != {'C', 'X'}
        if b == 'Y':
            assert right == 'ARROW'
        if a == 'Y':
            assert left == 'ARROW'
        if {a, b} == {'C', 'Y'}:
            assert (left if a == 'C' else right) == 'TAIL'
    return edges


def score(edges: list, target: list) -> dict:
    def normalize(e):
        a, left, right, b = e
        return (a, b), (left, right) if a < b else (right, left)

    actual, expected = {}, {}
    for e in edges:
        a, left, right, b = e
        actual[tuple(sorted((a, b)))] = (left, right) if a < b else (right, left)
    for e in target:
        a, left, right, b = e
        expected[tuple(sorted((a, b)))] = (left, right) if a < b else (right, left)
    overlap = actual.keys() & expected.keys()
    wrong = sum(mark != 'CIRCLE' and mark != expected[key][i]
                for key in overlap for i, mark in enumerate(actual[key]))
    unresolved = sum(mark == 'CIRCLE' for key in overlap for mark in actual[key])
    xy = actual.get(('X', 'Y'))
    return dict(tp=len(overlap), fp=len(actual.keys()-expected.keys()),
                fn=len(expected.keys()-actual.keys()), wrong_fixed_endpoints=wrong,
                unresolved_true_edge_endpoints=unresolved, xy_endpoints=xy,
                exact_xy_endpoints=xy == expected.get(('X', 'Y')))


def run(inputs: Path, output: Path, limit: int | None) -> None:
    verify_bundle(inputs)
    protocol = read_json(inputs / 'protocol.json')
    assert file_sha256(Path(__file__)) == protocol['python_implementation_sha256']
    assert file_sha256(RWORKER) == protocol['r_implementation_sha256']
    matrices = read_json(inputs / 'matrices.json')
    if limit is not None:
        matrices = matrices[:limit]
    output.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    completed = 0
    with (output / 'r-stderr.log').open('w', encoding='utf-8') as stderr:
        proc = subprocess.Popen([str(RSCRIPT), str(RWORKER)], stdin=subprocess.PIPE,
                                stdout=subprocess.PIPE, stderr=stderr, text=True,
                                encoding='utf-8', bufsize=1)
        assert proc.stdin is not None and proc.stdout is not None
        with (output / 'searches.jsonl').open('w', encoding='utf-8') as sink:
            for matrix in matrices:
                if time.monotonic()-started >= protocol['maximum_seconds']:
                    break
                proc.stdin.write(json.dumps(matrix)+'\n')
                proc.stdin.flush()
                for mode in ('0', '1', '12'):
                    line = proc.stdout.readline()
                    if not line:
                        raise RuntimeError(f'R worker ended at {matrix["identity"]}; inspect r-stderr.log')
                    result = json.loads(line)
                    assert result['identity'] == matrix['identity']
                    assert result['method'] == f'FCI_JCI{mode}'
                    result.update(scenario=matrix['scenario'], n=matrix['n'], seed=matrix['seed'],
                                  score=score(result['edges'], matrix['truth']))
                    sink.write(json.dumps(result)+'\n')
                    sink.flush()
                frame = pd.DataFrame(matrix['rows'], columns=matrix['labels'], dtype=int)
                t0 = time.monotonic()
                edges = gfci(frame)
                result = dict(identity=matrix['identity'], scenario=matrix['scenario'],
                              n=matrix['n'], seed=matrix['seed'], method='GFCI', edges=edges,
                              seconds=time.monotonic()-t0, score=score(edges, matrix['truth']),
                              warning_observation='Tetrad diagnostics retained in process log')
                sink.write(json.dumps(result)+'\n')
                sink.flush()
                completed += 1
                if completed % 16 == 0 or limit:
                    print(json.dumps({'completed_matrices': completed,
                                      'searches': 4*completed,
                                      'seconds': time.monotonic()-started}), flush=True)
        proc.stdin.close()
        code = proc.wait(timeout=30)
        if code:
            raise RuntimeError(f'R exited {code}')
    write_bundle(output / 'summary', {'completion.json': {
        'completed_matrices': completed, 'planned_matrices': len(matrices),
        'searches': 4*completed, 'seconds': time.monotonic()-started,
        'status': 'EXECUTED_DEVELOPMENT' if completed == len(matrices) else 'TIME_LIMIT_INCOMPLETE',
        'input_manifest': read_json(inputs / 'manifest.json'),
        'searches_sha256': file_sha256(output / 'searches.jsonl'),
        'r_stderr_sha256': file_sha256(output / 'r-stderr.log'),
    }})


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['freeze', 'run'])
    parser.add_argument('inputs', type=Path)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--limit', type=int)
    args = parser.parse_args()
    if args.action == 'freeze':
        freeze(args.inputs)
    else:
        assert args.output is not None
        run(args.inputs, args.output, args.limit)
