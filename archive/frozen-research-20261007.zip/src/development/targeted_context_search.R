.libPaths(c('.codex-runtime/r-lib', .libPaths()))
suppressPackageStartupMessages(library(pcalg))
suppressPackageStartupMessages(library(jsonlite))
input <- file('stdin', open='r')
marks <- c('NONE', 'CIRCLE', 'ARROW', 'TAIL')

complete_temporal <- function(pag, sepset, labels, mode) {
  stopifnot(identical(labels, c('C', 'X', 'Y')), pag[1,2] == 0, pag[2,1] == 0)
  rules <- rep(TRUE, 10)
  rules[5:7] <- FALSE
  for (iteration in seq_len(12)) {
    previous <- pag
    pag <- udag2pag(pag, sepset, rules=rules, jci='1',
                    contextVars=c(1L, 2L), orientCollider=FALSE)
    if (mode == '12') pag <- udag2pag(pag, sepset, rules=rules, jci='12',
                                    contextVars=1L, orientCollider=FALSE)
    if (identical(previous, pag)) break
    stopifnot(iteration < 12)
  }
  stopifnot(all(pag[c(1L,2L),3L] %in% c(0L,2L)))
  if (mode == '12') stopifnot(pag[3L,1L] %in% c(0L,3L))
  pag
}

repeat {
  line <- readLines(input, n=1L, warn=FALSE)
  if (length(line) == 0L) break
  request <- fromJSON(line)
  rows <- as.matrix(request$rows)
  labels <- request$labels
  colnames(rows) <- labels
  stopifnot(nrow(rows) == request$n, all(rows %in% c(0L, 1L)))
  for (test in c('g2', 'exact')) for (temporal in c(FALSE, TRUE)) for (mode in c('0', '1', '12')) {
    diagnostics <- list()
    warnings <- character()
    checked_ci <- function(x, y, S, suffStat) {
      groups <- if (length(S)) interaction(as.data.frame(suffStat$dm[,S,drop=FALSE]), drop=TRUE) else rep(1L, nrow(suffStat$dm))
      minima <- numeric()
      for (group in unique(groups)) {
        subset <- suffStat$dm[groups == group,,drop=FALSE]
        cells <- table(factor(subset[,x], levels=0:1), factor(subset[,y], levels=0:1))
        expected <- outer(rowSums(cells), colSums(cells)) / sum(cells)
        minima <- c(minima, min(expected))
      }
      key <- paste(c(sort(labels[c(x,y)]), sort(labels[S])), collapse='|')
      value <- if (test == 'g2') disCItest(x, y, S, suffStat) else request$exact_p[[key]]
      stopifnot(length(value) == 1, is.finite(value), value >= 0, value <= 1)
      diagnostics[[length(diagnostics)+1L]] <<- list(x=labels[x], y=labels[y], S=as.list(labels[S]),
        minimum_expected=min(minima), sparse=any(minima < 5), p_value=value,
        insufficient_n_guard=(test == 'g2' && nrow(rows) < 10 * 2^length(S)))
      value
    }
    gaps <- matrix(FALSE, 3, 3)
    if (temporal) gaps[1,2] <- gaps[2,1] <- TRUE
    started <- proc.time()[['elapsed']]
    graph <- withCallingHandlers(fci(
      suffStat=list(dm=rows, nlev=rep(2L, 3), adaptDF=FALSE),
      indepTest=checked_ci, alpha=.05, labels=labels, contextVars=1L, jci=mode,
      fixedGaps=gaps, selectionBias=FALSE, NAdelete=FALSE, verbose=FALSE
    ), warning=function(w) {
      warnings <<- c(warnings, conditionMessage(w))
      invokeRestart('muffleWarning')
    })
    pag <- graph@amat
    if (temporal) pag <- complete_temporal(pag, graph@sepset, labels, mode)
    edges <- list()
    for (i in seq_len(2)) for (j in seq.int(i+1L, 3L)) {
      if (pag[i,j] != 0L || pag[j,i] != 0L)
        edges[[length(edges)+1L]] <- c(labels[i], marks[pag[j,i]+1L], marks[pag[i,j]+1L], labels[j])
    }
    result <- list(identity=request$identity,
      method=paste0('FCI_JCI', mode, if (temporal) '_temporal_' else '_original_', test),
      edges=edges, warnings=as.list(unique(warnings)), ci_diagnostics=diagnostics,
      seconds=proc.time()[['elapsed']]-started,
      pcalg=as.character(packageVersion('pcalg')))
    cat(toJSON(result, auto_unbox=TRUE, null='null', digits=16), '\n', sep='')
    flush(stdout())
  }
}
close(input)
