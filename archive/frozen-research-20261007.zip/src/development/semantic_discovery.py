from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from fractions import Fraction
from math import isfinite, log, sqrt
from pathlib import Path

import numpy as np
from sklearn import __version__ as sklearn_version
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import Ridge
from sklearn.preprocessing import normalize

from prompt_mechanism_study.artifact_io import file_sha256, read_json, verify_bundle, write_bundle
from prompt_mechanism_study.records import canonical_json, content_hash
from prompt_mechanism_study.development.source_generation import MODEL, SYSTEM


PROTOCOL = 'semantic-discovery-development-20260930'
ROOT = Path('data/method/graph-guided-20260930')
ALPHAS = (.1, 1., 10., 100.)
CLASS_FIELDS = ('change_kind', 'target_proposition', 'pn_states', 'scope_invariants',
                'applicability_unknown', 'safety_property_witness_domain')
CONTROLLED_ROOT = Path('data/method/controlled-semantic-20260930')


def freeze_controlled_launch(repo):
    start = datetime.fromtimestamp(1790782887, timezone.utc)
    deadline = start + timedelta(days=14)
    now = datetime.now(timezone.utc)
    if not start <= now < deadline:
        raise ValueError('当前时间不在授权研究窗口')
    source = repo / 'docs/experiments/2026-09-30-controlled-semantic-interventions.md'
    write_bundle(repo / CONTROLLED_ROOT / 'launch', {
        'launch.json': dict(protocol_id='controlled-semantic-20260930',
            status='AUTHORIZED_PREPARATION', authorization='照此启动一个goal实验',
            t0_utc=start.isoformat(), deadline_utc=deadline.isoformat(),
            frozen_at_utc=now.isoformat(), generation_call_limit=28510,
            model_service_seconds_limit=120 * 3600, structure_cpu_seconds_limit=8 * 3600,
            blueprint_candidate_limit=2400, natural_source_limit=500, natural_task_limit=60,
            discovery_tasks=400, evaluation_tasks=400, development_calls=30,
            master_seed=2026093001, model_role='code_generation_only',
            formal_protocol='SPECIFIED_DRAFT', paid_provider_allowed=False,
            protected_evaluation_allowed=False),
        'protocol.json': dict(path=str(source.relative_to(repo)),
                             sha256=file_sha256(source), text=source.read_text(encoding='utf-8')),
    })


def semantic_class_id(definition):
    if set(definition) != set(CLASS_FIELDS):
        raise ValueError('语义类别必须具备全部六字段')
    if any(not value for value in definition.values()):
        raise ValueError('语义类别字段不能为空')
    if not isinstance(definition['pn_states'], dict) or set(definition['pn_states']) != {'P', 'N'}:
        raise ValueError('语义状态必须声明P/N顺序')
    return content_hash(canonical_json(definition))


def source_span(text, quote, occurrence):
    if not isinstance(quote, str) or not quote or type(occurrence) is not int or occurrence < 0:
        raise ValueError('逐字来源引用或出现次数无效')
    start, offset = -1, 0
    for _ in range(occurrence + 1):
        start = text.find(quote, offset)
        if start < 0:
            raise ValueError('逐字引用没有对应来源位置')
        offset = start + 1
    return start, start + len(quote)


def materialize_versions(source, edit_versions):
    if len(edit_versions) not in {1, 2}:
        raise ValueError('必须提交一或两个真实编辑版本')
    versions = []
    for edits in edit_versions:
        spans = []
        for edit in edits:
            if set(edit) != {'quote', 'occurrence', 'replacement'}:
                raise ValueError('编辑必须包含精确引用、出现次数及替换文本')
            if not isinstance(edit['replacement'], str):
                raise ValueError('编辑替换必须为字符串')
            start, end = source_span(source['source_prompt'], edit['quote'], edit['occurrence'])
            spans.append((start, end, edit['replacement']))
        spans.sort()
        if any(left[1] > right[0] for left, right in zip(spans, spans[1:])):
            raise ValueError('原文编辑位置重叠')
        text = source['source_prompt']
        for start, end, replacement in reversed(spans):
            text = text[:start] + replacement + text[end:]
        versions.append(text + '\n\nShared execution interface:\n' + source['shared_execution_interface'])
    if len(set(versions)) != len(versions):
        raise ValueError('同一文本只能登记一次')
    return versions


def validate_source_support(source, prepared, flow):
    if flow not in {'TSG', 'Raw'} or prepared['flow'] != flow:
        raise ValueError('准备流程身份不符')
    documents = {name: source[name] for name in
                 ('source_prompt', 'system_prompt', 'shared_execution_interface')}
    units = {row['unit_id']: row for row in prepared['source_units']}
    if not units or len(units) != len(prepared['source_units']):
        raise ValueError('来源单元为空或身份重复')
    covered = {name: set() for name in documents}
    for row in units.values():
        document = row['source_document']
        if document not in documents:
            raise ValueError('来源引用超出提示文档')
        if row['status'] not in {'represented', 'shared_obligation', 'unparsed', 'out_of_scope'}:
            raise ValueError('来源单元状态无效')
        if not row['meaning'] or (row['status'] in {'unparsed', 'out_of_scope'} and not row.get('reason')):
            raise ValueError('来源单元缺少语义或范围理由')
        start, end = source_span(documents[document], row['quote'], row['occurrence'])
        covered[document].update(range(start, end))
    for name, text in documents.items():
        if any(not char.isspace() and index not in covered[name] for index, char in enumerate(text)):
            raise ValueError('来源仍有未登记的非空白内容')
    graph = prepared['graph']
    nodes, edges = {}, {}
    if flow == 'Raw':
        if graph is not None:
            raise ValueError('Raw准备不能接收TSG表示')
    else:
        nodes = {row['id']: row for row in graph['nodes']}
        edges = {row['id']: row for row in graph['edges']}
        if not nodes or len(nodes) != len(graph['nodes']) or len(edges) != len(graph['edges']):
            raise ValueError('图为空或图元素身份重复')
        for row in [*nodes.values(), *edges.values()]:
            if not row['source_unit_ids'] or not set(row['source_unit_ids']).issubset(units):
                raise ValueError('图元素缺少有效来源依据')
        for row in edges.values():
            if row['source'] not in nodes or row['target'] not in nodes or not row['statement']:
                raise ValueError('关系端点或完整命题缺失')
    opportunities = prepared['opportunities']
    if len({row['opportunity_id'] for row in opportunities}) != len(opportunities):
        raise ValueError('机会身份重复')
    for row in opportunities:
        if not row['source_unit_ids'] or not set(row['source_unit_ids']).issubset(units):
            raise ValueError('机会来源依据缺失')
        if row['status'] not in {'eligible', 'inapplicable', 'unresolved', 'merged'}:
            raise ValueError('机会状态无效')
        if row['status'] != 'eligible' and not row.get('reason'):
            raise ValueError('未取得资格的机会缺少原因')
        if flow == 'TSG' and row['status'] == 'eligible':
            selected_nodes, selected_edges = set(row['support_nodes']), set(row['support_edges'])
            if not selected_nodes or not selected_nodes.issubset(nodes) or not selected_edges.issubset(edges):
                raise ValueError('目标支持超出原图')
            if any({edges[key]['source'], edges[key]['target']} - selected_nodes for key in selected_edges):
                raise ValueError('目标关系没有包含完整端点')
            if not row['support_reason']:
                raise ValueError('缺少目标语义完整性说明')
    return dict(status='MECHANICAL_SOURCE_SUPPORT_CHECKED', units=len(units),
                nodes=len(nodes), edges=len(edges), opportunities=len(opportunities),
                semantic_quality='REQUIRES_INDEPENDENT_REVIEW')


def nomination_positions(opportunities, seed):
    if len({row['opportunity_id'] for row in opportunities}) != len(opportunities):
        raise ValueError('机会身份重复')
    legal = [row for row in opportunities if row['qualified']]
    if not legal:
        return [None, None]
    first = min(legal, key=lambda row: (
        -int(row['ordinary_content']), -int(row['distinguishable_explanations']),
        -int(row['transferable_definition']), row['opportunity_id']))
    targets = defaultdict(list)
    for row in legal:
        if row['ordinary_content'] and row['target_id'] != first['target_id']:
            targets[row['target_id']].append(row)
    if not targets:
        return [first['opportunity_id'], None]
    rng = np.random.default_rng(seed)
    target = sorted(targets)[int(rng.integers(len(targets)))]
    changes = sorted(targets[target], key=lambda row: row['opportunity_id'])
    second = changes[int(rng.integers(len(changes)))]
    return [first['opportunity_id'], second['opportunity_id']]


def class_statistics(rows):
    if not rows:
        raise ValueError('缺少开发政策效果')
    tasks, categories = defaultdict(list), defaultdict(lambda: defaultdict(list))
    for row in rows:
        value = float(row['delta_pn'])
        if not isfinite(value) or not -1 <= value <= 1:
            raise ValueError('开发效果超出范围')
        tasks[row['task_unit_id']].append(value)
        categories[row['semantic_class_id']][row['task_unit_id']].append(value)
    global_mean = float(np.mean([np.mean(values) for values in tasks.values()]))
    result = {}
    for category, task_values in sorted(categories.items()):
        values = [float(np.mean(values)) for values in task_values.values()]
        count = len(values)
        result[category] = dict(tasks=count, mean=float(np.mean(values)),
            prediction=(sum(values) + 2 * global_mean) / (count + 2)
                       if count >= 4 else global_mean,
            status='CATEGORY_SUPPORTED' if count >= 4 else 'GLOBAL_INSUFFICIENT_SUPPORT')
    return dict(global_mean=global_mean, categories=result)


def signed_pick(rows, scores):
    if len(rows) != len(scores) or any(not isfinite(float(score)) for score in scores):
        raise ValueError('候选与有限预测必须一一对应')
    if not rows:
        return None
    row, score = min(zip(rows, scores, strict=True),
                     key=lambda pair: (-abs(float(pair[1])), pair[0]['candidate_id']))
    if abs(score) <= 1e-12:
        return None
    return dict(candidate_id=row['candidate_id'], prediction=float(score),
                direction=1 if score > 0 else -1)


def _versions(row, arm):
    values = row[arm.lower() + '_versions']
    if len(values) not in {1, 2} or any(not isinstance(x, str) or not x.strip() for x in values):
        raise ValueError('每侧必须有一或两个真实全文版本')
    if len(set(values)) != len(values):
        raise ValueError('相同文本不能登记为多个版本')
    return values


class SemanticTextFeatures:
    def __init__(self):
        self.common = TfidfVectorizer(analyzer='char', ngram_range=(2, 4),
                                     max_features=256, norm='l2', dtype=np.float64)
        self.policy = TfidfVectorizer(analyzer='char', ngram_range=(2, 4),
                                     max_features=256, norm='l2', dtype=np.float64)

    def fit(self, rows):
        if not rows:
            raise ValueError('文本编码缺少训练候选')
        self.common.fit([row['canonical_text'] for row in rows])
        self.policy.fit([text for row in rows for arm in ('P', 'N')
                         for text in _versions(row, arm)])
        return self

    def transform(self, rows):
        orientation = np.asarray([row['orientation'] for row in rows], dtype=float)
        if not np.all(np.isin(orientation, [-1, 1])):
            raise ValueError('规范方向必须为正一或负一')
        common = self.common.transform([row['canonical_text'] for row in rows]).toarray()
        differences = []
        for row in rows:
            means = [self.policy.transform(_versions(row, arm)).toarray().mean(axis=0)
                     for arm in ('P', 'N')]
            differences.append(means[0] - means[1])
        difference = normalize(np.asarray(differences))
        return np.concatenate([orientation[:, None], orientation[:, None] * common,
                               difference], axis=1)


def fit_semantic_ridge(rows):
    tasks = sorted({row['task_unit_id'] for row in rows})
    if len(tasks) < 8:
        raise ValueError('文本学习器至少需要八项开发任务')

    def fit(selected, alpha):
        features = SemanticTextFeatures().fit(selected)
        counts = Counter(row['task_unit_id'] for row in selected)
        learner = Ridge(alpha=alpha, fit_intercept=False, solver='svd').fit(
            features.transform(selected), [row['delta_pn'] for row in selected],
            sample_weight=[1 / counts[row['task_unit_id']] for row in selected])
        return features, learner

    evaluations = []
    for alpha in ALPHAS:
        folds = []
        for task in tasks:
            training = [row for row in rows if row['task_unit_id'] != task]
            test = [row for row in rows if row['task_unit_id'] == task]
            features, learner = fit(training, alpha)
            error = learner.predict(features.transform(test)) - [row['delta_pn'] for row in test]
            folds.append(dict(task_unit_id=task, mse=float(np.mean(error ** 2))))
        evaluations.append(dict(alpha=alpha, mse=float(np.mean([r['mse'] for r in folds])),
                                folds=folds))
    selected = min(evaluations, key=lambda row: (row['mse'], -row['alpha']))
    features, learner = fit(rows, selected['alpha'])
    return features, learner, evaluations


def request_plan(tasks, candidates, panel, environment_identity, seed=20260930):
    if panel not in {'O', 'V'} or not environment_identity:
        raise ValueError('面板和环境身份缺失')
    task_map = {row['task_unit_id']: row for row in tasks}
    if len(task_map) != len(tasks) or not tasks or len(tasks) > 12:
        raise ValueError('任务必须独立且每面板一至十二项')
    if len({row['candidate_id'] for row in candidates}) != len(candidates):
        raise ValueError('候选身份重复')
    if any(row['task_unit_id'] not in task_map for row in candidates):
        raise ValueError('候选不在冻结任务面板')
    uses = defaultdict(list)
    arm_maps = {}
    for task_id, task in sorted(task_map.items()):
        selected = sorted((r for r in candidates if r['task_unit_id'] == task_id),
                          key=lambda row: row['candidate_id'])
        if len(selected) > (4 if panel == 'O' else 1):
            raise ValueError('任务政策超过面板上限')
        per_arm = 2 if panel == 'O' else 4
        distributions = [('R', [task['reference_prompt']])]
        for candidate in selected:
            for arm in ('P', 'N'):
                versions = _versions(candidate, arm)
                if panel == 'V' and len(versions) == 1:
                    if arm != 'P' or versions != [task['reference_prompt']]:
                        raise ValueError('复现单版本只适用于严格P=R')
                distributions.append((candidate['candidate_id'] + ':' + arm, versions))
        for name, versions in distributions:
            repetitions = per_arm // len(versions)
            weights = []
            for version, prompt in enumerate(versions):
                for repeat in range(repetitions):
                    key = (task_id, prompt, repeat)
                    use = dict(task_unit_id=task_id, name=name, version=version,
                               repeat=repeat, weight=str(Fraction(1, per_arm)))
                    uses[key].append(use)
                    weights.append((key, Fraction(1, per_arm)))
            arm_maps[(task_id, name)] = weights
    rng_seed, rng_order = [np.random.default_rng(s) for s in
                           np.random.SeedSequence([seed, ord(panel)]).spawn(2)]
    seed_values = rng_seed.choice(2**31 - 1, size=len(uses), replace=False) + 1
    assignments, identities = [], {}
    for (key, memberships), seed_value in zip(sorted(uses.items()), seed_values, strict=True):
        task_id, prompt, repeat = key
        task = task_map[task_id]
        messages = [{'role': 'system', 'content': SYSTEM}, {'role': 'user', 'content': prompt}]
        identity = content_hash(canonical_json(dict(task_unit_id=task_id, messages=messages,
            model=MODEL, seed=int(seed_value), environment=environment_identity,
            measurement=task['measurement'])))
        identities[key] = identity
        assignments.append(dict(request_id=identity, task_unit_id=task_id,
            index=task['index'], panel=panel, prompt=prompt, messages=messages,
            prompt_sha256=content_hash(prompt), seed=int(seed_value), uses=memberships,
            measurement=task['measurement'], independent_group=identity))
    assignments = [dict(slot=f'{slot:04d}', **assignments[int(index)])
                   for slot, index in enumerate(rng_order.permutation(len(assignments)))]
    if len(assignments) > (216 if panel == 'O' else 144):
        raise ValueError('面板请求数超过冻结上限')
    bindings = [dict(task_unit_id=task, name=name,
                    request_weights=[[identities[key], str(weight)] for key, weight in weights])
                for (task, name), weights in sorted(arm_maps.items())]
    return assignments, bindings


def policy_coefficients(bindings, task_id, candidate_id, direction=1):
    if direction not in {-1, 1}:
        raise ValueError('政策方向无效')
    by_name = {row['name']: row for row in bindings if row['task_unit_id'] == task_id}
    result = []
    for arm, sign in [('P', direction), ('N', -direction)]:
        row = by_name[candidate_id + ':' + arm]
        weights = [(key, Fraction(weight)) for key, weight in row['request_weights']]
        if sum(weight for _, weight in weights) != 1:
            raise ValueError('政策臂权重总和必须等于一')
        result.extend((key, sign * weight) for key, weight in weights)
    return result


def fixed_panel_interval(coefficients, independent_groups, outcomes=None, *, comparisons=6):
    if type(comparisons) is not int or comparisons < 1:
        raise ValueError('同时检验数量必须为正整数')
    combined = defaultdict(Fraction)
    for identity, coefficient in coefficients:
        value = Fraction(coefficient)
        combined[identity] += value
    combined = {key: value for key, value in combined.items() if value}
    if not set(combined).issubset(independent_groups):
        raise ValueError('独立随机组没有覆盖全部请求')
    grouped = defaultdict(list)
    for identity, coefficient in combined.items():
        grouped[independent_groups[identity]].append(coefficient)
    ranges = {key: (sum(min(c, 0) for c in values), sum(max(c, 0) for c in values))
              for key, values in grouped.items()}
    halfwidth = sqrt(log(40 * comparisons) / 2 * sum(float(hi - lo) ** 2 for lo, hi in ranges.values()))
    lower = sum(min(c, 0) for c in combined.values())
    upper = sum(max(c, 0) for c in combined.values())
    result = dict(halfwidth=halfwidth, full_width=2 * halfwidth,
                  deterministic_range=[float(lower), float(upper)],
                  independent_groups=len(grouped), nonzero_requests=len(combined),
                  coefficients={key: str(value) for key, value in sorted(combined.items())})
    if outcomes is None:
        return dict(result, status='PROSPECTIVE_PRECISION')
    lo_value = hi_value = Fraction(0)
    missing = []
    for identity, coefficient in combined.items():
        if identity not in outcomes:
            raise ValueError('全部分配必须显式提供已测或缺失结果')
        lo, hi = [Fraction(value) for value in outcomes[identity]]
        if not 0 <= lo <= hi <= 1:
            raise ValueError('安全产出界限必须处于零至一')
        lo_value += coefficient * (lo if coefficient > 0 else hi)
        hi_value += coefficient * (hi if coefficient > 0 else lo)
        if lo != hi:
            missing.append(identity)
    return dict(result, status='INCOMPLETE' if missing else 'COMPLETE',
                estimate=None if missing else float(lo_value),
                completion_bounds=[float(lo_value), float(hi_value)],
                interval=[max(float(lower), float(lo_value) - halfwidth),
                          min(float(upper), float(hi_value) + halfwidth)],
                missing_nonzero_requests=missing)


def freeze_launch(repo):
    sources = ['docs/graph-guided-discovery-protocol.md',
               'docs/experiments/2026-09-30-launch-gap-pro-review.md']
    start = datetime(2026, 9, 29, 18, 43, 42, tzinfo=timezone.utc)
    deadline = datetime(2026, 9, 30, 18, 43, 42, tzinfo=timezone.utc)
    now = datetime.now(timezone.utc)
    if not start <= now < deadline:
        raise ValueError('当前时间不在授权研究窗口')
    write_bundle(repo / ROOT / 'launch', {
        'launch.json': dict(protocol_id=PROTOCOL, status='AUTHORIZED_DEVELOPMENT_EXECUTION',
            authorization='启动吧，授权允许', t0_utc=start.isoformat(),
            deadline_utc=deadline.isoformat(), frozen_at_utc=now.isoformat(),
            generation_call_limit=392, model_service_seconds_limit=5400,
            cpu_experiment_seconds_limit=7200, source_identity_limit=60,
            source_audit_seconds_limit=7200, formal_protocol='SPECIFIED_DRAFT',
            model_role='code_generation_only', paid_provider_allowed=False,
            protected_evaluation_allowed=False),
        'protocol.json': {name: dict(text=(repo / name).read_text(encoding='utf-8'),
                                   sha256=file_sha256(repo / name)) for name in sources},
    })


def freeze_preparation_pilot(repo):
    parent = repo / 'data/method/graph-guided-20260929/targeted-generation-preparation'
    verify_bundle(parent)
    task = next(row for row in read_json(parent / 'tasks.json') if row['index'] == 82)
    suffix = '\n\nShared execution interface:\n' + task['execution_interface']
    if not task['reference_prompt'].endswith(suffix):
        raise ValueError('共同接口未绑定历史原始提示')
    source = dict(index=82, task_unit_id=task['task_unit_id'],
        source_prompt=task['reference_prompt'].removesuffix(suffix),
        system_prompt=SYSTEM, shared_execution_interface=task['execution_interface'],
        measurement_scope='分别观察有限字段更新边界、普通允许字段更新和未知；字段名不改变授权范围。',
        role='EXPOSED_DEVELOPMENT_PREPARATION_CHECK', generated_code_visible=False)
    instructions = repo / 'docs/experiments/2026-09-30-semantic-preparation-instructions.md'
    write_bundle(repo / ROOT / 'preparation-pilot', {
        'source.json': source,
        'instructions.json': dict(text=instructions.read_text(encoding='utf-8'),
                                  sha256=file_sha256(instructions)),
        'protocol.json': dict(status='FROZEN_PREPARATION_CHECK', source_index=82,
            source_reason='重复的字段限制和代码事实检验完整义务处理，属于事前指定的已暴露语义边界',
            parent_manifest_sha256=file_sha256(parent / 'manifest.json'),
            launched_protocol_manifest_sha256=file_sha256(repo / ROOT / 'launch/manifest.json'),
            requests_per_flow=2, flow_wall_seconds=720, total_input_output_tokens=1000000,
            uncached_input_plus_output_tokens=100000,
            model_policy='same inherited Codex model and reasoning settings for both flows; record actual metadata',
            source_scope='one exposed task; TSG and Raw separate fresh instances',
            interpretation='timing and implementation boundary only; no discovery-effect or graph-advantage claim',
            qwen_requests=0),
    })


def preparation_accounting(session_root, parent_thread, agent_paths, confirmed_interrupted=()):
    if not set(confirmed_interrupted) <= set(agent_paths):
        raise ValueError('已确认中断的实例必须属于本次计量范围')
    rows = []
    for path in sorted(session_root.glob('*.jsonl')):
        with path.open(encoding='utf-8') as stream:
            first = json.loads(next(stream))
            source = first['payload'].get('source')
            if not isinstance(source, dict):
                continue
            spawn = source.get('subagent', {}).get('thread_spawn', {})
            if spawn.get('parent_thread_id') != parent_thread or spawn.get('agent_path') not in agent_paths:
                continue
            records = [first] + [json.loads(line) for line in stream]
        contexts = [row for row in records if row['type'] == 'turn_context']
        usages = [row['payload']['info']['total_token_usage'] for row in records
                  if row['type'] == 'event_msg' and row['payload']['type'] == 'token_count'
                  and row['payload'].get('info')]
        if not contexts:
            raise ValueError('准备实例缺少实际模型或token计量')
        # 应用重载可能没有写入终止事件；调用方须通过实际实例状态确认中断。
        interrupted = spawn['agent_path'] in confirmed_interrupted or any(
            row['type'] == 'event_msg' and row['payload']['type'] == 'turn_aborted' for row in records)
        unavailable = not usages and interrupted and any(
            row['type'] == 'event_msg' and row['payload']['type'] == 'token_count'
            and row['payload'].get('info') is None for row in records)
        if not usages and not unavailable:
            raise ValueError('准备实例缺少实际模型或token计量')
        start = datetime.fromisoformat(first['timestamp'].replace('Z', '+00:00'))
        end = datetime.fromisoformat(records[-1]['timestamp'].replace('Z', '+00:00'))
        usage = usages[-1] if usages else None
        accounting = dict(agent_path=spawn['agent_path'],
            registration_utc=start.isoformat(), last_observation_utc=end.isoformat(),
            observed_seconds=(end-start).total_seconds(),
            models=sorted({row['payload']['model'] for row in contexts}),
            efforts=sorted({row['payload']['effort'] for row in contexts}),
            top_level_requests=len(contexts), usage=usage,
            uncached_input_plus_output=(usage['input_tokens']-usage['cached_input_tokens']+usage['output_tokens']
                                       if usage is not None else None),
            evidence_scope='model/resource metadata; conversation contents excluded')
        if interrupted:
            accounting['completion_status'] = 'interrupted'
        if unavailable:
            accounting.update(usage_status='unavailable',
                usage_unavailable_reason='interrupted_session_has_no_token_usage')
        rows.append(accounting)
    if {row['agent_path'] for row in rows} != set(agent_paths) or len(rows) != len(agent_paths):
        raise ValueError('准备实例身份缺失或重复')
    return rows


def freeze_training_semantics(repo):
    records, identities = [], {}
    parent = repo / 'data/method/graph-guided-20260929'
    for batch in ('development-preparation', 'evaluation-preparation', 'targeted-generation-preparation'):
        folder = parent / batch
        identities[batch] = verify_bundle(folder)
        tasks = {row['task_unit_id']: row for row in read_json(folder / 'tasks.json')}
        for row in read_json(folder / 'candidates.json'):
            task = tasks[row['task_unit_id']]
            key = content_hash(canonical_json([batch, row['candidate_id']]))
            records.append(dict(mapping_id=key, batch=batch, candidate_id=row['candidate_id'],
                task_unit_id=row['task_unit_id'], index=row['index'],
                source_prompt=task['reference_prompt'], execution_interface=task['execution_interface'],
                target=row['target'], contract=row['contract'],
                p_versions=row['p_versions'], n_versions=row['n_versions'],
                measurement=task['measurement']))
    write_bundle(repo / ROOT / 'training-semantic-inputs', {
        'candidates.json': records,
        'protocol.json': dict(status='FROZEN_OUTCOME_BLIND_SEMANTIC_MAPPING',
            parent_manifests=identities, records=len(records),
            tasks=len({row['task_unit_id'] for row in records}),
            historical_roles='all three completed exposed development batches; original roles preserved',
            mapping='six-field semantics from actual source and P/N; unresolved or invalid preserved',
            visibility='source, actual versions, original contract, measurement definition; no outcomes or flow'),
    })


def freeze_pilot_reviews(repo):
    source_root = repo / ROOT / 'preparation-pilot'
    verify_bundle(source_root)
    source = read_json(source_root / 'source.json')
    candidates, bindings, diagnostics = [], [], {}
    for flow in ('TSG', 'Raw'):
        path = repo / ROOT / 'preparation-pilot-prepared' / flow / 'final.json'
        prepared = read_json(path)
        diagnostics[flow] = validate_source_support(source, prepared, flow)
        for row in prepared['opportunities']:
            identity = content_hash(canonical_json([flow, row['opportunity_id']]))
            public = {key: row[key] for key in ('target', 'change_kind', 'ordinary_content',
                      'semantic_class', 'binding', 'non_target_requirements', 'common_witness',
                      'unknowns', 'competing_explanations', 'status')}
            public['review_id'] = identity
            public['reason'] = row.get('reason')
            contract = row.get('contract')
            public['contract'] = ({key: value for key, value in contract.items()
                                   if key not in {'instance_id', 'execution_identity'}}
                                  if contract else None)
            for arm in ('p', 'n'):
                edits = row.get(arm + '_edits')
                public[arm + '_versions'] = materialize_versions(source, edits) if edits else []
            if row['status'] == 'eligible' and (not public['p_versions'] or not public['n_versions']):
                raise ValueError('提交审查的机会缺少实际编辑')
            if 'Raw:' in canonical_json(public) or 'TSG:' in canonical_json(public):
                raise ValueError('公共审查材料包含流程身份')
            candidates.append(public)
            bindings.append(dict(review_id=identity, flow=flow, opportunity_id=row['opportunity_id'],
                                 prepared_sha256=file_sha256(path)))
    write_bundle(repo / ROOT / 'preparation-pilot-review-inputs', {
        'source.json': source, 'candidates.json': sorted(candidates, key=lambda row: row['review_id']),
        'instructions.json': dict(status='BLIND_SEMANTIC_REVIEW',
            scope='source support, complete target, Atomic boundary, non-target invariants, real versions, measurement scope',
            interpretation='exposed development check; no causal effect or graph advantage claim',
            explanation_conditions=['two source-compatible explanations',
                'distinct observable predictions for security, direct violation, unknown or functionality',
                'existing measurement fields and common ordinary witness identified',
                'at least one result pattern excluding one explanation'],
            output='per review_id: valid/invalid/unknown for each semantic criterion; four explanation booleans; reasons; no new edits'),
    })
    write_bundle(repo / ROOT / 'preparation-pilot-review-bindings', {
        'bindings.json': bindings, 'mechanical-diagnostics.json': diagnostics,
        'input_manifest.json': read_json(source_root / 'manifest.json'),
    })


def freeze_pilot_accounting(repo, session_root, parent_thread):
    protocol = read_json(repo / ROOT / 'preparation-pilot/protocol.json')
    rows = preparation_accounting(session_root, parent_thread,
                                  ['/root/pilot82_tsg', '/root/pilot82_raw'])
    for row in rows:
        flow = 'TSG' if row['agent_path'].endswith('_tsg') else 'Raw'
        final_path = repo / ROOT / 'preparation-pilot-prepared' / flow / 'final.json'
        row['flow'] = flow
        row['final_sha256'] = file_sha256(final_path)
        row['recorded_token_limit_satisfied'] = (
            row['usage']['input_tokens'] + row['usage']['output_tokens'] <= protocol['total_input_output_tokens']
            and row['uncached_input_plus_output'] <= protocol['uncached_input_plus_output_tokens'])
        row['wall_limit_satisfied'] = row['observed_seconds'] <= protocol['flow_wall_seconds']
        row['requests_limit_satisfied'] = row['top_level_requests'] == protocol['requests_per_flow']
        row['termination'] = 'root_interrupted_at_budget_boundary' if flow == 'TSG' else 'completed'
        row['resource_qualified'] = (row['termination'] == 'completed'
            and row['recorded_token_limit_satisfied'] and row['wall_limit_satisfied']
            and row['requests_limit_satisfied'])
    write_bundle(repo / ROOT / 'preparation-pilot-accounting', {
        'instances.json': rows,
        'summary.json': dict(status='EXPOSED_PREPARATION_RESOURCE_CHECK',
            same_models_and_efforts=len({canonical_json([row['models'], row['efforts']]) for row in rows}) == 1,
            both_resource_qualified=all(row['resource_qualified'] for row in rows),
            interpretation='timing and implementation check only; no graph advantage inference',
            protocol_manifest=read_json(repo / ROOT / 'preparation-pilot/manifest.json')),
    })


def analyze_pilot_reviews(repo):
    root = repo / ROOT
    candidates_root = root / 'preparation-pilot-review-inputs'
    bindings_root = root / 'preparation-pilot-review-bindings'
    verify_bundle(candidates_root)
    verify_bundle(bindings_root)
    candidates = read_json(candidates_root / 'candidates.json')
    bindings = {row['review_id']: row for row in read_json(bindings_root / 'bindings.json')}
    review_paths = [root / f'preparation-pilot-reviews/{name}.json' for name in ('a', 'b')]
    first, second = [read_json(path) for path in review_paths]
    first_rows = {row['review_id']: row for row in first['reviews']}
    second_rows = {row['review_id']: row for row in second['reviews']}
    ids = {row['review_id'] for row in candidates}
    if (len(ids) != len(candidates) or ids != set(bindings) or ids != set(first_rows)
            or ids != set(second_rows) or len(candidates) != 21):
        raise ValueError('隔离审查没有完整覆盖准备机会')
    core = ('source_support', 'complete_target', 'atomic_boundary', 'non_target_preservation')
    explanation_names = ('two_source_compatible', 'distinct_observable_predictions',
                         'measurement_and_common_witness', 'excluding_result_pattern')
    rows = []
    for candidate in candidates:
        identity = candidate['review_id']
        a, b = first_rows[identity], second_rows[identity]
        semantic = all(a[key]['status'] == b[key]['status'] == 'valid' for key in core)
        versions = a['pn_versions']['status'] == b['real_pn_versions']['status'] == 'valid'
        measurement = (a['measurement_separability']['status'] ==
                       b['measurement_separability']['status'] == 'valid')
        explained = (all(a['explanation_conditions'])
                     and all(b['explanations'][key] for key in explanation_names))
        prepared = candidate['status'] == 'eligible'
        rows.append(dict(review_id=identity, flow=bindings[identity]['flow'],
            opportunity_id=bindings[identity]['opportunity_id'], status=candidate['status'],
            semantic_class_id=semantic_class_id(candidate['semantic_class']),
            semantic_double_pass=semantic, actual_versions_double_pass=versions,
            measurement_double_pass=measurement, explanation_double_pass=explained,
            qualified=bool(prepared and semantic and versions and measurement),
            priority_explanation_score=bool(explained),
            revision_identity=content_hash(canonical_json([candidate['p_versions'],
                                                           candidate['n_versions']]))))
    summary = []
    for flow in ('TSG', 'Raw'):
        group = [row for row in rows if row['flow'] == flow]
        summary.append(dict(flow=flow, opportunities=len(group),
            submitted=sum(row['status'] == 'eligible' for row in group),
            semantic_double_pass=sum(row['semantic_double_pass'] and row['actual_versions_double_pass']
                                     and row['status'] == 'eligible' for row in group),
            qualified=sum(row['qualified'] for row in group),
            explanations_double_pass=sum(row['explanation_double_pass'] for row in group),
            empty_nominations=not any(row['qualified'] for row in group)))
    eligible_by_flow = {
        flow: {row['revision_identity'] for row in rows
               if row['flow'] == flow and row['status'] == 'eligible'
               and row['semantic_double_pass'] and row['actual_versions_double_pass']}
        for flow in ('TSG', 'Raw')
    }
    shared_policies = eligible_by_flow['TSG'] & eligible_by_flow['Raw']
    output = repo / 'results/graph-guided-20260930/preparation-pilot-analysis-corrected'
    write_bundle(output, {'rows.json': rows,
        'summary.json': dict(status='EXPOSED_PREPARATION_DIAGNOSTIC', by_flow=summary,
            shared_complete_policy_count=len(shared_policies),
            same_complete_policy_across_flows=bool(shared_policies),
            reviewer_sha256={name: file_sha256(path) for name, path in
                             zip(('a', 'b'), review_paths, strict=True)},
            review_input_manifest=read_json(candidates_root / 'manifest.json'),
            resource_manifest=read_json(root / 'preparation-pilot-accounting/manifest.json'),
            qwen_requests=0, scientific_effect='not measured'),
    })


def freeze_panel_preparation(repo):
    audit = repo / ROOT / 'source-audit/completed'
    verify_bundle(audit)
    panel = read_json(audit / 'panel.json')
    design_path = repo / ROOT / 'panel-execution-design.json'
    design = read_json(design_path)
    if design['status'] != 'specified' or design['qualification_status'] != 'not_qualified':
        raise ValueError('共同执行设计状态不符')
    designs = design['tasks']
    if len(panel) != 14 or len({row['task_unit_id'] for row in panel}) != 14:
        raise ValueError('冻结面板必须包含十四项独立任务')
    if len(designs) != 14 or {row['task_unit_id'] for row in designs} != {row['task_unit_id'] for row in panel}:
        raise ValueError('执行接口没有逐项覆盖冻结来源')
    by_task = {row['task_unit_id']: row for row in designs}
    if len(by_task) != 14:
        raise ValueError('执行接口任务身份重复')
    for task in panel:
        design = by_task[task['task_unit_id']]
        if (design['audit_position'] != task['audit_position']
                or not design['shared_execution_interface'] or not design['measurement']):
            raise ValueError('执行接口来源身份或测量内容错误')
    instructions = repo / 'docs/experiments/2026-09-30-semantic-preparation-instructions.md'
    statuses = []
    for task in panel:
        design = by_task[task['task_unit_id']]
        source = dict(index=task['audit_position'], task_unit_id=task['task_unit_id'],
            source_prompt=task['prompt'], system_prompt=SYSTEM,
            shared_execution_interface=design['shared_execution_interface'],
            measurement_scope=design['measurement'], role=task['role'],
            generated_code_visible=False)
        folder = repo / ROOT / 'panel-preparation-inputs' / f"case-{task['audit_position']:02d}"
        write_bundle(folder, {'source.json': source,
            'instructions.json': dict(text=instructions.read_text(encoding='utf-8'),
                                      sha256=file_sha256(instructions)),
            'protocol.json': dict(status='FROZEN_OUTCOME_BLIND_PREPARATION',
                panel=task['role'], source_audit_manifest_sha256=file_sha256(audit / 'manifest.json'),
                design_sha256=file_sha256(design_path), task_unit_id=task['task_unit_id'],
                preparation_model='same inherited Codex model and reasoning settings',
                requests_per_flow=2, flow_wall_seconds=1800,
                total_input_output_tokens=2000000, uncached_input_plus_output_tokens=200000,
                qwen_requests=0, interpretation='preparation inputs; no effect or graph advantage claim')})
        statuses.append(dict(audit_position=task['audit_position'], role=task['role'],
                             manifest_sha256=file_sha256(folder / 'manifest.json')))
    write_bundle(repo / ROOT / 'panel-preparation-index', {'tasks.json': statuses})


def freeze_panel_reviews(repo, case):
    folder = repo / ROOT / 'panel-preparation-inputs' / f'case-{case:02d}'
    verify_bundle(folder)
    source = read_json(folder / 'source.json')
    if source['index'] != case:
        raise ValueError('来源位置与审查任务不一致')
    candidates, bindings, diagnostics = [], [], {}
    for flow in ('TSG', 'Raw'):
        path = repo / ROOT / 'panel-prepared' / f'case-{case:02d}' / flow / 'final.json'
        prepared = read_json(path)
        if prepared['task_unit_id'] != source['task_unit_id']:
            raise ValueError('准备产物任务身份不一致')
        diagnostics[flow] = validate_source_support(source, prepared, flow)
        for row in prepared['opportunities']:
            semantic_class_id(row['semantic_class'])
            identity = content_hash(canonical_json([flow, row['opportunity_id']]))
            public = {key: row[key] for key in ('target', 'change_kind', 'ordinary_content',
                      'semantic_class', 'binding', 'non_target_requirements', 'common_witness',
                      'unknowns', 'competing_explanations', 'status')}
            public['review_id'] = identity
            public['reason'] = row.get('reason')
            contract = row.get('contract')
            public['contract'] = ({key: value for key, value in contract.items()
                                   if key not in {'instance_id', 'execution_identity'}}
                                  if contract else None)
            for arm in ('p', 'n'):
                edits = row.get(arm + '_edits')
                public[arm + '_versions'] = materialize_versions(source, edits) if edits else []
            if row['status'] == 'eligible' and (not public['p_versions'] or not public['n_versions']):
                raise ValueError('提交审查的机会缺少真实编辑')
            if 'Raw:' in canonical_json(public) or 'TSG:' in canonical_json(public):
                raise ValueError('审查材料包含流程身份')
            candidates.append(public)
            bindings.append(dict(review_id=identity, flow=flow,
                                 opportunity_id=row['opportunity_id'],
                                 prepared_sha256=file_sha256(path)))
    if len({row['review_id'] for row in candidates}) != len(candidates):
        raise ValueError('审查身份重复')
    review_root = repo / ROOT / 'panel-review-inputs' / f'case-{case:02d}'
    write_bundle(review_root, {
        'source.json': source, 'candidates.json': sorted(candidates, key=lambda row: row['review_id']),
        'instructions.json': dict(status='BLIND_SEMANTIC_REVIEW',
            scope='source support, complete target, Atomic boundary, non-target invariants, real versions, finite measurement',
            explanation_conditions=['two source-compatible explanations',
                'distinct observable predictions for security, direct violation, unknown or functionality',
                'existing measurement fields and common ordinary witness identified',
                'at least one result pattern excluding one explanation'],
            output='per review_id: valid/invalid/unknown for each semantic criterion; four explanation booleans; reasons; no new edits'),
    })
    write_bundle(repo / ROOT / 'panel-review-bindings' / f'case-{case:02d}', {
        'bindings.json': bindings, 'mechanical-diagnostics.json': diagnostics,
        'source_manifest.json': read_json(folder / 'manifest.json'),
    })


def freeze_panel_accounting(repo, session_root, parent_thread, case):
    folder = repo / ROOT / 'panel-preparation-inputs' / f'case-{case:02d}'
    verify_bundle(folder)
    protocol = read_json(folder / 'protocol.json')
    names = [f'/root/panel_case{case:02d}_tsg', f'/root/panel_case{case:02d}_raw']
    rows = preparation_accounting(session_root, parent_thread, names)
    for row in rows:
        flow = 'TSG' if row['agent_path'].endswith('_tsg') else 'Raw'
        path = repo / ROOT / 'panel-prepared' / f'case-{case:02d}' / flow / 'final.json'
        row['flow'] = flow
        row['final_sha256'] = file_sha256(path)
        row['recorded_token_limit_satisfied'] = (
            row['usage']['input_tokens'] + row['usage']['output_tokens']
            <= protocol['total_input_output_tokens']
            and row['uncached_input_plus_output'] <= protocol['uncached_input_plus_output_tokens'])
        row['wall_limit_satisfied'] = row['observed_seconds'] <= protocol['flow_wall_seconds']
        row['requests_limit_satisfied'] = row['top_level_requests'] == protocol['requests_per_flow']
        row['resource_qualified'] = (row['recorded_token_limit_satisfied']
                                     and row['wall_limit_satisfied']
                                     and row['requests_limit_satisfied'])
    write_bundle(repo / ROOT / 'panel-preparation-accounting' / f'case-{case:02d}', {
        'instances.json': rows,
        'summary.json': dict(status='PANEL_PREPARATION_RESOURCE_CHECK',
            case=case, same_models_and_efforts=(len({canonical_json([row['models'], row['efforts']])
                                                 for row in rows}) == 1),
            both_resource_qualified=all(row['resource_qualified'] for row in rows),
            protocol_manifest=read_json(folder / 'manifest.json')),
    })


def analyze_panel_reviews(repo, case):
    review_root = repo / ROOT / 'panel-review-inputs' / f'case-{case:02d}'
    binding_root = repo / ROOT / 'panel-review-bindings' / f'case-{case:02d}'
    verify_bundle(review_root)
    verify_bundle(binding_root)
    candidates = read_json(review_root / 'candidates.json')
    bindings = {row['review_id']: row for row in read_json(binding_root / 'bindings.json')}
    paths = [repo / ROOT / 'panel-reviews' / f'case-{case:02d}' / f'{name}.json'
             for name in ('a', 'b')]
    reviews = [read_json(path) for path in paths]
    reviewers = [{row['review_id']: row for row in review['reviews']} for review in reviews]
    identities = {row['review_id'] for row in candidates}
    if (len(identities) != len(candidates) or set(bindings) != identities
            or any(len(rows) != len(identities) or set(rows) != identities for rows in reviewers)):
        raise ValueError('面板独立评审没有完整覆盖全部机会')
    criteria = ('source_support', 'complete_target', 'atomic_boundary',
                'non_target_preservation', 'pn_versions', 'measurement_separability')
    explanation = ('two_source_compatible', 'distinct_observable_predictions',
                   'measurement_and_common_witness', 'excluding_result_pattern')
    rows = []
    for candidate in candidates:
        identity = candidate['review_id']
        opinions = [reviewer[identity] for reviewer in reviewers]
        passes = {key: all(opinion[key]['status'] == 'valid' for opinion in opinions)
                  for key in criteria}
        explained = all(all(opinion['explanation_conditions'][key] is True
                            for key in explanation) for opinion in opinions)
        qualified = candidate['status'] == 'eligible' and all(passes.values())
        rows.append(dict(review_id=identity, flow=bindings[identity]['flow'],
            opportunity_id=bindings[identity]['opportunity_id'], status=candidate['status'],
            ordinary_content=candidate['ordinary_content'],
            semantic_class_id=semantic_class_id(candidate['semantic_class']),
            criteria_double_pass=passes, explanations_double_pass=explained,
            qualified=qualified,
            revision_identity=content_hash(canonical_json([candidate['p_versions'],
                                                            candidate['n_versions']]))))
    eligible_by_flow = {flow: {row['revision_identity'] for row in rows
                         if row['flow'] == flow and row['qualified']}
                        for flow in ('TSG', 'Raw')}
    summary = dict(status='PANEL_BLIND_REVIEW_COMPLETE', case=case,
        by_flow=[dict(flow=flow,
            opportunities=sum(row['flow'] == flow for row in rows),
            submitted=sum(row['flow'] == flow and row['status'] == 'eligible' for row in rows),
            qualified=sum(row['flow'] == flow and row['qualified'] for row in rows),
            explanations_double_pass=sum(row['flow'] == flow and row['explanations_double_pass']
                                         for row in rows)) for flow in ('TSG', 'Raw')],
        shared_qualified_policy_count=len(eligible_by_flow['TSG'] & eligible_by_flow['Raw']),
        reviewer_sha256={name: file_sha256(path) for name, path in
                         zip(('a', 'b'), paths, strict=True)},
        review_input_manifest=read_json(review_root / 'manifest.json'))
    write_bundle(repo / 'results/graph-guided-20260930/panel-review-analysis' / f'case-{case:02d}', {
        'rows.json': rows, 'summary.json': summary,
    })


def assemble_uniform_training_measurement(repo):
    from prompt_mechanism_study.development.graph_guided_report import (
        discovery_action_coefficients, discovery_panel_outcomes)
    base = repo / 'data/method/graph-guided-20260929'
    results = repo / 'results/graph-guided-20260929'
    measured_root = repo / 'results/graph-guided-20260930/measurement/verified'
    verify_bundle(measured_root)
    revised = read_json(measured_root / 'rows.json')
    alias = {'development-preparation': ('development-main', 'dev-main'),
             'evaluation-preparation': ('evaluation-main', 'eval-main'),
             'targeted-generation-preparation': ('targeted-generation-main', 'targeted-gen')}
    revised_by_slot = {(row['batch'], row['slot']): row for row in revised}
    if len(revised_by_slot) != 148:
        raise ValueError('统一测量原分配身份重复或缺失')
    outcomes, effects, accounting = [], [], []
    used_revised = set()
    for batch, (result_name, revised_name) in alias.items():
        inputs = base / batch
        verify_bundle(inputs)
        assignments = read_json(inputs / 'assignments.json')
        bindings = read_json(inputs / 'bindings.json')
        candidates = read_json(inputs / 'candidates.json')
        historical = discovery_panel_outcomes(inputs, results / result_name)
        if len(historical) != len(assignments):
            raise ValueError('历史分配结果数量不完整')
        values = {}
        for assignment in assignments:
            request = assignment['request_id']
            old = historical[request]
            key = (revised_name, assignment['slot'])
            if key in revised_by_slot:
                fresh = revised_by_slot[key]
                if (fresh['request_id'] != request or fresh['task_unit_id'] != assignment['task_unit_id']
                        or fresh['index'] != assignment['index']):
                    raise ValueError('原请求与重新测量身份不符')
                if fresh['original_status'] != 'returned' and old['reason'] != fresh['original_status']:
                    raise ValueError('原生成失败状态变化')
                value = int(fresh['secure_yield'])
                if value != int(fresh['security_label'] == 'secure'):
                    raise ValueError('安全产出与重新测量标签不一致')
                observation = dict(primary=value, security_label=fresh['security_label'],
                    functionality=fresh['functionality'], coverage=fresh['security_coverage'],
                    direct_violation=fresh['direct_violation'], joint=fresh['secure_and_functional'],
                    source='20260930_remeasurement', status=fresh['original_status'])
                used_revised.add(key)
            else:
                if old['primary'][0] != old['primary'][1]:
                    observation = dict(primary=None, security_label=old['security'],
                        functionality=old['functionality'], coverage=None, direct_violation=None,
                        joint=old['joint_success'], source='historical_infrastructure_missing',
                        status=old['reason'])
                else:
                    observation = dict(primary=int(old['primary'][0]), security_label=old['security'],
                        functionality=old['functionality'], coverage=int(old['security'] in {'secure', 'insecure'}),
                        direct_violation=int(old['security'] == 'insecure'),
                        joint=old['joint_success'], source='historical_unaffected_endpoint',
                        status=old['reason'])
            values[request] = observation
            outcomes.append(dict(batch=batch, slot=assignment['slot'], request_id=request,
                task_unit_id=assignment['task_unit_id'], index=assignment['index'], **observation))
        for candidate in candidates:
            coefficients = discovery_action_coefficients(candidate['task_unit_id'],
                dict(candidate_id=candidate['candidate_id'], direction=1), assignments, bindings)
            missing = [request for request, _ in coefficients if values[request]['primary'] is None]
            delta = None if missing else sum(weight * values[request]['primary']
                                             for request, weight in coefficients)
            effects.append(dict(batch=batch, candidate_id=candidate['candidate_id'],
                task_unit_id=candidate['task_unit_id'], index=candidate['index'],
                delta_pn=delta, missing_requests=missing,
                request_weights=[[request, weight] for request, weight in coefficients]))
        accounting.append(dict(batch=batch, assignments=len(assignments), candidates=len(candidates),
                               remapped=sum(row['batch'] == batch and row['source'] ==
                                            '20260930_remeasurement' for row in outcomes)))
    if len(used_revised) != len(revised) or len(outcomes) != 744 or len(effects) != 71:
        raise ValueError('统一训练测量没有覆盖全部分配或候选')
    return dict(outcomes=outcomes, effects=effects, accounting=accounting,
                revised_manifest=read_json(measured_root / 'manifest.json'))


def freeze_uniform_training_measurement(repo):
    result = assemble_uniform_training_measurement(repo)
    write_bundle(repo / 'results/graph-guided-20260930/training-uniform-measurement', {
        'outcomes.json': result['outcomes'], 'effects.json': result['effects'],
        'summary.json': dict(status='EXPLORATORY_UNIFIED_HISTORICAL_DEVELOPMENT_MEASUREMENT',
            accounting=result['accounting'], revised_manifest=result['revised_manifest'],
            source='all three previously generated batches; original artifacts unchanged',
            mapping_and_learning='not yet applied', qwen_requests=0),
    })


def freeze_training_mapping(repo):
    source = repo / ROOT / 'training-semantic-inputs'
    verify_bundle(source)
    draft_path = repo / ROOT / 'training-semantic-mapping/draft.json'
    draft = read_json(draft_path)
    candidates = read_json(source / 'candidates.json')
    if (draft['input']['sha256'] != file_sha256(source / 'candidates.json')
            or draft['input']['protocol_sha256'] != file_sha256(source / 'protocol.json')
            or draft['visibility']['outcome_blind'] is not True
            or draft['visibility']['flow_label_blind'] is not False):
        raise ValueError('语义映射输入或实际可见范围不一致')
    expected_ids = [row['mapping_id'] for row in candidates]
    actual_ids = [row['mapping_id'] for row in draft['records']]
    if (len(expected_ids) != 71 or len(set(expected_ids)) != 71
            or len(actual_ids) != 71 or set(actual_ids) != set(expected_ids)):
        raise ValueError('语义映射没有完整覆盖历史候选')
    task_ids = {str(row['index']) for row in candidates}
    if set(draft['task_bindings']) != task_ids:
        raise ValueError('语义映射任务绑定与来源不一致')
    class_keys = set(draft['classes'])
    if not class_keys:
        raise ValueError('语义类别为空')
    for key, definition in draft['classes'].items():
        semantic_class_id(definition['semantic_class'])
        if not definition['binding_tasks'] or not set(map(str, definition['binding_tasks'])).issubset(task_ids):
            raise ValueError(f'语义类别绑定任务无效: {key}')
    for row in draft['records']:
        if row['class_key'] not in class_keys or str(row['binding']['task']) not in task_ids:
            raise ValueError('候选类别或任务引用无效')
        if (row['semantic_status'] not in {'valid', 'invalid', 'unresolved'}
                or row['training_qualification'] not in {'eligible', 'invalid', 'unresolved'}):
            raise ValueError('语义映射资格状态无效')
        if not row['evidence'] or not row['qualification_reason']:
            raise ValueError('语义映射缺少来源或资格说明')
    frozen = dict(draft, status='FROZEN_OUTCOME_BLIND_SEMANTIC_MAPPING',
                  draft_sha256=file_sha256(draft_path),
                  input_manifest_sha256=file_sha256(source / 'manifest.json'))
    write_bundle(repo / ROOT / 'training-semantic-mapping/frozen', {
        'mapping.json': frozen,
        'summary.json': dict(status='FROZEN_OUTCOME_BLIND_SEMANTIC_MAPPING',
            records=len(actual_ids), tasks=len(task_ids), classes=len(class_keys),
            eligible=sum(row['training_qualification'] == 'eligible' for row in draft['records']),
            outcome_blind=True, flow_label_blind=False,
            input_manifest_sha256=frozen['input_manifest_sha256'],
            source_draft_sha256=frozen['draft_sha256']),
    })


def freeze_training_learning(repo):
    mapping_root = repo / ROOT / 'training-semantic-mapping/frozen'
    effects_root = repo / 'results/graph-guided-20260930/training-uniform-measurement'
    input_root = repo / ROOT / 'training-semantic-inputs'
    for path in (mapping_root, effects_root, input_root):
        verify_bundle(path)
    mapping = read_json(mapping_root / 'mapping.json')
    candidates = read_json(input_root / 'candidates.json')
    effects = read_json(effects_root / 'effects.json')
    candidates_by_id = {row['mapping_id']: row for row in candidates}
    effects_by_key = {(row['batch'], row['candidate_id']): row for row in effects}
    if len(candidates_by_id) != 71 or len(effects_by_key) != 71:
        raise ValueError('训练来源或统一效果身份重复')
    rows = []
    for record in mapping['records']:
        if record['training_qualification'] != 'eligible':
            continue
        candidate = candidates_by_id[record['mapping_id']]
        effect = effects_by_key[(candidate['batch'], candidate['candidate_id'])]
        if candidate['task_unit_id'] != effect['task_unit_id'] or effect['missing_requests']:
            raise ValueError('训练候选效果与来源身份不一致或缺少分配结果')
        definition = mapping['classes'][record['class_key']]['semantic_class']
        rows.append(dict(mapping_id=record['mapping_id'], candidate_id=candidate['candidate_id'],
            batch=candidate['batch'], task_unit_id=candidate['task_unit_id'],
            semantic_class_id=semantic_class_id(definition), class_key=record['class_key'],
            canonical_text=candidate['source_prompt'] + '\n' + candidate['execution_interface'],
            p_versions=list(dict.fromkeys(candidate['p_versions'])),
            n_versions=list(dict.fromkeys(candidate['n_versions'])),
            orientation=1, delta_pn=effect['delta_pn']))
    if len(rows) != 37 or len({row['task_unit_id'] for row in rows}) < 8:
        raise ValueError('合格训练候选或独立任务数量不符')
    category = class_statistics(rows)
    features, model, tuning = fit_semantic_ridge(rows)
    supported = [value for value in category['categories'].values() if value['tasks'] >= 4]
    chosen = min(tuning, key=lambda row: (row['mse'], -row['alpha']))
    output = repo / 'results/graph-guided-20260930/training-learning'
    write_bundle(output, {
        'training-rows.json': rows,
        'category.json': category,
        'ridge.json': dict(alpha=chosen['alpha'], fit_intercept=False,
            feature_rule='orientation + oriented source/interface TFIDF + P/N mean policy TFIDF difference',
            common_vocabulary={key: int(value) for key, value in features.common.vocabulary_.items()},
            common_idf=features.common.idf_.tolist(),
            policy_vocabulary={key: int(value) for key, value in features.policy.vocabulary_.items()},
            policy_idf=features.policy.idf_.tolist(),
            coefficients=model.coef_.tolist(),
            sklearn_version=sklearn_version, numpy_version=np.__version__),
        'tuning.json': tuning,
        'summary.json': dict(status='FROZEN_EXPLORATORY_TRAINING_SELECTORS',
            candidates=len(rows), tasks=len({row['task_unit_id'] for row in rows}),
            semantic_classes=len(category['categories']),
            supported_semantic_classes=len(supported),
            maximum_class_task_support=max(value['tasks'] for value in category['categories'].values()),
            category_rule='task-equal mean with two global pseudo-observations when class support >=4; otherwise global mean',
            ridge_alpha=chosen['alpha'], ridge_task_loo_mse=chosen['mse'],
            mapping_manifest_sha256=file_sha256(mapping_root / 'manifest.json'),
            measurement_manifest_sha256=file_sha256(effects_root / 'manifest.json'),
            implementation_sha256=file_sha256(Path(__file__)),
            eval_code_visible=False),
    })


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['launch', 'preparation-pilot', 'training-semantics',
                                            'pilot-reviews', 'pilot-analysis', 'panel-preparation',
                                            'panel-reviews', 'freeze-training-mapping', 'freeze-training-learning',
                                            'training-measurement', 'controlled-launch', 'controlled-generator',
                                            'controlled-observer-inputs', 'controlled-observer-qualify',
                                            'controlled-candidate-controls', 'controlled-natural-observer-inputs',
                                            'controlled-repair-inputs', 'submit-preparation', 'submit-review'])
    parser.add_argument('--repo', type=Path, default=Path.cwd())
    parser.add_argument('--case', type=int)
    parser.add_argument('--inputs', type=Path)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--worker', type=Path)
    parser.add_argument('--submission', type=Path)
    parser.add_argument('--image')
    parser.add_argument('--workers', type=int, default=1)
    args = parser.parse_args()
    if args.command in ('submit-preparation', 'submit-review'):
        from prompt_mechanism_study.development.controlled_tasks import submit_controlled_preparation, submit_controlled_review
        if any(value is None for value in (args.inputs, args.submission, args.output)):
            raise ValueError('提交需要指定源输入、完整提交文件及输出路径')
        submit = submit_controlled_preparation if args.command == 'submit-preparation' else submit_controlled_review
        print(json.dumps(submit(args.inputs, args.submission, args.output), ensure_ascii=False))
    elif args.command == 'controlled-repair-inputs':
        from prompt_mechanism_study.development.controlled_tasks import controlled_repair_inputs
        if args.output is None:
            raise ValueError('需要指定开发测量输入目录')
        controlled_repair_inputs(args.repo.resolve(), args.output)
    elif args.command == 'controlled-launch':
        freeze_controlled_launch(args.repo.resolve())
    elif args.command == 'controlled-generator':
        from prompt_mechanism_study.development.controlled_tasks import freeze_generator
        print(json.dumps(freeze_generator(args.repo.resolve()), ensure_ascii=False))
    elif args.command in ('controlled-observer-inputs', 'controlled-candidate-controls', 'controlled-natural-observer-inputs'):
        from prompt_mechanism_study.development.controlled_tasks import controlled_observer_inputs
        from prompt_mechanism_study.development.controlled_tasks import controlled_candidate_controls
        from prompt_mechanism_study.development.controlled_tasks import controlled_natural_observer_inputs
        if args.output is None:
            raise ValueError('需要指定控制输入目录')
        if args.command == 'controlled-candidate-controls':
            controlled_candidate_controls(args.repo.resolve(), args.output)
        elif args.command == 'controlled-natural-observer-inputs':
            controlled_natural_observer_inputs(args.repo.resolve(), args.output)
        else:
            controlled_observer_inputs(args.repo.resolve(), args.output)
    elif args.command == 'controlled-observer-qualify':
        from prompt_mechanism_study.development.controlled_tasks import qualify_controlled_observer
        if any(value is None for value in (args.inputs, args.output, args.worker, args.image)):
            raise ValueError('需要指定真实控制输入、结果、观察器和镜像')
        qualify_controlled_observer(args.inputs, args.output, args.worker, args.image, args.workers)
    elif args.command == 'launch':
        freeze_launch(args.repo.resolve())
    elif args.command == 'preparation-pilot':
        freeze_preparation_pilot(args.repo.resolve())
    elif args.command == 'training-semantics':
        freeze_training_semantics(args.repo.resolve())
    elif args.command == 'pilot-reviews':
        freeze_pilot_reviews(args.repo.resolve())
    elif args.command == 'panel-preparation':
        freeze_panel_preparation(args.repo.resolve())
    elif args.command == 'panel-reviews':
        if args.case is None:
            raise ValueError('面板审查必须指定来源位置')
        freeze_panel_reviews(args.repo.resolve(), args.case)
    elif args.command == 'freeze-training-mapping':
        freeze_training_mapping(args.repo.resolve())
    elif args.command == 'freeze-training-learning':
        freeze_training_learning(args.repo.resolve())
    elif args.command == 'pilot-analysis':
        analyze_pilot_reviews(args.repo.resolve())
    else:
        freeze_uniform_training_measurement(args.repo.resolve())
