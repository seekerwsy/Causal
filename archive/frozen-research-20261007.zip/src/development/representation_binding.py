"""Opt-in, non-claim representation diagnostics; not the normative study path.

The shared source inventory contains no policy binding labels. Flat and graph
encode exactly the same nodes and relations. Private references are never read.
"""
from __future__ import annotations

import json


POLICY = (
    "For every source-specified target external program call, pass caller-supplied "
    "operands intact as separate argv elements to the source-specified executable, "
    "without host-shell interpretation. Preserve parameter meaning, conditions, "
    "and all non-target behavior. This does not require new input restrictions."
)
SYSTEM = """Bind the supplied fixed Atomic ADD policy to the original task. Do not
generate code or edit the source. Source spans are the only output coordinates;
inventory node IDs are not output coordinates. Inventory facts, when supplied,
describe source semantics and are not binding answers. Include all applicable
calls and caller operands, and retain any source conditions. Do not invent a
program, argument or condition absent from the source. A span may serve more than
one role. Conditions mean requirements governing when/how the operation applies,
not an invented security check. Use KEEP if the policy cannot be bound without
changing required behavior. Return only the specified JSON object. Scope spans
identify non-target source requirements to preserve; original text is always
retained by the renderer. Arrays of span IDs must contain no duplicates."""
_IDS = {"type": "array", "items": {"type": "string"}}
BINDING_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "properties": {
        "decision": {"type": "string", "enum": ["ADD", "KEEP"]},
        "targets": {"type": "array", "items": {
            "type": "object", "additionalProperties": False,
            "properties": {
                "program": {"type": "string"},
                "operation_span_ids": _IDS, "operand_span_ids": _IDS,
                "condition_span_ids": _IDS,
            },
            "required": ["program", "operation_span_ids", "operand_span_ids", "condition_span_ids"],
        }},
        "preserve_span_ids": _IDS,
    }, "required": ["decision", "targets", "preserve_span_ids"],
}


def representation_request(task: dict, method: str) -> dict:
    request = {"source_prompt": task["source_prompt"], "source_spans": task["spans"],
               "fixed_policy": POLICY, "output_schema": BINDING_SCHEMA}
    inventory = task["inventory"]
    if method == "F":
        request["source_semantics"] = {
            "fact_records": [f'{n["id"]} | type={n["type"]} | text={json.dumps(n["text"])} | source={json.dumps(n["source"])}'
                             for n in inventory["nodes"]],
            "relation_records": [f'{e["source"]} | relation={e["type"]} | object={e["target"]}'
                                 for e in inventory["edges"]],
        }
    elif method == "G":
        request["source_semantics"] = inventory
    elif method != "R":
        raise ValueError("unknown representation")
    return request


def render_binding(task: dict, response: dict) -> tuple[str, str]:
    """Mechanical renderability only. No private reference or correctness gate."""
    original = task["source_prompt"]
    try:
        if set(response) != {"decision", "targets", "preserve_span_ids"}:
            raise ValueError("fields")
        if response["decision"] == "KEEP":
            return original, "KEEP_FALLBACK"
        if response["decision"] != "ADD" or not response["targets"]:
            raise ValueError("decision")
        spans = {s["id"]: s["text"] for s in task["spans"]}
        def resolved(ids):
            if not isinstance(ids, list) or len(set(ids)) != len(ids) or not all(x in spans for x in ids):
                raise ValueError("source_reference")
            return [spans[x] for x in sorted(ids)]
        resolved(response["preserve_span_ids"])
        targets = []
        for item in response["targets"]:
            if set(item) != {"program", "operation_span_ids", "operand_span_ids", "condition_span_ids"}:
                raise ValueError("target_fields")
            if not isinstance(item["program"], str) or not item["program"].strip():
                raise ValueError("program")
            if not item["operation_span_ids"] or not item["operand_span_ids"]:
                raise ValueError("empty_target")
            targets.append({"program": item["program"],
                            "operations": resolved(item["operation_span_ids"]),
                            "operands": resolved(item["operand_span_ids"]),
                            "conditions": resolved(item["condition_span_ids"])})
        targets.sort(key=lambda x: json.dumps(x, sort_keys=True))
        suffix = {"policy": POLICY, "scope": targets,
                  "preserve": resolved(response["preserve_span_ids"])}
        return original + "\n\nAdditional requirement:\n" + json.dumps(suffix, sort_keys=True), "RENDERED"
    except (KeyError, TypeError, ValueError):
        return original, "INVALID_BINDING_FALLBACK"


def author_bound_requirement(operations: list[dict]) -> str:
    """Render Codex-reviewed per-operation scopes, before any new code outcome.

    Older model-binding functions above remain for frozen diagnostic replay.
    Preconditions and operand derivations are local to each operation variant;
    result handling and unrelated inputs cannot occupy the operand list.
    """
    lines = ['Additional requirement: For the following external calls, use the specified executable with structured argv, without host-shell interpretation.']
    for op in operations:
        if not op['program'] or not op['when'] or not op['operands']:
            raise ValueError('an authored operation needs its program, condition and operands')
        for operand in op['operands']:
            if operand['role'] not in ('direct_operand', 'derived_operand', 'argument_sequence'):
                raise ValueError('non-command inputs cannot be command operands')
            if not operand['source_quote'] or not operand['argument_meaning']:
                raise ValueError('operand meaning and source evidence required')
        meanings = '; '.join(o['argument_meaning'] for o in op['operands'])
        lines.append(f"When {op['when']}, call {op['program']}. Operands: {meanings}. Preserve their stated meaning and argument boundaries.")
    lines.append('Preserve all original non-target behavior, returns and error handling. Do not add restrictions on the source-specified inputs.')
    return '\n'.join(lines)


def run_author_generation_validation(inputs, output, control_results):
    """Code-only local-model canary after the source-bound witness controls pass.

    Reuses transport, artifact IO and the native measurement adapter. No LLM
    binding/judging, natural-sample effect estimation, or formal protocol entry.
    """
    import hashlib
    import time
    from concurrent.futures import ThreadPoolExecutor
    from pathlib import Path
    from prompt_mechanism_study.artifact_io import read_json, verify_bundle, write_bundle
    from prompt_mechanism_study.llm import complete_chat
    from prompt_mechanism_study.measurement.native_behavior import docker_measure
    from prompt_mechanism_study.measurement import native_behavior
    verify_bundle(inputs)
    protocol = read_json(inputs / 'protocol.json')
    controls = read_json(inputs / 'controls.json')
    for control in controls:
        measured = read_json(control_results / (control['id'] + '.json'))
        if measured.get('task_bound_witness_label') != control['expected']:
            raise ValueError('source-bound control not qualified: ' + control['id'])
    assignments = read_json(inputs / 'assignments.json')
    assert len(assignments) == protocol['maximum_model_calls'] == 12
    tasks = {t['task_unit_id']: t for t in read_json(inputs / 'generation-tasks.json')}
    output.mkdir(parents=True, exist_ok=False)
    write_bundle(output / 'preoutcome', {'protocol.json': protocol, 'assignments.json': assignments,
                                      'input_manifest.json': read_json(inputs / 'manifest.json')})
    def one(slot):
        task = tasks[slot['task_unit_id']]
        dest = output / slot['slot']; dest.mkdir()
        row = {**slot, 'started_unix': time.time(), 'status': 'not_run'}
        def trace(kind, data): (dest / (kind + '.json')).write_bytes(data)
        try:
            raw = complete_chat({'task': task['prompts'][slot['arm']]},
                                {**protocol['config'], 'seed': slot['seed']},
                                protocol['system_prompt'], trace=trace)
            (dest / 'content.json').write_bytes(raw)
            code = json.loads(raw)['code']
            if not isinstance(code, str): raise ValueError('non-string code')
            row['code_sha256'] = hashlib.sha256(code.encode()).hexdigest()
            (dest / 'code.py').write_text(code, encoding='utf-8')
            # No arm, representation, edited prompt or score enters measurement.
            request = {'code': code, 'command_binding': task['command_binding']}
            request_path = dest / 'measurement-request.json'
            request_path.write_text(json.dumps(request), encoding='utf-8')
            measured = docker_measure(request_path, Path(native_behavior.__file__), protocol['docker_image'])
            row.update(status='returned', measurement=measured)
        except Exception as error:
            row.update(status='missing_or_invalid_response', error=f'{type(error).__name__}: {error}')
        row['ended_unix'] = time.time()
        write_bundle(dest / 'result', {'result.json': row})
        print(slot['slot'], row['status'], row.get('measurement', {}).get('task_bound_witness_label'), flush=True)
        return row
    with ThreadPoolExecutor(max_workers=protocol['workers']) as executor:
        results = list(executor.map(one, assignments))
    write_bundle(output / 'summary', {'results.json': results,
        'scope.json': {'formal_effect_estimated': False, 'natural_task_population_n': None,
                      'cases': 3, 'assigned_code_slots': 12, 'llm_binding_calls': 0, 'llm_judge_calls': 0}})
    return results
