from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import subprocess
import time
import math
from collections import Counter, defaultdict
from datetime import datetime, timezone
from fractions import Fraction
from difflib import SequenceMatcher
from pathlib import Path

import numpy as np
from markdown_it import MarkdownIt
from scipy.stats import random_table

from prompt_mechanism_study.artifact_io import file_sha256, read_json, verify_bundle, write_bundle
from prompt_mechanism_study.records import canonical_json, content_hash
from prompt_mechanism_study.development.structure_policy_cpu import RWorker, random_stream
from prompt_mechanism_study.development.graph_guided_decisions import fit_task_equal_ridge


LABELS = ('C', 'X1', 'X2', 'X3', 'Y')


def validate_controlled_natural_source_qualification(root, qualification=None):
    root = root.resolve()
    repo = root.parents[2]
    qualification = (read_json(root / 'natural-source-qualification.json')
                     if qualification is None else qualification)
    fields = {'dispositions', 'input_sha256', 'main_outcomes_seen', 'protected_prompt_file_read',
              'qualification_rule', 'reference_universe_count', 'result_values_read',
              'selector_results_seen', 'source_count', 'status', 'unresolved_scope'}
    inputs = ('natural-contract-fingerprints.json', 'reference-contract-fingerprints.json',
              'natural-source-review.json', 'natural-source-acquisition/frame/manifest.json')
    if (set(qualification) != fields
            or qualification['status'] != 'COMPLETED_OUTCOME_BLIND_SOURCE_QUALIFICATION'
            or qualification['source_count'] != 419 or qualification['reference_universe_count'] != 2171
            or any(qualification[key] is not False for key in (
                'main_outcomes_seen', 'protected_prompt_file_read', 'result_values_read', 'selector_results_seen'))
            or qualification['input_sha256'] != {name: file_sha256(root / name) for name in inputs}
            or any(not isinstance(qualification[key], str) or not qualification[key].strip()
                   for key in ('qualification_rule', 'unresolved_scope'))):
        raise ValueError('自然来源资格的完成状态、盲态或输入身份不符')
    identity_metadata = read_json(root / 'natural-source-identity-audit/metadata.json')
    if (len(identity_metadata['metadata_sha256']) != 7
            or identity_metadata['source_identities'] != 419
            or identity_metadata['source_manifest_sha256'] != qualification['input_sha256'][inputs[3]]
            or identity_metadata['result_values_read'] is not False
            or identity_metadata['protected_source_text_used_for_preparation'] is not False):
        raise ValueError('自然身份审查元数据范围不符')
    for name, digest in identity_metadata['metadata_sha256'].items():
        if file_sha256(repo / Path(name.replace('\\', '/'))) != digest:
            raise ValueError('自然身份审查的保护或暴露元数据已经变化')
    natural, reference = (read_json(root / name) for name in inputs[:2])
    if (natural['natural_source_count'] != 419 or natural['current_development_count'] != 6
            or reference['reference_task_count'] != 2165
            or any(payload['result_values_read'] is not False for payload in (natural, reference))):
        raise ValueError('自然资格需要完整自然、既有及开发参照范围')
    for payload in (natural, reference):
        for row in payload['records']:
            if (row['fingerprint_sha256'] != content_hash({key: value for key, value in row.items()
                                                        if key != 'fingerprint_sha256'})
                    or row['functional_fields_sha256'] != content_hash(row['functional_fields'])):
                raise ValueError('自然资格的指纹内容哈希不符')
    sources = [row for row in natural['records'] if row['identity']['origin'] == 'natural-source-review']
    development = [row for row in natural['records'] if row['identity']['origin'] == 'controlled-development']
    references = {row['identity']['task_unit_id']: row for row in [*reference['records'], *development]}
    if (len(natural['records']) != 425 or len(sources) != 419 or len(development) != 6
            or len(reference['records']) != 2165 or len(references) != 2171
            or len({row['identity']['task_unit_id'] for row in natural['records']}) != 425):
        raise ValueError('自然资格的来源或参照身份存在重复或遗漏')
    reviews = read_json(root / 'natural-source-review.json')['reviews']
    by_position = {review['position']: review for review in reviews}
    if len(by_position) != 419 or len(reviews) != 419 or set(by_position) != set(range(1, 420)):
        raise ValueError('自然来源审查存在身份重复或遗漏')
    reviews = [by_position[position] for position in range(1, 420)]
    frame = read_json(root / 'natural-source-acquisition/frame/sources.json')
    dispositions = qualification['dispositions']
    if any(len(rows) != 419 for rows in (sources, reviews, frame, dispositions)):
        raise ValueError('自然资格没有完整覆盖逐来源处置')
    counts = dict(OUTSIDE_TASK_SCOPE=0, UNKNOWN_IDENTITY=0, NOT_ESTABLISHED=0)
    reference_ids = set()
    for position, (source, review, original, disposition) in enumerate(
            zip(sources, reviews, frame, dispositions, strict=True), 1):
        identity = source['identity']
        if (identity['source_position'] != position or review['position'] != position
                or original['source_position'] != position or disposition['source_position'] != position
                or identity['task_unit_id'] != original['source_id']
                or disposition['source_id'] != identity['task_unit_id']
                or identity['original_url'] != original['original_url']
                or identity['source_record_sha256'] != original['source_snapshot_sha256']
                or identity['source_review_sha256'] != content_hash(review)
                or disposition['fingerprint_sha256'] != source['fingerprint_sha256']
                or source['functional_fields'] != {key: value for key, value in review.items() if key in {
                    'status', 'basis', 'family', 'contract', 'target_input', 'requirements_to_preserve', 'reason'}}):
            raise ValueError(f'自然资格的来源身份、顺序或实际来源审查不符：{position}')
        core = {'source_position', 'source_id', 'fingerprint_sha256', 'status'}
        if review['status'] == 'outside_task_scope':
            if (set(disposition) != core | {'source_review_sha256'}
                    or disposition['status'] != 'OUTSIDE_TASK_SCOPE'
                    or disposition['source_review_sha256'] != identity['source_review_sha256']):
                raise ValueError('范围外来源处置与实际来源审查不符')
        else:
            if (set(disposition) != core | {'witnesses'} or disposition['status'] != 'UNKNOWN_IDENTITY'
                    or not isinstance(disposition['witnesses'], list) or not disposition['witnesses']):
                raise ValueError('自然来源独立资格尚未建立或缺少必要未知见证')
            witness_ids = set()
            for witness in disposition['witnesses']:
                if (set(witness) != {'decision', 'missing_reference_facts', 'reference_fingerprint_sha256',
                                    'reference_task_unit_id', 'source_operation_basis', 'why_needed_for_identity'}
                        or witness['decision'] != 'UNKNOWN'
                        or witness['reference_task_unit_id'] not in references
                        or witness['reference_task_unit_id'] in witness_ids
                        or witness['reference_fingerprint_sha256'] !=
                            references[witness['reference_task_unit_id']]['fingerprint_sha256']):
                    raise ValueError('必要未知见证的参照绑定不符')
                for key in ('missing_reference_facts', 'source_operation_basis', 'why_needed_for_identity'):
                    if (not isinstance(witness[key], str) or not witness[key].strip()
                            or not any('\u4e00' <= character <= '\u9fff' for character in witness[key])):
                        raise ValueError('必要未知见证需要非空中文功能依据')
                witness_ids.add(witness['reference_task_unit_id'])
                reference_ids.add(witness['reference_task_unit_id'])
        counts[disposition['status']] += 1
    return dict(source_count=419, qualified_source_count=0, reference_universe_count=2171,
                source_disposition_counts=counts, reference_ids_count=len(reference_ids))


def _validate_controlled_natural_qualification_review(root, qualification, review, summary):
    positions = [row['source_position'] for row in qualification['dispositions']
                 if row['status'] == 'UNKNOWN_IDENTITY']
    if (review['status'] != 'PASS' or review['semantic_review_performed'] is not True
            or review['qualification_sha256'] != file_sha256(root / 'natural-source-qualification.json')
            or review['reviewed_source_positions'] != positions
            or review['invalid_witness_source_positions'] != []
            or review['reference_ids_count'] != summary['reference_ids_count']
            or any(review[key] is not False for key in (
                'main_outcomes_seen', 'selector_results_seen', 'protected_prompt_file_read', 'result_values_read'))):
        raise ValueError('自然资格冻结需要完整独立实际语义审查通过')


def _validate_controlled_natural_preparation_costs(costs):
    by_agent = {row['agent_path']: row for row in costs}
    if len(by_agent) != len(costs):
        raise ValueError('自然准备资源记录重复覆盖同一实际实例')
    for path in ('/root/natural_identity_qualification_witnesses', '/root/natural_qualification_independent_audit'):
        if path not in by_agent:
            raise ValueError('自然资格缺少作者或独立审查的实际资源记录')
        row = by_agent[path]
        if (row['top_level_requests'] != 1 or row['models'] != ['gpt-6.1-sol']
                or row['efforts'] != ['high'] or row['usage'] is None
                or row['usage']['output_tokens'] > 12000):
            raise ValueError('自然资格作者或独立审查超出授权模型、轮次或输出预算')


def freeze_controlled_natural_preparation(root, output):
    from prompt_mechanism_study.development.source_generation import MODEL, SYSTEM
    root = root.resolve()
    repo = root.parents[2]
    if (root != repo / 'data/method/controlled-semantic-20260930'
            or output.resolve() != root / 'natural-preparation'):
        raise ValueError('自然准备冻结需要使用规定的研究目录')
    if output.exists():
        raise FileExistsError(output)
    for folder in ('natural-source-acquisition/frame', 'natural-source-identity-audit',
                   'development-qualified-inputs', 'model-identity'):
        verify_bundle(root / folder)
    summary = validate_controlled_natural_source_qualification(root)
    qualification = read_json(root / 'natural-source-qualification.json')
    review = read_json(root / 'natural-source-qualification-review.json')
    _validate_controlled_natural_qualification_review(root, qualification, review, summary)
    costs = read_json(root / 'natural-preparation-costs.json')
    _validate_controlled_natural_preparation_costs(costs)
    environment = read_json(root / 'development-qualified-inputs/environment.json')
    if environment['model'] != MODEL or environment['system_prompt'] != SYSTEM:
        raise ValueError('自然准备的模型身份与授权生成策略不符')
    environment.update(model_manifest_sha256=file_sha256(root / 'model-identity/manifest.json'),
        worker_sha256=file_sha256(repo / 'src/measurement/natural_command.py'),
        measurement_sha256=file_sha256(repo / 'src/measurement/controlled_command.py'),
        runtime_sha256=file_sha256(repo / 'docs/experiments/2026-09-30-jci-runtime.py'))
    results = repo / 'results/controlled-semantic-20260930'
    if any(list((results / phase).glob('*/assigned/manifest.json')) for phase in ('training', 'evaluation', 'natural')):
        raise ValueError('主结果出现后不能冻结自然资格和适用集合')
    metadata = dict(summary, status='FROZEN_OUTCOME_BLIND_NATURAL_PREPARATION', task_count=0,
        source_manifest_sha256=file_sha256(root / 'natural-source-acquisition/frame/manifest.json'),
        qualification_sha256=file_sha256(root / 'natural-source-qualification.json'),
        qualification_review_sha256=file_sha256(root / 'natural-source-qualification-review.json'),
        preparation_costs_sha256=file_sha256(root / 'natural-preparation-costs.json'),
        input_sha256=qualification['input_sha256'], main_discovery_outcomes_seen=False,
        selector_results_seen=False, result_values_read=False, protected_prompt_file_read=False,
        reason='范围内自然来源存在必要未知独立性关系，无法进入自然验证；其余参照及自然来源内部关系保持未比较。',
        frozen_at_utc=datetime.now(timezone.utc).isoformat())
    write_bundle(output, {'tasks.json': [], 'policy-sets.json': controlled_natural_policy_sets([]),
        'environment.json': environment, 'metadata.json': metadata, 'qualification.json': qualification,
        'qualification-review.json': review,
        'preparation-costs.json': costs,
        'natural-contract-fingerprints.json': read_json(root / 'natural-contract-fingerprints.json'),
        'reference-contract-fingerprints.json': read_json(root / 'reference-contract-fingerprints.json'),
        'identity-audit-metadata.json': read_json(root / 'natural-source-identity-audit/metadata.json')})
    return metadata


def audit_exposure(root, output):
    verify_bundle(root / 'source-check')
    sources = read_json(root / 'source-check/source-records.json')
    tokens = defaultdict(set)
    for row in sources:
        for key in ('task_unit_id', 'near_duplicate_group_id', 'prompt_sha256', 'source_task_record_sha256'):
            tokens[row[key]].add(row['case_id'])
    command = ['rg', '--json', '--only-matching', '--fixed-strings']
    for token in tokens:
        command.extend(['-e', token])
    command.extend(['data/method', 'docs/experiments'])
    completed = subprocess.run(command, capture_output=True, text=True, encoding='utf-8', check=True)
    matches = defaultdict(lambda: defaultdict(set))
    for line in completed.stdout.splitlines():
        event = json.loads(line)
        if event['type'] != 'match':
            continue
        data = event['data']
        path = data['path']['text'].replace('\\', '/')
        if '/jci-ridge-20260930/' in path:
            continue
        for submatch in data['submatches']:
            token = submatch['match']['text']
            for case_id in tokens[token]:
                matches[case_id][path].add(token)
    records = [dict(case_id=row['case_id'], task_unit_id=row['task_unit_id'],
                    path_matches=[dict(path=path, matched_identity_tokens=sorted(values))
                                  for path, values in sorted(matches[row['case_id']].items())])
               for row in sources]
    write_bundle(output, {'records.json': records, 'metadata.json': dict(
        source_manifest_sha256=file_sha256(root / 'source-check/manifest.json'),
        generated_content_read=False, result_values_read=False,
        search_mode='rg identity substrings and file paths only')})
    print(json.dumps(dict(tasks=len(records), paths=sum(len(r['path_matches']) for r in records))))


def prepare_semantics(root, output, case_ids=None):
    verify_bundle(root / 'source-check')
    sources = {row['case_id']: row for row in read_json(root / 'source-check/source-records.json')}
    author = read_json(root / 'manual-tsg-policies.json')
    records = []
    for item in author:
        source = sources[item['case_id']]
        text = source['prompt']
        if content_hash(text) != source['prompt_sha256']:
            raise ValueError('来源文本身份不匹配')
        nodes = {}
        declared_nodes = list(item['nodes'])
        declared_edges = list(item['edges'])
        response_format = "Only return the code, don't include any other information,\n    such as a preamble or suffix."
        # 独立审查明确指出的共有响应义务按精确原文登记。
        if response_format in text:
            declared_nodes.append(['source_response_format', 'output_format', response_format])
            declared_edges.append(['source_response_format', 'constrains_response', 'operation'])
        for identity, kind, quote in declared_nodes:
            if identity in nodes or text.count(quote) != 1:
                raise ValueError(f'{item["case_id"]}/{identity}: 来源定位不唯一')
            start = text.index(quote)
            nodes[identity] = dict(id=identity, kind=kind, quote=quote,
                                   start_character=start, end_character=start + len(quote),
                                   start_byte=len(text[:start].encode()),
                                   end_byte=len(text[:start + len(quote)].encode()),
                                   quote_sha256=hashlib.sha256(quote.encode()).hexdigest())
        if not nodes or len(item['anchor_ids']) > 6 or not set(item['anchor_ids']) <= nodes.keys():
            raise ValueError('来源节点或六锚点约束不满足')
        for left, relation, right in declared_edges:
            if left not in nodes or right not in nodes or not relation:
                raise ValueError('语义边引用未知节点')
        policies = []
        seen_slots = set()
        for policy in item['policies']:
            slot = policy['slot']
            if slot not in (1, 2) or slot in seen_slots or not set(policy['target_nodes']) <= nodes.keys():
                raise ValueError('候选槽或目标绑定不满足')
            seen_slots.add(slot)
            operation = policy['operation']
            if operation == 'DELETE_NONEXHAUSTIVE_EXAMPLE':
                target = nodes[policy['delete_node']]
                if target['kind'] != 'nonexhaustive_example':
                    raise ValueError('删除目标缺少非穷尽示例标记')
                edited = text[:target['start_character']] + text[target['end_character']:]
                deleted, added = len(target['quote']), 0
            elif operation == 'ADD_OPTIONAL_IMPLEMENTATION_CUE':
                if not policy['added_text'].startswith('Implementation hint:'):
                    raise ValueError('新增线索必须显式标记为可选线索')
                edited = text + '\n\n' + policy['added_text']
                deleted, added = 0, 2 + len(policy['added_text'])
            elif operation == 'MOVE_QUALIFIER_TO_OPERATION':
                target = nodes[policy['move_node']]
                destination = nodes[policy['destination_node']]
                original = policy.get('remove_prefix', '') + target['quote']
                if text.count(original) != 1:
                    raise ValueError('移动单元不唯一')
                edited = text.replace(original, '', 1)
                if edited.count(destination['quote']) != 1:
                    raise ValueError('移动目标已被删除或不唯一')
                edited = edited.replace(destination['quote'], destination['quote'] + ' ' + target['quote'], 1)
                deleted, added = len(original), 1 + len(target['quote'])
            else:
                raise ValueError(operation)
            if edited == text:
                raise ValueError('候选没有改变全文')
            full = edited + item['call_contract']
            states = policy['states']
            base = item['source_states']
            delta = [None if a is None or b is None else a-b for a, b in zip(states, base, strict=True)]
            features = [*base, *delta,
                        int(operation == 'DELETE_NONEXHAUSTIVE_EXAMPLE'),
                        int(operation == 'MOVE_QUALIFIER_TO_OPERATION'),
                        int(operation == 'ADD_OPTIONAL_IMPLEMENTATION_CUE'),
                        *policy['relation_features'], min(1., (deleted + added) / max(1, len(text)))]
            if len(features) != 13:
                raise ValueError('候选特征数量必须为13')
            policies.append(dict(policy, edited_prompt=full, features=features,
                                 policy_hash=hashlib.sha256(full.encode()).hexdigest(),
                                 new_content_status='NEW_CUE' if added and not deleted else 'SOURCE_CONTENT',
                                 changed_states={name: delta[i] for i, name in enumerate(('X_ex','X_cue','X_local'))
                                                 if states[i] != base[i]}))
        baseline = text + item['call_contract']
        tokens = MarkdownIt().parse(text)
        units = [dict(type=token.type, line_range=token.map) for token in tokens
                 if token.map is not None and token.type in ('paragraph_open','list_item_open','fence','code_block')]
        covered = {offset for node in nodes.values()
                   for offset in range(node['start_character'], node['end_character'])}
        record = dict(item, nodes=list(nodes.values()), edges=declared_edges, policies=policies,
                      task_unit_id=source['task_unit_id'], source_lineage_id=source['source_lineage_id'],
                      source_prompt=text, source_prompt_sha256=source['prompt_sha256'], baseline_prompt=baseline,
                      baseline_hash=hashlib.sha256(baseline.encode()).hexdigest(),
                      markdown_units=units, source_character_coverage=len(covered)/len(text),
                      semantic_review_status='PENDING_INDEPENDENT_REVIEW',
                      evidence_level='AUTHOR_PREPARED_DEVELOPMENT_INPUT_NO_MODEL_OUTCOMES')
        records.append(record)
    if len({item['case_id'] for item in records}) != len(records):
        raise ValueError('重复来源身份')
    if case_ids is not None:
        if not set(case_ids) <= {row['case_id'] for row in records}:
            raise ValueError('指定了尚未准备的来源')
        records = [row for row in records if row['case_id'] in case_ids]
    write_bundle(output, {'records.json': records,
                         'inputs.json': {'manual_sha256': file_sha256(root/'manual-tsg-policies.json'),
                                         'source_manifest_sha256': file_sha256(root/'source-check/manifest.json')}})
    print(json.dumps(dict(tasks=len(records), policies=sum(len(row['policies']) for row in records),
                          output=str(output))))


def freeze_inputs(root, prepared, qualification, output):
    if read_json(root / 'launch/launch.json').get('protocol_id') == 'controlled-semantic-20260930':
        return freeze_controlled_inputs(root, qualification, output)
    for name in ('launch', 'source-check', 'exposure-paths', 'command-final-inputs'):
        verify_bundle(root / name)
    verify_bundle(prepared)
    now = datetime.now(timezone.utc)
    launch = read_json(root / 'launch/launch.json')
    if now >= datetime.fromisoformat(launch['preparation_deadline_utc']):
        raise ValueError('准备期限已结束')
    records = read_json(prepared / 'records.json')
    admitted = [row for row in records if row['semantic_review_status'] == 'QUALIFIED']
    cases = {row['case_id'] for row in admitted}
    controls = read_json(qualification / 'summary.json')
    manifest = read_json(root / 'command-final-inputs/manifest.json')
    if {row['input'] for row in controls} != set(manifest['files']):
        raise ValueError('实际资格未覆盖完整冻结控制')
    if not all(row['matched'] and row['status'] == 'measured' for row in controls):
        raise ValueError('共同测量环境未通过资格')
    measurements = {}
    for row in controls:
        control = read_json(root / 'command-final-inputs' / row['input'])
        actual = read_json(qualification / row['input'])
        if actual['security_label'] != control['expected_label'] or actual['status'] != 'measured':
            raise ValueError('资格摘要与原始测量不一致')
        case = control['command_execution']['case_id']
        measurements[case] = control['command_execution']
    if set(measurements) != cases:
        raise ValueError('来源资格与观察器集合不相同')
    sources = read_json(root / 'source-check/source-records.json')
    if len({row['task_unit_id'] for row in admitted}) != len(admitted):
        raise ValueError('独立任务重复')
    source_map = {row['case_id']: row for row in sources}
    if len({source_map[row['case_id']]['near_duplicate_group_id'] for row in admitted}) != len(admitted):
        raise ValueError('近重复组未去重')
    audited = {row['case_id']: row for row in read_json(root / 'exposure-paths/records.json')}
    old_path = Path('data/method/structure-binding-development-20260926/development-exposure.json')
    old = read_json(old_path)
    previous = {row['task_unit_id']: row for row in old['withheld']}
    prior_source = {row['task_unit_id'] for row in old['tasks']}
    exposure = []
    for row in admitted:
        paths = {item['path'] for item in audited[row['case_id']]['path_matches']}
        mentions = previous.get(row['task_unit_id'], {}).get('existing_mentions', [])
        if isinstance(mentions, str):
            mentions = [mentions]
        paths.update(path.replace('\\', '/') for path in mentions)
        evidence = sorted(path for path in paths if any(token in path for token in (
            '/results/', '/run/graphs/', '/run/candidates/', '-gold-', '/native-calibration-inputs/'))
            or ('/frozen/' in path and '/assignments' in path))
        exposure.append(dict(case_id=row['case_id'], task_unit_id=row['task_unit_id'],
                             prior_method_result_exposed=bool(evidence), evidence_paths=evidence,
                             prior_source_preparation_exposed=row['task_unit_id'] in prior_source,
                             current_author_and_reviewer_preparation_exposed=True))
    exposed = {row['task_unit_id'] for row in exposure if row['prior_method_result_exposed']}
    evaluation_count = min(24, len(admitted)//3)
    order = []
    for was_exposed in (False, True):
        lineages = defaultdict(list)
        for row in admitted:
            if (row['task_unit_id'] in exposed) == was_exposed:
                lineages[row['source_lineage_id']].append(row)
        for group in lineages.values():
            group.sort(key=lambda row: hashlib.sha256(row['task_unit_id'].encode()).hexdigest())
        while any(lineages.values()):
            for lineage in sorted(lineages):
                if lineages[lineage]:
                    order.append(lineages[lineage].pop(0)['task_unit_id'])
    evaluation_ids = set(order[:evaluation_count])
    training = [row for row in admitted if row['task_unit_id'] not in evaluation_ids]
    for row in admitted:
        row['role'] = 'evaluation' if row['task_unit_id'] in evaluation_ids else 'training'
        row['measurement'] = measurements[row['case_id']]
    requests = mixed_training_requests(training, 'jci-ridge-20260930-training')
    mixed = [row['request_id'] for row in requests if row['component'] == 'random_mixture']
    subsets = []
    for index in range(100):
        rng = random_stream('jci-ridge-20260930', 'structure-subsample', index)
        selected = sorted(rng.choice(len(mixed), size=int(.8*len(mixed)), replace=False).tolist())
        subsets.append(dict(index=index, request_ids=[mixed[i] for i in selected]))
    disposition = read_json(root / 'preparation-dispositions.json')
    pending = {row['case_id']: row for row in disposition['remaining_independent_cases']}
    reviewed = {row['case_id']: row for row in records}
    initial = {row[0]: row[1:] for row in read_json(root / 'manual-source-review.json')['rows']}
    source_disposition = []
    for row in sources:
        case = row['case_id']
        if case in cases:
            status, reason = 'ADMITTED', '语义、独立身份和真实观察资格通过'
        elif case in reviewed:
            status, reason = 'SEMANTIC_CONTRACT_UNQUALIFIED', reviewed[case]['semantic_judgment'].get('reason_summary', '一次独立合同审查未通过')
        elif case in pending:
            status, reason = pending[case]['status'], pending[case]['reason']
        elif case in disposition['duplicates']:
            status, reason = 'DUPLICATE', disposition['duplicates'][case]
        else:
            status, reason = initial[case]
            if status == 'POTENTIAL_DATA_BOUNDARY':
                raise ValueError('独立候选缺少准备处置')
        source_disposition.append(dict(case_id=case, status=status, reason=reason))
    identities = {path.as_posix(): file_sha256(path) for path in (
        prepared / 'manifest.json', root / 'launch/manifest.json', root / 'exposure-paths/manifest.json',
        root / 'command-final-inputs/manifest.json', qualification / 'summary.json', old_path,
        root / 'preparation-dispositions.json', Path(__file__),
        Path('src/measurement/command_execution.py'), Path('src/measurement/native_behavior.py'),
        root / 'Dockerfile.measurement')}
    metadata = dict(frozen_at_utc=now.isoformat(), protocol_id=launch['protocol_id'],
                    M=len(admitted), H=len(training), E=evaluation_count, training_calls=len(requests),
                    graph_mixture_requests=len(mixed), graph_subsamples=100,
                    evidence_level='AUTHORIZED_BOUNDED_DEVELOPMENT_RESEARCH',
                    unseen_task_claim=False, qualification_controls=len(controls),
                    docker_image='sha256:45ff9ac28f50665ab8bd1f85ed6023779c8107fb6970d283bfcd90fd7187694e',
                    qualification_result_sha256={row['input']: file_sha256(qualification / row['input']) for row in controls})
    write_bundle(output, {'tasks.json': admitted, 'training-requests.json': requests,
                         'structure-subsamples.json': subsets, 'source-disposition.json': source_disposition,
                         'exposure.json': exposure, 'metadata.json': metadata, 'input-identities.json': identities})
    print(json.dumps(metadata))


def freeze_controlled_inputs(root, qualification, output):
    from prompt_mechanism_study.development.controlled_tasks import assemble_main_semantics, controlled_rng
    from prompt_mechanism_study.development.source_generation import MODEL, SYSTEM
    repo = root.resolve().parents[2]
    expected_root = repo / 'data/method/controlled-semantic-20260930'
    if root.resolve() != expected_root or output.resolve() != root.resolve() / 'experiment-qualified-inputs':
        raise ValueError('主研究冻结需要使用规定的研究目录')
    for folder in ('launch', 'main-sources', 'development-qualified-inputs', 'model-identity',
                   'natural-source-acquisition/frame', 'natural-source-identity-audit', 'natural-preparation'):
        verify_bundle(root / folder)
    verify_bundle(qualification)
    natural = read_json(root / 'natural-preparation/metadata.json')
    if (natural['status'] != 'FROZEN_OUTCOME_BLIND_NATURAL_PREPARATION'
            or natural['main_discovery_outcomes_seen'] is not False or natural['source_count'] > 500):
        raise ValueError('自然来源适用集合须在发现代码结果出现前冻结')
    natural_tasks = read_json(root / 'natural-preparation/tasks.json')
    natural_sets = read_json(root / 'natural-preparation/policy-sets.json')
    natural_root = root / 'natural-preparation'
    natural_qualification = read_json(natural_root / 'qualification.json')
    summary = validate_controlled_natural_source_qualification(root, natural_qualification)
    natural_review = read_json(natural_root / 'qualification-review.json')
    _validate_controlled_natural_qualification_review(root, natural_qualification, natural_review, summary)
    _validate_controlled_natural_preparation_costs(read_json(natural_root / 'preparation-costs.json'))
    if (natural_qualification != read_json(root / 'natural-source-qualification.json')
            or natural_review != read_json(root / 'natural-source-qualification-review.json')
            or natural['qualification_sha256'] != file_sha256(root / 'natural-source-qualification.json')
            or natural['qualification_review_sha256'] != file_sha256(root / 'natural-source-qualification-review.json')
            or natural['preparation_costs_sha256'] != file_sha256(root / 'natural-preparation-costs.json')
            or file_sha256(natural_root / 'preparation-costs.json') != natural['preparation_costs_sha256']
            or natural['input_sha256'] != natural_qualification['input_sha256']
            or any(natural[key] != value for key, value in summary.items())
            or natural_tasks != [] or natural['task_count'] != 0
            or any(natural[key] is not False for key in (
                'main_discovery_outcomes_seen', 'selector_results_seen', 'result_values_read', 'protected_prompt_file_read'))
            or not isinstance(natural['reason'], str) or not natural['reason'].strip()):
        raise ValueError('冻结自然资格、处置计数或任务选择不符')
    for name in ('natural-contract-fingerprints.json', 'reference-contract-fingerprints.json'):
        if file_sha256(natural_root / name) != natural_qualification['input_sha256'][name]:
            raise ValueError('冻结自然资格的指纹身份不符')
    if read_json(natural_root / 'identity-audit-metadata.json') != read_json(root / 'natural-source-identity-audit/metadata.json'):
        raise ValueError('冻结自然资格的保护或暴露元数据身份不符')
    if natural_sets != controlled_natural_policy_sets(natural_tasks):
        raise ValueError('冻结自然适用集合与逐任务事前语义资格不符')
    source_frame = read_json(root / 'natural-source-acquisition/frame/sources.json')
    if (natural['source_count'] != len(source_frame) or natural['task_count'] != len(natural_tasks)
            or natural['source_manifest_sha256'] != file_sha256(root / 'natural-source-acquisition/frame/manifest.json')):
        raise ValueError('自然准备的来源范围或任务数量与冻结记录不符')
    by_source = {source['source_id']: source for source in source_frame}
    source_ids = [task['source']['source_id'] for task in natural_tasks]
    if len(set(source_ids)) != len(source_ids):
        raise ValueError('自然任务重复使用同一个来源身份')
    for task in natural_tasks:
        source = by_source[task['source']['source_id']]
        if task['source'] != dict(source_id=source['source_id'], position=source['source_position'],
                original_url=source['original_url'], source_snapshot_sha256=source['source_snapshot_sha256']):
            raise ValueError('自然任务的原始来源与冻结来源范围不符')
    results = repo / 'results/controlled-semantic-20260930'
    if any(list((results / phase).glob('*/assigned/manifest.json')) for phase in ('training', 'evaluation', 'natural')):
        raise ValueError('主结果出现后不能重新冻结实验输入')
    control_identity = read_json(qualification / 'identity.json')
    if file_sha256(qualification / 'manifest.json') != read_json(root / 'main-sources/metadata.json')['qualification_manifest_sha256']:
        raise ValueError('主任务来源与实际控制资格身份不符')
    worker = repo / 'src/measurement/command_execution.py'
    helper = repo / 'src/measurement/controlled_command.py'
    development_environment = read_json(root / 'development-qualified-inputs/environment.json')
    if (file_sha256(worker) != control_identity['worker_sha256']
            or file_sha256(helper) != development_environment['measurement_sha256']
            or control_identity['image'] != development_environment['image']):
        raise ValueError('最终观察环境需要保持已通过真实控制的实现身份')
    native_environment = read_json(root / 'natural-preparation/environment.json')
    if (native_environment['model'] != MODEL or native_environment['system_prompt'] != SYSTEM
            or native_environment['image'] != control_identity['image']
            or native_environment['model_manifest_sha256'] != file_sha256(root / 'model-identity/manifest.json')
            or native_environment['worker_sha256'] != file_sha256(repo / 'src/measurement/natural_command.py')
            or native_environment['measurement_sha256'] != file_sha256(helper)
            or native_environment['runtime_sha256'] != file_sha256(repo / 'docs/experiments/2026-09-30-jci-runtime.py')):
        raise ValueError('自然模型、观察器及执行环境需要在发现生成前固定')
    tasks, semantic_identities = assemble_main_semantics(repo)
    now = datetime.now(timezone.utc)
    if datetime.fromisoformat(natural['frozen_at_utc']) > now:
        raise ValueError('自然适用集合的冻结时间晚于主输入冻结')
    launch = read_json(root / 'launch/launch.json')
    if now >= datetime.fromisoformat(launch['deadline_utc']):
        raise ValueError('研究执行期限已经结束')
    implementation = {name: file_sha256(repo / name) for name in (
        'src/measurement/command_execution.py', 'src/measurement/controlled_command.py',
        'src/measurement/native_behavior.py', 'src/development/controlled_tasks.py',
        'src/development/jci_ridge.py', 'src/development/semantic_discovery.py',
        'src/development/graph_guided_decisions.py', 'src/development/structure_policy_cpu.R',
        'src/development/source_generation.py', 'src/llm.py')}
    environment = dict(model=MODEL, system_prompt=SYSTEM,
        model_manifest_sha256=file_sha256(root / 'model-identity/manifest.json'),
        image=control_identity['image'], worker_sha256=file_sha256(worker),
        measurement_sha256=file_sha256(helper),
        runtime_sha256=file_sha256(repo / 'docs/experiments/2026-09-30-jci-runtime.py'))
    used_seeds = {row['seed'] for row in read_json(root / 'development-qualified-inputs/development-requests.json')}
    training_tasks = [row for row in tasks if row['role'] == 'training']
    evaluation_tasks = [row for row in tasks if row['role'] == 'evaluation']
    if len(training_tasks) != 400 or len(evaluation_tasks) != 400:
        raise ValueError('主发现与评价须保留各四百个独立任务')
    training = controlled_requests(training_tasks, 'training', environment, used_seeds)
    evaluation = controlled_requests(evaluation_tasks, 'evaluation', environment,
                                     used_seeds | {row['seed'] for row in training})
    if len(training)+len(evaluation)+30 > launch['generation_call_limit']:
        raise ValueError('固定主分配超过研究请求预算')
    mixtures = [row['request_id'] for row in training if row['component'] == 'random_mixture']
    if len(mixtures) != 4000 or sum(len(row['members']) for row in training if row['component'] == 'coverage') != 4000:
        raise ValueError('发现覆盖或独立随机混合分配数量不符')
    subsets = []
    for index in range(100):
        selected = sorted(controlled_rng('structure-subsample', index).choice(4000, 3200, replace=False).tolist())
        subsets.append(dict(index=index, request_ids=[mixtures[position] for position in selected]))
    ordered_tasks = sorted(row['task_unit_id'] for row in training_tasks)
    ordering = controlled_rng('ridge', 'task-folds').permutation(400)
    folds = {ordered_tasks[index]: position % 5 for position, index in enumerate(ordering)}
    _, coverage = state_coverage(training_tasks)
    causal_design = controlled_causal_design_check(training_tasks)
    preparation_costs = []
    for name in sorted(semantic_identities):
        preparation_costs.append(read_json(root / 'main-preparation-records' / name / 'accounting.json'))
        preparation_costs.append(read_json(root / 'main-qualified' / name / 'review-accounting.json'))
    from prompt_mechanism_study.development.controlled_tasks import validate_main_model_accounting
    if len(preparation_costs) != 3200:
        raise ValueError('全部隔离准备与检查计量须完整')
    for row in preparation_costs:
        validate_main_model_accounting(root, row)
    from prompt_mechanism_study.development.controlled_tasks import controlled_preparation_attempts
    attempts = controlled_preparation_attempts(root, preparation_costs)
    write_bundle(output, {'tasks.json': tasks, 'training-requests.json': training,
        'evaluation-requests.json': evaluation, 'structure-subsamples.json': subsets,
        'task-folds.json': folds, 'state-coverage.json': coverage,
        'causal-design.json': causal_design,
        'environment.json': environment, 'input-identities.json': implementation,
        'semantic-identities.json': semantic_identities, 'preparation-costs.json': preparation_costs,
        'preparation-attempts.json': attempts, 'model-policy.json': read_json(root / 'main-model-policy.json'),
        'metadata.json': dict(protocol_id=launch['protocol_id'], status='FROZEN_CONTROLLED_EXPERIMENT_INPUTS',
            M=800, H=400, E=400, training_calls=len(training), evaluation_calls=len(evaluation),
            training_logical_calls=8000, evaluation_logical_calls=17600,
            graph_mixture_requests=4000, graph_subsamples=100,
            docker_image=control_identity['image'], model_outcomes_seen=False,
            evidence_level='AUTHORIZED_PROSPECTIVE_CONTROLLED_METHOD_RESEARCH',
            main_source_manifest_sha256=file_sha256(root / 'main-sources/manifest.json'),
            qualification_manifest_sha256=file_sha256(qualification / 'manifest.json'),
            natural_preparation_manifest_sha256=file_sha256(root / 'natural-preparation/manifest.json'),
            model_policy_sha256=file_sha256(root / 'main-model-policy.json'),
            launch_manifest_sha256=file_sha256(root / 'launch/manifest.json'),
            frozen_at_utc=now.isoformat())})


def make_scm_tasks(mechanism, n, repetition, generations=4):
    rng = random_stream('prompt-state-scm', mechanism, n, repetition)
    u = rng.binomial(1, .5, n)
    noise = rng.random((n, 3))
    states = np.zeros((n, 3, 3), dtype=int)
    probabilities = np.zeros((n, 3))
    for c in range(3):
        px = np.column_stack((.2+.4*(c == 1)+.2*u, np.full(n, .2+.4*(c == 2)), .2+.4*u))
        x = states[:, c] = (noise < px).astype(int)
        if mechanism == 'direct':
            py = .15+.45*x[:, 0]+.15*x[:, 1]
        elif mechanism == 'latent':
            py = .20+.40*u+.15*x[:, 1]
        elif mechanism == 'uncovered':
            py = .15+.30*x[:, 0]+.25*(c == 2)+.10*u
        elif mechanism == 'null':
            py = .35+.20*u
        else:
            raise ValueError(mechanism)
        probabilities[:, c] = py
    outcomes = (rng.random((n, 3, generations)) < probabilities[:, :, None]).astype(int)
    return states, probabilities, outcomes


def merge_semantic_reviews(root, prepared, review_paths, output):
    verify_bundle(prepared)
    records = read_json(prepared / 'records.json')
    by_case = {row['case_id']: row for row in records}
    seen = set()
    identities = {}
    for path in review_paths:
        review = read_json(path)
        if review['review_round_per_policy'] != 1 or review['generated_outcomes_disclosed'] is not False:
            raise ValueError('独立审查必须为首次且结果盲态')
        original_root = root / review['input_bundle']
        verify_bundle(original_root)
        original = {row['case_id']: row for row in read_json(original_root / 'records.json')}
        identities[path.name] = dict(review_sha256=file_sha256(path),
                                     input_manifest_sha256=file_sha256(original_root / 'manifest.json'))
        if set(original) != {row['case_id'] for row in review['rows']}:
            raise ValueError('独立审查未完整覆盖其输入任务')
        for judgment in review['rows']:
            identity = judgment['case_id']
            if identity in seen or identity not in by_case:
                raise ValueError('重复审查或未提供待组装任务')
            seen.add(identity)
            row, prior = by_case[identity], original[identity]
            if row['baseline_prompt'] != prior['baseline_prompt'] or row['source_prompt'] != prior['source_prompt']:
                raise ValueError('当前来源或 baseline 与实际审查输入不同')
            previous = {item['slot']: item for item in prior['policies']}
            decisions = {item['slot']: item for item in judgment['policies']}
            if set(previous) != set(decisions) or set(previous) != {item['slot'] for item in row['policies']}:
                raise ValueError('候选槽与一次审查不对应')
            row['source_states'] = judgment['source_states_review']
            if len(row['source_states']) != 3 or any(value not in (0, 1, None) for value in row['source_states']):
                raise ValueError('独立状态读出无效')
            missing = judgment.get('coverage_missing', [])
            common_missing = review.get('common_coverage_missing')
            format_present = any(node['id'] == 'source_response_format' for node in row['nodes'])
            if missing or common_missing:
                explicit = missing or [common_missing]
                if not format_present or any('Only return the code' not in reason for reason in explicit):
                    raise ValueError('独立审查指出的来源语义尚未完整表达')
            supported = judgment['tsg_supported'] is True and judgment['call_contract_supported'] is True
            row['semantic_review_status'] = 'QUALIFIED' if supported else 'UNQUALIFIED'
            row['semantic_judgment'] = judgment
            row['slot_prompt_hashes'] = [row['baseline_hash']] * 3
            row['slot_states'] = [list(row['source_states']) for _ in range(3)]
            for candidate in row['policies']:
                slot = candidate['slot']
                if candidate['edited_prompt'] != previous[slot]['edited_prompt']:
                    raise ValueError('候选全文在一次审查后改变')
                decision = decisions[slot]
                states, relations = decision['state_review'], decision['relation_features_review']
                if len(states) != 3 or len(relations) != 3 or any(value not in (0, 1, None) for value in states + relations):
                    raise ValueError('独立候选状态或关系读出无效')
                delta = [None if a is None or b is None else a-b
                         for a, b in zip(states, row['source_states'], strict=True)]
                candidate['states'], candidate['relation_features'] = states, relations
                candidate['features'] = [*row['source_states'], *delta, *candidate['features'][6:9],
                                         *relations, candidate['features'][-1]]
                candidate['changed_states'] = {name: delta[index] for index, name in enumerate(('X_ex','X_cue','X_local'))
                                               if delta[index] is None or delta[index] != 0}
                candidate['semantic_qualified'] = supported and decision['atomic_and_preserving'] is True
                if candidate['semantic_qualified']:
                    row['slot_prompt_hashes'][slot] = candidate['policy_hash']
                    row['slot_states'][slot] = list(states)
    if seen != set(by_case):
        raise ValueError('当前准备包含尚未独立审查的任务')
    write_bundle(output, {'records.json': records, 'inputs.json': dict(
        prepared_manifest_sha256=file_sha256(prepared / 'manifest.json'), reviews=identities)})
    print(json.dumps(dict(tasks=len(records), qualified_tasks=sum(row['semantic_review_status'] == 'QUALIFIED' for row in records),
                          qualified_policies=sum(candidate['semantic_qualified'] for row in records for candidate in row['policies']))))


def structure_rows(states, outcomes, identity, draw):
    n = len(states)
    if states.shape != (n, 3, 3) or outcomes.shape[:2] != (n, 3):
        raise ValueError('SCM 任务或生成数组无效')
    rng = random_stream(identity, 'one-row-per-task', draw)
    contexts = rng.integers(0, 3, n)
    seeds = rng.integers(0, outcomes.shape[2], n)
    positions = np.arange(n)
    return np.column_stack((contexts, states[positions, contexts], outcomes[positions, contexts, seeds]))


def population_joint(mechanism):
    joint = []
    for c, x1, x2, x3, y in itertools.product(range(3), range(2), range(2), range(2), range(2)):
        mass = Fraction(0)
        for u in range(2):
            px = (Fraction(1, 5) + Fraction(2, 5)*(c == 1) + Fraction(u, 5),
                  Fraction(1, 5) + Fraction(2, 5)*(c == 2),
                  Fraction(1, 5) + Fraction(2*u, 5))
            if mechanism == 'direct':
                py = Fraction(3, 20) + Fraction(9*x1, 20) + Fraction(3*x2, 20)
            elif mechanism == 'latent':
                py = Fraction(1, 5) + Fraction(2*u, 5) + Fraction(3*x2, 20)
            elif mechanism == 'uncovered':
                py = Fraction(3, 20) + Fraction(3*x1, 10) + Fraction(c == 2, 4) + Fraction(u, 10)
            elif mechanism == 'null':
                py = Fraction(7, 20) + Fraction(u, 5)
            else:
                raise ValueError(mechanism)
            term = Fraction(1, 6) * (py if y else 1-py)
            for value, probability in zip((x1, x2, x3), px, strict=True):
                term *= probability if value else 1-probability
            mass += term
        joint.append(((c, x1, x2, x3, y), mass))
    assert sum(mass for _, mass in joint) == 1
    return joint


def pearson_binary_margin_variance(row_margins, positive_count):
    margins = [int(value) for value in row_margins]
    total = sum(margins)
    if (not margins or any(value <= 0 for value in margins)
            or not 0 < positive_count < total):
        raise ValueError('Pearson 条件边际必须具有两个非空类别')

    def falling(value, degree):
        return math.prod(range(value - degree + 1, value + 1)) if value >= degree else 0

    def moment(powers):
        degree = sum(powers.values())
        if degree > total:
            return Fraction(0)
        numerator = falling(positive_count, degree)
        for index, power in powers.items():
            numerator *= falling(margins[index], power)
        return Fraction(numerator, falling(total, degree))

    # 固定边际下，Pearson 统计量等于二阶计数和的仿射变换。
    first, second = Fraction(0), Fraction(0)
    for i, margin in enumerate(margins):
        first += (moment({i: 2}) + moment({i: 1})) / margin
        second += sum(coefficient * moment({i: degree})
                      for degree, coefficient in ((4, 1), (3, 6), (2, 7), (1, 1))) / margin**2
        for j in range(i):
            second += 2 * sum(moment({i: left, j: right})
                              for left in (1, 2) for right in (1, 2)) / (margin * margins[j])
    probability = Fraction(positive_count, total)
    variance = (second - first**2) / (probability * (1 - probability))**2
    if variance < 0:
        raise ArithmeticError('精确 Pearson 方差不能为负数')
    return variance


class StructureCpuLimit(Exception):
    pass


class DiscreteCI:
    def __init__(self, identity, labels, rows=None, joint=None, cpu_remaining=None):
        if (rows is None) == (joint is None):
            raise ValueError('必须提供一种离散数据来源')
        self.identity, self.labels = identity, tuple(labels)
        self.rows = None if rows is None else np.asarray(rows)
        self.joint, self.cache, self.queries = joint, {}, []
        self.cpu_remaining = cpu_remaining
        if len(set(self.labels)) != len(self.labels):
            raise ValueError('变量名称重复')
        if self.rows is not None:
            if (self.rows.ndim != 2 or self.rows.shape[1] != len(self.labels)
                    or len(self.rows) < 1 or not np.isfinite(self.rows).all()
                    or not np.equal(self.rows, self.rows.astype(int)).all()):
                raise ValueError('离散观测矩阵无效')
            self.rows = self.rows.astype(int)

    def query(self, x, y, conditioned):
        self._check_budget()
        x, y = sorted((x, y))
        conditioned = sorted(conditioned)
        if x == y or len(set(conditioned)) != len(conditioned) or {x, y} & set(conditioned):
            raise ValueError('CI 查询变量无效')
        indices = [self.labels.index(v) for v in (x, y, *conditioned)]
        key = '|'.join((x, y, *conditioned))
        self.queries.append(key)
        if key not in self.cache:
            answer = self._population(indices) if self.joint is not None else self._sample(indices, key)
            self.cache[key] = dict(answer, key=key, x=x, y=y, conditioned=conditioned)
        return self.cache[key]

    def _check_budget(self):
        if self.cpu_remaining is not None and self.cpu_remaining() <= 0:
            raise StructureCpuLimit('结构计算 CPU 额度已经达到')

    def _population(self, indices):
        tables = {}
        for state, mass in self.joint:
            group = tuple(state[i] for i in indices[2:])
            cell = (state[indices[0]], state[indices[1]])
            table = tables.setdefault(group, {})
            table[cell] = table.get(cell, Fraction(0)) + mass
        independent = True
        for table in tables.values():
            total = sum(table.values())
            xvalues, yvalues = {x for x, _ in table}, {y for _, y in table}
            xm = {x: sum(v for (i, _), v in table.items() if i == x) for x in xvalues}
            ym = {y: sum(v for (_, j), v in table.items() if j == y) for y in yvalues}
            independent &= all(table.get((x, y), 0)*total == xm[x]*ym[y]
                               for x in xvalues for y in yvalues)
        return dict(status='determined', p_value=float(independent), independent=independent,
                    mode='rational_population')

    def _sample(self, indices, key):
        rows = self.rows
        groups = np.zeros(len(rows), dtype=int)
        if len(indices) > 2:
            _, groups = np.unique(rows[:, indices[2:]], axis=0, return_inverse=True)
        simulated, observed, informative, exchangeable = np.zeros(9999), 0., 0, 0
        statistic_can_vary = False
        rng = random_stream(self.identity, key, 'multicategory_conditional_pearson')
        for group in np.unique(groups):
            self._check_budget()
            sample = rows[groups == group]
            xv, xi = np.unique(sample[:, indices[0]], return_inverse=True)
            yv, yi = np.unique(sample[:, indices[1]], return_inverse=True)
            if len(xv) < 2 or len(yv) < 2:
                continue
            cells = np.bincount(xi*len(yv)+yi, minlength=len(xv)*len(yv)).reshape(len(xv), len(yv))
            margins_x, margins_y = cells.sum(axis=1), cells.sum(axis=0)
            expected = np.outer(margins_x, margins_y) / cells.sum()
            observed += float(np.sum((cells-expected)**2 / expected))
            if cells.shape[1] != 2:
                cells = cells.T
                margins_x, margins_y = cells.sum(axis=1), cells.sum(axis=0)
                expected = np.outer(margins_x, margins_y) / cells.sum()
            if cells.shape[1] != 2 or cells.shape[0] > 5:
                raise ValueError('主研究要求至多五值的政策及二元状态')
            statistic_can_vary |= pearson_binary_margin_variance(margins_x, int(margins_y[1])) > 0
            draws = random_table.rvs(margins_x, margins_y, size=9999, random_state=rng)
            simulated += np.sum((draws-expected)**2 / expected, axis=(1, 2))
            self._check_budget()
            informative += 1
            exchangeable += len(sample)
        if not informative or not statistic_can_vary:
            return dict(status='statistically_undetermined', p_value=None, mode='degenerate_strata',
                        informative_strata=informative, exchangeable_rows=exchangeable,
                        statistic_can_vary=bool(statistic_can_vary))
        return dict(status='determined', p_value=(1+int(np.count_nonzero(simulated >= observed-1e-12)))/10000,
                    statistic=observed, informative_strata=informative, exchangeable_rows=exchangeable,
                    mode='fixed_margin_conditional_permutation', permutations=9999)


def mixed_training_requests(tasks, identity, *, environment=None, used_seeds=()):
    if environment is not None:
        return controlled_requests(tasks, 'training', environment, used_seeds)
    if not tasks or len({task['task_unit_id'] for task in tasks}) != len(tasks):
        raise ValueError('训练任务身份缺失或重复')
    requests = []
    for task in tasks:
        slots = task['slot_prompt_hashes']
        if len(slots) != 3 or any(not isinstance(value, str) or not value for value in slots):
            raise ValueError('每项任务必须定义三个完整槽，包括映射 B 的空槽')
        for prompt_hash in sorted(set(slots)):
            for repeat in range(2):
                requests.append(dict(task_unit_id=task['task_unit_id'], prompt_hash=prompt_hash,
                                     component='balanced', repeat=repeat, context=None))
    rng = random_stream(identity, 'training-task-and-context')
    for index in range(6*len(tasks)):
        task = tasks[int(rng.integers(len(tasks)))]
        context = int(rng.integers(3))
        requests.append(dict(task_unit_id=task['task_unit_id'], context=context,
                             prompt_hash=task['slot_prompt_hashes'][context],
                             component='random_mixture', repeat=index))
    seed_rng = random_stream(identity, 'unique-generation-seeds')
    used = set()
    for index, request in enumerate(requests):
        seed = int(seed_rng.integers(1, 2**31-1))
        while seed in used:
            seed = int(seed_rng.integers(1, 2**31-1))
        used.add(seed)
        request.update(request_id=f'{identity}-{index:05d}', seed=seed)
    order = random_stream(identity, 'training-dispatch').permutation(len(requests))
    return [requests[index] for index in order]


def controlled_requests(tasks, phase, environment, used_seeds=(), *, selected_policy=None):
    from prompt_mechanism_study.development.controlled_tasks import controlled_rng
    from prompt_mechanism_study.development.source_generation import SYSTEM
    if (phase not in ('training', 'evaluation', 'natural') or not tasks
            or len({task['task_unit_id'] for task in tasks}) != len(tasks)
            or any(task['role'] != phase for task in tasks)):
        raise ValueError('受控分配任务身份或角色无效')
    if phase == 'natural':
        if selected_policy not in ('local', 'example', 'reference') or len(tasks) > 60:
            raise ValueError('自然分配需要有效的选定政策及最多六十项任务')
        for task in tasks:
            candidate = next(row for row in task['policies']['TSG'] if row['policy'] == selected_policy)
            if candidate['semantic_qualified'] is not True:
                raise ValueError('自然分配的政策必须属于事前通过检查的适用集合')
    elif selected_policy is not None:
        raise ValueError('选定政策参数仅适用于自然分配')
    order = ('B', 'local', 'example', 'reference', 'S')
    physical = {}

    def assign(task, flow, condition, version, repeat, component, event=None):
        mapping = task['conditions'][flow][str(version)][condition]
        prompt = task['prompts'][mapping['prompt_hash']]
        if content_hash(prompt) != mapping['prompt_hash']:
            raise ValueError('受控分配全文身份不符')
        states = mapping['states']
        allowed_states = (0, 1, None) if phase == 'natural' else (0, 1)
        if len(states) != 3 or any(value not in allowed_states for value in states):
            raise ValueError('受控分配状态未确定')
        if phase == 'natural':
            policy_index = ('local', 'example', 'reference').index(selected_policy)
            initial = task['initial_states'][policy_index]
            if type(initial) is not int or initial not in (0, 1):
                raise ValueError('自然分配的选定政策原始状态未确定')
            expected = list(task['initial_states'])
            if condition == selected_policy:
                expected[policy_index] = 1-initial
            if states != expected:
                raise ValueError('自然分配的实际状态违反目标翻转或控制不变量')
        messages = [dict(role='system', content=SYSTEM),
                    dict(role='user', content=canonical_json({'task': prompt}))]
        identity = dict(task_unit_id=task['task_unit_id'], messages=messages, environment=environment,
            measurement=task['measurement'], version=version, repeat=repeat,
            phase=phase, component=component, independent_event=event)
        key = content_hash(identity)
        member = dict(flow=flow, condition=condition, context=order.index(condition),
                      version=version, repeat=repeat)
        if key in physical:
            request = physical[key]
            if request['actual_states'] != states or member in request['members']:
                raise ValueError('共享全文的语义状态冲突或逻辑分配重复')
            request['members'].append(member)
        else:
            physical[key] = dict(task_unit_id=task['task_unit_id'], prompt_hash=mapping['prompt_hash'],
                component=component, version=version, repeat=repeat, actual_states=states,
                context=order.index(condition) if component == 'random_mixture' else None,
                independent_event=event, members=[member], messages=messages)

    for task in sorted(tasks, key=lambda row: row['task_unit_id']):
        for flow in (('TSG',) if phase in ('training', 'natural') else ('TSG', 'Raw', 'Rich-Flat')):
            conditions = ('B', selected_policy, 'S') if phase == 'natural' else order if flow == 'TSG' else order[1:4]
            for condition in conditions:
                for version in (1, 2):
                    for repeat in range(1 if phase == 'training' else 8 if phase == 'natural' else 2):
                        assign(task, flow, condition, version, repeat,
                               'coverage' if phase == 'training' else phase)
    if phase == 'training':
        ordered = sorted(tasks, key=lambda row: row['task_unit_id'])
        rng = controlled_rng('discovery', 'independent-task-context-expression')
        for event in range(4000):
            task = ordered[int(rng.integers(len(ordered)))]
            condition, version = order[int(rng.integers(5))], int(rng.integers(1, 3))
            assign(task, 'TSG', condition, version, event, 'random_mixture', event)
    requests, used = [], set(used_seeds)
    for key, request in sorted(physical.items()):
        rng = controlled_rng('generation', key)
        seed = int(rng.integers(1, 2**31 - 1))
        while seed in used:
            seed = int(rng.integers(1, 2**31 - 1))
        used.add(seed)
        identity = content_hash(dict(allocation_identity=key, seed=seed))
        request.update(seed=seed, allocation_identity=key, physical_identity=identity,
            independent_group=identity, request_id=f'controlled-{phase}-{identity[:20]}')
        requests.append(request)
    permutation = controlled_rng(phase, 'dispatch').permutation(len(requests))
    return [requests[index] for index in permutation]


def select_policy(candidates, predictions, supports=None, *, minimum_gain=0., frozen_discovery=False):
    if len(candidates) != len(predictions) or not np.isfinite(predictions).all():
        raise ValueError('候选或共同预测无效')
    if not frozen_discovery:
        if supports is not None:
            raise ValueError('安全收益选择不使用结构频率乘数')
        if not np.isfinite(minimum_gain) or not 0 <= minimum_gain <= 1 or any(abs(value) > 1 for value in predictions):
            raise ValueError('安全收益及预定阈值必须处于有效范围')
        names = [row['policy'] if 'policy' in row else row['policy_hash'] for row in candidates]
        if any(not isinstance(name, str) or not name or name == 'B' for name in names) or len(set(names)) != len(names):
            raise ValueError('候选政策身份必须唯一且完整')
        scores = dict(zip(names, map(float, predictions), strict=True))
        eligible = [index for index, value in enumerate(predictions) if value > minimum_gain]
        if not eligible:
            return dict(action='B', direction=0, scores=scores, effect=0., objective='safe_yield', minimum_gain=minimum_gain)
        chosen = max(eligible, key=lambda index: float(predictions[index]))
        return dict(action=names[chosen], direction=1, scores=scores, effect=float(predictions[chosen]),
                    objective='safe_yield', minimum_gain=minimum_gain)
    # 完成研究的方向发现公式仅用于冻结证据复现。
    if minimum_gain != 0:
        raise ValueError('冻结方向发现不接受新的收益阈值')
    if candidates and all('policy' in candidate for candidate in candidates):
        names = ('local', 'example', 'reference')
        if len(candidates) != 3 or tuple(row['policy'] for row in candidates) != names:
            raise ValueError('受控选择须保留三个固定政策位置及顺序')
        if supports is not None and (set(supports) != set(names)
                or any(not np.isfinite(value) or not 0 <= value <= 1 for value in supports.values())):
            raise ValueError('结构选择需要完整有效的三项支持')
        scores = {name: abs(float(value)) * (1 + supports[name] if supports is not None else 1)
                  for name, value in zip(names, predictions, strict=True)}
        if not any(predictions):
            return dict(action='B', direction=0, scores=scores, effect=0.)
        chosen = max(range(3), key=lambda index: scores[names[index]])
        effect = float(predictions[chosen])
        return dict(action=names[chosen], direction=1 if effect > 0 else -1,
                    scores=scores, effect=effect)
    choices = []
    for candidate, prediction in zip(candidates, predictions, strict=True):
        if prediction == 0:
            continue
        priority = supports is not None and any(
            value is not None and value != 0 and supports.get(name, 0.) >= .8
            for name, value in candidate['changed_states'].items())
        choices.append((int(priority), abs(float(prediction)), candidate['policy_hash'], float(prediction)))
    if not choices:
        return dict(action='B', direction=0, prediction=0., structure_priority=False)
    chosen = min(choices, key=lambda row: (-row[0], -row[1], row[2]))
    return dict(action=chosen[2], direction=1 if chosen[3] > 0 else -1,
                prediction=chosen[3], structure_priority=bool(chosen[0]))


def controlled_ridge_features(task, policy):
    names = ('local', 'example', 'reference')
    families = ('find', 'grep', 'tar', 'git')
    if policy not in names or task['family'] not in families:
        raise ValueError('辅助预测政策或操作家族未知')
    initial = task['initial_states']
    states, lengths = [], []
    for version in ('1', '2'):
        conditions = task['conditions']['TSG'][version]
        original = task['prompts'][conditions['B']['prompt_hash']]
        edited = task['prompts'][conditions[policy]['prompt_hash']]
        states.append(conditions[policy]['states'])
        changes = sum((b-a)+(d-c) for tag, a, b, c, d
                      in SequenceMatcher(None, original, edited, autojunk=False).get_opcodes() if tag != 'equal')
        lengths.append(min(1., changes / len(original)))
    if states[0] != states[1] or len(initial) != 3:
        raise ValueError('两套表达的辅助预测状态不一致')
    blueprint = task['measurement']['blueprint']
    objects = sum(key.endswith('_query') for key in blueprint)
    features = [*initial, *[a-b for a, b in zip(states[0], initial, strict=True)],
                *[int(policy == name) for name in names],
                *[int(task['family'] == family) for family in families],
                objects, objects, sum(lengths)/2]
    if len(features) != 16 or not np.isfinite(features).all():
        raise ValueError('辅助预测的十六项特征不完整')
    return features


def prepare_safe_decisions(inputs: Path, analysis: Path, output: Path, minimum_gain: float):
    verify_bundle(inputs)
    verify_bundle(analysis)
    tasks = read_json(inputs / 'tasks.json')
    training = read_json(analysis / 'training-features.json')
    training_ids = {task['task_unit_id'] for task in tasks if task['role'] == 'training'}
    names = ('local', 'example', 'reference')
    positions = {(row['task_unit_id'], row['policy']) for row in training}
    if (len(positions) != len(training) or positions != {(identity, name) for identity in training_ids for name in names}
            or any(len(row['features']) != 16 for row in training)):
        raise ValueError('完整任务及全部候选的随机政策差标签必须保留')
    folds = read_json(inputs / 'task-folds.json')
    learner, validation = fit_task_equal_ridge(training, ['continuous'] * 16, task_folds=folds,
        penalties=(.01, .1, 1., 10., 100.), minimum_task_support=1)
    decisions = []
    for task in tasks:
        if task['role'] != 'evaluation':
            continue
        candidates = [dict(policy=name, features=controlled_ridge_features(task, name)) for name in names]
        gains = learner.predict(candidates).tolist()
        decisions.append(dict(case_id=task['case_id'], task_unit_id=task['task_unit_id'],
            actual_edit_gains=gains, choice=select_policy(candidates, gains, minimum_gain=minimum_gain)))
    counts = Counter(row['choice']['action'] for row in decisions)
    write_bundle(output, {'decisions.json': decisions, 'learner.json': learner.record(),
        'cross-validation.json': validation, 'identity.json': dict(
            evidence_role='POST_HOC_EXPOSED_METHOD_CHECK', objective='actual_edit_minus_baseline_secure_yield',
            minimum_gain=minimum_gain, training_tasks=len(training_ids), training_positions=len(training),
            target_tasks=len(decisions), action_counts=dict(counts), target_tasks_previously_exposed=True,
            evaluation_outcomes_read=False, input_manifest_sha256=file_sha256(inputs / 'manifest.json'),
            analysis_manifest_sha256=file_sha256(analysis / 'manifest.json'),
            implementation_sha256=file_sha256(Path(__file__)))})
    return dict(action_counts=dict(counts), target_tasks=len(decisions), minimum_gain=minimum_gain)


def evaluation_budget(training_tasks, evaluation_tasks, training_unique, evaluation_unique, disagreement):
    if min(training_tasks, evaluation_tasks, training_unique, evaluation_unique) < 1:
        raise ValueError('训练与评价数量必须为正数')
    training_calls = 2*training_unique+6*training_tasks
    repeats = min(32, (1344-training_calls)//evaluation_unique) if disagreement else 8
    if repeats < 8 or training_calls+repeats*evaluation_unique > 1344:
        raise ValueError('请求计划超出冻结预算')
    return dict(training_calls=training_calls, evaluation_repeats=repeats,
                total_calls=training_calls+repeats*evaluation_unique)


def state_coverage(tasks):
    if tasks and all('conditions' in task for task in tasks):
        names = ('X_local', 'X_example', 'X_reference')
        conditions = ('B', 'local', 'example', 'reference', 'S')
        vectors, diagnostics = [], []
        for index, name in enumerate(names):
            values = [task['conditions']['TSG'][version][condition]['states'][index]
                      for task in tasks for version in ('1', '2') for condition in conditions]
            counts = {str(value): len({task['task_unit_id'] for task in tasks
                if any(task['conditions']['TSG'][version][condition]['states'][index] == value
                       for version in ('1', '2') for condition in conditions)}) for value in (0, 1)}
            reasons = []
            if any(value not in (0, 1) for value in values):
                reasons.append('SEMANTIC_UNKNOWN')
            if len(set(values)) < 2:
                reasons.append('CONSTANT')
            if values in vectors:
                reasons.append('DUPLICATE')
            if all(len({task['conditions']['TSG'][version][condition]['states'][index]
                        for task in tasks}) == 1 for version in ('1', '2') for condition in conditions):
                reasons.append('DETERMINISTIC_FROM_CONTEXTS')
            vectors.append(values)
            diagnostics.append(dict(name=name, status='BLOCKED' if reasons else 'DEFINED',
                reasons=reasons, distinct_task_support=counts,
                context_expression_counts={f'{condition}:V{version}': {
                    str(value): sum(task['conditions']['TSG'][version][condition]['states'][index] == value
                                    for task in tasks) for value in (0, 1, None)}
                    for version in ('1', '2') for condition in conditions}))
        return list(names), diagnostics
    names = ('X_ex', 'X_cue', 'X_local')
    retained, diagnostics, vectors = [], [], []
    for index, name in enumerate(names):
        values = [row['slot_states'][c][index] for row in tasks for c in range(3)]
        counts = {str(value): len({row['task_unit_id'] for row in tasks
                                  if value in [state[index] for state in row['slot_states']]})
                  for value in (0, 1)}
        reason = None
        if None in values:
            reason = 'SEMANTIC_UNKNOWN'
        elif len(set(values)) < 2:
            reason = 'CONSTANT'
        elif values in vectors:
            reason = 'DUPLICATE'
        elif all(len({row['slot_states'][c][index] for row in tasks}) == 1 for c in range(3)):
            reason = 'DETERMINISTIC_FROM_CONTEXT'
        elif min(counts.values()) < 4:
            reason = 'FEWER_THAN_FOUR_TASKS_PER_STATE'
        if reason is None:
            retained.append(name)
            vectors.append(values)
        diagnostics.append(dict(name=name, retained=reason is None, exclusion=reason,
                                distinct_task_support=counts,
                                context_counts={str(c): {str(value): sum(row['slot_states'][c][index] == value for row in tasks)
                                                         for value in (0, 1, None)} for c in range(3)}))
    return retained, diagnostics


def controlled_causal_design_check(tasks):
    if (not tasks or len(tasks) > 400 or any(task['role'] != 'training' for task in tasks)
            or len({task['task_unit_id'] for task in tasks}) != len(tasks)):
        raise ValueError('因果设计检查需要唯一的发现任务及实际提示映射')
    names = ('X_local', 'X_example', 'X_reference')
    labels = ('C', 'V', *names, 'Y')
    conditions = ('B', 'local', 'example', 'reference', 'S')
    cells = defaultdict(int)
    for task in tasks:
        for context, condition in enumerate(conditions):
            for version in (1, 2):
                states = task['conditions']['TSG'][str(version)][condition]['states']
                if len(states) != 3 or any(value is not None and (type(value) is not int or value not in (0, 1)) for value in states):
                    raise ValueError('因果设计检查的实际状态无效')
                cells[(context, version-1, *states)] += 1
    _, coverage = state_coverage(tasks)
    blocked = [dict(variable=row['name'], reasons=row['reasons']) for row in coverage if row['status'] == 'BLOCKED']
    base = dict(scope='ASSUMED_SCM_DESIGN_CHECK_ONLY', fixed_task_count=len(tasks),
        task_ids=sorted(task['task_unit_id'] for task in tasks), labels=list(labels),
        context_probabilities=['1/5']*5, expression_probabilities=['1/2']*2,
        input_cells=[dict(values=list(values), task_count=count, probability=str(Fraction(count, 10*len(tasks))))
            for values, count in sorted(cells.items(), key=lambda row: repr(row[0]))],
        blocked_variables=blocked, empirical_model_outcomes_used=False,
        causal_identification_claim=False, finite_sample_power_claim=False)
    if blocked:
        return dict(base, status='BLOCKED', scenarios={}, distinguishable=False)
    queries = [('C', 'Y', [*names, 'V'])]
    queries.extend((name, 'Y', ['C', 'V', *[other for other in names if other != name]]) for name in names)
    formulas = dict(null='P(Y=1)=1/2', state_response='P(Y=1|X,V)=1/8+(X_local+2*X_example+3*X_reference+V)/16',
        context_response='P(Y=1|C,V)=1/8+C/8+V/16')
    scenarios = {}
    # 仅构造事前假定 SCM 的精确分布，不产生或填充模型结果。
    for scenario, formula in formulas.items():
        joint = []
        for values, count in cells.items():
            context, version, x1, x2, x3 = values
            positive = (Fraction(1, 2) if scenario == 'null' else
                Fraction(1, 8)+Fraction(x1+2*x2+3*x3+version, 16) if scenario == 'state_response' else
                Fraction(1, 8)+Fraction(context, 8)+Fraction(version, 16))
            mass = Fraction(count, 10*len(tasks))
            joint.extend(((*values, outcome), mass*(positive if outcome else 1-positive)) for outcome in (0, 1))
        ci = DiscreteCI(f'controlled-design-{scenario}', labels, joint=joint)
        signature = [dict(x=x, y=y, conditioned=conditioned,
            independent=ci.query(x, y, conditioned)['independent']) for x, y, conditioned in queries]
        scenarios[scenario] = dict(formula=formula, ci_signature=signature)
    signatures = {tuple(row['independent'] for row in scenario['ci_signature']) for scenario in scenarios.values()}
    distinguishable = len(signatures) == len(scenarios)
    return dict(base, status='CHECKED_ASSUMED_STRUCTURES' if distinguishable else 'ASSUMED_STRUCTURES_NOT_DISTINGUISHED',
        scenarios=scenarios, distinguishable=distinguishable)


def assemble_training(inputs, training):
    verify_bundle(inputs)
    verify_bundle(training / 'summary')
    if read_json(inputs / 'metadata.json').get('protocol_id') == 'controlled-semantic-20260930':
        return assemble_controlled_training(inputs, training)
    tasks = read_json(inputs / 'tasks.json')
    requests = read_json(inputs / 'training-requests.json')
    observed = read_json(training / 'summary/results.json')
    if len(observed) != len(requests) or len({row['request_id'] for row in observed}) != len(requests):
        raise ValueError('训练分配结果不完整或重复')
    results = {row['request_id']: row for row in observed}
    means = defaultdict(list)
    by_task = {row['task_unit_id']: row for row in tasks}
    matrix = []
    names = ('X_ex', 'X_cue', 'X_local')
    retained, coverage = state_coverage([row for row in tasks if row['role'] == 'training'])
    for request in requests:
        result = results[request['request_id']]
        verify_bundle(training / request['request_id'] / 'result')
        if result != read_json(training / request['request_id'] / 'result/result.json'):
            raise ValueError('训练结果摘要与单项不匹配')
        if any(result[key] != value for key, value in request.items()) or result['secure_yield'] not in (0, 1):
            raise ValueError('训练身份不匹配或存在基础设施缺失')
        means[(request['task_unit_id'], request['prompt_hash'])].append(result['secure_yield'])
        if request['component'] == 'random_mixture':
            states = by_task[request['task_unit_id']]['slot_states'][request['context']]
            values = [request['context'], *[states[names.index(name)] for name in retained], result['secure_yield']]
            matrix.append(dict(request_id=request['request_id'], values=values))
    labels = ['C', *retained, 'Y']
    training_rows, effects = [], []
    for task in tasks:
        if task['role'] != 'training':
            continue
        identity = task['task_unit_id']
        baseline = means[(identity, task['baseline_hash'])]
        if not baseline:
            raise ValueError('训练 baseline 请求缺失')
        for candidate in task['policies']:
            if not candidate['semantic_qualified']:
                continue
            edited = means[(identity, candidate['policy_hash'])]
            if not edited:
                raise ValueError('训练候选全文请求缺失')
            effect = float(np.mean(edited)-np.mean(baseline))
            training_rows.append(dict(task_unit_id=identity, case_id=task['case_id'], features=candidate['features'],
                                      policy_hash=candidate['policy_hash'], delta_pn=effect))
            effects.append(dict(case_id=task['case_id'], policy_hash=candidate['policy_hash'],
                                baseline_count=len(baseline), edited_count=len(edited),
                                baseline_mean=float(np.mean(baseline)), edited_mean=float(np.mean(edited)), tau=effect))
    return tasks, labels, coverage, matrix, training_rows, effects


def assemble_controlled_training(inputs, training):
    tasks = read_json(inputs / 'tasks.json')
    requests = read_json(inputs / 'training-requests.json')
    observed = read_json(training / 'summary/results.json')
    results = {row['request_id']: row for row in observed}
    if len(results) != len(observed) or set(results) != {row['request_id'] for row in requests}:
        raise ValueError('发现物理请求结果缺失或重复')
    panel = [task for task in tasks if task['role'] == 'training']
    if len(panel) != 400 or len({task['task_unit_id'] for task in panel}) != 400:
        raise ValueError('发现结果须保留四百项完整任务')
    by_task = {task['task_unit_id']: task for task in panel}
    means, matrix = defaultdict(list), []
    for request in requests:
        result = results[request['request_id']]
        folder = training / request['request_id'] / 'result'
        verify_bundle(folder)
        if result != read_json(folder / 'result.json'):
            raise ValueError('发现结果摘要与单项原始结果不符')
        if any(result[key] != value for key, value in request.items()) or result['secure_yield'] not in (0, 1):
            raise ValueError('发现请求身份不符或存在基础设施缺失')
        task = by_task[request['task_unit_id']]
        for member in request['members']:
            mapping = task['conditions'][member['flow']][str(member['version'])][member['condition']]
            if mapping['prompt_hash'] != request['prompt_hash'] or mapping['states'] != request['actual_states']:
                raise ValueError('发现实际状态与逻辑分配不符')
            means[(task['task_unit_id'], member['condition'], member['version'])].append(result['secure_yield'])
        if request['component'] == 'random_mixture':
            if len(request['members']) != 1:
                raise ValueError('随机混合请求必须具有独立抽样事件')
            matrix.append(dict(request_id=request['request_id'],
                task_unit_id=task['task_unit_id'], assigned_context=request['context'], version=request['version'],
                values=[request['context'], request['version']-1, *request['actual_states'], result['secure_yield']]))
    if len(matrix) != 4000:
        raise ValueError('主结构表必须保留四千次实际随机混合观察')
    labels = ['C', 'V', 'X_local', 'X_example', 'X_reference', 'Y']
    _, coverage = state_coverage(panel)
    features, effects = [], []
    for task in panel:
        identity = task['task_unit_id']
        for index, policy in enumerate(('local', 'example', 'reference')):
            versions = []
            for version in (1, 2):
                baseline, edited = means[(identity, 'B', version)], means[(identity, policy, version)]
                if not baseline or not edited:
                    raise ValueError('发现任务的完整条件或表达版本缺失')
                versions.append(dict(version=version, baseline_count=len(baseline), edited_count=len(edited),
                    baseline_mean=float(np.mean(baseline)), edited_mean=float(np.mean(edited)),
                    actual_edit_minus_baseline=float(np.mean(edited)-np.mean(baseline))))
            delta = sum(row['actual_edit_minus_baseline'] for row in versions)/2
            orientation = 1-2*task['initial_states'][index]
            effects.append(dict(task_unit_id=identity, case_id=task['case_id'], policy=policy,
                orientation=orientation, versions=versions, actual_edit_minus_baseline=delta,
                canonical_effect=orientation*delta,
                semantic_qualified=task['policies']['TSG'][index]['semantic_qualified']))
            features.append(dict(task_unit_id=identity, case_id=task['case_id'], policy=policy,
                features=controlled_ridge_features(task, policy), delta_pn=delta))
    if len(features) != 1200:
        raise ValueError('辅助学习必须保留全部任务和三个政策位置')
    return tasks, labels, coverage, matrix, features, effects


def analyze_training(inputs, training, output):
    tasks, labels, coverage, matrix, rows, effects = assemble_training(inputs, training)
    if read_json(inputs / 'metadata.json').get('protocol_id') == 'controlled-semantic-20260930':
        return analyze_controlled_training(inputs, training, output, tasks, labels, coverage, matrix, rows, effects)
    output.mkdir(parents=True, exist_ok=False)
    matrix_by_id = {row['request_id']: row['values'] for row in matrix}
    subsets = read_json(inputs / 'structure-subsamples.json')
    samples = [*subsets, dict(index='full', request_ids=list(matrix_by_id))]
    graph_results = []
    cpu_started = time.process_time()
    r_cpu = 0.
    with (output / 'r-stderr.log').open('w', encoding='utf-8') as stderr:
        worker = PromptFCI(stderr)
        try:
            for sample in samples:
                if time.process_time()-cpu_started+r_cpu >= 7200:
                    raise TimeoutError('结构分析 CPU 额度已经达到')
                ci = DiscreteCI(f'jci-real-{sample["index"]}', labels,
                                rows=[matrix_by_id[identity] for identity in sample['request_ids']])
                pair = []
                for selector, mode in (('F', '1'), ('J', '12')):
                    search = worker.search(ci, mode)
                    r_cpu = search['r_process_cpu_seconds']
                    pair.append(dict(search, selector=selector, subsample=sample['index']))
                graph_results.extend(pair)
                write_bundle(output / f'graph-{sample["index"]}', {'searches.json': pair,
                    'queries.json': ci.cache, 'query_order.json': ci.queries, 'request-ids.json': sample['request_ids']})
        finally:
            worker.close()
    structure_cpu = time.process_time()-cpu_started+r_cpu
    if structure_cpu > 7200:
        raise TimeoutError('结构分析 CPU 额度超过限制')
    supports = {selector: {name: sum(row['selector'] == selector and row['subsample'] != 'full'
                                   and name in row.get('ancestors_y', []) for row in graph_results)/100
                           for name in labels[1:-1]} for selector in ('J', 'F')}
    if len({row['task_unit_id'] for row in rows}) >= 2:
        learner, folds = fit_task_equal_ridge(rows, ['discrete']*12+['continuous'])
        learner_record = learner.record()
    else:
        learner, folds, learner_record = None, [], dict(status='FEWER_THAN_TWO_FIT_TASKS')
    decisions = []
    opportunities = []
    for task in tasks:
        if task['role'] != 'evaluation':
            continue
        candidates = [row for row in task['policies'] if row['semantic_qualified']]
        opportunities.append(dict(case_id=task['case_id'], candidate_count=len(candidates),
            possible_nonzero_ranking_contrast=len(candidates) >= 2,
            candidate_changed_states={row['policy_hash']: row['changed_states'] for row in candidates}))
        predictions = learner.predict(candidates).tolist() if learner is not None and candidates else [0.]*len(candidates)
        selected = {selector: select_policy(candidates, predictions, supports.get(selector), frozen_discovery=True) for selector in ('R', 'J', 'F')}
        for action in selected.values():
            if action['action'] == 'B':
                action['action'] = task['baseline_hash']
        decisions.append(dict(case_id=task['case_id'], task_unit_id=task['task_unit_id'],
                              baseline_hash=task['baseline_hash'], selected=selected,
                              candidate_predictions=[dict(policy_hash=row['policy_hash'], prediction=value)
                                                     for row, value in zip(candidates, predictions, strict=True)]))
    write_bundle(output / 'analysis', {'decisions.json': decisions, 'learner.json': learner_record,
        'cross-validation.json': folds, 'training-effects.json': effects,
        'decision-opportunities.json': dict(tasks=opportunities,
            multiple_candidate_tasks=sum(row['possible_nonzero_ranking_contrast'] for row in opportunities),
            interpretation='共享预测与零预测规则时，单候选任务的祖先优先标记不能改变选择动作或符号。'),
        'structure-summary.json': dict(labels=labels, coverage=coverage, supports=supports,
                                       structure_cpu_seconds=structure_cpu, searches=graph_results),
        'mixture-rows.json': matrix, 'training-features.json': rows,
        'identity.json': dict(input_manifest_sha256=file_sha256(inputs / 'manifest.json'),
                             training_manifest_sha256=file_sha256(training / 'summary/manifest.json'),
                             analysis_sha256=file_sha256(Path(__file__)),
                             r_sha256=file_sha256(Path(__file__).with_name('structure_policy_cpu.R')),
                             ridge_sha256=file_sha256(Path(__file__).with_name('graph_guided_decisions.py')))})
    print(json.dumps(dict(supports=supports, structure_cpu_seconds=structure_cpu, evaluation_tasks=len(decisions))))


def comparison_coefficients(decisions, comparator):
    result = []
    for row in decisions:
        j, other = row['selected']['J'], row['selected'][comparator]
        coefficients = defaultdict(int)
        coefficients[j['action']] += j['direction']
        coefficients[other['action']] -= other['direction']
        coefficients[row['baseline_hash']] += other['direction']-j['direction']
        result.append(dict(case_id=row['case_id'], task_unit_id=row['task_unit_id'],
                           coefficients={key: value for key, value in coefficients.items() if value}))
    return result


def analyze_controlled_training(inputs, training, output, tasks, labels, coverage, matrix, rows, effects):
    names = ('local', 'example', 'reference')
    launch = read_json(inputs.parent / 'launch/launch.json')
    limit = launch['structure_cpu_seconds_limit']
    if limit != 28800 or labels != ['C', 'V', 'X_local', 'X_example', 'X_reference', 'Y']:
        raise ValueError('受控结构预算或完整变量定义不符')
    samples = read_json(inputs / 'structure-subsamples.json')
    if (len(samples) != 100 or {row['index'] for row in samples} != set(range(100))
            or any(len(row['request_ids']) != 3200 or len(set(row['request_ids'])) != 3200 for row in samples)):
        raise ValueError('结构扰动名单须为一百份八成无放回子样本')
    output.mkdir(parents=True, exist_ok=False)
    matrix_by_id = {row['request_id']: row['values'] for row in matrix}
    values = np.asarray([row['values'] for row in matrix])
    structural_issues = [dict(variable=row['name'], reasons=row['reasons'])
                         for row in coverage if row['status'] != 'DEFINED']
    for column, name in enumerate(labels):
        reasons = []
        if len(np.unique(values[:, column])) < 2:
            reasons.append('CONSTANT_IN_ACTUAL_MIXTURE')
        if any(np.array_equal(values[:, column], values[:, previous]) for previous in range(column)):
            reasons.append('DUPLICATE_IN_ACTUAL_MIXTURE')
        if column >= 2 and all(len(np.unique(values[(values[:, 0] == c) & (values[:, 1] == v), column])) <= 1
                               for c, v in itertools.product(range(5), range(2))):
            reasons.append('DETERMINISTIC_FROM_CONTEXTS_IN_ACTUAL_MIXTURE')
        if reasons:
            structural_issues.append(dict(variable=name, reasons=reasons))
    canonical_effects = {policy: sum(row['canonical_effect'] for row in effects
                                     if row['policy'] == policy)/400 for policy in names}
    candidates = [dict(policy=name) for name in names]
    predictions = [canonical_effects[name] for name in names]
    selected = dict(RD=dict(status='FROZEN', **select_policy(candidates, predictions, frozen_discovery=True)))
    graphs, cpu_used, stopped = [], 0., None
    planned = [dict(index='full', request_ids=[row['request_id'] for row in matrix]), *samples]
    if not structural_issues:
        cpu_started = time.process_time()
        with (output / 'r-stderr.log').open('w', encoding='utf-8') as stderr:
            worker = PromptFCI(stderr)
            worker.r_cpu_seconds = 0.
            def remaining():
                return limit - (time.process_time()-cpu_started) - worker.r_cpu_seconds
            try:
                for sample in planned:
                    ci = DiscreteCI(f'controlled-semantic-structure-{sample["index"]}', labels,
                        rows=[matrix_by_id[key] for key in sample['request_ids']], cpu_remaining=remaining)
                    pair = []
                    for selector, mode in (('F', '1'), ('J', '12')):
                        if stopped is not None or remaining() <= 0:
                            stopped = 'STRUCTURE_CPU_LIMIT_REACHED'
                            search = dict(status='unexecuted', reason=stopped, edges=None)
                        else:
                            search = worker.search(ci, mode, ('C', 'V'))
                            if search['status'] == 'cpu_budget_exhausted':
                                stopped = 'STRUCTURE_CPU_LIMIT_REACHED'
                        pair.append(dict(search, selector=selector, subsample=sample['index']))
                    graphs.extend(pair)
                    write_bundle(output / f'graph-{sample["index"]}', {'searches.json': pair,
                        'queries.json': ci.cache, 'query_order.json': ci.queries,
                        'request-ids.json': sample['request_ids'], 'resource.json': dict(
                            python_cpu_seconds=time.process_time()-cpu_started,
                            r_cpu_seconds=worker.r_cpu_seconds, cpu_limit_seconds=limit)})
            finally:
                worker.close()
        cpu_used = time.process_time()-cpu_started + worker.r_cpu_seconds
    else:
        graphs = [dict(status='unexecuted', reason='PRIMARY_STRUCTURE_VARIABLES_BLOCKED',
                       selector=selector, subsample=sample['index'], edges=None)
                  for sample in planned for selector in ('F', 'J')]
    available = not structural_issues and stopped is None and len(graphs) == 202
    supports = None
    permutations = []
    if available:
        if any(row['status'] not in ('determined', 'statistically_undetermined') for row in graphs):
            raise ValueError('完整结构支持包含未定义的搜索结果')
        supports = {selector: {policy: sum(row['selector'] == selector and row['subsample'] != 'full'
                    and f'X_{policy}' in row.get('ancestors_y', []) for row in graphs)/100
                    for policy in names} for selector in ('J', 'F')}
        selected.update({selector: dict(status='FROZEN', **select_policy(candidates, predictions, supports[selector], frozen_discovery=True))
                         for selector in ('J', 'F')})
        for indices in itertools.permutations(range(3)):
            permuted = {name: supports['J'][names[index]] for name, index in zip(names, indices, strict=True)}
            permutations.append(dict(support_permutation=list(indices), supports=permuted,
                                     choice=select_policy(candidates, predictions, permuted, frozen_discovery=True), weight=1/6))
    else:
        selected.update({selector: dict(status='unexecuted', reason=stopped or 'PRIMARY_STRUCTURE_VARIABLES_BLOCKED')
                         for selector in ('J', 'F')})
    folds = read_json(inputs / 'task-folds.json')
    learner, cross_validation = fit_task_equal_ridge(rows, ['continuous']*16,
        task_folds=folds, penalties=(.01, .1, 1., 10., 100.), minimum_task_support=1)
    learner_record = dict(learner.record(), minimum_task_support=1, task_weight='equal; three policies equal',
        feature_length_rule='mean over both versions of clipped changed characters divided by baseline length; SequenceMatcher with autojunk disabled')
    decisions = []
    for task in tasks:
        if task['role'] != 'evaluation':
            continue
        features = [dict(policy=policy, features=controlled_ridge_features(task, policy)) for policy in names]
        estimates = learner.predict(features).tolist()
        normalized = [value*(1-2*task['initial_states'][index]) for index, value in enumerate(estimates)]
        decisions.append(dict(case_id=task['case_id'], task_unit_id=task['task_unit_id'],
            selected=selected, permutation_choices=permutations,
            ridge=dict(choice=select_policy(candidates, normalized, frozen_discovery=True), actual_edit_predictions=estimates,
                       canonical_predictions=normalized)))
    write_bundle(output / 'analysis', {'decisions.json': decisions, 'learner.json': learner_record,
        'cross-validation.json': cross_validation, 'training-effects.json': effects,
        'canonical-effects.json': canonical_effects, 'training-features.json': rows, 'mixture-rows.json': matrix,
        'selection.json': dict(selected=selected, permutations=permutations),
        'structure-summary.json': dict(status='COMPLETED' if available else 'BLOCKED', labels=labels,
            coverage=coverage, structural_issues=structural_issues, supports=supports, searches=graphs,
            graph_support_denominator=100, structure_cpu_seconds=cpu_used, stop_reason=stopped,
            undetermined_counts={selector: sum(row['selector'] == selector and row['subsample'] != 'full'
                and row['status'] == 'statistically_undetermined' for row in graphs) for selector in ('J', 'F')}),
        'identity.json': dict(input_manifest_sha256=file_sha256(inputs / 'manifest.json'),
            training_manifest_sha256=file_sha256(training / 'summary/manifest.json'),
            analysis_sha256=file_sha256(Path(__file__)),
            r_sha256=file_sha256(Path(__file__).with_name('structure_policy_cpu.R')),
            ridge_sha256=file_sha256(Path(__file__).with_name('graph_guided_decisions.py')),
            frozen_at_utc=datetime.now(timezone.utc).isoformat())})


def controlled_policy_coefficients(tasks, requests, policy, reference='B'):
    names = ('local', 'example', 'reference')
    task_ids = {task['task_unit_id'] for task in tasks}
    if (not tasks or len(task_ids) != len(tasks) or policy not in names or reference not in ('B', 'S')
            or len({request['request_id'] for request in requests}) != len(requests)):
        raise ValueError('政策效果比较的任务、请求或条件无效')
    assigned, members = defaultdict(list), set()
    for request in requests:
        if request['task_unit_id'] not in task_ids:
            raise ValueError('政策比较请求来自其他固定面板')
        for member in request['members']:
            if member['flow'] != 'TSG' or member['condition'] not in (policy, reference):
                continue
            key = (request['task_unit_id'], member['condition'], member['version'], member['repeat'])
            if key in members or member['version'] not in (1, 2):
                raise ValueError('政策比较存在重复逻辑分配或未规定表达')
            members.add(key)
            assigned[key[:3]].append(request['request_id'])
    coefficients = []
    for task in tasks:
        state = task['initial_states'][names.index(policy)]
        if type(state) is not int or state not in (0, 1):
            raise ValueError('政策效果的原始状态未确定')
        orientation = 1-2*state
        for version in (1, 2):
            for condition, sign in ((policy, orientation), (reference, -orientation)):
                identities = assigned[(task['task_unit_id'], condition, version)]
                if not identities or len(set(identities)) != len(identities):
                    raise ValueError('政策效果缺少完整条件或表达分配')
                coefficients.extend((identity, Fraction(sign, 2*len(tasks)*len(identities)))
                                    for identity in identities)
    return coefficients


def controlled_natural_policy_sets(tasks):
    names = ('local', 'example', 'reference')
    if (len(tasks) > 60 or len({task['task_unit_id'] for task in tasks}) != len(tasks)
            or any(task['role'] != 'natural' for task in tasks)):
        raise ValueError('自然适用集合需要最多六十项独立自然任务')
    memberships = {policy: [] for policy in names}
    for task in tasks:
        policies = task['policies']['TSG']
        if len(policies) != 3 or {row['policy'] for row in policies} != set(names):
            raise ValueError('自然适用资格必须保留三项政策位置')
        states = task['initial_states']
        if len(states) != 3 or any(value is not None and (type(value) is not int or value not in (0, 1)) for value in states):
            raise ValueError('自然政策状态必须明确保留零、一或未知')
        for index, policy in enumerate(names):
            row = next(row for row in policies if row['policy'] == policy)
            if type(row['semantic_qualified']) is not bool:
                raise ValueError('自然语义资格必须为明确布尔值')
            if not row['semantic_qualified']:
                continue
            if states[index] is None or row['execution_mapping'] != 'edited':
                raise ValueError('自然适用政策缺少确定原状态或合法编辑')
            expected = list(states)
            expected[index] = 1-expected[index]
            review = row['review']
            versions = review['versions']
            if (review['status'] != 'pass' or len(versions) != 2
                    or {version['version'] for version in versions} != {1, 2}
                    or row['actual_states'] != expected
                    or any(version['status'] != 'pass' or version['binding_preserved'] is not True
                           or version['non_target_preserved'] is not True or version['states_before'] != states
                           or version['states_after'] != expected for version in versions)):
                raise ValueError('自然适用政策缺少完整两套表达的独立检查')
            for version in (1, 2):
                mappings = task['conditions']['TSG'][str(version)]
                for condition in ('B', policy, 'S'):
                    mapping = mappings[condition]
                    prompt = task['prompts'][mapping['prompt_hash']]
                    if (content_hash(prompt) != mapping['prompt_hash']
                            or mapping['states'] != (expected if condition == policy else states)
                            or condition == policy and row['prompts'][str(version)] != prompt):
                        raise ValueError('自然适用政策的完整提示或实际状态不符')
            memberships[policy].append(task['task_unit_id'])
    return {policy: sorted(identities) for policy, identities in memberships.items()}


def controlled_natural_comparison(tasks, requests, policy):
    from prompt_mechanism_study.development.semantic_discovery import fixed_panel_interval
    if not 1 <= len(tasks) <= 60 or policy not in ('local', 'example', 'reference'):
        raise ValueError('自然比较需要一至六十项任务及有效的选定政策')
    actual = [(request['task_unit_id'], member['condition'], member['version'], member['repeat'])
              for request in requests for member in request['members']]
    expected = {(task['task_unit_id'], condition, version, repeat) for task in tasks
                for condition in ('B', policy, 'S') for version in (1, 2) for repeat in range(8)}
    if (len(actual) != len(expected) or set(actual) != expected
            or any(member['flow'] != 'TSG' for request in requests for member in request['members'])):
        raise ValueError('自然比较必须保留每任务三项条件、两套表达及每表达八次的完整分配')
    coefficients = controlled_policy_coefficients(tasks, requests, policy)
    groups = {request['request_id']: request['independent_group'] for request in requests}
    planned = fixed_panel_interval(coefficients, groups, comparisons=12)
    return dict(planned,
        alpha=.05/12, fixed_task_count=len(tasks), selected_policy=policy,
        estimand='STATE_ONE_MINUS_STATE_ZERO', precision_qualified=planned['halfwidth'] <= .15)


def controlled_natural_nomination(tasks, policy_sets, selection, environment, used_seeds=()):
    names = ('local', 'example', 'reference')
    if policy_sets != controlled_natural_policy_sets(tasks):
        raise ValueError('自然提名不能改变事前政策适用集合')
    if selection['status'] not in ('FROZEN', 'unexecuted'):
        raise ValueError('自然提名的 JCI 选择状态无效')
    selected = selection.get('action') if selection['status'] == 'FROZEN' else None
    if selection['status'] == 'FROZEN' and (selected not in (*names, 'B')
            or selection['direction'] not in ((0,) if selected == 'B' else (-1, 1))):
        raise ValueError('自然提名的 JCI 政策或冻结方向无效')
    reason = ('JCI_NOMINATION_UNAVAILABLE' if selected is None else
              'JCI_ABSTENTION' if selected == 'B' else
              'NATURAL_POLICY_SET_EMPTY' if not policy_sets[selected] else None)
    base = dict(nomination=dict(selection), policy_sets=policy_sets,
                selected_policy=selected if selected in names else None)
    if reason is not None:
        return dict(base, status='unexecuted', reason=reason, fixed_task_ids=[], requests=[],
                    comparison=dict(status='unexecuted', reason=reason, alpha=.05/12))
    by_task = {task['task_unit_id']: task for task in tasks}
    fixed_ids = policy_sets[selected]
    fixed_tasks = [by_task[identity] for identity in fixed_ids]
    requests = controlled_requests(fixed_tasks, 'natural', environment, used_seeds, selected_policy=selected)
    comparison = controlled_natural_comparison(fixed_tasks, requests, selected)
    return dict(base, status='READY' if comparison['precision_qualified'] else 'unexecuted',
        reason=None if comparison['precision_qualified'] else 'NATURAL_FIXED_PANEL_PRECISION_INSUFFICIENT',
        fixed_task_ids=fixed_ids, requests=requests, comparison=comparison)


def validate_controlled_natural_execution(tasks, requests):
    names = ('local', 'example', 'reference')
    policies = {member['condition'] for request in requests for member in request['members']
                if member['condition'] not in ('B', 'S')}
    if (len(policies) != 1 or not policies <= set(names)
            or any(task['role'] != 'natural' for task in tasks)):
        raise ValueError('自然执行需要一个选定政策及完整自然任务角色')
    policy = next(iter(policies))
    by_task = {task['task_unit_id']: task for task in tasks}
    for task in tasks:
        candidate = next(row for row in task['policies']['TSG'] if row['policy'] == policy)
        if candidate['semantic_qualified'] is not True:
            raise ValueError('自然执行的选定政策未通过事前语义检查')
    for request in requests:
        task = by_task[request['task_unit_id']]
        for member in request['members']:
            mapping = task['conditions']['TSG'][str(member['version'])][member['condition']]
            states = list(task['initial_states'])
            if member['condition'] == policy:
                index = names.index(policy)
                if type(states[index]) is not int or states[index] not in (0, 1):
                    raise ValueError('自然执行的选定政策原始状态未确定')
                states[index] = 1-states[index]
            if request['actual_states'] != states or mapping['states'] != states:
                raise ValueError('自然执行的目标翻转或非目标状态发生变化')
            prompt = task['prompts'][mapping['prompt_hash']]
            if request['prompt_hash'] != mapping['prompt_hash'] or content_hash(prompt) != mapping['prompt_hash']:
                raise ValueError('自然执行的逻辑条件与实际全文身份不符')
    planned = controlled_natural_comparison(tasks, requests, policy)
    if not planned['precision_qualified']:
        raise ValueError('自然执行的事前固定面板区间半宽超过 0.15')
    return planned


def validate_controlled_natural_binding(prepared, decisions, inputs, source, analysis):
    for folder in (prepared, decisions, inputs, source, analysis, inputs.parent / 'development-qualified-inputs'):
        verify_bundle(folder)
    metadata = read_json(prepared / 'metadata.json')
    identity = read_json(prepared / 'identity.json')
    plan = read_json(decisions / 'natural-plan.json')
    if (metadata['status'] != 'FROZEN_CONTROLLED_NATURAL_INPUTS'
            or metadata['protocol_id'] != 'controlled-semantic-20260930'
            or metadata['natural_model_outcomes_seen'] is not False
            or metadata['execution_status'] != plan['status']
            or plan['status'] != 'READY'):
        raise ValueError('自然提名尚未取得执行资格')
    if (identity['evaluation_manifest_sha256'] != file_sha256(decisions / 'manifest.json')
            or identity['input_manifest_sha256'] != file_sha256(inputs / 'manifest.json')
            or identity['natural_preparation_manifest_sha256'] != file_sha256(source / 'manifest.json')
            or identity['analysis_manifest_sha256'] != read_json(decisions / 'identity.json')['analysis_manifest_sha256']
            or identity['analysis_manifest_sha256'] != file_sha256(analysis / 'manifest.json')
            or read_json(analysis / 'selection.json')['selected']['J'] != plan['nomination']
            or read_json(decisions / 'identity.json')['input_manifest_sha256'] != file_sha256(inputs / 'manifest.json')
            or read_json(inputs / 'metadata.json')['natural_preparation_manifest_sha256']
                != identity['natural_preparation_manifest_sha256']
            or read_json(prepared / 'nomination.json') != plan):
        raise ValueError('自然执行的提名或冻结来源身份不符')
    by_task = {task['task_unit_id']: task for task in read_json(source / 'tasks.json')}
    tasks = [by_task[task_id] for task_id in plan['fixed_task_ids']]
    environment = read_json(source / 'environment.json')
    used_seeds = {row['seed'] for phase in ('training', 'evaluation')
                  for row in read_json(inputs / f'{phase}-requests.json')}
    used_seeds.update(row['seed'] for row in read_json(inputs.parent / 'development-qualified-inputs/development-requests.json'))
    if plan['identity'] != dict(natural_preparation_manifest_sha256=file_sha256(source / 'manifest.json'),
            analysis_manifest_sha256=file_sha256(analysis / 'manifest.json'),
            input_manifest_sha256=file_sha256(inputs / 'manifest.json'), environment=environment,
            excluded_seeds=sorted(used_seeds)):
        raise ValueError('自然执行的原始阶段身份或随机子流排除名单不符')
    implementations = dict(read_json(inputs / 'input-identities.json'))
    implementations['src/measurement/natural_command.py'] = environment['worker_sha256']
    if (read_json(prepared / 'tasks.json') != tasks
            or read_json(prepared / 'natural-requests.json') != plan['requests']
            or read_json(prepared / 'environment.json') != environment
            or read_json(prepared / 'input-identities.json') != implementations
            or metadata['selected_policy'] != plan['selected_policy']
            or metadata['fixed_task_count'] != len(tasks)
            or metadata['natural_calls'] != len(plan['requests'])
            or metadata['natural_logical_calls'] != 48*len(tasks)
            or metadata['docker_image'] != environment['image']):
        raise ValueError('自然执行任务、全文、分配或环境改变')
    sets = read_json(source / 'policy-sets.json')
    expected = controlled_natural_nomination(list(by_task.values()), sets, plan['nomination'],
        environment, plan['identity']['excluded_seeds'])
    if any(plan[key] != value for key, value in expected.items()):
        raise ValueError('自然执行的事前集合、提名规则或完整分配改变')
    actual = validate_controlled_natural_execution(tasks, plan['requests'])
    if actual != plan['comparison']:
        raise ValueError('自然执行的实际物理系数或精度改变')
    return actual


def controlled_comparisons(tasks, requests, decisions):
    from prompt_mechanism_study.development.semantic_discovery import fixed_panel_interval
    names = ('local', 'example', 'reference')
    task_ids = {task['task_unit_id'] for task in tasks}
    choices = {row['task_unit_id']: row for row in decisions}
    if not tasks or len(task_ids) != len(tasks) or set(choices) != task_ids or len(choices) != len(decisions):
        raise ValueError('固定比较的任务与决策身份不符')
    assigned = defaultdict(list)
    groups = {}
    for request in requests:
        identity = request['request_id']
        if identity in groups or request['task_unit_id'] not in task_ids:
            raise ValueError('固定比较包含重复请求或其他面板任务')
        groups[identity] = request['independent_group']
        for member in request['members']:
            assigned[(request['task_unit_id'], member['flow'], member['condition'], member['version'])].append(identity)

    def contrast(task, flow, policy, direction, reference='B'):
        if policy == 'B':
            if direction != 0:
                raise ValueError('弃权动作的冻结方向必须为零')
            return []
        if policy not in names or direction not in (-1, 1):
            raise ValueError('冻结政策选择或方向无效')
        orientation = 1-2*task['initial_states'][names.index(policy)]
        entries = []
        for version in (1, 2):
            for condition, sign in ((policy, direction*orientation), (reference, -direction*orientation)):
                source_flow = 'TSG' if condition in ('B', 'S') else flow
                identities = assigned[(task['task_unit_id'], source_flow, condition, version)]
                if not identities or len(identities) != len(set(identities)):
                    raise ValueError('固定比较缺少完整的逻辑条件与表达分配')
                entries.extend((identity, Fraction(sign, 2*len(tasks)*len(identities))) for identity in identities)
        return entries

    def collect(selector, flow='TSG', use_direction=True):
        rows = []
        for task in tasks:
            decision = choices[task['task_unit_id']]
            action = decision['ridge']['choice'] if selector == 'Ridge' else decision['selected'][selector]
            if action.get('status', 'FROZEN') != 'FROZEN':
                return None
            direction = action['direction'] if use_direction or action['action'] == 'B' else 1
            rows.extend(contrast(task, flow, action['action'], direction))
        return rows

    coefficients = {}
    for index, policy in enumerate(names):
        coefficients[f'H{index+1}'] = controlled_policy_coefficients(tasks, requests, policy)
        coefficients[f'H{index+4}'] = controlled_policy_coefficients(tasks, requests, policy, 'S')
    values = {selector: collect(selector) for selector in ('RD', 'J', 'F', 'Ridge')}
    permuted = []
    for task in tasks:
        entries = choices[task['task_unit_id']]['permutation_choices']
        if not entries:
            permuted = None
            break
        if (len(entries) != 6 or {tuple(row['support_permutation']) for row in entries}
                != set(itertools.permutations(range(3)))):
            raise ValueError('置换对照须保留全部六种排列')
        for entry in entries:
            if not math.isclose(entry['weight'], 1/6, rel_tol=0, abs_tol=1e-15):
                raise ValueError('置换对照权重必须为六分之一')
            action = entry['choice']
            permuted.extend((identity, weight/6) for identity, weight
                            in contrast(task, 'TSG', action['action'], action['direction']))
    values['Permutation'] = permuted
    for hypothesis, comparator in (('H7', 'RD'), ('H8', 'F'), ('H9', 'Permutation')):
        coefficients[hypothesis] = (None if values['J'] is None or values[comparator] is None
            else [*values['J'], *[(identity, -weight) for identity, weight in values[comparator]]])
    for hypothesis, flow in (('H10', 'Raw'), ('H11', 'Rich-Flat')):
        representation = collect('RD', flow)
        coefficients[hypothesis] = (None if values['RD'] is None or representation is None
            else [*values['RD'], *[(identity, -weight) for identity, weight in representation]])
    comparisons = {hypothesis: (dict(status='unexecuted', reason='REQUIRED_FROZEN_SELECTION_UNAVAILABLE',
        alpha=.05/12, fixed_task_count=len(tasks)) if entries is None else
        dict(fixed_panel_interval(entries, groups, comparisons=12), alpha=.05/12, fixed_task_count=len(tasks)))
        for hypothesis, entries in coefficients.items()}
    comparisons['H12'] = dict(status='unexecuted', reason='NATURAL_EVALUATION_NOT_FROZEN', alpha=.05/12)
    descriptions = {selector: (dict(status='unexecuted', reason='REQUIRED_FROZEN_SELECTION_UNAVAILABLE')
        if entries is None else dict(fixed_panel_interval(entries, groups, comparisons=12),
        interval_status='DESCRIPTIVE_FIXED_PANEL')) for selector, entries in values.items()}
    descriptions.update({f'{selector}_state_one_effect': dict(
        fixed_panel_interval(entries, groups, comparisons=12), interval_status='DESCRIPTIVE_FIXED_PANEL')
        for selector in ('RD', 'J', 'F') if (entries := collect(selector, use_direction=False)) is not None})
    return comparisons, descriptions


def freeze_controlled_evaluation(inputs, analysis, service, output):
    from prompt_mechanism_study.development.semantic_discovery import fixed_panel_interval
    for folder in (inputs, analysis / 'analysis'):
        verify_bundle(folder)
    metadata = read_json(inputs / 'metadata.json')
    tasks = [row for row in read_json(inputs / 'tasks.json') if row['role'] == 'evaluation']
    requests = read_json(inputs / 'evaluation-requests.json')
    decisions = read_json(analysis / 'analysis/decisions.json')
    identity = read_json(analysis / 'analysis/identity.json')
    if identity['input_manifest_sha256'] != file_sha256(inputs / 'manifest.json') or len(tasks) != 400:
        raise ValueError('发现选择身份或独立评价面板数量不符')
    services = []
    for folder in sorted(service.glob('service-*')):
        verify_bundle(folder / 'stopped')
        record = read_json(folder / 'stopped/service.json')
        if not record['process_absent']:
            raise ValueError('已有模型服务尚未终止')
        services.append(record)
    if not any(row['phase'] == 'training' for row in services):
        raise ValueError('发现生成服务尚未完成')
    launch = read_json(inputs.parent / 'launch/launch.json')
    prior_seconds = sum(row['service_seconds'] for row in services)
    prior_attempts = sum(len(list((service / phase).glob('*/assigned/manifest.json')))
                         for phase in {row['phase'] for row in services})
    if (prior_seconds >= launch['model_service_seconds_limit']
            or prior_attempts+len(requests) > launch['generation_call_limit']
            or datetime.now(timezone.utc) >= datetime.fromisoformat(launch['deadline_utc'])):
        raise ValueError('独立评价超过研究时间或请求预算')
    if any(record['phase'] in ('evaluation', 'natural') for record in services):
        raise ValueError('发现选择须在独立评价结果出现前冻结')
    counts = defaultdict(int)
    for request in requests:
        for member in request['members']:
            counts[(request['task_unit_id'], member['flow'], member['condition'], member['version'])] += 1
    expected = {(task['task_unit_id'], flow, condition, version): 2 for task in tasks
                for flow in ('TSG', 'Raw', 'Rich-Flat')
                for condition in (('B', 'local', 'example', 'reference', 'S') if flow == 'TSG'
                                  else ('local', 'example', 'reference')) for version in (1, 2)}
    if dict(counts) != expected or len(requests) != metadata['evaluation_calls']:
        raise ValueError('独立评价分配违反事前冻结的完整数量')
    comparisons, values = controlled_comparisons(tasks, requests, decisions)
    natural_root = inputs.parent / 'natural-preparation'
    verify_bundle(natural_root)
    if file_sha256(natural_root / 'manifest.json') != metadata['natural_preparation_manifest_sha256']:
        raise ValueError('自然政策适用集合与主输入冻结身份不符')
    native_tasks = read_json(natural_root / 'tasks.json')
    native_sets = read_json(natural_root / 'policy-sets.json')
    native_environment = read_json(natural_root / 'environment.json')
    used_seeds = {row['seed'] for row in requests}
    used_seeds.update(row['seed'] for row in read_json(inputs / 'training-requests.json'))
    used_seeds.update(row['seed'] for row in read_json(inputs.parent / 'development-qualified-inputs/development-requests.json'))
    nomination = read_json(analysis / 'analysis/selection.json')['selected']['J']
    natural_plan = controlled_natural_nomination(native_tasks, native_sets, nomination, native_environment, used_seeds)
    if (prior_attempts+len(requests)+(len(natural_plan['requests']) if natural_plan['status'] == 'READY' else 0)
            > launch['generation_call_limit']):
        raise ValueError('独立评价及自然提名分配超过累计请求预算')
    natural_plan['identity'] = dict(natural_preparation_manifest_sha256=file_sha256(natural_root / 'manifest.json'),
        analysis_manifest_sha256=file_sha256(analysis / 'analysis/manifest.json'),
        input_manifest_sha256=file_sha256(inputs / 'manifest.json'),
        environment=native_environment, excluded_seeds=sorted(used_seeds))
    groups = {request['request_id']: request['independent_group'] for request in requests}
    for specification in [*comparisons.values(), *values.values()]:
        if 'coefficients' in specification:
            actual = fixed_panel_interval(specification['coefficients'].items(), groups, comparisons=12)
            if actual['halfwidth'] != specification['halfwidth']:
                raise ValueError('固定比较物理请求系数核验失败')
    native_output = inputs.parent / 'natural-qualified-inputs'
    if output.exists() or native_output.exists():
        raise FileExistsError('评价及自然执行冻结目录必须尚未存在')
    frozen_at = datetime.now(timezone.utc).isoformat()
    native_by_task = {task['task_unit_id']: task for task in native_tasks}
    native_task_subset = [native_by_task[task_id] for task_id in natural_plan['fixed_task_ids']]
    native_implementations = dict(read_json(inputs / 'input-identities.json'))
    native_implementations['src/measurement/natural_command.py'] = native_environment['worker_sha256']
    write_bundle(output, {'evaluation-requests.json': requests, 'decisions.json': decisions,
        'natural-plan.json': natural_plan,
        'comparisons.json': comparisons, 'selector-coefficients.json': values,
        'budget.json': dict(evaluation_calls=len(requests), logical_evaluation_calls=17600,
            prior_attempts=prior_attempts, prior_service_seconds=prior_seconds,
            generation_call_limit=launch['generation_call_limit'],
            model_service_seconds_limit=launch['model_service_seconds_limit']),
        'identity.json': dict(input_manifest_sha256=file_sha256(inputs / 'manifest.json'),
            analysis_manifest_sha256=file_sha256(analysis / 'analysis/manifest.json'),
            frozen_at_utc=frozen_at, implementation_sha256=file_sha256(Path(__file__)))})
    write_bundle(native_output, {
        'tasks.json': native_task_subset,
        'natural-requests.json': natural_plan['requests'], 'nomination.json': natural_plan,
        'environment.json': native_environment, 'input-identities.json': native_implementations,
        'identity.json': dict(input_manifest_sha256=file_sha256(inputs / 'manifest.json'),
            analysis_manifest_sha256=file_sha256(analysis / 'analysis/manifest.json'),
            evaluation_manifest_sha256=file_sha256(output / 'manifest.json'),
            natural_preparation_manifest_sha256=file_sha256(natural_root / 'manifest.json'),
            frozen_at_utc=frozen_at, implementation_sha256=file_sha256(Path(__file__))),
        'metadata.json': dict(protocol_id=metadata['protocol_id'], status='FROZEN_CONTROLLED_NATURAL_INPUTS',
            execution_status=natural_plan['status'], reason=natural_plan['reason'],
            selected_policy=natural_plan['selected_policy'], fixed_task_count=len(natural_plan['fixed_task_ids']),
            natural_calls=len(natural_plan['requests']), natural_logical_calls=48*len(natural_plan['fixed_task_ids']),
            natural_model_outcomes_seen=False, docker_image=native_environment['image'], frozen_at_utc=frozen_at)})


def freeze_evaluation(inputs, analysis, service, output):
    if read_json(inputs / 'metadata.json').get('protocol_id') == 'controlled-semantic-20260930':
        return freeze_controlled_evaluation(inputs, analysis, service, output)
    for path in (inputs, analysis / 'analysis', service / 'stopped'):
        verify_bundle(path)
    metadata = read_json(inputs / 'metadata.json')
    tasks = [row for row in read_json(inputs / 'tasks.json') if row['role'] == 'evaluation']
    decisions = read_json(analysis / 'analysis/decisions.json')
    if {row['task_unit_id'] for row in decisions} != {row['task_unit_id'] for row in tasks}:
        raise ValueError('评价任务与冻结决策不对应')
    disagreement = any(len({(action['action'], action['direction']) for action in row['selected'].values()}) > 1
                       for row in decisions)
    unique_texts = sum(len(set(row['slot_prompt_hashes'])) for row in tasks)
    budget = evaluation_budget(metadata['H'], metadata['E'],
                               (metadata['training_calls']-6*metadata['H'])//2, unique_texts, disagreement)
    runtime = read_json(service / 'stopped/service.json')
    repeats = budget['evaluation_repeats']
    available = 21600-runtime['cumulative_service_seconds']
    training_results = read_json(service.parent / 'training/summary/results.json')
    generation_seconds = [row['generation_seconds'] for row in training_results if row['generation_seconds'] is not None]
    # 每项预留实际训练耗时的第九十分位数、35秒探针、容器成本及模型重新加载时间。
    seconds_per_request = float(np.quantile(generation_seconds, .9)) + 40
    feasible = int(max(0., available-600)//(unique_texts*seconds_per_request))
    if feasible < repeats:
        repeats = feasible
    if repeats < 8:
        raise ValueError('剩余服务时间不足每全文八次；评价尚未执行')
    requests, used = [], {row['seed'] for row in read_json(inputs / 'training-requests.json')}
    seeds = random_stream('jci-ridge-20260930', 'evaluation-generation-seeds')
    for task in tasks:
        for prompt_hash in sorted(set(task['slot_prompt_hashes'])):
            for repeat in range(repeats):
                seed = int(seeds.integers(1, 2**31-1))
                while seed in used:
                    seed = int(seeds.integers(1, 2**31-1))
                used.add(seed)
                requests.append(dict(task_unit_id=task['task_unit_id'], prompt_hash=prompt_hash,
                                     component='evaluation', context=None, repeat=repeat, seed=seed,
                                     request_id=f'jci-ridge-20260930-evaluation-{len(requests):05d}'))
    order = random_stream('jci-ridge-20260930', 'evaluation-dispatch').permutation(len(requests))
    requests = [requests[index] for index in order]
    comparisons = {}
    for comparator in ('R', 'F'):
        coefficients = comparison_coefficients(decisions, comparator)
        squares = sum(value**2 for row in coefficients for value in row['coefficients'].values())
        half_width = math.sqrt(math.log(80)*squares/(2*len(tasks)**2*repeats))
        comparisons[f'J-{comparator}'] = dict(coefficients=coefficients, coefficient_squares=squares,
            alpha=.025, half_width=half_width, fixed_task_count=len(tasks), repeats=repeats,
            attainable_range=[-sum(abs(value) for row in coefficients for value in row['coefficients'].values())/(2*len(tasks)),
                               sum(abs(value) for row in coefficients for value in row['coefficients'].values())/(2*len(tasks))])
    write_bundle(output, {'evaluation-requests.json': requests, 'decisions.json': decisions,
        'comparisons.json': comparisons, 'budget.json': dict(budget, evaluation_repeats=repeats,
            actual_planned_total=metadata['training_calls']+len(requests), evaluation_unique_texts=unique_texts,
            disagreement=disagreement, service_seconds_available=available,
            planning_seconds_per_request=seconds_per_request, planning_startup_seconds=600),
        'identity.json': dict(input_manifest_sha256=file_sha256(inputs / 'manifest.json'),
            analysis_manifest_sha256=file_sha256(analysis / 'analysis/manifest.json'),
            frozen_at_utc=datetime.now(timezone.utc).isoformat())})
    print(json.dumps(dict(requests=len(requests), repeats=repeats, disagreement=disagreement,
                          half_widths={key: value['half_width'] for key, value in comparisons.items()})))


def report_evaluation(inputs, decisions_root, evaluation, output):
    if read_json(inputs / 'metadata.json').get('protocol_id') == 'controlled-semantic-20260930':
        return report_controlled_evaluation(inputs, decisions_root, evaluation, output)
    verify_bundle(inputs)
    verify_bundle(decisions_root)
    decisions = read_json(decisions_root / 'decisions.json')
    requests = read_json(decisions_root / 'evaluation-requests.json')
    budget = read_json(decisions_root / 'budget.json')
    comparisons = read_json(decisions_root / 'comparisons.json')
    tasks = [row for row in read_json(inputs / 'tasks.json') if row['role'] == 'evaluation']
    repeats, task_count = budget['evaluation_repeats'], len(tasks)
    observations, groups = [], defaultdict(list)
    for request in requests:
        root = evaluation / request['request_id'] / 'result'
        if root.exists():
            verify_bundle(root)
            result = read_json(root / 'result.json')
            if any(result[key] != value for key, value in request.items()):
                raise ValueError('评价请求身份不匹配')
            if result['secure_yield'] not in (0, 1, None):
                raise ValueError('评价结果超出冻结范围')
            result['result_manifest_sha256'] = file_sha256(root / 'manifest.json')
        else:
            result = dict(request, status='unexecuted', secure_yield=None, code_valid=None,
                          security_label=None, functionality=None, joint_success=None)
        observations.append(result)
        groups[(request['task_unit_id'], request['prompt_hash'])].append(result)
    if len({row['request_id'] for row in observations}) != len(requests):
        raise ValueError('评价物理请求重复')
    if any(len(rows) != repeats for rows in groups.values()):
        raise ValueError('全文请求数不符合冻结重复数量')
    means = {}
    for key, rows in groups.items():
        values = [row['secure_yield'] for row in rows]
        missing = sum(value is None for value in values)
        total = sum(value for value in values if value is not None)
        means[key] = dict(mean=total/repeats if not missing else None,
                          completion_lower=total/repeats, completion_upper=(total+missing)/repeats,
                          assigned=repeats, missing=missing,
                          label_counts={str(label): sum(row['security_label'] == label for row in rows)
                                        for label in ('secure', 'insecure', 'unknown', 'invalid', None)},
                          valid=sum(row['code_valid'] is True for row in rows),
                          partial_functionality=sum(row['functionality'] == 'partial_pass' for row in rows))
    def evaluate_coefficients(coefficients, divisor):
        lower = upper = squares = 0.
        missing = 0
        for row in coefficients:
            for prompt_hash, coefficient in row['coefficients'].items():
                mean = means[(row['task_unit_id'], prompt_hash)]
                a, b = coefficient*mean['completion_lower']/divisor, coefficient*mean['completion_upper']/divisor
                lower += min(a, b)
                upper += max(a, b)
                squares += coefficient**2/(divisor**2*repeats)
                missing += mean['missing']
        half_width = math.sqrt(math.log(80)*squares/2)
        return dict(estimate=lower if not missing else None, completion_envelope=[lower, upper],
                    half_width=half_width, interval=[lower-half_width, upper+half_width],
                    missing_contributing_requests=missing)
    comparison_results = {}
    for name, specification in comparisons.items():
        result = evaluate_coefficients(specification['coefficients'], task_count)
        if not math.isclose(result['half_width'], specification['half_width'], abs_tol=1e-12):
            raise ValueError('实际比较半宽与评价前冻结不一致')
        result.update(alpha=specification['alpha'], coefficients=specification['coefficients'])
        lower, upper = result['interval']
        result['interpretation'] = ('IDENTICAL_ASSIGNED_ACTIONS_AND_SIGNS' if result['half_width'] == 0
            else 'POSITIVE_INCREMENT_OVER_0_10' if lower > .1
            else 'POSITIVE_INCREMENT' if lower > 0
            else 'NEGATIVE_INCREMENT' if upper < 0
            else 'UNRESOLVED_AT_0_10_SCALE' if upper >= .1 else 'INTERVAL_INCLUDES_ZERO')
        comparison_results[name] = result
    values = {}
    for selector in ('R', 'J', 'F'):
        coefficients = []
        for row in decisions:
            action = row['selected'][selector]
            merged = defaultdict(int)
            merged[action['action']] += action['direction']
            merged[row['baseline_hash']] -= action['direction']
            coefficients.append(dict(task_unit_id=row['task_unit_id'],
                                      coefficients={key: value for key, value in merged.items() if value}))
        values[selector] = evaluate_coefficients(coefficients, task_count)
        values[selector]['interval_status'] = 'DESCRIPTIVE_FIXED_PANEL_NOT_ADDITIONAL_MAIN_TEST'
    cases = []
    for task in tasks:
        base = means[(task['task_unit_id'], task['baseline_hash'])]
        policies = []
        for candidate in task['policies']:
            if not candidate['semantic_qualified']:
                continue
            edited = means[(task['task_unit_id'], candidate['policy_hash'])]
            raw = evaluate_coefficients([dict(task_unit_id=task['task_unit_id'],
                coefficients={candidate['policy_hash']:1, task['baseline_hash']:-1})], 1)
            policies.append(dict(policy_hash=candidate['policy_hash'], slot=candidate['slot'],
                operation=candidate['operation'], changed_states=candidate['changed_states'], edited=edited,
                policy_effect=raw, interval_status='DESCRIPTIVE_NOT_MULTIPLICITY_ADJUSTED_MECHANISM_CLAIM'))
        cases.append(dict(case_id=task['case_id'], task_unit_id=task['task_unit_id'], baseline=base, policies=policies))
    complete = all(row['secure_yield'] is not None for row in observations)
    launch = read_json(inputs.parent / 'launch/launch.json')
    input_metadata = read_json(inputs / 'metadata.json')
    results_root = evaluation.parent
    services, usage = {}, {}
    for phase in ('training', 'evaluation'):
        stopped = results_root / f'service-{phase}' / 'stopped'
        verify_bundle(stopped)
        services[phase] = read_json(stopped / 'service.json')
        phase_requests = (read_json(inputs / 'training-requests.json') if phase == 'training' else requests)
        total_tokens, counted, attempts = 0, 0, 0
        for request in phase_requests:
            attempts += (results_root / phase / request['request_id'] / 'assigned/manifest.json').exists()
            path = results_root / phase / request['request_id'] / 'response.json'
            if path.exists():
                count = read_json(path).get('usage', {}).get('total_tokens')
                if count is not None:
                    total_tokens += count
                    counted += 1
        usage[phase] = dict(assigned=len(phase_requests), generation_attempts=attempts, usage_records=counted,
                            known_total_tokens=total_tokens,
                            complete_total_tokens=total_tokens if counted == len(phase_requests) else None)
    start = datetime.fromisoformat(launch['t0_utc'])
    finished = datetime.fromisoformat(services['evaluation']['stopped_utc'])
    prepared_at = datetime.fromisoformat(input_metadata['frozen_at_utc'])
    structure = read_json(results_root / 'analysis/analysis/structure-summary.json')
    service_seconds = sum(row['service_seconds'] for row in services.values())
    cost = dict(model_usage=usage, services=services, model_service_seconds=service_seconds,
        generation_attempts=sum(row['generation_attempts'] for row in usage.values()),
        structure_cpu_seconds=structure['structure_cpu_seconds'],
        preparation_seconds=(prepared_at-start).total_seconds(),
        experiment_seconds_through_service_shutdown=(finished-start).total_seconds(),
        semantic_review_sessions=1, semantic_review_requests=7, semantic_review_tokens=None,
        budget_checks=dict(generation=sum(row['generation_attempts'] for row in usage.values()) <= 1344,
            model_service=service_seconds <= 21600, structure_cpu=structure['structure_cpu_seconds'] <= 7200,
            preparation=prepared_at <= datetime.fromisoformat(launch['preparation_deadline_utc']),
            experiment=finished <= datetime.fromisoformat(launch['deadline_utc'])),
        interpretation='实际可获得的调用、服务和准备计量；网页 token 与手工准备 token 未获得。')
    write_bundle(output, {'comparisons.json': comparison_results, 'selector-values.json': values,
        'cases.json': cases, 'observations.json': observations, 'cost.json': cost,
        'status.json': dict(complete=complete, assigned=len(requests), observed=sum(row['secure_yield'] is not None for row in observations),
            fixed_task_count=task_count, repeats=repeats, primary_endpoint='oracle_evaluable_secure_code_yield',
            functionality_scope='partial', joint_success_claim=False, task_population_inference=False,
            input_manifest_sha256=file_sha256(inputs / 'manifest.json'),
            decision_manifest_sha256=file_sha256(decisions_root / 'manifest.json'),
            report_sha256=file_sha256(Path(__file__)))})
    print(json.dumps(dict(complete=complete, comparisons=comparison_results)))


def controlled_natural_condition_summary(rows):
    if not rows or len({row['request_id'] for row in rows}) != len(rows):
        raise ValueError('自然条件汇总需要完整且唯一的分配身份')
    values = [row['secure_yield'] for row in rows]
    if any(value is not None and (type(value) is not int or value not in (0, 1)) for value in values):
        raise ValueError('自然主要安全产出超出规定范围')
    assigned, missing = len(rows), sum(value is None for value in values)
    total = sum(value for value in values if value is not None)
    return dict(assigned=assigned, missing=missing, mean=None if missing else total/assigned,
        completion_bounds=[total/assigned, (total+missing)/assigned],
        request_ids=[row['request_id'] for row in rows],
        security_labels={str(label): sum(row.get('security_label') == label for row in rows)
            for label in ('secure', 'insecure', 'unknown', 'invalid', None)},
        code_valid=sum(row.get('code_valid') is True for row in rows),
        oracle_supported=sum(row.get('oracle_support') is True for row in rows),
        direct_unsafe=sum(row.get('direct_unsafe') is True for row in rows),
        partial_functionality_pass=sum(row.get('functionality') == 'partial_pass' for row in rows),
        complete_functionality_unknown=sum(row.get('complete_functionality') in (None, 'unknown') for row in rows),
        joint_success_unknown=sum(row.get('joint_success') is None for row in rows),
        finite_witness_joint=sum(row.get('finite_witness_joint') == 1 for row in rows),
        unknown_reasons=[row.get('unknown_reason') for row in rows])


def controlled_interval_interpretation(result):
    lower, upper = result['interval']
    return ('IDENTICAL_PHYSICAL_COEFFICIENTS' if result['nonzero_requests'] == 0
        else 'POSITIVE_INCREMENT_OVER_0_10' if lower > .1
        else 'POSITIVE_INCREMENT' if lower > 0
        else 'NEGATIVE_INCREMENT' if upper < 0
        else 'UNRESOLVED_AT_0_10_SCALE' if upper >= .1 else 'INTERVAL_INCLUDES_ZERO')


def report_controlled_natural(inputs, decisions_root, results):
    from prompt_mechanism_study.development.semantic_discovery import fixed_panel_interval
    prepared = inputs.parent / 'natural-qualified-inputs'
    for folder in (inputs, decisions_root, prepared):
        verify_bundle(folder)
    plan = read_json(decisions_root / 'natural-plan.json')
    if (read_json(prepared / 'nomination.json') != plan
            or read_json(prepared / 'identity.json')['evaluation_manifest_sha256']
                != file_sha256(decisions_root / 'manifest.json')):
        raise ValueError('自然报告与评价前冻结提名身份不符')
    tasks = read_json(prepared / 'tasks.json')
    requests = read_json(prepared / 'natural-requests.json')
    if requests != plan['requests'] or [task['task_unit_id'] for task in tasks] != plan['fixed_task_ids']:
        raise ValueError('自然报告的完整分配或任务名单改变')
    status = dict(execution_status=plan['status'], reason=plan['reason'],
        selected_policy=plan['selected_policy'], fixed_task_count=len(tasks),
        assigned_physical_requests=0, assigned_logical_requests=0, observed_physical_requests=0,
        complete=False, primary_endpoint='oracle_evaluable_secure_code_yield',
        functionality_scope='partial', complete_functionality='unknown', joint_success_claim=False,
        task_population_inference=False, natural_input_manifest_sha256=file_sha256(prepared / 'manifest.json'))
    if plan['status'] != 'READY':
        if list((results / 'natural').glob('*/assigned/manifest.json')):
            raise ValueError('未取得执行资格的自然计划存在实际模型分配')
        comparison = dict(status='unexecuted', reason=plan['reason'], alpha=.05/12,
            selected_policy=plan['selected_policy'], fixed_task_count=len(tasks),
            prospective_comparison=plan['comparison'])
        return dict(comparison=comparison, observations=[], cases=[], status=status)
    expected = validate_controlled_natural_binding(prepared, decisions_root, inputs,
        inputs.parent / 'natural-preparation', results / 'analysis/analysis')
    groups, outcomes, observations, logical = {}, {}, [], defaultdict(list)
    frozen_at = datetime.fromisoformat(read_json(prepared / 'identity.json')['frozen_at_utc'])
    for request in requests:
        folder = results / 'natural' / request['request_id'] / 'result'
        if folder.is_dir():
            verify_bundle(folder)
            result = read_json(folder / 'result.json')
            if any(result.get(key) != value for key, value in request.items()):
                raise ValueError('自然原始结果与冻结请求身份不符')
            if datetime.fromisoformat(result['started_utc']) < frozen_at:
                raise ValueError('自然生成早于输入冻结')
            result['result_manifest_sha256'] = file_sha256(folder / 'manifest.json')
        else:
            result = dict(request, status='unexecuted', secure_yield=None, code_valid=None,
                security_label=None, oracle_support=None, direct_unsafe=None, functionality=None,
                complete_functionality=None, joint_success=None, unknown_reason='request_not_measured')
        value = result['secure_yield']
        if value is not None and (type(value) is not int or value not in (0, 1)):
            raise ValueError('自然主要安全产出超出规定范围')
        identity = request['request_id']
        if identity in outcomes:
            raise ValueError('自然物理请求重复')
        groups[identity] = request['independent_group']
        outcomes[identity] = [0, 1] if value is None else [value, value]
        observations.append(result)
        for member in request['members']:
            logical[(request['task_unit_id'], member['condition'], member['version'])].append(result)
    interval = fixed_panel_interval(expected['coefficients'].items(), groups, outcomes, comparisons=12)
    if not math.isclose(interval['halfwidth'], expected['halfwidth'], rel_tol=0, abs_tol=1e-15):
        raise ValueError('自然报告的区间半宽与事前冻结不符')
    comparison = dict(expected, **interval, interpretation=controlled_interval_interpretation(interval))
    cases = []
    for task in tasks:
        conditions = []
        for condition in ('B', plan['selected_policy'], 'S'):
            versions = []
            for version in (1, 2):
                rows = logical[(task['task_unit_id'], condition, version)]
                if len(rows) != 8:
                    raise ValueError('自然报告必须保留每套表达的八次逻辑分配')
                versions.append(dict(version=version, **controlled_natural_condition_summary(rows)))
            bounds = [sum(row['completion_bounds'][index] for row in versions)/2 for index in (0, 1)]
            conditions.append(dict(condition=condition, versions=versions, assigned=16,
                completion_bounds=bounds, mean=bounds[0] if bounds[0] == bounds[1] else None))
        cases.append(dict(task_unit_id=task['task_unit_id'], source=task['source'],
            initial_states=task['initial_states'], conditions=conditions))
    status.update(assigned_physical_requests=len(requests), assigned_logical_requests=48*len(tasks),
        observed_physical_requests=sum(row['secure_yield'] is not None for row in observations),
        complete=all(row['secure_yield'] is not None for row in observations))
    return dict(comparison=comparison, observations=observations, cases=cases, status=status)


def report_controlled_evaluation(inputs, decisions_root, evaluation, output):
    from prompt_mechanism_study.development.source_generation import read_jci_result
    from prompt_mechanism_study.development.semantic_discovery import fixed_panel_interval
    for folder in (inputs, decisions_root):
        verify_bundle(folder)
    if read_json(decisions_root / 'identity.json')['input_manifest_sha256'] != file_sha256(inputs / 'manifest.json'):
        raise ValueError('评价结果所用冻结输入身份不符')
    tasks = [row for row in read_json(inputs / 'tasks.json') if row['role'] == 'evaluation']
    by_task = {row['task_unit_id']: row for row in tasks}
    requests = read_json(decisions_root / 'evaluation-requests.json')
    if len(tasks) != 400 or requests != read_json(inputs / 'evaluation-requests.json'):
        raise ValueError('评价面板或物理请求分配改变')
    specifications = read_json(decisions_root / 'comparisons.json')
    selectors = read_json(decisions_root / 'selector-coefficients.json')
    observations, outcomes, groups, logical = [], {}, {}, defaultdict(list)
    for request in requests:
        folder = evaluation / request['request_id'] / 'result'
        if folder.is_dir():
            verify_bundle(folder)
            result = read_jci_result(folder.parent)
            if any(result.get(key) != value for key, value in request.items()):
                raise ValueError('评价原始结果与冻结请求身份不符')
            result['result_manifest_sha256'] = file_sha256(folder / 'manifest.json')
        else:
            result = dict(request, status='unexecuted', secure_yield=None, code_valid=None,
                security_label=None, oracle_support=None, direct_unsafe=None, functionality=None,
                complete_functionality=None, joint_success=None, unknown_reason='request_not_measured')
        value = result['secure_yield']
        if value not in (0, 1, None):
            raise ValueError('评价主要安全产出超出规定范围')
        identity = request['request_id']
        if identity in outcomes:
            raise ValueError('评价物理请求重复')
        groups[identity] = request['independent_group']
        outcomes[identity] = [0, 1] if value is None else [value, value]
        observations.append(result)
        task = by_task[request['task_unit_id']]
        for member in request['members']:
            mapping = task['conditions'][member['flow']][str(member['version'])][member['condition']]
            if mapping['prompt_hash'] != request['prompt_hash'] or mapping['states'] != request['actual_states']:
                raise ValueError('评价实际全文或语义状态与逻辑条件不符')
            logical[(task['task_unit_id'], member['flow'], member['condition'], member['version'])].append(result)

    def calculate(specification):
        if 'coefficients' not in specification:
            return specification
        result = fixed_panel_interval(specification['coefficients'].items(), groups, outcomes, comparisons=12)
        if not math.isclose(result['halfwidth'], specification['halfwidth'], rel_tol=0, abs_tol=1e-15):
            raise ValueError('报告区间半宽与评价前冻结不符')
        return dict(specification, **result, interpretation=controlled_interval_interpretation(result))

    comparisons = {name: calculate(specification) for name, specification in specifications.items()}
    natural = report_controlled_natural(inputs, decisions_root, evaluation.parent)
    comparisons['H12'] = natural['comparison']
    values = {name: calculate(specification) for name, specification in selectors.items()}
    cases = []
    for task in tasks:
        conditions = []
        for flow in ('TSG', 'Raw', 'Rich-Flat'):
            for condition in ('B', 'local', 'example', 'reference', 'S'):
                versions = []
                for version in (1, 2):
                    source_flow = 'TSG' if condition in ('B', 'S') else flow
                    rows = logical[(task['task_unit_id'], source_flow, condition, version)]
                    if len(rows) != 2:
                        raise ValueError('报告必须保留每套表达的两次逻辑分配')
                    measured = [row['secure_yield'] for row in rows if row['secure_yield'] is not None]
                    total, missing = sum(measured), 2-len(measured)
                    versions.append(dict(version=version, assigned=2, missing=missing,
                        mean=None if missing else total/2, completion_bounds=[total/2, (total+missing)/2],
                        request_ids=[row['request_id'] for row in rows],
                        security_labels={str(label): sum(row.get('security_label') == label for row in rows)
                            for label in ('secure', 'insecure', 'unknown', 'invalid', None)},
                        code_valid=sum(row.get('code_valid') is True for row in rows),
                        oracle_supported=sum(row.get('oracle_support') is True for row in rows),
                        direct_unsafe=sum(row.get('direct_unsafe') is True for row in rows),
                        finite_functionality_pass=sum(row.get('functionality') == 'finite_pass' for row in rows),
                        complete_functionality_unknown=sum(row.get('complete_functionality') in (None, 'unknown') for row in rows),
                        unknown_reasons=[row.get('unknown_reason') for row in rows]))
                bounds = [sum(row['completion_bounds'][index] for row in versions)/2 for index in (0, 1)]
                conditions.append(dict(flow=flow, condition=condition, versions=versions,
                    completion_bounds=bounds, mean=bounds[0] if bounds[0] == bounds[1] else None,
                    preparation_qualified=(None if condition in ('B', 'S') else
                        task['policies'][flow][('local', 'example', 'reference').index(condition)]['semantic_qualified'])))
        cases.append(dict(task_unit_id=task['task_unit_id'], case_id=task['case_id'], family=task['family'],
                          initial_states=task['initial_states'], conditions=conditions))
    launch = read_json(inputs.parent / 'launch/launch.json')
    services, phases = [], {}
    for folder in sorted(evaluation.parent.glob('service-*')):
        verify_bundle(folder / 'stopped')
        service = read_json(folder / 'stopped/service.json')
        if not service['process_absent']:
            raise ValueError('结果报告时仍存在研究模型服务')
        services.append(service)
    for phase in ('development', 'training', 'evaluation', 'natural'):
        directory = evaluation.parent / phase
        assigned = list(directory.glob('*/assigned/manifest.json'))
        total, counted = 0, 0
        for path in assigned:
            response_path = path.parents[1] / 'response.json'
            if response_path.is_file():
                usage = read_json(response_path).get('usage', {}).get('total_tokens')
                if usage is not None:
                    total += usage
                    counted += 1
        phases[phase] = dict(generation_attempts=len(assigned), usage_records=counted,
                            known_total_tokens=total, complete_total_tokens=total if counted == len(assigned) else None)
    preparation = read_json(inputs / 'preparation-attempts.json')
    protocol_preparation = read_json(inputs / 'preparation-costs.json')
    attempted = {row['agent_path']: row for row in preparation}
    if len(attempted) != len(preparation) or any(attempted.get(row['agent_path']) != row for row in protocol_preparation):
        raise ValueError('全部实际准备资源未覆盖协议内的准备实例')
    development_costs = read_json(inputs.parent / 'development-qualified-inputs/preparation-costs.json')
    natural_costs = read_json(inputs.parent / 'natural-preparation/preparation-costs.json')
    costs = [*preparation, *development_costs, *natural_costs]
    metered_costs = [row for row in costs if row['usage'] is not None]
    structure = read_json(evaluation.parent / 'analysis/analysis/structure-summary.json')
    service_seconds = sum(row['service_seconds'] for row in services)
    attempts = sum(row['generation_attempts'] for row in phases.values())
    finished = max((row['stopped_utc'] for row in services), default=launch['t0_utc'])
    cost = dict(model_usage=phases, services=services, generation_attempts=attempts,
        model_service_seconds=service_seconds, structure_cpu_seconds=structure['structure_cpu_seconds'],
        preparation_instances=len(costs), preparation_calls=sum(row['top_level_requests'] for row in costs),
        preparation_protocol_instances=len(protocol_preparation)+len(development_costs),
        preparation_extra_instances=len(preparation)-len(protocol_preparation)+len(natural_costs),
        preparation_natural_instances=len(natural_costs),
        preparation_usage_records=len(metered_costs),
        preparation_unknown_usage_instances=len(costs)-len(metered_costs),
        preparation_known_input_tokens=sum(row['usage']['input_tokens'] for row in metered_costs),
        preparation_known_output_tokens=sum(row['usage']['output_tokens'] for row in metered_costs),
        preparation_known_reasoning_tokens=sum(row['usage']['reasoning_output_tokens'] for row in metered_costs),
        preparation_complete_total_tokens=(sum(row['usage']['total_tokens'] for row in metered_costs)
                                           if len(metered_costs) == len(costs) else None),
        preparation_model_configurations=sorted({canonical_json([row['models'], row['efforts']]) for row in costs}),
        experiment_seconds_through_service_shutdown=(datetime.fromisoformat(finished)
            -datetime.fromisoformat(launch['t0_utc'])).total_seconds(),
        budget_checks=dict(generation=attempts <= launch['generation_call_limit'],
            model_service=service_seconds <= launch['model_service_seconds_limit'],
            structure_cpu=structure['structure_cpu_seconds'] <= launch['structure_cpu_seconds_limit'],
            experiment=datetime.fromisoformat(finished) <= datetime.fromisoformat(launch['deadline_utc'])))
    write_bundle(output, {'comparisons.json': comparisons, 'selector-values.json': values,
        'cases.json': cases, 'observations.json': observations, 'cost.json': cost,
        'natural-cases.json': natural['cases'], 'natural-observations.json': natural['observations'],
        'natural-status.json': natural['status'],
        'status.json': dict(evaluation_complete=all(row['secure_yield'] is not None for row in observations),
            assigned_physical_requests=len(requests), assigned_tsg_logical_requests=8000,
            assigned_representation_target_requests=9600, fixed_task_count=400,
            observed_physical_requests=sum(row['secure_yield'] is not None for row in observations),
            primary_endpoint='oracle_evaluable_secure_code_yield', complete_functionality='unknown',
            joint_success_claim=False, task_population_inference=False, multiplicity_positions=12,
            input_manifest_sha256=file_sha256(inputs / 'manifest.json'),
            decision_manifest_sha256=file_sha256(decisions_root / 'manifest.json'),
            implementation_sha256=file_sha256(Path(__file__)))})


class PromptFCI(RWorker):
    def search(self, ci, mode, context_labels=('C',)):
        if mode not in ('0', '1', '12') or ci.labels[0] != 'C' or ci.labels[-1] != 'Y':
            raise ValueError('FCI 背景或变量次序无效')
        contexts = tuple(context_labels)
        if (not contexts or contexts != ci.labels[:len(contexts)]
                or len(set(contexts)) != len(contexts) or 'Y' in contexts):
            raise ValueError('随机 context 必须占据变量列表的连续起始位置')
        process = self.process
        process.stdin.write(json.dumps(dict(identity=ci.identity, labels=ci.labels, jci=mode,
                                           context_labels=contexts))+'\n')
        process.stdin.flush()
        while True:
            line = process.stdout.readline()
            if not line:
                raise RuntimeError('R 搜索终止，请检查诊断文件')
            message = json.loads(line)
            if message['type'] == 'query':
                self.r_cpu_seconds = message['r_process_cpu_seconds']
                try:
                    answer = ci.query(message['x'], message['y'], message['conditioned'])
                except StructureCpuLimit as limit:
                    answer = dict(status='cpu_budget_exhausted', reason=str(limit))
                process.stdin.write(json.dumps(answer)+'\n')
                process.stdin.flush()
                continue
            if message.pop('type') != 'result' or message['identity'] != ci.identity:
                raise ValueError('搜索输出身份不匹配')
            self.r_cpu_seconds = message['r_process_cpu_seconds']
            if message['status'] == 'determined':
                edges = message['edges']
                for a, left, right, b in edges:
                    if 'Y' in (a, b) and (left if a == 'Y' else right) != 'ARROW':
                        raise ValueError('结果违反共同时间背景')
                    if a in contexts and b in contexts:
                        raise ValueError('独立随机 context 之间不允许邻接')
                    for context, own, other in ((a, left, right), (b, right, left)):
                        if mode != '0' and context in contexts and other != 'ARROW':
                            raise ValueError('结果违反 context 外生性')
                        if mode == '12' and context in contexts and own != 'TAIL':
                            raise ValueError('结果违反 context 无混杂约束')
                message['ancestors_y'] = ancestors_y(edges)
            return message


def ancestors_y(edges):
    arrows = []
    for a, left, right, b in edges:
        if (left, right) == ('TAIL', 'ARROW'):
            arrows.append((a, b))
        elif (left, right) == ('ARROW', 'TAIL'):
            arrows.append((b, a))
    reached = {'Y'}
    while True:
        expanded = reached | {a for a, b in arrows if b in reached}
        if expanded == reached:
            return sorted(reached - {'Y'})
        reached = expanded


def population_check(output: Path):
    output.mkdir(parents=True, exist_ok=False)
    results = []
    with (output / 'r-stderr.log').open('w', encoding='utf-8') as stderr:
        worker = PromptFCI(stderr)
        for mechanism in ('direct', 'latent', 'uncovered', 'null'):
            ci = DiscreteCI(f'population-{mechanism}', LABELS, joint=population_joint(mechanism))
            for mode in ('0', '1', '12'):
                result = worker.search(ci, mode)
                results.append(dict(result, mechanism=mechanism, jci=mode))
            (output / f'{mechanism}-queries.json').write_text(json.dumps(ci.cache, indent=2), encoding='utf-8')
        worker.close()
    (output / 'population-searches.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
    print(json.dumps([dict(mechanism=r['mechanism'], jci=r['jci'], ancestors_y=r['ancestors_y'])
                      for r in results]))


def finite_check(output: Path):
    output.mkdir(parents=True, exist_ok=False)
    results = []
    with (output / 'r-stderr.log').open('w', encoding='utf-8') as stderr:
        worker = PromptFCI(stderr)
        for mechanism in ('direct', 'latent', 'uncovered', 'null'):
            states, _, outcomes = make_scm_tasks(mechanism, 128, 0)
            matrix = structure_rows(states, outcomes, mechanism, 0)
            ci = DiscreteCI(f'finite-readiness-{mechanism}', LABELS, rows=matrix)
            for mode in ('0', '1', '12'):
                result = worker.search(ci, mode)
                results.append(dict(result, mechanism=mechanism, jci=mode))
            (output / f'{mechanism}-queries.json').write_text(json.dumps(ci.cache, indent=2), encoding='utf-8')
            (output / f'{mechanism}-rows.json').write_text(json.dumps(matrix.tolist()), encoding='utf-8')
        worker.close()
    (output / 'finite-searches.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
    print(json.dumps([dict(mechanism=r['mechanism'], jci=r['jci'], status=r['status'],
                           ancestors_y=r.get('ancestors_y')) for r in results]))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=('prepare-semantics', 'merge-reviews', 'audit-exposure',
                                           'freeze-inputs', 'analyze-training', 'freeze-evaluation', 'report-evaluation',
                                           'freeze-controlled-natural-preparation', 'safe-decisions'))
    parser.add_argument('--root', type=Path, default=Path('data/method/jci-ridge-20260930'))
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--cases', nargs='+')
    parser.add_argument('--prepared', type=Path)
    parser.add_argument('--reviews', nargs='+', type=Path)
    parser.add_argument('--qualification', type=Path)
    parser.add_argument('--training', type=Path)
    parser.add_argument('--analysis', type=Path)
    parser.add_argument('--service', type=Path)
    parser.add_argument('--decisions', type=Path)
    parser.add_argument('--evaluation', type=Path)
    parser.add_argument('--minimum-gain', type=float, default=0.)
    args = parser.parse_args()
    if args.command == 'safe-decisions':
        if args.prepared is None or args.analysis is None:
            raise ValueError('安全收益选择需要完整输入及随机政策差标签')
        print(json.dumps(prepare_safe_decisions(args.prepared, args.analysis, args.output, args.minimum_gain)))
    elif args.command == 'freeze-controlled-natural-preparation':
        print(json.dumps(freeze_controlled_natural_preparation(args.root, args.output)))
    elif args.command == 'prepare-semantics':
        prepare_semantics(args.root, args.output, args.cases)
    elif args.command == 'audit-exposure':
        audit_exposure(args.root, args.output)
    elif args.command == 'freeze-inputs':
        freeze_inputs(args.root, args.prepared, args.qualification, args.output)
    elif args.command == 'analyze-training':
        analyze_training(args.prepared, args.training, args.output)
    elif args.command == 'freeze-evaluation':
        freeze_evaluation(args.prepared, args.analysis, args.service, args.output)
    elif args.command == 'report-evaluation':
        report_evaluation(args.prepared, args.decisions, args.evaluation, args.output)
    else:
        if args.prepared is None or not args.reviews:
            raise ValueError('审查组装需要完整准备和独立结果路径')
        merge_semantic_reviews(args.root, args.prepared, args.reviews, args.output)


if __name__ == '__main__':
    main()
