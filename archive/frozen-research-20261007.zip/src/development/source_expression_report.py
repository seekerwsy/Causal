from __future__ import annotations

import hashlib
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

from prompt_mechanism_study.artifact_io import read_json, verify_bundle, write_bundle
from prompt_mechanism_study.development.source_policy_report import combine


ROOT = Path('data/method/source-hypotheses-20260927')
PANELS = ('expression-diagnostic', 'expression-matched')


def report(repo: Path, destination: Path) -> None:
    root = repo / ROOT
    rows = []
    generation_count = 0
    modes = Counter()
    input_manifests = {}
    for panel_name in PANELS:
        inputs = root / f'{panel_name}-inputs'
        results = root / panel_name
        verify_bundle(inputs)
        input_manifests[panel_name] = read_json(inputs / 'manifest.json')
        assignments = read_json(inputs / 'assignments.json')
        summary = read_json(results / 'summary/results.json')
        if len(assignments) != len(summary):
            raise ValueError('incomplete expression panel')
        for assignment, summary_row in zip(assignments, summary, strict=True):
            directory = results / assignment['slot']
            verify_bundle(directory / 'result')
            generation = read_json(directory / 'result/result.json')
            if generation != summary_row or generation['status'] != 'returned':
                raise ValueError(f'incomplete expression generation: {panel_name} {assignment["slot"]}')
            code = (directory / 'code.py').read_text(encoding='utf-8')
            original = (directory / 'raw_code.py').read_text(encoding='utf-8')
            if (hashlib.sha256(code.encode()).hexdigest() != generation['code_sha256']
                    or hashlib.sha256(original.encode()).hexdigest() != generation['raw_code_sha256']
                    or hashlib.sha256(assignment['prompt'].encode()).hexdigest() != assignment['prompt_sha256']):
                raise ValueError('expression prompt or code hash mismatch')
            modes[generation['envelope_mode']] += 1
            generation_count += 1
            if len(generation['measurements']) != len(assignment['measurements']):
                raise ValueError('expression measurement count mismatch')
            for position, (measured, frozen) in enumerate(zip(
                    generation['measurements'], assignment['measurements'], strict=True)):
                request = read_json(directory / (f'measurement-request-{position}.json'
                                                 if len(assignment['measurements']) > 1 else
                                                 'measurement-request.json'))
                if (request['code'] != code or request['entry_point'] != frozen['entry_point']
                        or request['tests'] != frozen['tests']
                        or measured['candidate_slot'] != frozen['candidate_slot']
                        or measured['measurement']['status'] != 'measured'):
                    raise ValueError('expression measurement binding mismatch')
                observation = combine([measured['measurement']])
                rows.append(dict(panel=panel_name, slot=assignment['slot'],
                                 index=assignment['index'],
                                 task_unit_id=assignment['task_unit_id'],
                                 candidate_slot=frozen['candidate_slot'],
                                 version=assignment['version'], arm=assignment['arm'],
                                 repeat=assignment['repeat'], seed=assignment['seed'],
                                 envelope_mode=generation['envelope_mode'], **observation))
    if generation_count != 388 or len(rows) != 390:
        raise ValueError('expression panel accounting changed')

    grouped = defaultdict(list)
    for row in rows:
        grouped[row['index'], row['candidate_slot'], row['version'], row['arm']].append(row)
    candidates = []
    identities = sorted({(row['index'], row['candidate_slot']) for row in rows})
    if len(identities) != 15:
        raise ValueError('expression candidate count changed')
    for index, slot in identities:
        versions = sorted({row['version'] for row in rows if
                           row['index'] == index and row['candidate_slot'] == slot
                           and row['version'] is not None})
        if len(versions) != 3:
            raise ValueError('missing prepared expression version')
        control = grouped[index, slot, None, 'R']
        if len(control) != 2:
            raise ValueError('missing matched-seed source control')
        control_yield = sum(row['secure_code_yield'] for row in control) / 2
        version_rows = []
        for version in versions:
            arm_rows = {}
            for arm in ('N', 'S', 'G', 'P'):
                pair = grouped[index, slot, version, arm]
                if len(pair) != 2 or {row['repeat'] for row in pair} != {0, 1}:
                    raise ValueError('missing expression arm or repeat')
                arm_rows[arm] = dict(secure_code_yield=sum(row['secure_code_yield']
                                                            for row in pair) / 2,
                                     functionality_pass=sum(row['functionality_pass']
                                                            for row in pair) / 2,
                                     secure_and_functional=sum(row['secure_and_functional']
                                                               for row in pair) / 2,
                                     unknown_security=sum(row['security_label'] == 'unknown'
                                                          for row in pair),
                                     invalid_code=sum(not row['code_valid'] for row in pair))
            version_rows.append(dict(version=version, arms=arm_rows,
                                     effect_P_N=(arm_rows['P']['secure_code_yield'] -
                                                 arm_rows['N']['secure_code_yield']),
                                     effect_P_R=(arm_rows['P']['secure_code_yield'] - control_yield)))
        p_yields = [row['arms']['P']['secure_code_yield'] for row in version_rows]
        n_yields = [row['arms']['N']['secure_code_yield'] for row in version_rows]
        policy_effects = [row['effect_P_N'] for row in version_rows]
        candidates.append(dict(index=index, candidate_slot=slot,
                               source_control_yield=control_yield,
                               versions=version_rows,
                               P_range=max(p_yields) - min(p_yields),
                               N_range=max(n_yields) - min(n_yields),
                               effect_P_N_range=max(policy_effects) - min(policy_effects),
                               P_mean=sum(p_yields) / 3,
                               N_mean=sum(n_yields) / 3,
                               effect_P_N_mean=sum(row['effect_P_N'] for row in version_rows) / 3,
                               effect_P_R_mean=sum(row['effect_P_R'] for row in version_rows) / 3))
    report_data = dict(status='POSTHOC_DEVELOPMENT_EXPRESSION_ANALYSIS',
                       evidence_role='development_only_after_original_panel_outcomes',
                       formal_protocol='SPECIFIED_DRAFT',
                       input_manifests=input_manifests,
                       assigned_generations=generation_count,
                       candidate_measurement_rows=len(rows),
                       task_units=len({row['task_unit_id'] for row in rows}),
                       candidates=len(candidates),
                       envelope_modes=dict(modes),
                       security_labels=dict(Counter(row['security_label'] for row in rows)),
                       P_version_sensitive_candidates=sum(row['P_range'] > 0 for row in candidates),
                       N_version_sensitive_candidates=sum(row['N_range'] > 0 for row in candidates),
                       policy_effect_version_sensitive_candidates=sum(
                           row['effect_P_N_range'] > 0 for row in candidates),
                       candidate_rows=candidates, assignment_rows=rows)
    write_bundle(destination, {'analysis.json': report_data})
    verify_bundle(destination)
    print(json.dumps(dict(status=report_data['status'],
                          assigned=report_data['assigned_generations'],
                          task_units=report_data['task_units'],
                          candidates=report_data['candidates'],
                          security_labels=report_data['security_labels'],
                          envelope_modes=report_data['envelope_modes'],
                          P_version_sensitive_candidates=report_data['P_version_sensitive_candidates'],
                          N_version_sensitive_candidates=report_data['N_version_sensitive_candidates'],
                          policy_effect_version_sensitive_candidates=(
                              report_data['policy_effect_version_sensitive_candidates']))))


if __name__ == '__main__':
    report(Path(sys.argv[1]), Path(sys.argv[2]))
