from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

import numpy as np
from sklearn.linear_model import Ridge
from sklearn.preprocessing import OneHotEncoder

from prompt_mechanism_study.artifact_io import read_json, verify_bundle, write_bundle


ROOT = Path('data/method/source-hypotheses-20260927')
PANELS = ('development-panel', 'development-extension', 'development-extension-2')
HELDOUT = (3, 4, 23, 62, 102)
ALPHAS = (0.1, 1.0, 10.0, 100.0)


def arm_yield(panel: Path, assignments: list[dict], index: int, candidate_slot: int,
              arm: str) -> float:
    matching = [row for row in assignments if row['index'] == index and row['arm'] == arm
                and (row['candidate_slot'] == candidate_slot or arm == 'R')]
    if len(matching) != 2:
        raise ValueError(f'incomplete assigned arm: {index} {candidate_slot} {arm}')
    outcomes = []
    for assignment in matching:
        result_dir = panel / assignment['slot']
        verify_bundle(result_dir / 'result')
        result = read_json(result_dir / 'result/result.json')
        if result['status'] != 'returned':
            raise ValueError(f'incomplete development observation: {result_dir}')
        measured = next(row['measurement'] for row in result['measurements']
                        if row['candidate_slot'] == candidate_slot)
        security = measured['channels']['security']
        label = (security.get('observation', {}).get('security_label', 'unknown')
                 if security['status'] == 'passed' else 'unknown')
        if label not in {'secure', 'insecure', 'unknown'}:
            raise ValueError(f'unknown security label: {result_dir}')
        outcomes.append(int(label == 'secure'))
    return float(np.mean(outcomes))


def source_rows(repo: Path) -> tuple[list[dict], dict[str, dict]]:
    root = repo / ROOT
    development = []
    manifests = {}
    for name in PANELS:
        inputs = root / f'{name}-inputs'
        verify_bundle(inputs)
        assignments = read_json(inputs / 'assignments.json')
        manifests[name] = read_json(inputs / 'manifest.json')
        identities = sorted({(row['index'], row['candidate_slot']) for row in assignments
                             if row['candidate_slot'] is not None})
        for index, slot in identities:
            case_root = root / f'prepared/case-{index:04d}'
            verify_bundle(case_root)
            case = read_json(case_root / 'case.json')
            candidate = next(row for row in case['author_card']['candidate_slots']
                             if row['slot'] == slot)
            if case['assignment']['role'] != 'development' or candidate['status'] != 'eligible':
                raise ValueError(f'unexpected development candidate: {index} {slot}')
            means = {arm: arm_yield(root / name, assignments, index, slot, arm)
                     for arm in ('R', 'N', 'P')}
            development.append(dict(index=index, task_unit_id=case['assignment']['task_unit_id'],
                                    candidate_slot=slot, representation=case['assignment']['representation'],
                                    policy_family=candidate['policy_family'],
                                    direction=candidate['direction'],
                                    operation_family=candidate['operation_family'],
                                    **{f'{arm}_yield': value for arm, value in means.items()},
                                    effect_P_R=means['P']-means['R'],
                                    effect_P_N=means['P']-means['N']))
    if len(development) != 15:
        raise ValueError(f'unexpected development candidate count: {len(development)}')
    return development, manifests


def encode_fit(rows: list[dict]):
    encoder = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
    features = [[row['representation'], row['operation_family']] for row in rows]
    return encoder, encoder.fit_transform(features)


def estimate(rows: list[dict], candidate: dict, alpha: float, target: str) -> float:
    encoder, features = encode_fit(rows)
    target_values = np.array([row[target] for row in rows], dtype=float)
    model = Ridge(alpha=alpha)
    model.fit(features, target_values)
    input_features = encoder.transform([[candidate['representation'], candidate['operation_family']]])
    return float(model.predict(input_features)[0])


def choose_alpha(rows: list[dict], mode: str) -> tuple[float, list[dict]]:
    evaluations = []
    for alpha in ALPHAS:
        rewards = []
        for heldout in rows:
            training = [row for row in rows if row['task_unit_id'] != heldout['task_unit_id']]
            if len({row['task_unit_id'] for row in training}) < 4:
                raise ValueError('grouped cross-validation lacks four training tasks')
            if mode == 'causal':
                score = estimate(training, heldout, alpha, 'effect_P_R')
            else:
                score = estimate(training, heldout, alpha, 'P_yield') - float(
                    np.mean([row['R_yield'] for row in training]))
            rewards.append(dict(index=heldout['index'], predicted=score,
                                decision='P' if score > 0 else 'R',
                                realized_gain=heldout['effect_P_R'] if score > 0 else 0.0))
        evaluations.append(dict(alpha=alpha, mean_realized_gain=float(np.mean(
            [row['realized_gain'] for row in rewards])), folds=rewards))
    winner = max(evaluations, key=lambda row: (row['mean_realized_gain'], row['alpha']))
    return winner['alpha'], evaluations


def heldout_rows(repo: Path) -> tuple[list[dict], dict[str, dict]]:
    root = repo / ROOT
    candidates = []
    manifests = {}
    for index in HELDOUT:
        case_root = root / f'prepared/case-{index:04d}'
        verify_bundle(case_root)
        manifests[str(index)] = read_json(case_root / 'manifest.json')
        case = read_json(case_root / 'case.json')
        if case['assignment']['role'] != 'heldout':
            raise ValueError(f'heldout source role mismatch: {index}')
        for candidate in case['author_card']['candidate_slots']:
            if candidate['status'] != 'eligible':
                continue
            candidates.append(dict(index=index, task_unit_id=case['assignment']['task_unit_id'],
                                   candidate_slot=candidate['slot'],
                                   representation=case['assignment']['representation'],
                                   policy_family=candidate['policy_family'],
                                   direction=candidate['direction'],
                                   operation_family=candidate['operation_family'],
                                   source_score=int(candidate['assessment']['complete_binding'] and
                                                    candidate['assessment']['relevance'] == 'supported' and
                                                    candidate['assessment']['compatibility'] == 'compatible')))
    if len(candidates) != 6:
        raise ValueError(f'unexpected heldout candidate count: {len(candidates)}')
    return candidates, manifests


def freeze(repo: Path, destination: Path) -> None:
    development, input_manifests = source_rows(repo)
    heldout, case_manifests = heldout_rows(repo)
    support = Counter((row['policy_family'], row['direction']) for row in development)
    supported = [row for row in development if support[row['policy_family'], row['direction']] >= 4]
    if len(supported) != 5 or {(row['policy_family'], row['direction']) for row in supported} != {('html_output', 'ADD')}:
        raise ValueError('supported family changed')
    causal_alpha, causal_cv = choose_alpha(supported, 'causal')
    association_alpha, association_cv = choose_alpha(supported, 'association')
    decisions = []
    for index in HELDOUT:
        options = [row for row in heldout if row['index'] == index]
        scores = []
        for option in options:
            family = (option['policy_family'], option['direction'])
            training = [row for row in development if
                        (row['policy_family'], row['direction']) == family]
            eligible = len({row['task_unit_id'] for row in training}) >= 4
            record = dict(candidate_slot=option['candidate_slot'],
                          policy_family=option['policy_family'], direction=option['direction'],
                          operation_family=option['operation_family'],
                          support_tasks=len({row['task_unit_id'] for row in training}),
                          source_score=option['source_score'], eligible=eligible)
            if eligible:
                record['overall_effect'] = float(np.mean([row['effect_P_R'] for row in training]))
                record['causal_effect'] = estimate(training, option, causal_alpha, 'effect_P_R')
                record['association_effect'] = (estimate(training, option, association_alpha, 'P_yield') -
                                                float(np.mean([row['R_yield'] for row in training])))
            scores.append(record)

        def pick(field: str, require_positive: bool, gate: bool) -> str:
            allowed = [row for row in scores if not gate or row['eligible']]
            if not allowed:
                return 'R'
            ranked = sorted(allowed, key=lambda row: (-row[field], row['candidate_slot']))
            best = ranked[0]
            return (f"P:{best['candidate_slot']}" if not require_positive or best[field] > 0 else 'R')

        decisions.append(dict(index=index, task_unit_id=options[0]['task_unit_id'],
                              scores=scores, choices={
                                  'no_edit': 'R',
                                  'source_semantics': pick('source_score', False, False),
                                  'source_semantics_support_matched': pick('source_score', False, True),
                                  'overall_randomized_effect': pick('overall_effect', True, True),
                                  'conditional_causal_ridge': pick('causal_effect', True, True),
                                  'treated_outcome_association': pick('association_effect', True, True)}))
    protocol = dict(status='FROZEN_EXPLORATORY_HELDOUT_DECISIONS',
                    formal_protocol='SPECIFIED_DRAFT',
                    selection_read_no_heldout_generated_code=True,
                    development_panels=list(PANELS), development_input_manifests=input_manifests,
                    heldout_case_manifests=case_manifests,
                    heldout_indices=list(HELDOUT),
                    minimum_independent_support=4,
                    features=['representation', 'operation_family'],
                    estimator='sklearn Ridge with OneHotEncoder fit inside each training fold',
                    alpha_grid=list(ALPHAS), group_cv='leave-one-development-task-out',
                    alpha_rule='maximum realized policy gain, strongest regularization on ties',
                    causal_alpha=causal_alpha, association_alpha=association_alpha,
                    source_semantics_rule='complete compatible supported candidate; smallest slot on ties',
                    decision_threshold='predicted P minus R strictly greater than zero',
                    unsupported_action='R')
    write_bundle(destination, {'protocol.json': protocol, 'development.json': development,
                               'heldout-source.json': heldout, 'cross-validation.json': {
                                   'causal': causal_cv, 'association': association_cv},
                               'decisions.json': decisions})
    verify_bundle(destination)
    print(json.dumps(dict(status='FROZEN', development_candidates=len(development),
                          supported_candidates=len(supported), heldout_candidates=len(heldout),
                          decisions=decisions, output=str(destination))))


if __name__ == '__main__':
    freeze(Path(sys.argv[1]), Path(sys.argv[2]))
