import hashlib
import json
from collections import Counter
from pathlib import Path


ROOT = Path('data/method/graph-guided-20260930/source-audit')


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def verify():
    # 独立重算文件摘要、类别排序与任务分配，不调用来源审计的选择函数。
    for name in ('frame', 'identity-path-audit', 'completed'):
        directory = ROOT / name
        manifest = load(directory / 'manifest.json')
        assert set(manifest['files']) == {path.name for path in directory.iterdir() if path.name != 'manifest.json'}
        for filename, expected in manifest['files'].items():
            assert hashlib.sha256((directory / filename).read_bytes()).hexdigest() == expected
    protocol = load(ROOT / 'frame/protocol.json')
    for path, expected in protocol['input_sha256'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected
    for path, expected in load(ROOT / 'completed/input-identity.json').items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected
    order = load(ROOT / 'frame/audit-order.json')
    decisions = load(ROOT / 'completed/source-decisions.json')
    report = load(ROOT / 'completed/report.json')
    classes = load(ROOT / 'completed/semantic-classes.json')
    definitions = load(ROOT / 'semantic-classes.json')
    assert len(order) == len(decisions) == 60
    assert [row['task_unit_id'] for row in order] == [row['task_unit_id'] for row in decisions]
    assert [row['audit_position'] for row in decisions] == list(range(1, 61))
    assert len({row['near_duplicate_group_id'] for row in decisions}) == 60
    for row in decisions:
        assert not row['concrete_protected'] and row['source_content_read']
        assert not row['result_values_read'] and not row['generated_content_read']
    assert dict(Counter(row['disposition'] for row in decisions)) == report['source_disposition_counts']
    eligible = {row['audit_position']: row for row in decisions if row['disposition'] == 'ELIGIBLE_BOUNDED_EVALUATION_SOURCE'}
    recalculated = []
    for row in definitions['classes']:
        identity = {key: row[key] for key in definitions['class_identity_fields']}
        encoded = json.dumps(identity, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
        digest = hashlib.sha256(encoded).hexdigest()
        support = [position for position in row['source_positions'] if position in eligible]
        if support:
            recalculated.append((-len(support), digest, row['class_id'], support))
    winner = sorted(recalculated)[0]
    assert winner[2] == report['selected_class'] and winner[1] == report['selected_class_sha256']
    assert winner[2] == classes[0]['class_id']
    v_positions = sorted(winner[3], key=lambda p: eligible[p]['replication_order_hash'])[:12]
    o_positions = [position for position in sorted(eligible) if position not in v_positions][:12]
    assert report['v_positions'] == v_positions and report['o_positions'] == o_positions
    panel = load(ROOT / 'completed/panel.json')
    assert [row['audit_position'] for row in panel if row['role'] == 'V'] == v_positions
    assert [row['audit_position'] for row in panel if row['role'] == 'O'] == o_positions
    assert len({row['task_unit_id'] for row in panel}) == len(panel)
    source = {row['task_unit_id']: row for row in load(Path('data/dataset-curation/research-candidate-pool-v4/tasks.json'))}
    for row in panel:
        assert row['prompt'] == source[row['task_unit_id']]['prompt']
        prompt_bytes = json.dumps(row['prompt'], ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()
        assert hashlib.sha256(prompt_bytes).hexdigest() == row['prompt_sha256']
        assert not row['formal_role_assigned']
    print(json.dumps({'status': 'VERIFIED', 'audited_identities': 60, 'eligible_sources': len(eligible),
                      'V': len(v_positions), 'O': len(o_positions), 'selected_class': winner[2]}))


if __name__ == '__main__':
    verify()
