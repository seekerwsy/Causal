from __future__ import annotations

import hashlib
import json
import sys
from importlib.metadata import version
from pathlib import Path

from markdown_it import MarkdownIt

from prompt_mechanism_study.artifact_io import read_json, verify_bundle, write_bundle


def extract_code(value: str) -> tuple[str, str]:
    tokens = MarkdownIt().parse(value)
    if len(tokens) == 1 and tokens[0].type == 'fence':
        language = tokens[0].info.strip().lower()
        if language in {'python', 'py'}:
            return tokens[0].content, 'single_python_fence'
        return value, 'unsupported_fence_language'
    if any(token.type == 'fence' for token in tokens):
        return value, 'unsupported_mixed_markdown'
    return value, 'raw_code'


def materialize(repo: Path, destination: Path) -> None:
    root = repo / 'data/method/source-hypotheses-20260927'
    heldout_inputs = root / 'heldout-panel-inputs'
    common_plan = root / 'measurement/case62-common-plan'
    verify_bundle(heldout_inputs)
    verify_bundle(common_plan)
    assignments = read_json(heldout_inputs / 'assignments.json')
    plan = read_json(common_plan / 'plan.json')
    requests, provenance = {}, []
    for assignment in assignments:
        slot = assignment['slot']
        result_dir = root / 'heldout-panel' / slot
        verify_bundle(result_dir / 'result')
        result = read_json(result_dir / 'result/result.json')
        if result['slot'] != slot or result['status'] != 'returned':
            raise ValueError(f'missing original code output: {slot}')
        original = (result_dir / 'code.py').read_text(encoding='utf-8')
        if hashlib.sha256(original.encode()).hexdigest() != result['code_sha256']:
            raise ValueError(f'original code hash mismatch: {slot}')
        normalized, mode = extract_code(original)
        if assignment['index'] == 62:
            specifications = [dict(family=family, entry_point=plan['entry_point'], tests=tests)
                              for family, tests in plan['tests'].items()]
        else:
            specifications = assignment['measurements']
        for position, specification in enumerate(specifications):
            requests[f'{slot}-{position}.json'] = dict(code=normalized,
                entry_point=specification['entry_point'], tests=specification['tests'],
                trace_assertions=False, channel_timeout_seconds=60)
        provenance.append(dict(slot=slot, index=assignment['index'], arm=assignment['arm'],
                               candidate_slot=assignment['candidate_slot'], mode=mode,
                               original_sha256=result['code_sha256'],
                               normalized_sha256=hashlib.sha256(normalized.encode()).hexdigest(),
                               measurement_families=[row['family'] for row in specifications],
                               original_result_manifest=read_json(result_dir / 'result/manifest.json')))
    if len(requests) != 76:
        raise ValueError(f'unexpected normalized measurement count: {len(requests)}')
    write_bundle(destination, requests)
    write_bundle(destination.parent / f'{destination.name}-provenance', {
        'provenance.json': dict(status='EXPLORATORY_AFTER_FORMAT_FAILURE',
                                parser='markdown-it-py', parser_version=version('markdown-it-py'),
                                rule='extract only a sole Python fenced block; retain all other content verbatim',
                                original_input_manifest=read_json(heldout_inputs / 'manifest.json'),
                                case62_common_plan_manifest=read_json(common_plan / 'manifest.json'),
                                rows=provenance)})
    verify_bundle(destination)
    print(json.dumps(dict(status='EXPLORATORY_MATERIALIZED', assignments=len(assignments),
                          requests=len(requests),
                          modes={mode: sum(row['mode'] == mode for row in provenance)
                                 for mode in sorted({row['mode'] for row in provenance})},
                          output=str(destination))))


if __name__ == '__main__':
    materialize(Path(sys.argv[1]), Path(sys.argv[2]))
