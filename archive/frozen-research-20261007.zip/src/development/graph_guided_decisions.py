from __future__ import annotations

import argparse
import json
from collections import Counter
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction import DictVectorizer
from sklearn.linear_model import Ridge
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.preprocessing import normalize

from prompt_mechanism_study.artifact_io import file_sha256, read_json, verify_bundle, write_bundle
from prompt_mechanism_study.records import canonical_json, content_hash


ROOT = Path('data/method/graph-guided-20260928')
RESULTS = Path('results/graph-guided-20260928')
ALPHAS = (.1, 1., 10., 100.)
CATEGORY = {0: 'input_object_emphasis', 2: 'input_role_clarification'}
GRAPH_CATEGORICAL = ('operation', 'outcome', 'node_types', 'relation_types',
                     'object_role_explicit', 'condition_recipient_explicit',
                     'direct_security_requirement', 'operation_order_explicit')
GRAPH_NUMERIC = ('node_count', 'relation_count')
NODE_CATEGORICAL = ('operation', 'outcome', 'node_types', 'direct_security_requirement')
NODE_NUMERIC = ('node_count',)
MODES = ('tsg_ridge', 'text_ridge', 'two_arm_ridge', 'node_only_ridge',
         'treated_outcome_ridge', 'tsg_forest')


class DiscoveryFeatures:
    def __init__(self):
        self.common = TfidfVectorizer(analyzer='char', ngram_range=(2, 4),
                                     max_features=256, norm='l2', dtype=np.float64)
        self.policy = TfidfVectorizer(analyzer='char', ngram_range=(2, 4),
                                     max_features=256, norm='l2', dtype=np.float64)
        self.marginal = DictVectorizer(sparse=False, sort=True, dtype=np.float64)
        self.relation = DictVectorizer(sparse=False, sort=True, dtype=np.float64)

    @staticmethod
    def relation_counts(row):
        tuples = row['relations']
        if any(len(edge) != 5 or any(not isinstance(value, str) or not value for value in edge)
               for edge in tuples):
            raise ValueError('关系必须包含完整端点角色、名称、范围和极性')
        return Counter(json.dumps(edge, ensure_ascii=False, separators=(',', ':'))
                       for edge in tuples)

    def fit(self, rows):
        if not rows:
            raise ValueError('学习器没有开发候选')
        for row in rows:
            if len(row['p_versions']) != 2 or len(row['n_versions']) != 2:
                raise ValueError('每项政策必须有两个版本')
        self.common.fit([row['canonical_text'] for row in rows])
        self.policy.fit([text for row in rows for text in row['p_versions'] + row['n_versions']])
        self.marginal.fit([row['marginals'] for row in rows])
        self.relation.fit([self.relation_counts(row) for row in rows])
        return self

    @staticmethod
    def _normalize(block):
        return normalize(block) if block.shape[1] else block

    def blocks(self, rows):
        if not rows or any(len(row['p_versions']) != 2 or len(row['n_versions']) != 2 for row in rows):
            raise ValueError('特征输入必须包含候选及每组两个版本')
        orientation = np.asarray([row['orientation'] for row in rows], dtype=float)
        if not np.all(np.isin(orientation, [-1, 1])):
            raise ValueError('政策方向必须为+1或-1')
        common = self.common.transform([row['canonical_text'] for row in rows]).toarray()
        p = self.policy.transform([text for row in rows for text in row['p_versions']]).toarray()
        n = self.policy.transform([text for row in rows for text in row['n_versions']]).toarray()
        difference = self._normalize(p.reshape(len(rows), 2, -1).mean(axis=1)
                                     - n.reshape(len(rows), 2, -1).mean(axis=1))
        marginal = self._normalize(self.marginal.transform([row['marginals'] for row in rows]))
        counts = [self.relation_counts(row) for row in rows]
        relation = self._normalize(self.relation.transform(counts))
        unseen = [{key: count for key, count in row.items() if key not in self.relation.vocabulary_}
                  for row in counts]
        return (orientation[:, None], orientation[:, None] * common, difference,
                orientation[:, None] * marginal, orientation[:, None] * relation, unseen)

    def transform(self, rows, mode):
        if mode not in {'common', 'relations', 'endpointless'}:
            raise ValueError('未知发现特征模式')
        orientation, common, difference, marginal, relation, unseen = self.blocks(rows)
        blocks = [orientation, common, difference]
        if mode != 'common':
            blocks.extend([marginal, relation if mode == 'relations' else np.zeros_like(relation)])
        return np.concatenate(blocks, axis=1), unseen


def discovery_weights(rows):
    counts = Counter(row['task_unit_id'] for row in rows)
    return np.asarray([1 / counts[row['task_unit_id']] for row in rows])


class TaskEqualRidge:
    def __init__(self, feature_kinds, penalty, minimum_task_support=4):
        if any(kind not in ('discrete', 'continuous') for kind in feature_kinds) or penalty <= 0:
            raise ValueError('Ridge 属性定义或惩罚值无效')
        self.feature_kinds, self.penalty = tuple(feature_kinds), float(penalty)
        if type(minimum_task_support) is not int or minimum_task_support < 1:
            raise ValueError('属性取值的最小任务支持无效')
        self.minimum_task_support = minimum_task_support

    def fit(self, rows):
        if not rows:
            raise ValueError('缺少训练政策')
        identities = np.asarray([row['task_unit_id'] for row in rows])
        self.tasks = sorted(set(identities))
        weights = discovery_weights(rows) / len(self.tasks)
        x = np.asarray([row['features'] for row in rows], dtype=float)
        y = np.asarray([row['delta_pn'] for row in rows], dtype=float)
        if (x.shape != (len(rows), len(self.feature_kinds)) or np.isinf(x).any()
                or not np.isfinite(y).all() or np.any(abs(y) > 1)):
            raise ValueError('属性矩阵或完整政策效果无效')
        self.allowed, self.means, self.scales, self.retained = [], [], [], []
        for index, kind in enumerate(self.feature_kinds):
            column = x[:, index].copy()
            finite = np.isfinite(column)
            values = None
            if kind == 'discrete':
                values = [float(value) for value in np.unique(column[finite])
                          if len(set(identities[column == value])) >= self.minimum_task_support]
                finite &= np.isin(column, values)
            elif len(set(identities[finite])) < self.minimum_task_support:
                finite[:] = False
            mean = float(np.average(column[finite], weights=weights[finite])) if finite.any() else 0.
            filled = np.where(finite, column, mean)
            variance = float(np.sum(weights*(filled-mean)**2))
            self.allowed.append(values)
            self.means.append(mean)
            self.scales.append(float(np.sqrt(variance)) if variance > 1e-15 else 1.)
            self.retained.append(variance > 1e-15)
        z = self.transform(rows)
        design = np.column_stack((np.ones(len(rows)), z))
        regularizer = np.eye(design.shape[1])*self.penalty
        regularizer[0, 0] = 0
        self.coefficients = np.linalg.solve(design.T@(weights[:, None]*design)+regularizer,
                                            design.T@(weights*y))
        return self

    def transform(self, rows):
        x = np.asarray([row['features'] for row in rows], dtype=float)
        if x.shape != (len(rows), len(self.feature_kinds)) or np.isinf(x).any():
            raise ValueError('待预测属性矩阵无效')
        for index, allowed in enumerate(self.allowed):
            invalid = ~np.isfinite(x[:, index])
            if allowed is not None:
                invalid |= ~np.isin(x[:, index], allowed)
            x[invalid, index] = self.means[index]
        return ((x-np.asarray(self.means))/np.asarray(self.scales))[:, self.retained]

    def predict(self, rows):
        design = np.column_stack((np.ones(len(rows)), self.transform(rows)))
        return np.clip(design@self.coefficients, -1., 1.)

    def record(self):
        return dict(penalty=self.penalty, feature_kinds=self.feature_kinds, allowed=self.allowed,
                    means=self.means, scales=self.scales, retained=self.retained,
                    coefficients=self.coefficients.tolist(), training_task_ids=self.tasks)


def fit_task_equal_ridge(rows, feature_kinds, task_folds=None, penalties=(.01, .1, 1., 10.),
                         minimum_task_support=4):
    tasks = sorted({row['task_unit_id'] for row in rows})
    if len(tasks) < 2:
        raise ValueError('完整任务留一验证需要至少两个训练任务')
    if task_folds is not None:
        if set(task_folds) != set(tasks) or set(task_folds.values()) != set(range(5)):
            raise ValueError('固定五折验证必须包含每项完整任务')
        groups = [[identity for identity in tasks if task_folds[identity] == fold] for fold in range(5)]
    else:
        groups = [[identity] for identity in tasks]
    evaluations = []
    for penalty in penalties:
        folds = []
        for identities in groups:
            training = [row for row in rows if row['task_unit_id'] not in identities]
            validation = [row for row in rows if row['task_unit_id'] in identities]
            learner = TaskEqualRidge(feature_kinds, penalty, minimum_task_support).fit(training)
            error = learner.predict(validation)-np.asarray([row['delta_pn'] for row in validation])
            task_errors = [float(np.mean([float(error[index])**2 for index, row in enumerate(validation)
                                          if row['task_unit_id'] == identity])) for identity in identities]
            fold = dict(mse=float(np.mean(task_errors)), retained=learner.retained)
            fold.update(task_unit_ids=identities) if task_folds is not None else fold.update(task_unit_id=identities[0])
            folds.append(fold)
        task_mean_error = sum(fold['mse']*len(group) for fold, group in zip(folds, groups, strict=True))/len(tasks)
        evaluations.append(dict(penalty=penalty, mse=float(task_mean_error), folds=folds))
    chosen = min(evaluations, key=lambda value: (value['mse'], -value['penalty']))
    return TaskEqualRidge(feature_kinds, chosen['penalty'], minimum_task_support).fit(rows), evaluations


def fit_discovery_ridge(rows, mode='common'):
    tasks = sorted({row['task_unit_id'] for row in rows})
    if len(tasks) < 8:
        raise ValueError('开发任务不足八项，学习器比较保持未完成')
    evaluations = []
    for alpha in ALPHAS:
        folds = []
        for identity in tasks:
            training = [row for row in rows if row['task_unit_id'] != identity]
            targets = [row for row in rows if row['task_unit_id'] == identity]
            features = DiscoveryFeatures().fit(training)
            x, _ = features.transform(training, mode)
            learner = Ridge(alpha=alpha, fit_intercept=False, solver='svd').fit(
                x, [row['delta_pn'] for row in training], sample_weight=discovery_weights(training))
            test, _ = features.transform(targets, mode)
            error = learner.predict(test) - [row['delta_pn'] for row in targets]
            folds.append(dict(task_unit_id=identity, mse=float(np.mean(error ** 2))))
        evaluations.append(dict(alpha=alpha, mse=float(np.mean([row['mse'] for row in folds])), folds=folds))
    chosen = min(evaluations, key=lambda row: (row['mse'], -row['alpha']))
    features = DiscoveryFeatures().fit(rows)
    x, _ = features.transform(rows, mode)
    learner = Ridge(alpha=chosen['alpha'], fit_intercept=False, solver='svd').fit(
        x, [row['delta_pn'] for row in rows], sample_weight=discovery_weights(rows))
    return features, learner, evaluations


def discovery_pick(rows, scores):
    if not rows:
        return None
    selected = min(zip(rows, scores, strict=True),
                   key=lambda pair: (-abs(float(pair[1])), pair[0]['candidate_id']))
    row, value = selected
    return dict(candidate_id=row['candidate_id'], direction=-1 if value < 0 else 1,
                prediction=float(value))


def discovery_contract_statistics(rows):
    if not rows:
        return [], None, None
    representatives, task_values = {}, defaultdict(list)
    for row in rows:
        key = row['task_unit_id'], row['contract_id']
        order = row['citation_start'], row['candidate_id']
        if key not in representatives or order < (representatives[key]['citation_start'], representatives[key]['candidate_id']):
            representatives[key] = row
        task_values[row['task_unit_id']].append(row['delta_pn'])
    global_mean = float(np.mean([np.mean(values) for values in task_values.values()]))
    grouped = defaultdict(list)
    for (_, contract), row in representatives.items():
        grouped[contract].append(row['delta_pn'])
    statistics = []
    for contract, values in sorted(grouped.items()):
        n = len(values)
        mean = float(np.mean(values))
        score = (max(abs(mean) - 1.28 * float(np.std(values, ddof=1)) / np.sqrt(n), 0)
                 if n >= 4 else 0)
        statistics.append(dict(contract_id=contract, tasks=n, mean=mean, nomination_score=score,
                               prediction=(sum(values) + 2 * global_mean) / (n + 2),
                               direction=-1 if mean < 0 else 1))
    nominated = [row for row in statistics if row['nomination_score'] > 0]
    nominee = min(nominated, key=lambda row: (-row['nomination_score'], row['contract_id'])) if nominated else None
    return statistics, global_mean, nominee


def targeted_selector_comparison(preparation: Path, analysis: Path, output: Path):
    for source in (preparation, analysis):
        verify_bundle(source)
    if output.exists():
        raise FileExistsError(output)
    candidates = read_json(preparation / 'candidates.json')
    bindings = {row['candidate_id']: row for row in read_json(preparation / 'bindings.json')}
    tasks = {row['task_unit_id']: row for row in read_json(preparation / 'tasks.json')}
    assignments = read_json(preparation / 'assignments.json')
    effects = {row['candidate_id']: row for row in read_json(analysis / 'effects.json')}
    outcomes = read_json(analysis / 'outcomes.json')
    qualified = sorted((row for row in candidates if row['quality_qualified']),
                       key=lambda row: row['candidate_id'])
    groups = defaultdict(list)
    for candidate in qualified:
        groups[bindings[candidate['candidate_id']]['policy_id']].append(candidate)
    features, targets, aliases = [], {}, {}
    for policy_id, members in sorted(groups.items()):
        candidate = members[0]
        identity = candidate['candidate_id']
        effect = effects[identity]
        task_id = candidate['task_unit_id']
        for member in members:
            if (member['task_unit_id'] != task_id
                    or member['p_versions'] != candidate['p_versions']
                    or member['n_versions'] != candidate['n_versions']
                    or effects[member['candidate_id']]['pn'] != effect['pn']):
                raise ValueError('共享政策的任务、提示或效果不一致')
        arms = {}
        for arm in ('P', 'N'):
            requests = [row for row in assignments
                        if row['policy_id'] == policy_id and row['arm'] == arm]
            if len(requests) != 4 or len({row['seed'] for row in requests}) != 2:
                raise ValueError('政策分配数量或 seed 数量不符合冻结设计')
            primary = np.mean([outcomes[row['request_id']]['primary'] for row in requests], axis=0)
            bounds = np.mean([outcomes[row['request_id']]['sensitivity'] for row in requests], axis=0)
            if (not np.allclose(primary, effect['arms'][arm]['endpoints']['primary'])
                    or not np.allclose(bounds, effect['arms'][arm]['endpoints']['sensitivity'])):
                raise ValueError('保存效果与逐请求结局不一致')
            arms[arm] = dict(primary=primary.tolist(), bounds=bounds.tolist(),
                             request_ids=[row['request_id'] for row in requests])
        delta = arms['P']['primary'][0] - arms['N']['primary'][0]
        bounds = [arms['P']['bounds'][0] - arms['N']['bounds'][1],
                  arms['P']['bounds'][1] - arms['N']['bounds'][0]]
        if not np.allclose([delta, delta], effect['pn']['primary']) or not np.allclose(bounds, effect['pn']['sensitivity']):
            raise ValueError('P−N 效果重算不一致')
        features.append(dict(candidate_id=identity, policy_id=policy_id, task_unit_id=task_id,
            index=candidate['index'], operation=candidate['operation'],
            original_candidate_id=candidate['original_candidate_id'], flow=candidate['flow'],
            contract_id=content_hash(candidate['contract']), citation_start=0, orientation=1,
            canonical_text=tasks[task_id]['reference_prompt'] + '\n' + canonical_json(candidate['contract']),
            p_versions=candidate['p_versions'], n_versions=candidate['n_versions'],
            marginals={}, relations=[]))
        targets[identity] = dict(delta_pn=delta, p_mean=arms['P']['primary'][0],
                                 unknown_bounds=bounds, arms=arms)
        aliases[identity] = [row['candidate_id'] for row in members]
    task_ids = sorted({row['task_unit_id'] for row in features})
    if (len(qualified), len(features), len(task_ids)) != (19, 18, 10):
        raise ValueError('本次事后分析的冻结任务范围不匹配')
    folds = []
    methods = ('effect-ridge', 'contract-shrinkage', 'global-effect-mean',
               'first-fixed', 'uniform-positive', 'P-outcome-ridge')
    for heldout in task_ids:
        training_features = [row for row in features if row['task_unit_id'] != heldout]
        heldout_features = sorted((row for row in features if row['task_unit_id'] == heldout),
                                  key=lambda row: row['candidate_id'])
        training = [dict(row, delta_pn=targets[row['candidate_id']]['delta_pn']) for row in training_features]
        statistics, global_mean, _ = discovery_contract_statistics(training)
        contract_scores = {row['contract_id']: row['prediction'] for row in statistics}
        predictions, alphas, choices = {}, {}, {}
        for method, target in (('effect-ridge', 'delta_pn'), ('P-outcome-ridge', 'p_mean')):
            train = [dict(row, delta_pn=targets[row['candidate_id']][target]) for row in training_features]
            transformer, learner, evaluations = fit_discovery_ridge(train, mode='common')
            x, _ = transformer.transform(heldout_features, mode='common')
            scores = learner.predict(x).tolist()
            predictions[method] = scores
            alphas[method] = dict(selected=float(learner.alpha), inner_evaluations=evaluations)
            if method == 'effect-ridge':
                choices[method] = discovery_pick(heldout_features, scores)
            else:
                row, score = min(zip(heldout_features, scores, strict=True),
                                 key=lambda pair: (-pair[1], pair[0]['candidate_id']))
                choices[method] = dict(candidate_id=row['candidate_id'], direction=1, prediction=score)
        predictions['contract-shrinkage'] = [contract_scores.get(row['contract_id'], global_mean)
                                               for row in heldout_features]
        predictions['global-effect-mean'] = [global_mean] * len(heldout_features)
        for method in ('contract-shrinkage', 'global-effect-mean'):
            choices[method] = discovery_pick(heldout_features, predictions[method])
        choices['first-fixed'] = dict(candidate_id=heldout_features[0]['candidate_id'], direction=1,
                                      prediction=None)
        distributions = {method: [dict(candidate_id=choice['candidate_id'], direction=choice['direction'],
                                        probability=1.)] for method, choice in choices.items()}
        distributions['uniform-positive'] = [dict(candidate_id=row['candidate_id'], direction=1,
            probability=1 / len(heldout_features)) for row in heldout_features]
        # 外层结局仅在各方法选择完成后用于效用计算。
        evaluation = {}
        for method, distribution in distributions.items():
            utility, lower, upper = 0., 0., 0.
            for choice in distribution:
                target = targets[choice['candidate_id']]
                direction, probability = choice['direction'], choice['probability']
                bound = target['unknown_bounds']
                signed = bound if direction == 1 else [-bound[1], -bound[0]]
                utility += probability * direction * target['delta_pn']
                lower += probability * signed[0]
                upper += probability * signed[1]
            evaluation[method] = dict(signed_pn_utility=utility, unknown_bounds=[lower, upper])
        oracle = max(abs(targets[row['candidate_id']]['delta_pn']) for row in heldout_features)
        folds.append(dict(task_unit_id=heldout, index=heldout_features[0]['index'],
            candidate_ids=[row['candidate_id'] for row in heldout_features],
            training_task_ids=sorted({row['task_unit_id'] for row in training}),
            training_candidate_ids=[row['candidate_id'] for row in training],
            training_policy_ids=[row['policy_id'] for row in training],
            predictions=predictions, alphas=alphas, choices=choices, distributions=distributions,
            evaluation=evaluation, global_mean=global_mean, contract_statistics=statistics,
            unseen_contracts=[row['candidate_id'] for row in heldout_features
                              if row['contract_id'] not in contract_scores],
            posthoc_oracle_upper=oracle))
    summary = {method: dict(task_equal_utility=float(np.mean([
        row['evaluation'][method]['signed_pn_utility'] for row in folds])),
        task_equal_unknown_bounds=np.mean([row['evaluation'][method]['unknown_bounds'] for row in folds], axis=0).tolist())
        for method in methods}
    agreement = []
    for i, left in enumerate(methods):
        for right in methods[i + 1:]:
            candidate_matches, directed_matches = 0., 0.
            for fold in folds:
                for a in fold['distributions'][left]:
                    for b in fold['distributions'][right]:
                        weight = a['probability'] * b['probability']
                        if a['candidate_id'] == b['candidate_id']:
                            candidate_matches += weight
                            directed_matches += weight * (a['direction'] == b['direction'])
            agreement.append(dict(left=left, right=right, candidate_matches=candidate_matches,
                                  directed_matches=directed_matches, tasks=len(folds)))
    metadata = dict(status='EXECUTED_POSTOUTCOME_EXPLORATORY_LOTO',
        qualified_nominations=len(qualified), unique_policies=len(features), tasks=len(task_ids),
        independent_new_evaluation_tasks=0, confidence_intervals=None, significance_tests=None,
        source_manifests={str(path): file_sha256(path / 'manifest.json') for path in (preparation, analysis)},
        rule_document_sha256=file_sha256(Path('docs/experiments/2026-09-29-targeted-selector-analysis.md')),
        implementation_sha256=file_sha256(Path(__file__)),
        all_heldout_contracts_unseen=all(len(row['unseen_contracts']) == len(row['candidate_ids']) for row in folds),
        posthoc_oracle_upper=float(np.mean([row['posthoc_oracle_upper'] for row in folds])),
        P_outcome_direction_information='P label only; fixed positive direction',
        interpretation='任务等权开发探索；未知界限无抽样覆盖含义；不证明图优势或结构因果识别')
    return write_bundle(output, {'metadata.json': metadata, 'summary.json': summary,
        'folds.json': folds, 'agreement.json': agreement, 'features.json': features,
        'targets.json': targets, 'aliases.json': aliases})


def case_row(case, candidate):
    nodes = {row['id']: row for row in case['targets']['nodes']}
    relations = {row['id']: row for row in case['targets']['relations']}
    target = candidate['target']
    hypothesis = candidate['hypothesis']
    node_text = '\n'.join(sorted(' | '.join((nodes[n]['type'], nodes[n]['meaning'], nodes[n]['quote']))
                                  for n in target['nodes']))
    relation_text = '\n'.join(sorted(' | '.join((nodes[relations[r]['from']]['type'],
        nodes[relations[r]['from']]['meaning'], relations[r]['type'],
        nodes[relations[r]['to']]['type'], nodes[relations[r]['to']]['meaning'], relations[r]['quote']))
        for r in target['relations']))
    return dict(index=case['source']['index'], task_unit_id=case['source']['task_unit_id'],
                slot=candidate['slot'], category=CATEGORY[candidate['slot']],
                operation=hypothesis['operation'], outcome='secure_yield',
                node_types='|'.join(sorted({nodes[node]['type'] for node in target['nodes']})),
                relation_types='|'.join(sorted({relations[relation]['type'] for relation in target['relations']})),
                node_count=len(target['nodes']), relation_count=len(target['relations']),
                text=case['source']['prompt']+'\n'+hypothesis['hypothesis']+'\n'+hypothesis['operation'],
                node_semantics=node_text, graph_semantics=node_text+'\n'+relation_text,
                **{name: str(value) for name, value in case['author_card']['source_x'].items()})


def feature_model(mode, parameter):
    if mode == 'text_ridge':
        transform = ColumnTransformer([
            ('text', TfidfVectorizer(ngram_range=(1, 2), max_features=128), 'text'),
            ('common', OneHotEncoder(handle_unknown='ignore', sparse_output=False), ['operation', 'outcome']),
        ], sparse_threshold=0)
    elif mode in ('semantic_graph_ridge', 'semantic_node_ridge'):
        field = 'graph_semantics' if mode == 'semantic_graph_ridge' else 'node_semantics'
        transform = ColumnTransformer([
            ('semantics', TfidfVectorizer(analyzer='char', ngram_range=(2,4), max_features=128), field),
            ('common', OneHotEncoder(handle_unknown='ignore', sparse_output=False), ['operation','outcome']),
        ], sparse_threshold=0)
    else:
        categorical = NODE_CATEGORICAL if mode == 'node_only_ridge' else GRAPH_CATEGORICAL
        numeric = NODE_NUMERIC if mode == 'node_only_ridge' else GRAPH_NUMERIC
        transform = ColumnTransformer([
            ('categorical', OneHotEncoder(handle_unknown='ignore', sparse_output=False), list(categorical)),
            ('numeric', StandardScaler(), list(numeric)),
        ])
    estimator = (RandomForestRegressor(n_estimators=200, max_depth=parameter['max_depth'],
                                      min_samples_leaf=parameter['min_samples_leaf'],
                                      max_features=1., random_state=20260928)
                 if mode == 'tsg_forest' else Ridge(alpha=parameter['alpha']))
    return Pipeline([('features', transform), ('estimator', estimator)])


def predict(training, targets, mode, parameter):
    train_frame, target_frame = pd.DataFrame(training), pd.DataFrame(targets)
    if mode == 'two_arm_ridge':
        treatment = feature_model(mode, parameter).fit(train_frame, [row['P'] for row in training])
        reference = feature_model(mode, parameter).fit(train_frame, [row['R'] for row in training])
        return treatment.predict(target_frame)-reference.predict(target_frame)
    outcome = 'P' if mode == 'treated_outcome_ridge' else 'P_minus_R'
    model = feature_model(mode, parameter).fit(train_frame, [row[outcome] for row in training])
    predicted = model.predict(target_frame)
    if mode == 'treated_outcome_ridge':
        reference_by_task = {row['task_unit_id']: row['R'] for row in training}
        predicted -= np.mean(list(reference_by_task.values()))
    return predicted


def pick(rows, predicted):
    scores = [(float(value), row['slot']) for row, value in zip(rows, predicted, strict=True)]
    best, slot = sorted(scores, key=lambda value: (-value[0], value[1]))[0]
    return f'P:{slot}' if best > 0 else 'R'


def tune(training, mode):
    parameters = ([dict(max_depth=depth, min_samples_leaf=leaf)
                   for depth in (2, None) for leaf in (3, 6)] if mode == 'tsg_forest'
                  else [dict(alpha=alpha) for alpha in ALPHAS])
    folds = sorted({row['task_unit_id'] for row in training})
    evaluations = []
    for parameter in parameters:
        gains = []
        for identity in folds:
            train = [row for row in training if row['task_unit_id'] != identity]
            test = [row for row in training if row['task_unit_id'] == identity]
            assert len({row['task_unit_id'] for row in train}) == 6
            scores = predict(train, test, mode, parameter)
            choice = pick(test, scores)
            gain = 0. if choice == 'R' else next(row['P_minus_R'] for row in test
                                                if row['slot'] == int(choice.split(':')[1]))
            gains.append(dict(task_unit_id=identity, choice=choice, gain=gain,
                              scores={str(row['slot']): float(value)
                                      for row, value in zip(test, scores, strict=True)}))
        evaluations.append(dict(parameter=parameter, mean_gain=float(np.mean([row['gain'] for row in gains])), folds=gains))
    def rank(evaluation):
        parameter = evaluation['parameter']
        regularization = ((parameter['min_samples_leaf'], int(parameter['max_depth'] == 2))
                          if mode == 'tsg_forest' else (parameter['alpha'], 0))
        return (evaluation['mean_gain'], *regularization)
    selected = max(evaluations, key=rank)
    return selected['parameter'], evaluations


def freeze(repo):
    verify_bundle(repo / ROOT / 'development-nomination')
    verify_bundle(repo / ROOT / 'heldout-tranche')
    all_effects = []
    for name in ('development-seven-task-independent-verification.json',
                 'development-second-seven-independent-verification.json'):
        verified = read_json(repo / RESULTS / name)
        assert verified['status'] == 'verified'
        all_effects.extend(row for row in verified['effects'] if row['slot'] in (0, 2)
                           and not (row['index'] == 44 and row['slot'] == 2))
    assert len(all_effects) == 27
    development = []
    case_hashes = {}
    for index in sorted({row['index'] for row in all_effects}):
        directory = repo / ROOT / f'prepared/case-{index:04d}'
        verify_bundle(directory)
        case = read_json(directory / 'case.json')
        if case['source']['representation'] != 'TSG':
            continue
        case_hashes[str(index)] = file_sha256(directory / 'manifest.json')
        for candidate in case['candidates']:
            if candidate['slot'] not in (0, 2):
                continue
            observed = next(row for row in all_effects if row['index'] == index and row['slot'] == candidate['slot'])
            development.append(dict(**case_row(case, candidate), P=observed['P'], R=observed['R'],
                                    P_minus_R=observed['P_minus_R']))
    assert len(development) == 14 and len({row['task_unit_id'] for row in development}) == 7
    tranche = read_json(repo / ROOT / 'heldout-tranche/tranche.json')
    heldout = []
    for index in tranche['selected_indices']:
        if index == 184:
            continue
        suffix = '-v2' if index in (38, 206) else ''
        directory = repo / ROOT / f'prepared/case-{index:04d}{suffix}'
        verify_bundle(directory)
        case = read_json(directory / 'case.json')
        assert case['source']['role'] == 'heldout'
        if case['source']['representation'] == 'TSG':
            case_hashes[str(index)] = file_sha256(directory / 'manifest.json')
            heldout.extend(case_row(case, candidate) for candidate in case['candidates'])
    assert len(heldout) == 16 and len({row['task_unit_id'] for row in heldout}) == 8
    tuned, cv = {}, {}
    scores_by_mode = {}
    for mode in MODES:
        parameter, evaluations = tune(development, mode)
        tuned[mode], cv[mode] = parameter, evaluations
        scores_by_mode[mode] = predict(development, heldout, mode, parameter)
    by_task = defaultdict(list)
    for position, row in enumerate(heldout):
        by_task[row['index']].append((position, row))
    graph_summary = read_json(repo / RESULTS / 'real-context-search-common-gap/bundle/summary.json')
    structural_actions = {(row['category'], row['method']): row['action'] for row in graph_summary}
    pooled = {slot: float(np.mean([row['P_minus_R'] for row in development if row['slot'] == slot])) for slot in (0, 2)}
    choices = []
    for index, positioned in sorted(by_task.items()):
        positions, rows = zip(*positioned)
        actions = dict(no_edit='R', source_semantics='P:0',
                       overall_randomized_effect=pick(rows, [pooled[row['slot']] for row in rows]))
        scores = {}
        for mode in MODES:
            values = [scores_by_mode[mode][position] for position in positions]
            actions[mode] = pick(rows, values)
            scores[mode] = {str(row['slot']): float(value) for row, value in zip(rows, values, strict=True)}
        for method in ('FCI_JCI0', 'FCI_JCI1', 'FCI_JCI12', 'GFCI'):
            choice = actions['tsg_ridge']
            if choice != 'R':
                category = CATEGORY[int(choice.split(':')[1])]
                if structural_actions[category, method] == 'forbid_P':
                    choice = 'R'
            actions[f'tsg_ridge_plus_{method}'] = choice
        choices.append(dict(index=index, task_unit_id=rows[0]['task_unit_id'], choices=actions, scores=scores))
    write_bundle(repo / ROOT / 'heldout-policy-decisions', {
        'development.json': development, 'heldout-source.json': heldout,
        'cross-validation.json': cv, 'decisions.json': choices,
        'protocol.json': dict(status='FROZEN_BEFORE_HELDOUT_GENERATION', formal_protocol='SPECIFIED_DRAFT',
                              scientific_scope='exploratory_TSG_candidate_feature_substudy',
                              training_task_units=7, evaluation_task_units=8,
                              support_minimum=6, tuning=tuned, feature_categorical=GRAPH_CATEGORICAL,
                              feature_numeric=GRAPH_NUMERIC,
                              same_candidate_comparison=True,
                              raw_preparation_comparison='BLOCKED_INDEPENDENT_QUALITY_REVIEW',
                              structural_population_limit='Graph filters use a separate randomized-context diagnostic of fourteen development tasks; filter comparisons are exploratory and do not establish an equal-training-budget advantage.',
                              case_manifest_sha256=case_hashes,
                              implementation_sha256=file_sha256(Path(__file__)),
                              decision_threshold='strictly_positive_P_minus_R',
                              fold_rule='leave_one_task_out; all candidates from one task remain together',
                              alpha_grid=ALPHAS, text_features='unigram_bigram_TFIDF_128',
                              forest_tie_rule='larger_leaf_then_depth_2',
                              independent_quality_review='pending')})
    print(dict(frozen_choices=len(choices), tuned=tuned,
               action_counts={mode: dict((choice, sum(row['choices'][mode] == choice for row in choices))
                                        for choice in sorted({row['choices'][mode] for row in choices}))
                              for mode in choices[0]['choices']}))


def repair_semantic_selection(repo):
    modes = ('text_ridge','tsg_ridge','semantic_node_ridge','semantic_graph_ridge')
    previous = repo / ROOT / 'heldout-policy-decisions'
    verify_bundle(previous)
    training = read_json(previous / 'development.json')
    targets = []
    for suffix in ('','-remaining','-performance'):
        directory = repo / ROOT / ('heldout-policy-decisions'+suffix)
        verify_bundle(directory)
        targets.extend(read_json(directory / 'heldout-source.json'))
    for rows in (training,targets):
        for row in rows:
            suffix = '-v2' if row['index'] in (38,206) else ''
            directory = repo / ROOT / f"prepared/case-{row['index']:04d}{suffix}"
            verify_bundle(directory)
            case = read_json(directory / 'case.json')
            candidate = next(c for c in case['candidates'] if c['slot'] == row['slot'])
            source_features = case_row(case,candidate)
            assert all(row[key] == source_features[key] for key in row if key in source_features)
            row.update(node_semantics=source_features['node_semantics'],graph_semantics=source_features['graph_semantics'])
    assert len(training) == 14 and len(targets) == 30
    write_bundle(repo / ROOT / 'repair-semantic-selection-inputs', {'training.json':training,'targets.json':targets,
        'protocol.json':dict(status='FROZEN_POST_OUTCOME_SELECTOR_DIAGNOSTIC',modes=modes,alphas=ALPHAS,
            comparison='Same 14 training candidates and 30 evaluation candidates; task-grouped cross-validation.',
            semantic_encoding='Character TFIDF 2-4 grams, maximum 128 features; exact node meanings, quotes and relation endpoint meanings.',
            original_policies_changed=False,implementation_sha256=file_sha256(Path(__file__)))})
    records = []
    for filename in ('heldout-independent-verification.json','heldout-remaining-independent-verification.json',
                     'heldout-performance-independent-verification.json'):
        records.extend(read_json(repo / RESULTS / filename)['records'])
    revised = {}
    for prefix in ('source-measurement-review','privacy-property-review'):
        directory = repo / RESULTS / (prefix+'-verification')
        verify_bundle(directory)
        revised.update({(r['index'],r['slot']):r for r in read_json(directory / 'verification.json')['records']})
    choices, cv, values = {}, {}, []
    for mode in modes:
        parameter,evaluations = tune(training,mode)
        scores = predict(training,targets,mode,parameter)
        cv[mode] = dict(parameter=parameter,evaluations=evaluations)
        decisions = []
        for index in sorted({r['index'] for r in targets}):
            positions = [i for i,r in enumerate(targets) if r['index'] == index]
            rows = [targets[i] for i in positions]
            choice = pick(rows,[scores[i] for i in positions])
            arm,slot = ('R',None) if choice == 'R' else ('P',int(choice.split(':')[1]))
            observed = [r for r in records if r['index'] == index and r['arm'] == arm and r['candidate_slot'] == slot]
            assert len(observed) == 3
            original_yield = float(np.mean([r['secure_yield'] for r in observed]))
            source_yield = float(np.mean([revised.get((r['index'],r['slot']),r)['secure_yield'] for r in observed]))
            decisions.append(dict(index=index,choice=choice,original_yield=original_yield,
                                  source_sensitive_yield=source_yield,scores={str(targets[i]['slot']):float(scores[i]) for i in positions}))
        choices[mode] = decisions
        values.append(dict(method=mode,task_units=len(decisions),
            original_yield=float(np.mean([r['original_yield'] for r in decisions])),
            source_sensitive_yield=float(np.mean([r['source_sensitive_yield'] for r in decisions]))))
    write_bundle(repo / RESULTS / 'repair-semantic-selection', {'decisions.json':choices,'cross-validation.json':cv,
        'policy-values.json':values,'completion.json':dict(status='EXECUTED_POST_OUTCOME_DIAGNOSTIC',
            training_task_units=7,evaluation_task_units=15,independent_semantic_review=False,
            original_training_nonzero=sum(r['P_minus_R'] != 0 for r in training))})
    print(values)


def freeze_remaining(repo, performance=False):
    previous = repo / ROOT / 'heldout-policy-decisions'
    verify_bundle(previous)
    suffix = '-performance' if performance else '-remaining'
    verify_bundle(repo / ROOT / ('heldout-tranche'+suffix))
    protocol = read_json(previous / 'protocol.json')
    training = read_json(previous / 'development.json')
    previous_targets = read_json(previous / 'heldout-source.json')
    previous_choices = read_json(previous / 'decisions.json')
    targets, case_hashes = [], {}
    for index in read_json(repo / ROOT / ('heldout-tranche'+suffix) / 'tranche.json')['selected_indices']:
        directory = repo / ROOT / f'prepared/case-{index:04d}'
        verify_bundle(directory)
        case = read_json(directory / 'case.json')
        assert case['source']['role'] == 'heldout'
        if case['source']['representation'] == 'TSG':
            targets.extend(case_row(case, candidate) for candidate in case['candidates'])
            case_hashes[str(index)] = file_sha256(directory / 'manifest.json')
    task_count = 3 if performance else 4
    assert len(targets) == task_count*2 and len({row['task_unit_id'] for row in targets}) == task_count
    predictions = {}
    for mode in MODES:
        parameter = protocol['tuning'][mode]
        replay = predict(training, previous_targets, mode, parameter)
        for row, value in zip(previous_targets, replay, strict=True):
            expected = next(choice for choice in previous_choices if choice['index'] == row['index'])
            assert np.isclose(value, expected['scores'][mode][str(row['slot'])], rtol=0, atol=1e-12)
        predictions[mode] = predict(training, targets, mode, parameter)
    summary = read_json(repo / RESULTS / 'real-context-search-common-gap/bundle/summary.json')
    structural = {(row['category'], row['method']): row['action'] for row in summary}
    pooled = {slot: float(np.mean([row['P_minus_R'] for row in training if row['slot'] == slot])) for slot in (0, 2)}
    choices = []
    for index in sorted({row['index'] for row in targets}):
        positions = [position for position, row in enumerate(targets) if row['index'] == index]
        rows = [targets[position] for position in positions]
        actions = dict(no_edit='R', source_semantics='P:0',
                       overall_randomized_effect=pick(rows, [pooled[row['slot']] for row in rows]))
        scores = {}
        for mode in MODES:
            values = [predictions[mode][position] for position in positions]
            actions[mode] = pick(rows, values)
            scores[mode] = {str(row['slot']): float(value) for row, value in zip(rows, values, strict=True)}
        for method in ('FCI_JCI0', 'FCI_JCI1', 'FCI_JCI12', 'GFCI'):
            choice = actions['tsg_ridge']
            if choice != 'R' and structural[CATEGORY[int(choice.split(':')[1])], method] == 'forbid_P':
                choice = 'R'
            actions[f'tsg_ridge_plus_{method}'] = choice
        choices.append(dict(index=index, task_unit_id=rows[0]['task_unit_id'], choices=actions, scores=scores))
    write_bundle(repo / ROOT / ('heldout-policy-decisions'+suffix), {
        'heldout-source.json': targets, 'decisions.json': choices,
        'protocol.json': dict(status='FROZEN_BEFORE_REMAINING_GENERATION', formal_protocol='SPECIFIED_DRAFT',
            scientific_scope='exploratory_remaining_TSG_candidate_feature_substudy', training_task_units=7,
            evaluation_task_units=task_count, original_policy_manifest_sha256=file_sha256(previous / 'manifest.json'),
            training_policy='Unchanged original training records and selected parameters; previous scores exactly replayed.',
            case_manifest_sha256=case_hashes, tuning=protocol['tuning'],
            implementation_sha256=file_sha256(Path(__file__)), independent_quality_review='pending')})
    print(dict(frozen_choices=len(choices), actions={row['index']: row['choices'] for row in choices}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, default=Path('.'))
    parser.add_argument('--remaining', action='store_true')
    parser.add_argument('--performance', action='store_true')
    parser.add_argument('--repair', action='store_true')
    options = parser.parse_args()
    if options.repair:
        repair_semantic_selection(options.repo)
    else:
        freeze_remaining(options.repo, options.performance) if options.remaining or options.performance else freeze(options.repo)
