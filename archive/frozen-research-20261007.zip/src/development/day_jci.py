"""Randomized version-mixture JCI query diagnostic, separate from code outcomes."""
from __future__ import annotations

import csv
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd


MECHANISMS=("valid_coarse_B", "unrecorded_wording", "deterministic_B", "invalid_hidden_B_confounding")
SIZES=(64,256,1024)
SEEDS=tuple(range(12001,12051))
EQUIVALENCE_MARGIN=.15
CI_MULTIPLIER=1.64


def draw(mechanism,n,seed):
    rng=np.random.default_rng(seed)
    c=rng.binomial(1,.5,n)
    u=rng.binomial(1,.5,n)
    if mechanism=="deterministic_B":
        b=c.copy()
    elif mechanism=="invalid_hidden_B_confounding":
        b=rng.binomial(1,.15+.4*c+.2*u)
    else:
        b=rng.binomial(1,.25+.5*c)
    if mechanism=="unrecorded_wording":
        w=rng.binomial(1,.1+.8*c)
        probability=.25+.2*b+.25*w
    elif mechanism=="invalid_hidden_B_confounding":
        probability=.3+.25*b+.2*u
    else:
        probability=.3+.25*b
    assert np.all((probability>=0)&(probability<=1))
    y=rng.binomial(1,probability)
    return pd.DataFrame(dict(C=c,B=b,Y=y,mechanism=mechanism,n_total=n,seed=seed))


def make_input(root):
    frames=[draw(name,n,seed) for name in MECHANISMS for n in SIZES for seed in SEEDS]
    assert len(frames)==600
    root.mkdir(parents=True,exist_ok=True)
    target=root/'input.csv'
    if target.exists(): raise FileExistsError(target)
    pd.concat(frames,ignore_index=True).to_csv(target,index=False)
    print(json.dumps(dict(matrices=len(frames),rows=sum(map(len,frames)))))


def direct_equivalence(frame):
    contrasts=[]
    for b in (0,1):
        groups=[frame.loc[(frame.B==b)&(frame.C==c),'Y'].to_numpy() for c in (0,1)]
        if min(map(len,groups))<10:
            return dict(pool=False, reason='positivity_or_precision', contrasts=contrasts)
        difference=float(np.mean(groups[1])-np.mean(groups[0]))
        se=math.sqrt(sum(float(np.var(x,ddof=1))/len(x) for x in groups))
        contrasts.append(dict(B=b,difference=difference,se=se,
                              passes=abs(difference)+CI_MULTIPLIER*se<EQUIVALENCE_MARGIN))
    return dict(pool=all(x['passes'] for x in contrasts),reason='equivalence' if all(x['passes'] for x in contrasts)
                else 'residual_or_imprecise',contrasts=contrasts)


def choose_complete_version(frame):
    """Known randomized mixture probabilities; use both C strata equally."""
    weighted=[]
    for b in (0,1):
        probability=np.where(frame.C.to_numpy()==0,.25,.75)
        probability=probability if b==1 else 1-probability
        weighted.append(float(np.mean((frame.B.to_numpy()==b)*frame.Y.to_numpy()/probability)))
    return dict(chosen_B=int(weighted[1]>weighted[0]),weighted_yields=weighted)


def summarize(root):
    data=pd.read_csv(root/'input.csv',keep_default_na=False)
    graphs={}
    with (root/'jci.csv').open(newline='',encoding='utf-8') as stream:
        for row in csv.DictReader(stream):
            key=(row['mechanism'],int(row['n_total']),int(row['seed']),row['method'])
            assert key not in graphs
            graphs[key]=row
    assert len(graphs)==1200
    decisions=[]
    for key,frame in data.groupby(['mechanism','n_total','seed'],sort=False):
        mechanism,n,seed=key
        direct=direct_equivalence(frame)
        version=choose_complete_version(frame) if direct['pool'] else None
        for method in ('JCI0','JCI12'):
            graph=graphs[(mechanism,int(n),int(seed),method)]
            bad=bool(graph['error'] or graph['warnings'])
            adjacent=graph['cy_adjacent']=='TRUE' if not bad else None
            # A PAG adjacency is only a veto and can nominate finer wording as
            # a next randomized contrast. Non-adjacency never establishes equivalence.
            action=('POOL_B' if direct['pool'] and adjacent is False else
                    'AUDIT_AND_RANDOMIZE_FINER_VERSION' if direct['pool'] and adjacent is True else
                    'NO_POOL_UNRESOLVED')
            baseline='POOL_B' if direct['pool'] else 'NO_POOL_UNRESOLVED'
            decisions.append(dict(mechanism=mechanism,n_total=int(n),seed=int(seed),method=method,
                                  baseline=baseline,jci_consumer=action,cy_adjacent=adjacent,
                                  graph_unusable=bad,direct=direct,
                                  chosen_complete_version=version if action=='POOL_B' else None,
                                  action_changed=action!=baseline))
    target=root/'decisions.json'
    if target.exists(): raise FileExistsError(target)
    target.write_text(json.dumps(decisions,separators=(',',':')),encoding='utf-8')
    groups=defaultdict(list)
    for row in decisions: groups[(row['mechanism'],row['n_total'],row['method'])].append(row)
    summary=[]
    for key,rows in groups.items():
        summary.append(dict(zip(('mechanism','n_total','method'),key)) |
                       dict(repetitions=len(rows),baseline_pool=sum(x['baseline']=='POOL_B' for x in rows),
                            jci_pool=sum(x['jci_consumer']=='POOL_B' for x in rows),
                            changed=sum(x['action_changed'] for x in rows),
                            cy_adjacent=sum(x['cy_adjacent'] is True for x in rows),
                            unusable=sum(x['graph_unusable'] for x in rows)))
    (root/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(dict(matrices=600,searches=len(graphs),decisions=len(decisions))))


def oracle_audit(root):
    """Post-hoc population check of the frozen gate's decision semantics.

    No FCI search is run: for three observed variables C and Y can be
    separated only by the empty set or B. Degenerate support is excluded.
    """
    cases=[]
    for name in (*MECHANISMS, 'exploratory_submargin_wording'):
        joint=np.zeros((2,2,2))
        for c in (0,1):
            for u in (0,1):
                pb=(float(c) if name=='deterministic_B' else
                    .15+.4*c+.2*u if name=='invalid_hidden_B_confounding' else .25+.5*c)
                for b in (0,1):
                    mass=.25*(pb if b else 1-pb)
                    for w in (0,1):
                        pw=.1+.8*c
                        py=(.25+.2*b+(.1 if name=='exploratory_submargin_wording' else .25)*w
                            if name in ('unrecorded_wording','exploratory_submargin_wording') else
                            .3+.25*b+.2*u if name=='invalid_hidden_B_confounding' else .3+.25*b)
                        for y in (0,1):
                            joint[c,b,y]+=mass*(pw if w else 1-pw)*(py if y else 1-py)
        assert abs(joint.sum()-1)<1e-12
        support=joint.sum(axis=2)
        overlap=bool(np.all(support>0))
        marginal=[float(joint[c,:,1].sum()/joint[c].sum()) for c in (0,1)]
        conditional=([float(joint[1,b,1]/support[1,b]-joint[0,b,1]/support[0,b])
                      for b in (0,1)] if overlap else None)
        marginal_independent=abs(marginal[1]-marginal[0])<1e-12
        conditional_independent=all(abs(x)<1e-12 for x in conditional) if overlap else None
        adjacent=not (marginal_independent or conditional_independent) if overlap else None
        direct=overlap and all(abs(x)<EQUIVALENCE_MARGIN for x in conditional)
        consumer=direct and adjacent is False
        cases.append(dict(mechanism=name, joint_C_B_Y=joint.tolist(), full_support=overlap,
            exact_conditional_C_risk_differences=conditional,
            marginal_C_Y_independent=marginal_independent,
            conditional_C_Y_given_B_independent=conditional_independent,
            oracle_C_Y_skeleton_adjacent=adjacent,
            direct_population_pool=direct, oracle_veto_population_pool=consumer,
            action_changed=direct!=consumer,
            identity='POSTHOC_NEW_MECHANISM' if name.startswith('exploratory') else 'EXISTING_FROZEN_MECHANISM'))
    root.mkdir(parents=True,exist_ok=False)
    report=dict(status='POSTHOC_EXACT_DISTRIBUTION_CONSUMER_AUDIT',
        tolerance=EQUIVALENCE_MARGIN, cases=cases,
        interpretation='Exact-zero conditional independence and tolerance-based equivalence are different queries. A submargin residual can trigger the graph veto despite acceptable pooling under the direct tolerance.',
        limits='Oracle skeleton diagnostic only; not a new FCI/JCI run, endpoint-direction theorem, natural result, or independent policy-value experiment. Deterministic support and hidden-B confounding remain stress cases.')
    (root/'population-query.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps([{k:r[k] for k in ('mechanism','exact_conditional_C_risk_differences',
        'oracle_C_Y_skeleton_adjacent','direct_population_pool','oracle_veto_population_pool')} for r in cases]))


if __name__=='__main__':
    mode,output=sys.argv[1:]
    {'input':make_input,'summarize':summarize,'oracle-audit':oracle_audit}[mode](Path(output))
