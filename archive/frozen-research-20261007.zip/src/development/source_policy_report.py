from __future__ import annotations

import hashlib
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from prompt_mechanism_study.artifact_io import read_json, verify_bundle, write_bundle


ROOT = Path('data/method/source-hypotheses-20260927')
METHODS = ('no_edit', 'source_semantics', 'source_semantics_support_matched',
           'overall_randomized_effect', 'conditional_causal_ridge',
           'treated_outcome_association')


def channel_label(channel: dict, field: str, allowed: set[str]) -> str:
    value = channel.get('observation', {}).get(field, 'unknown') if channel['status'] == 'passed' else 'unknown'
    if value not in allowed:
        raise ValueError(f'unrecognized channel observation: {field}={value}')
    return value


def combine(measurements: list[dict]) -> dict:
    labels = [channel_label(row['channels']['security'], 'security_label',
                            {'secure', 'insecure', 'unknown'}) for row in measurements]
    functions = [channel_label(row['channels']['functionality'], 'functionality',
                               {'pass', 'partial_pass', 'fail', 'unknown'}) for row in measurements]
    security = ('insecure' if 'insecure' in labels else
                'secure' if all(value == 'secure' for value in labels) else 'unknown')
    functionality = ('fail' if 'fail' in functions else
                     'pass' if all(value == 'pass' for value in functions) else
                     'partial_pass' if all(value in {'pass', 'partial_pass'} for value in functions) else
                     'unknown')
    return dict(security_label=security, functionality=functionality,
                code_valid=all(row['channels']['security']['status'] != 'invalid_code'
                               for row in measurements),
                channel_statuses=[dict(security=row['channels']['security']['status'],
                                       functionality=row['channels']['functionality']['status'])
                                  for row in measurements],
                component_security=labels, component_functionality=functions,
                secure_code_yield=int(security == 'secure'),
                functionality_pass=int(functionality == 'pass'),
                secure_and_functional=int(security == 'secure' and functionality == 'pass'))


def assemble(repo: Path, mode: str) -> dict:
    root = repo / ROOT
    inputs = root / 'heldout-panel-inputs'
    selection = root / 'heldout-decisions'
    verify_bundle(inputs)
    verify_bundle(selection)
    assignments = read_json(inputs / 'assignments.json')
    decisions = read_json(selection / 'decisions.json')
    if len(assignments) != 58 or len(decisions) != 5:
        raise ValueError('heldout input identities changed')
    by_candidate = defaultdict(list)
    assignment_rows = []
    for assignment in assignments:
        slot = assignment['slot']
        result_dir = root / 'heldout-panel' / slot
        verify_bundle(result_dir / 'result')
        generation = read_json(result_dir / 'result/result.json')
        if generation['status'] != 'returned' or generation['slot'] != slot:
            raise ValueError(f'incomplete generation: {slot}')
        code = (result_dir / 'code.py').read_text(encoding='utf-8')
        if hashlib.sha256(code.encode()).hexdigest() != generation['code_sha256']:
            raise ValueError(f'code mismatch: {slot}')
        if mode == 'original':
            if assignment['index'] == 62:
                measurements = [read_json(root / f'measurement/case62-common/{slot}-{family}.json')
                                for family in ('apidomain', 'apiendpoint')]
            else:
                measurements = [generation['measurements'][0]['measurement']]
        else:
            count = 2 if assignment['index'] == 62 else 1
            measurements = [read_json(root / f'measurement/heldout-envelope-diagnostic/{slot}-{position}.json')
                            for position in range(count)]
        if any(row['status'] != 'measured' for row in measurements):
            raise ValueError(f'incomplete measurement: {slot}')
        observation = combine(measurements)
        row = dict(slot=slot, index=assignment['index'], arm=assignment['arm'],
                   candidate_slot=assignment['candidate_slot'], repeat=assignment['repeat'],
                   task_unit_id=assignment['task_unit_id'], **observation)
        assignment_rows.append(row)
        target_slots = ([assignment['candidate_slot']] if assignment['candidate_slot'] is not None else
                        [specification['candidate_slot'] for specification in assignment['measurements']])
        for candidate_slot in target_slots:
            by_candidate[assignment['index'], candidate_slot, assignment['arm']].append(row)
    if len(assignment_rows) != 58:
        raise ValueError('assignment denominator changed')
    if any(len(rows) != 2 for rows in by_candidate.values()):
        raise ValueError('candidate arm repetition changed')
    candidate_rows = []
    for (index, candidate_slot, arm), rows in sorted(by_candidate.items()):
        candidate_rows.append(dict(index=index, candidate_slot=candidate_slot, arm=arm,
                                   secure_code_yield=float(np.mean([row['secure_code_yield'] for row in rows])),
                                   functionality_pass=float(np.mean([row['functionality_pass'] for row in rows])),
                                   secure_and_functional=float(np.mean([row['secure_and_functional'] for row in rows])),
                                   unknown_security=sum(row['security_label'] == 'unknown' for row in rows),
                                   invalid_code=sum(not row['code_valid'] for row in rows)))
    table = {(row['index'], row['candidate_slot'], row['arm']): row for row in candidate_rows}
    task_rows = []
    for frozen in decisions:
        index = frozen['index']
        slots = [score['candidate_slot'] for score in frozen['scores']]
        if len({table[index, slot, 'R']['secure_code_yield'] for slot in slots}) != 1:
            raise ValueError(f'candidate-specific R outcomes differ: {index}')
        choices = {}
        for method in METHODS:
            action = frozen['choices'][method]
            selected_slot, arm = (slots[0], 'R') if action == 'R' else (int(action.split(':')[1]), 'P')
            selected = table[index, selected_slot, arm]
            choices[method] = dict(action=action,
                                   secure_code_yield=selected['secure_code_yield'],
                                   functionality_pass=selected['functionality_pass'],
                                   secure_and_functional=selected['secure_and_functional'])
        task_rows.append(dict(index=index, task_unit_id=frozen['task_unit_id'], choices=choices))
    method_values = {method: float(np.mean([row['choices'][method]['secure_code_yield']
                                             for row in task_rows])) for method in METHODS}
    comparisons = []
    rng = np.random.default_rng(20260927)
    draws = rng.integers(0, len(task_rows), size=(5000, len(task_rows)))
    for baseline in ('overall_randomized_effect', 'source_semantics',
                     'source_semantics_support_matched', 'treated_outcome_association'):
        differences = np.array([row['choices']['conditional_causal_ridge']['secure_code_yield'] -
                                row['choices'][baseline]['secure_code_yield'] for row in task_rows])
        bootstrap = differences[draws].mean(axis=1)
        comparisons.append(dict(comparison=f'conditional_causal_ridge-minus-{baseline}',
                                estimate=float(differences.mean()),
                                interval_98_3333=[float(value) for value in
                                                  np.quantile(bootstrap, [1/120, 119/120])],
                                degenerate=bool(np.ptp(bootstrap) == 0),
                                action_disagreements=sum(
                                    row['choices']['conditional_causal_ridge']['action'] !=
                                    row['choices'][baseline]['action'] for row in task_rows)))
    return dict(mode=mode, evidence_role=('frozen_exploratory_heldout' if mode == 'original' else
                                          'posthoc_format_diagnostic'),
                assigned=len(assignment_rows), task_units=len(task_rows),
                candidate_arm_rows=len(candidate_rows),
                label_counts=dict(Counter(row['security_label'] for row in assignment_rows)),
                invalid_code_assignments=sum(not row['code_valid'] for row in assignment_rows),
                method_values=method_values, comparisons=comparisons,
                assignment_rows=assignment_rows, candidate_rows=candidate_rows,
                task_rows=task_rows)


def report(repo: Path, destination: Path) -> None:
    root = repo / ROOT
    original = assemble(repo, 'original')
    normalized = assemble(repo, 'normalized')
    protocol = dict(status='EXPLORATORY_HELDOUT_ANALYSIS', formal_protocol='SPECIFIED_DRAFT',
                    selection_manifest=read_json(root / 'heldout-decisions/manifest.json'),
                    heldout_input_manifest=read_json(root / 'heldout-panel-inputs/manifest.json'),
                    common_outcome_plan_manifest=read_json(root / 'measurement/case62-common-plan/manifest.json'),
                    normalized_input_manifest=read_json(root / 'measurement/heldout-envelope-diagnostic-inputs/manifest.json'),
                    normalized_provenance_manifest=read_json(
                        root / 'measurement/heldout-envelope-diagnostic-inputs-provenance/manifest.json'),
                    bootstrap=dict(task_units=5, draws=5000, seed=20260927,
                                   interval='paired percentile 98.3333 percent',
                                   limitation='small independent task count and degenerate intervals do not prove equivalence'))
    write_bundle(destination, {'protocol.json': protocol, 'original.json': original,
                               'format-diagnostic.json': normalized})
    verify_bundle(destination)
    print(json.dumps(dict(status='REPORTED', original=dict(
        label_counts=original['label_counts'], invalid_code=original['invalid_code_assignments'],
        method_values=original['method_values'], comparisons=original['comparisons']),
        normalized=dict(label_counts=normalized['label_counts'],
                        invalid_code=normalized['invalid_code_assignments'],
                        method_values=normalized['method_values'],
                        comparisons=normalized['comparisons'])), ensure_ascii=False))


if __name__ == '__main__':
    report(Path(sys.argv[1]), Path(sys.argv[2]))
