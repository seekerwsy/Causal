import argparse
import hashlib
import itertools
import json
import platform
import subprocess
import time
from collections import Counter, defaultdict
from importlib.metadata import version
from importlib.resources import files
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import hypergeom

from prompt_mechanism_study.artifact_io import file_sha256, read_json, verify_bundle, write_bundle
from prompt_mechanism_study.development.context_algorithms import RSCRIPT, gfci, gfci_temporal
from prompt_mechanism_study.development.graph_guided_report import discovery_missing_interval


ROOT = Path('data/method/graph-guided-20260929/targeted-generation-preparation')
ANALYSIS = Path('results/graph-guided-20260929/targeted-generation-analysis')
RWORKER = Path('src/development/targeted_context_search.R')
LABELS = ('C', 'X', 'Y')
R_METHODS = tuple(f'FCI_JCI{mode}_{background}_{test}' for test in ('g2', 'exact')
                  for background in ('original', 'temporal') for mode in ('0', '1', '12'))


def exact_ci(rows, first, second, conditioned):
    values = np.asarray(rows, dtype=int)
    groups = [values] if conditioned is None else [values[values[:, conditioned] == k] for k in (0, 1)]
    strata, distributions = [], []
    parameters = []
    statistic = 0.
    for group in groups:
        if not len(group):
            continue
        cells = np.zeros((2, 2), dtype=int)
        for row in group:
            cells[row[first], row[second]] += 1
        n = int(cells.sum())
        nx, ny, a = int(cells[1].sum()), int(cells[:, 1].sum()), int(cells[1, 1])
        expected = np.outer(cells.sum(axis=1), cells.sum(axis=0)) / n
        support = range(max(0, nx + ny - n), min(nx, ny) + 1)
        distributions.append([(k, float(hypergeom.pmf(k, n, ny, nx))) for k in support])
        expectation = nx * ny / n
        denominator = nx * ny * (n - nx) * (n - ny) / n**3
        parameters.append((expectation, denominator))
        statistic += (a - expectation)**2 / denominator if denominator else 0.
        strata.append(dict(cells=cells.tolist(), minimum_expected=float(expected.min())))
    mass, tail = 0., 0.
    for combination in itertools.product(*distributions):
        probability = float(np.prod([row[1] for row in combination]))
        mass += probability
        permuted = sum((row[0] - expectation)**2 / denominator if denominator else 0.
                       for row, (expectation, denominator) in zip(combination, parameters, strict=True))
        if permuted >= statistic - 1e-12:
            tail += probability
    assert abs(mass - 1) < 1e-10
    return dict(x=LABELS[first], y=LABELS[second], S=[] if conditioned is None else [LABELS[conditioned]],
                p_value=float(np.clip(tail, 0, 1)), statistic=statistic, strata=strata,
                statistic_definition='sum_of_stratum_Pearson_statistics',
                minimum_expected=min(row['minimum_expected'] for row in strata))


def unique_candidates(candidates, bindings):
    policy_by_candidate = {row['candidate_id']: row['policy_id'] for row in bindings}
    grouped = defaultdict(list)
    for row in candidates:
        if row['quality_qualified']:
            grouped[policy_by_candidate[row['candidate_id']]].append(row)
    return [dict(min(group, key=lambda row: row['candidate_id']), policy_id=identity,
                 memberships=[row['candidate_id'] for row in group]) for identity, group in sorted(grouped.items())]


def make_inputs():
    verify_bundle(ROOT)
    verify_bundle(ANALYSIS)
    candidates = read_json(ROOT / 'candidates.json')
    bindings = read_json(ROOT / 'bindings.json')
    assignments = read_json(ROOT / 'assignments.json')
    outcomes = read_json(ANALYSIS / 'outcomes.json')
    effects = {row['candidate_id']: row for row in read_json(ANALYSIS / 'effects.json')}
    unique = unique_candidates(candidates, bindings)
    assert len(unique) == 18 and len({r['task_unit_id'] for r in unique}) == 10
    panels = {}
    for name, pool in [('policy_family', unique), ('tsg_support', unique_candidates(
            [row for row in candidates if row['flow'] == 'TSG'], bindings))]:
        grouped = defaultdict(list)
        for row in pool:
            grouped[row['task_unit_id']].append(row)
        panels[name] = [min(group, key=lambda row: row['candidate_id']) for _, group in sorted(grouped.items())]
    assert [len(panels[key]) for key in ('policy_family', 'tsg_support')] == [10, 7]
    rng = np.random.default_rng(2026092930)
    matrices = []
    for panel, chosen in panels.items():
        for draw in range(32):
            records = []
            for candidate in chosen:
                arm = 'P' if rng.integers(2) else 'N'
                requests = sorted([row for row in assignments if row['policy_id'] == candidate['policy_id']
                                   and row['arm'] == arm], key=lambda row: (row['seed'], row['version']))
                assert len(requests) == 4
                request = requests[int(rng.integers(4))]
                observed = outcomes[request['request_id']]
                assert observed['primary'][0] == observed['primary'][1]
                records.append(dict(index=candidate['index'], task_unit_id=candidate['task_unit_id'],
                    candidate_id=candidate['candidate_id'], policy_id=candidate['policy_id'],
                    request_id=request['request_id'], slot=request['slot'], arm=arm,
                    seed=request['seed'], version=request['version'], C=int(arm == 'P'),
                    X=int(candidate['operation'] == 'REMOVE') if panel == 'policy_family'
                    else int(len(candidate['source_unit_ids']) > 1),
                    primary=int(observed['primary'][0]), coverage=int(observed['security'] in ('secure', 'insecure')),
                    security=observed['security']))
            for endpoint in ('primary', 'coverage'):
                rows = [[row['C'], row['X'], row[endpoint]] for row in records]
                tests = [exact_ci(rows, a, b, s) for a, b in itertools.combinations(range(3), 2)
                         for s in (None, next(k for k in range(3) if k not in (a, b)))]
                exact_p = {'|'.join(sorted([t['x'], t['y']]) + t['S']): t['p_value'] for t in tests}
                matrices.append(dict(identity=f'{panel}:{endpoint}:{draw:02}', panel=panel, endpoint=endpoint,
                    draw=draw, n=len(rows), labels=list(LABELS), records=records, rows=rows,
                    exact_tests=tests, exact_p=exact_p))
    task_effects = []
    for task_id in sorted({row['task_unit_id'] for row in unique}):
        group = [effects[row['candidate_id']] for row in unique if row['task_unit_id'] == task_id]
        task_effects.append(dict(task_unit_id=task_id, index=group[0]['index'], policies=len(group),
            primary=float(np.mean([row['pn']['primary'][0] for row in group])),
            sensitivity=np.mean([row['pn']['sensitivity'] for row in group], axis=0).tolist(),
            coverage=float(np.mean([row['pn']['oracle_coverage'][0] for row in group]))))
    direct = dict(task_effects=task_effects,
        primary_mean=float(np.mean([row['primary'] for row in task_effects])),
        coverage_mean=float(np.mean([row['coverage'] for row in task_effects])),
        sensitivity_mean=np.mean([row['sensitivity'] for row in task_effects], axis=0).tolist(),
        primary_interval=discovery_missing_interval([r['primary'] for r in task_effects],
            [r['primary'] for r in task_effects], (-1, 1), .05),
        sensitivity_interval=discovery_missing_interval([r['sensitivity'][0] for r in task_effects],
            [r['sensitivity'][1] for r in task_effects], (-1, 1), .05),
        interpretation='exploratory fixed policy mixture, task equal; no selected direction or fresh population claim')
    direct['selected_panels'] = {}
    for panel, chosen in panels.items():
        selected = [dict(index=row['index'], candidate_id=row['candidate_id'],
                         primary=effects[row['candidate_id']]['pn']['primary'][0],
                         sensitivity=effects[row['candidate_id']]['pn']['sensitivity'],
                         coverage=effects[row['candidate_id']]['pn']['oracle_coverage'][0]) for row in chosen]
        direct['selected_panels'][panel] = dict(tasks=selected,
            primary_mean=float(np.mean([r['primary'] for r in selected])),
            coverage_mean=float(np.mean([r['coverage'] for r in selected])),
            sensitivity_mean=np.mean([r['sensitivity'] for r in selected], axis=0).tolist())
    return matrices, direct, {name: [dict(index=r['index'], candidate_id=r['candidate_id'],
        policy_id=r['policy_id'], operation=r['operation'], source_units=len(r['source_unit_ids'])) for r in chosen]
        for name, chosen in panels.items()}


def normalize_edges(edges):
    normalized = []
    for a, left, right, b in edges:
        normalized.append([a, left, right, b] if a < b else [b, right, left, a])
    return sorted(normalized)


def summarize(matrices, searches):
    grouped = defaultdict(list)
    by_identity = {row['identity']: row for row in matrices}
    for row in searches:
        matrix = by_identity[row['identity']]
        grouped[matrix['panel'], matrix['endpoint'], row['method']].append(row)
    summary = []
    for (panel, endpoint, method), group in sorted(grouped.items()):
        edges = [normalize_edges(row['edges']) for row in group]
        def marks(first, second):
            return Counter('absent' if not (found := [edge for edge in graph if edge[0] == first and edge[3] == second])
                           else found[0][1] + '-' + found[0][2] for graph in edges)
        queries = [query for row in group for query in row.get('ci_diagnostics', [])]
        summary.append(dict(panel=panel, endpoint=endpoint, method=method, draws=len(group),
            n=by_identity[group[0]['identity']]['n'], cy=dict(marks('C', 'Y')), xy=dict(marks('X', 'Y')),
            empty_graphs=sum(not graph for graph in edges),
            warning_draws=sum(bool(row.get('warnings')) for row in group),
            ci_queries=len(queries), sparse_queries=sum(q['sparse'] for q in queries),
            guarded_queries=sum(q.get('insufficient_n_guard', False) for q in queries)))
    comparisons = []
    for background in ('original', 'temporal'):
        for test in ('g2', 'exact'):
            for panel in ('policy_family', 'tsg_support'):
                for endpoint in ('primary', 'coverage'):
                    pool = {(r['identity'], r['method']): r for r in searches}
                    subset = [m for m in matrices if m['panel'] == panel and m['endpoint'] == endpoint]
                    differences = []
                    for matrix in subset:
                        zero = pool[matrix['identity'], f'FCI_JCI0_{background}_{test}']
                        twelve = pool[matrix['identity'], f'FCI_JCI12_{background}_{test}']
                        if normalize_edges(zero['edges']) != normalize_edges(twelve['edges']):
                            differences.append(dict(identity=matrix['identity'], zero=zero['edges'], jci12=twelve['edges']))
                    comparisons.append(dict(panel=panel, endpoint=endpoint, background=background,
                        test=test, changed_graphs=len(differences), changes=differences))
    return dict(methods=summary, jci_comparisons=comparisons)


def run(destination, limit=None):
    matrices, direct, panels = make_inputs()
    if limit is not None:
        matrices = matrices[:limit]
    destination.mkdir(parents=True, exist_ok=False)
    with files('pytetrad').joinpath('resources', 'tetrad-current.jar').open('rb') as stream:
        jar_sha256 = hashlib.file_digest(stream, 'sha256').hexdigest()
    write_bundle(destination / 'inputs', {'matrices.json': matrices, 'direct.json': direct,
        'plan.json': dict(status='POST_OUTCOME_DEVELOPMENT_EXPLORATION', panels=panels,
            planned_searches=14*len(matrices), rng_seed=2026092930,
            preparation_manifest_sha256=file_sha256(ROOT / 'manifest.json'),
            analysis_manifest_sha256=file_sha256(ANALYSIS / 'manifest.json'),
            python_sha256=file_sha256(Path(__file__)), r_sha256=file_sha256(RWORKER),
            backend_sha256=file_sha256(Path('src/development/context_algorithms.py')),
            protocol_sha256=file_sha256(Path('docs/experiments/2026-09-29-targeted-causal-analysis.md')),
            python=platform.python_version(), packages={key: version(key) for key in ('numpy','pandas','scipy','py-tetrad','JPype1')},
            tetrad_jar_sha256=jar_sha256,
            no_new_generation=True, no_new_evaluation=True, context_modifier_inference=False)})
    searches = []
    started = time.monotonic()
    with (destination / 'r-stderr.log').open('w', encoding='utf-8') as errors:
        process = subprocess.Popen([str(RSCRIPT), str(RWORKER)], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=errors, text=True, encoding='utf-8', bufsize=1)
        assert process.stdin is not None and process.stdout is not None
        with (destination / 'searches.jsonl').open('w', encoding='utf-8') as sink:
            for matrix in matrices:
                request = {key: matrix[key] for key in ('identity','n','labels','rows','exact_p')}
                process.stdin.write(json.dumps(request)+'\n')
                process.stdin.flush()
                for method in R_METHODS:
                    line = process.stdout.readline()
                    if not line:
                        raise RuntimeError(f'R搜索终止：{matrix["identity"]}；检查r-stderr.log')
                    result = json.loads(line)
                    assert result['identity'] == matrix['identity'] and result['method'] == method
                    searches.append(result)
                    sink.write(json.dumps(result)+'\n')
                frame = pd.DataFrame(matrix['rows'], columns=LABELS, dtype=int)
                for method, function in [('GFCI_original', gfci), ('GFCI_JCI12_temporal', gfci_temporal)]:
                    begin = time.monotonic()
                    result = dict(identity=matrix['identity'], method=method, edges=function(frame),
                        seconds=time.monotonic()-begin,
                        all_possible_ci_audit=matrix['exact_tests'], internal_ci_trace_available=False)
                    searches.append(result)
                    sink.write(json.dumps(result)+'\n')
                sink.flush()
                if len(searches) % 224 == 0 or limit:
                    print(json.dumps(dict(searches=len(searches), planned=14*len(matrices))), flush=True)
        process.stdin.close()
        assert process.wait(timeout=30) == 0
    assert len(searches) == 14*len(matrices)
    write_bundle(destination / 'summary', {'tables.json': summarize(matrices, searches),
        'completion.json': dict(status='EXECUTED_EXPLORATORY_CAUSAL_COMPARISON', searches=len(searches),
            matrices=len(matrices), seconds=time.monotonic()-started,
            input_manifest_sha256=file_sha256(destination / 'inputs/manifest.json'),
            searches_sha256=file_sha256(destination / 'searches.jsonl'),
            stderr_sha256=file_sha256(destination / 'r-stderr.log'),
            scientific_status='UNRESOLVED_STRUCTURAL_ALGORITHM_CHOICE')})


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('destination', type=Path)
    parser.add_argument('--limit', type=int)
    arguments = parser.parse_args()
    run(arguments.destination, arguments.limit)
