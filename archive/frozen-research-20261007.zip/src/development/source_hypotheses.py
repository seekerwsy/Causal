from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

from prompt_mechanism_study.artifact_io import file_sha256, read_json, verify_bundle, write_bundle


SEED = "source-hypotheses-20260927-v1"
SOURCE_ROOT = Path("data/dataset-curation/research-candidate-pool-v4")
RUN_ROOT = Path("data/method/source-hypotheses-20260927")


def ordering(label: str, identity: str) -> str:
    return hashlib.sha256(f"{SEED}|{label}|{identity}".encode()).hexdigest()


def inventory(repo: Path) -> tuple[list[dict], dict]:
    verify_bundle(repo / SOURCE_ROOT)
    records = read_json(repo / SOURCE_ROOT / "tasks.json")
    screening = read_json(repo / SOURCE_ROOT / "screening.json")
    protected = {row["task_unit_id"] for row in screening
                 if row["decision"] == "PRESERVE_PROTECTED_INPUT"}
    python = [row for row in records if row["language"] == "python"]
    if protected.intersection(row["task_unit_id"] for row in python):
        raise ValueError("protected task appears in research pool")
    if len(python) != len({row["task_unit_id"] for row in python}):
        raise ValueError("duplicate task unit in research pool")
    if len(python) != len({row["near_duplicate_group_id"] for row in python}):
        raise ValueError("dependent task units in research pool")

    # 只检索历史研究文件中的任务身份，避免将历史暴露误记为新留出。
    search = subprocess.run(
        ["rg", "--only-matching", "--no-filename", "semantic_cluster_[a-f0-9]{64}",
         "data/method", "-g", "*.json", "-g", "*.jsonl",
         "-g", "!**/source-hypotheses-20260927/**"],
        cwd=repo, capture_output=True, text=True, check=True,
    )
    mentioned = set(search.stdout.splitlines())
    eligible = [row for row in python if row["task_unit_id"] not in mentioned]
    summary = dict(
        pool_sha256=file_sha256(repo / SOURCE_ROOT / "tasks.json"),
        pool_manifest_sha256=file_sha256(repo / SOURCE_ROOT / "manifest.json"),
        python_task_units=len(python),
        historically_mentioned=len(python) - len(eligible),
        eligible_without_recorded_method_mention=len(eligible),
        available_by_lineage=dict(sorted(Counter(row["source_lineage_id"] for row in eligible).items())),
        exposure_rule="Exclude each Python task identity mentioned in prior data/method JSON or JSONL; conservative source-only identity search.",
        exposure_identity_set_sha256=hashlib.sha256("\n".join(sorted(mentioned)).encode()).hexdigest(),
        protected_overlap=0,
    )
    return eligible, summary


def register(repo: Path) -> None:
    destination = repo / RUN_ROOT / "registration"
    if destination.exists():
        raise FileExistsError(destination)
    eligible, summary = inventory(repo)
    by_lineage = defaultdict(list)
    for row in eligible:
        by_lineage[row["source_lineage_id"]].append(row)
    lineages = sorted(by_lineage, key=lambda value: ordering("lineage_role", value))
    if len(lineages) < 2:
        raise ValueError("independent source-lineage split unavailable")
    training_lineages = set(lineages[:len(lineages) // 2])
    for lineage, rows in by_lineage.items():
        rows.sort(key=lambda row: ordering("source_order", row["task_unit_id"]))

    # 各来源轮流获取下一身份，数量不足的来源保留其实际数量。
    selected = []
    offset = 0
    while len(selected) < min(384, len(eligible)):
        for lineage in lineages:
            if offset < len(by_lineage[lineage]) and len(selected) < 384:
                row = by_lineage[lineage][offset]
                route_offset = int(ordering("route_offset", lineage), 16) % 2
                selected.append(dict(
                    index=len(selected), task_unit_id=row["task_unit_id"],
                    near_duplicate_group_id=row["near_duplicate_group_id"],
                    source_lineage_id=lineage, source_prompt_sha256=row["prompt_sha256"],
                    source_task_record_sha256=row["source_task_record_sha256"],
                    role="development" if lineage in training_lineages else "heldout",
                    representation="TSG" if (offset + route_offset) % 2 else "Raw",
                    prior_method_mention=False,
                ))
        offset += 1
    plan = repo / "docs/next-experiment-plan.md"
    launch = dict(
        status="ACTIVE_BOUNDED_RESEARCH", t0_utc="2026-09-27T11:00:15Z",
        last_new_model_request_utc="2026-09-28T07:00:15Z",
        last_new_experiment_utc="2026-09-28T09:00:15Z",
        deadline_utc="2026-09-28T11:00:15Z", formal_protocol="SPECIFIED_DRAFT",
        generation_call_limit=2048, planned_generation_calls=1936,
        a800_service_hours_limit=18, protected_evaluation_allowed=False,
        paid_provider_allowed=False, plan_sha256=file_sha256(plan),
        model_role="code_generation_only", preparation_role="Codex",
        registration_implementation_sha256=file_sha256(Path(__file__)),
    )
    selection = dict(
        status="FROZEN_BEFORE_NEW_SOURCE_TEXT_INSPECTION", seed=SEED,
        registered_utc=datetime.now(timezone.utc).isoformat(),
        inspection_limit=384, selected_task_units=len(selected),
        source_rule="Round-robin independently hashed source identities across lineages; no replacement after source inspection.",
        role_rule="First floor(number_of_lineages/2) independently hashed source lineages are development; remaining lineages are heldout.",
        representation_rule="Alternating Raw/TSG within each hashed source order, with a lineage-specific hashed offset.",
        target_generation_task_units=96, target_task_units_per_role=48,
        selection_inputs=["language", "task_unit_id", "source_lineage_id", "recorded_method_exposure"],
        coverage_target=dict(policy_families=3, operation_families=4),
        role_counts=dict(Counter(row["role"] for row in selected)),
        representation_counts=dict(Counter(row["representation"] for row in selected)),
        inventory=summary, selected=selected,
    )
    write_bundle(destination, {"launch.json": launch, "selection.json": selection,
                               "plan.json": dict(text=plan.read_text(encoding="utf-8"))})
    verify_bundle(destination)
    print(json.dumps({**summary, "selected": len(selected), "role_counts": selection["role_counts"],
                      "representation_counts": selection["representation_counts"], "output": str(destination)}))


def inspect_sources(repo: Path, start: int, count: int) -> None:
    root = repo / RUN_ROOT / "registration"
    verify_bundle(root)
    selection = read_json(root / "selection.json")
    if file_sha256(repo / SOURCE_ROOT / "tasks.json") != selection["inventory"]["pool_sha256"]:
        raise ValueError("registered source pool changed")
    pool = {row["task_unit_id"]: row for row in read_json(repo / SOURCE_ROOT / "tasks.json")}
    if start < 0 or count < 1 or start + count > len(selection["selected"]):
        raise ValueError("source inspection range is outside registration")
    for record in selection["selected"][start:start + count]:
        task = pool[record["task_unit_id"]]
        visible = {key: record[key] for key in
                   ("index", "task_unit_id", "source_lineage_id", "source_prompt_sha256")}
        print(json.dumps({**visible, "prompt": task["prompt"]}, ensure_ascii=False))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("inventory", "register", "inspect"))
    parser.add_argument("repo", type=Path)
    parser.add_argument("--start", type=int, default=0)
    parser.add_argument("--count", type=int, default=8)
    args = parser.parse_args()
    repo = args.repo.resolve()
    if args.mode == "inventory":
        print(json.dumps(inventory(repo)[1]))
    elif args.mode == "register":
        register(repo)
    else:
        inspect_sources(repo, args.start, args.count)


if __name__ == "__main__":
    main()
