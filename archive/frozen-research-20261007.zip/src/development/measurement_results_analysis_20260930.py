import hashlib
import json
from collections import Counter
from pathlib import Path

from prompt_mechanism_study.artifact_io import read_json, verify_bundle, write_bundle


INPUT = Path('data/method/graph-guided-20260930/measurement')
RESULT = Path('results/graph-guided-20260930/measurement')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def channel_label(measurement, channel):
    row = measurement['channels'][channel]
    if row['status'] != 'passed':
        return 'unknown'
    return row['observation']['security_label' if channel == 'security' else 'functionality']


def counter_rows(rows, fields):
    counts = Counter(tuple(row[field] for field in fields) for row in rows)
    return [dict(zip(fields, key, strict=True), count=count) for key, count in sorted(counts.items())]


def analyze():
    # 只读取已保存的数据；此模块不导入候选程序或观察器，不执行任何安全测试。
    for directory in (INPUT / 'freeze', RESULT / 'qualified', RESULT / 'verified'):
        verify_bundle(directory)
    identity = read_json(INPUT / 'freeze/identity.json')
    provenance = {row['key']: row for row in read_json(INPUT / 'freeze/provenance.json')}
    rows = read_json(RESULT / 'verified/rows.json')
    summary = read_json(RESULT / 'verified/summary.json')
    assert len(rows) == len(provenance) == 148
    assert len({row['request_id'] for row in rows}) == 148
    assert sum(row['scheduled'] for row in rows) == 146
    assert {row['key'] for row in rows} == set(provenance)
    batches = {'dev-main': 'dev-main-inputs', 'eval-main': 'eval-main-inputs', 'targeted-gen': 'targeted-gen-inputs'}
    for name, folder in batches.items():
        assert verify_bundle(Path('data/method/graph-guided-20260929') / folder) == identity['batch_input_manifests'][name]
    for relative, expected in identity['source_hashes'].items():
        assert digest(Path(relative)) == expected
    for folder, manifest_field, expected_count in (
        ('qualification-inputs', 'qualification_manifest', 31),
        ('remeasurement-inputs', 'remeasurement_manifest', 146),
        ('original-environment-inputs', 'original_environment_manifest', 38),
    ):
        manifest = verify_bundle(INPUT / folder)
        assert manifest == identity[manifest_field]
        assert len(manifest['files']) == expected_count
    qualification = read_json(RESULT / 'qualified/qualification.json')
    assert len(qualification['controls']) == 31
    assert qualification['freeze_manifest'] == read_json(INPUT / 'freeze/manifest.json')
    assert qualification['image'] == read_json(RESULT / 'environment.json')
    controls = []
    for row in qualification['controls']:
        path = RESULT / 'qualification' / row['name']
        assert digest(path) == row['result_sha256']
        raw = read_json(path)
        assert channel_label(raw, 'security') == row['security']
        assert channel_label(raw, 'functionality') == row['functionality']
        controls.append({key: row[key] for key in ('name', 'family', 'security', 'functionality')})
    analysis_rows = []
    for row in rows:
        original = provenance[row['key']]
        assert all(row[key] == value for key, value in original.items())
        old_directory = Path(row['result_path'])
        assert verify_bundle(old_directory / 'result') == row['original_result_manifest']
        old_result = read_json(old_directory / 'result/result.json')
        assert old_result['request_id'] == row['request_id'] and old_result['slot'] == row['slot']
        record = dict(key=row['key'], index=row['index'], batch=row['batch'], arm=row['arm'],
            task_unit_id=row['task_unit_id'], request_id=row['request_id'], candidate_memberships=row['candidate_memberships'],
            scheduled=row['scheduled'], original_status=row['original_status'],
            new_security=row['security_label'], new_functionality=row['functionality'],
            new_secure_yield=row['secure_yield'], new_direct_violation=row['direct_violation'],
            new_security_coverage=row['security_coverage'], new_joint=row['secure_and_functional'])
        if row['scheduled']:
            assert digest(old_directory / 'code.py') == row['code_sha256']
            assert digest(RESULT / 'remeasurement' / row['key']) == row['measurement_sha256']
            matching = [m['measurement'] for m in row['original_measurements'] if m['family'] == row['family']]
            assert len(matching) == 1
            old = matching[0]
            old_channel = old['channels']['security']
            observation = row['security_observation']
            record.update(old_security=channel_label(old, 'security'),
                old_functionality=channel_label(old, 'functionality'),
                old_channel_status=old_channel['status'], old_error_type=old_channel.get('error_type'),
                old_error=old_channel.get('error'), old_security_observation=old_channel.get('observation'),
                new_observation=observation, new_unknown_reason=observation.get('unknown_reason'),
                new_error_type=observation.get('error_type'), new_error=observation.get('error'))
            if row['index'] == 74:
                assert digest(RESULT / 'original-environment' / row['key']) == row['original_environment_sha256']
                base = row['original_environment_observation']
                record.update(same_observer_old_environment=base,
                    same_observer_old_environment_security=base['security_label'],
                    same_observer_old_environment_functionality=base.get('functionality', 'unknown'))
        else:
            assert row['secure_yield'] == row['security_coverage'] == row['direct_violation'] == row['secure_and_functional'] == 0
            record.update(old_security='unknown', old_functionality='unknown',
                old_channel_status='not_returned', old_error_type=None, old_error=None,
                old_security_observation=None, new_observation={}, new_unknown_reason=row['unknown_reason'],
                new_error_type=None, new_error=None)
        analysis_rows.append(record)
    assert sum('same_observer_old_environment' in row for row in analysis_rows) == 38
    cases = []
    for index in (74, 198, 182, 128):
        subset = [row for row in analysis_rows if row['index'] == index]
        cases.append(dict(index=index, assignments=len(subset), returned=sum(row['scheduled'] for row in subset),
            old_security=dict(Counter(row['old_security'] for row in subset)),
            new_security=dict(Counter(row['new_security'] for row in subset)),
            old_functionality=dict(Counter(row['old_functionality'] for row in subset)),
            new_functionality=dict(Counter(row['new_functionality'] for row in subset)),
            secure_yield=sum(row['new_secure_yield'] for row in subset),
            coverage=sum(row['new_security_coverage'] for row in subset),
            direct_violation=sum(row['new_direct_violation'] for row in subset),
            secure_and_common_functional=sum(row['new_joint'] for row in subset),
            security_transitions=counter_rows(subset, ['old_security', 'new_security']),
            function_transitions=counter_rows(subset, ['old_functionality', 'new_functionality'])))
    forum = [row for row in analysis_rows if row['index'] == 74 and row['scheduled']]
    dependencies = []
    for row in forum:
        base = row['same_observer_old_environment']
        if base['security_label'] != row['new_security'] or base.get('functionality') != row['new_functionality']:
            dependencies.append(dict(key=row['key'], arm=row['arm'], candidate_memberships=row['candidate_memberships'],
                old_environment=base, new_environment=row['new_observation']))
    numeric = [row for row in analysis_rows if row['index'] == 182]
    upload = [row for row in analysis_rows if row['index'] == 198]
    yaml_rows = [row for row in analysis_rows if row['index'] == 128]
    diagnostics = dict(
        forum_environment_label_transitions=counter_rows(forum, ['same_observer_old_environment_security', 'new_security']),
        forum_environment_changes=dependencies,
        forum_environment_identical_observation_count=sum(row['same_observer_old_environment'] == row['new_observation'] for row in forum),
        upload_exception_contract=Counter(row['new_observation'].get('exception_contract', 'unknown') for row in upload),
        upload_attack_terminations=Counter(str((probe['termination'], probe['exception_type']))
            for row in upload for probe in row['new_observation']['probes'] if not probe['ordinary']),
        upload_cumulative_exceeds_extent=sum(any(probe['cumulative_read_bytes'] > probe['consumed_extent']
            for probe in row['new_observation']['probes']) for row in upload),
        upload_violations=Counter(name for row in upload for probe in row['new_observation']['probes']
            for name in ('cumulative_read_violation','consumed_extent_violation','retained_file_violation') if probe[name]),
        expression_ordinary_arithmetic=Counter(str(row['new_observation'].get('arithmetic', {}).get('semantic_match')) for row in numeric),
        expression_string_witnesses=Counter(str(tuple(item['semantic_match'] for item in row['new_observation'].get('strings', []))) for row in numeric),
        expression_target_return_string=Counter(str(row['new_observation'].get('target_return_string')) for row in numeric),
        expression_target_failure_string=Counter(str(row['new_observation'].get('target_failure_string')) for row in numeric),
        expression_unknown_examples=[dict(key=row['key'], observation=row['new_observation']) for row in numeric if row['new_security']=='unknown'],
        yaml_quantity_target_by_arm=[dict(arm=arm, count=len(group), quantity_pass=sum(row['new_observation']['target_quantity_multiplication'] for row in group))
            for arm in ('P','N','R') if (group := [row for row in yaml_rows if row['arm']==arm])],
        failures=[dict(key=row['key'], status=row['original_status'], reason=row['new_unknown_reason']) for row in analysis_rows if not row['scheduled']],
    )
    output = dict(status='READ_ONLY_FROZEN_RESULT_ATTRIBUTION', assignments=148, returned_code=146,
        qualification_controls=31, old_environment_retests=38, original_result_manifests_verified=148,
        original_code_hashes_verified=146, cases=cases, diagnostics=diagnostics,
        control_counts_by_family=dict(Counter(row['family'] for row in controls)), model_calls=0,
        candidate_programs_executed=0, safety_tests_executed=0,
        frozen_inputs={str(path): digest(path) for path in [INPUT/'freeze/manifest.json',
            RESULT/'qualified/manifest.json', RESULT/'verified/manifest.json', Path(__file__)]})
    write_bundle(RESULT / 'analysis', {'summary.json': output, 'rows.json': analysis_rows, 'controls.json': controls})
    verify_bundle(RESULT / 'analysis')
    print(json.dumps({key: output[key] for key in ('status','assignments','returned_code','qualification_controls',
        'old_environment_retests','original_result_manifests_verified','cases','control_counts_by_family')}, ensure_ascii=False))


if __name__ == '__main__':
    analyze()
