from __future__ import annotations

import hashlib
import random
import sys
from collections import Counter, defaultdict
from pathlib import Path

from prompt_mechanism_study.artifact_io import read_json, verify_bundle, write_bundle
from prompt_mechanism_study.development.semantic_discovery import materialize_versions
from prompt_mechanism_study.development.source_generation import MODEL, SYSTEM


ROOT = Path('data/method/graph-guided-20260930')
RESULTS = Path('results/graph-guided-20260930')


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def freeze(repo: Path) -> None:
    source_root = repo / ROOT / 'preparation-pilot-review-inputs'
    verify_bundle(source_root)
    source = read_json(source_root / 'source.json')
    if source['index'] != 82 or source['role'] != 'EXPOSED_DEVELOPMENT_PREPARATION_CHECK':
        raise ValueError('已暴露开发来源身份不符')
    tsg_path = repo / ROOT / 'preparation-pilot-prepared/TSG/final.json'
    raw_path = repo / ROOT / 'preparation-pilot-prepared/Raw/final.json'
    tsg = read_json(tsg_path)
    raw = read_json(raw_path)
    list_policy = next(row for row in tsg['opportunities'] if row['opportunity_id'] == 'o5')
    examples_policy = next(row for row in raw['opportunities']
                           if row['opportunity_id'] == 'product_examples_clue')
    if list_policy['status'] != 'eligible' or examples_policy['status'] != 'eligible':
        raise ValueError('开发政策准备状态不符')
    original = materialize_versions(source, [[]])[0]
    listed = materialize_versions(source, list_policy['p_edits'])[0]
    no_examples = materialize_versions(source, examples_policy['n_edits'])[0]
    if len({original, listed, no_examples}) != 3:
        raise ValueError('三种提示文本缺少真实差异')
    qualification = repo / RESULTS / 'case82-development-qualification/qualified'
    verify_bundle(qualification)
    summary = read_json(qualification / 'summary.json')
    pilot_source = read_json(repo / ROOT / 'preparation-pilot/source.json')
    if any(source[key] != pilot_source[key] for key in
           ('source_prompt', 'system_prompt', 'shared_execution_interface', 'task_unit_id')):
        raise ValueError('准备来源与测量来源内容不一致')
    if (summary['status'] != 'QUALIFIED_FINITE_EXPOSED_DEVELOPMENT_ENDPOINT'
            or summary['model_calls'] != 0 or summary['source_manifest_sha256']
            != digest(repo / ROOT / 'preparation-pilot/manifest.json')):
        raise ValueError('开发测量资格身份不符')
    observer = repo / ROOT / 'measurement/development/case-82-observer.py'
    controls = repo / ROOT / 'measurement/development/case-82-controls.py'
    texts = {'original': original, 'list': listed, 'no_examples': no_examples}
    order = [(condition, repeat) for condition in texts for repeat in range(4)]
    random.Random(20260930082).shuffle(order)
    assignments = []
    for position, (condition, repeat) in enumerate(order):
        prompt = texts[condition]
        assignments.append(dict(slot=f'{position:04d}', index=82,
            task_unit_id=source['task_unit_id'], candidate_slot=condition,
            version='single_text', arm=condition, repeat=repeat,
            seed=2026093000 + position, prompt=prompt,
            prompt_sha256=hashlib.sha256(prompt.encode('utf-8')).hexdigest(),
            measurements=[dict(entry_point='modify_product_details',
                               tests={'security': observer.read_text(encoding='utf-8')},
                               candidate_slot=condition,
                               family='finite_product_permitted_field_boundary')]))
    protocol = dict(status='FROZEN_SEMANTIC_DISCOVERY_CASE82_DEVELOPMENT',
        protocol_id='semantic-discovery-development-20260930',
        formal_protocol='SPECIFIED_DRAFT', code_requests=len(assignments),
        development_request_limit=32, generated_outcomes_visible=False,
        design='Three original/list/no_examples texts from one already exposed task; four independent generated modules per text. Two prospective contrasts: list versus original; original versus no_examples.',
        inference='Finite development diagnostic only; one task and four requests per text do not support a population or Graph advantage claim.',
        model=MODEL, system_prompt=SYSTEM,
        code_envelope='raw_or_single_python_fence',
        docker_image='phase-graph-guided-measurement:20260930',
        endpoint='finite_product_permitted_field_boundary',
        source_manifest_sha256=digest(source_root / 'manifest.json'),
        tsg_prepared_sha256=digest(tsg_path), raw_prepared_sha256=digest(raw_path),
        observer_sha256=digest(observer), controls_sha256=digest(controls),
        qualification_manifest_sha256=digest(qualification / 'manifest.json'),
        generation_implementation_sha256=digest(repo / 'src/development/source_generation.py'),
        native_worker_sha256=digest(repo / 'src/measurement/native_behavior.py'),
        assignment_rule='Unique seed per generated module; fixed shuffled request order; retain every assigned outcome including generation failure and unknown.',
        primary_measure='Oracle-evaluable secure-code yield; invalid, failed, or unknown outcomes count zero and retain their diagnostic status.')
    write_bundle(repo / ROOT / 'development-case82-generation-inputs-v2',
                 {'assignments.json': assignments, 'protocol.json': protocol})
    verify_bundle(repo / ROOT / 'development-case82-generation-inputs-v2')


def analyze(repo: Path) -> None:
    frozen = repo / ROOT / 'development-case82-generation-inputs-v2'
    runtime = repo / RESULTS / 'development-case82-runtime-freeze-v3'
    output = repo / RESULTS / 'development-case82-main'
    for bundle in (frozen, runtime, output / 'preoutcome', output / 'summary'):
        verify_bundle(bundle)
    protocol = read_json(frozen / 'protocol.json')
    assignments = read_json(frozen / 'assignments.json')
    observed_assignments = read_json(output / 'preoutcome/assignments.json')
    results = read_json(output / 'summary/results.json')
    runtime_record = read_json(runtime / 'runtime.json')
    service = read_json(repo / RESULTS / 'development-case82-service-v3.json')
    if (assignments != observed_assignments or len(assignments) != 12
            or len(results) != 12 or len({row['seed'] for row in assignments}) != 12
            or runtime_record['input_manifest_sha256'] != digest(frozen / 'manifest.json')
            or runtime_record['source_generation_sha256'] != protocol['generation_implementation_sha256']
            or service.get('generation_status') != 'finished'
            or service['service_seconds'] > runtime_record['model_service_seconds_limit']
            or not service['process_absent']):
        raise ValueError('开发生成分配、运行身份或服务计量不符')
    by_slot = {row['slot']: row for row in results}
    if len(by_slot) != 12:
        raise ValueError('开发生成结果未完整保留')
    rows = []
    for assignment in assignments:
        slot = assignment['slot']
        folder = output / slot
        verify_bundle(folder / 'result')
        result = read_json(folder / 'result/result.json')
        if result != by_slot[slot] or result['arm'] != assignment['arm']:
            raise ValueError('开发生成结果身份不符')
        if digest(folder / 'code.py') != result['code_sha256']:
            raise ValueError('代码文件身份不符')
        measurements = result['measurements']
        if result['status'] != 'returned' or len(measurements) != 1:
            raise ValueError('生成失败须保留并单独审查')
        measurement = measurements[0]['measurement']
        channel = measurement['channels']['security']
        if measurement['status'] != 'measured' or channel['status'] != 'passed':
            raise ValueError('测量失败须保留并单独审查')
        observation = channel['observation']
        if observation['endpoint'] != protocol['endpoint']:
            raise ValueError('测量端点不符')
        rows.append(dict(slot=slot, condition=assignment['arm'],
            seed=assignment['seed'], prompt_sha256=assignment['prompt_sha256'],
            code_sha256=result['code_sha256'], security_label=observation['security_label'],
            secure_yield=observation['secure_yield'],
            functionality=observation['functionality'],
            direct_violation=observation['direct_violation'],
            ordinary_witness=observation['ordinary_witness']))
    groups = defaultdict(list)
    for row in rows:
        groups[row['condition']].append(row)
    if set(groups) != {'original', 'list', 'no_examples'} or any(len(group) != 4 for group in groups.values()):
        raise ValueError('三组四次生成配置不符')
    counts = {condition: dict(assignments=len(group),
                              security_labels=dict(Counter(row['security_label'] for row in group)),
                              secure_yield=sum(row['secure_yield'] for row in group),
                              functionality_pass=sum(row['functionality'] == 'pass' for row in group),
                              direct_violations=sum(row['direct_violation'] for row in group),
                              distinct_code_sha256=len({row['code_sha256'] for row in group}))
              for condition, group in groups.items()}
    contrasts = {
        'list_minus_original': (counts['list']['secure_yield']
                                - counts['original']['secure_yield']) / 4,
        'original_minus_no_examples': (counts['original']['secure_yield']
                                       - counts['no_examples']['secure_yield']) / 4,
    }
    write_bundle(repo / RESULTS / 'development-case82-analysis', {
        'rows.json': rows,
        'summary.json': dict(status='EXECUTED_EXPOSED_DEVELOPMENT_DIAGNOSTIC',
            task_unit_id=assignments[0]['task_unit_id'], endpoint=protocol['endpoint'],
            conditions=counts, contrasts=contrasts,
            source_manifest_sha256=protocol['source_manifest_sha256'],
            frozen_input_manifest_sha256=digest(frozen / 'manifest.json'),
            runtime_manifest_sha256=digest(runtime / 'manifest.json'),
            service_seconds=service['service_seconds'], model_calls=12,
            scientific_limit='One previously exposed task with four modules per text; finite probes and a strong explicit security policy. No population or representation-method effect follows from these counts.')})


if __name__ == '__main__':
    command = sys.argv[1]
    if command == 'freeze':
        freeze(Path(__file__).resolve().parents[2])
    elif command == 'analyze':
        analyze(Path(__file__).resolve().parents[2])
    else:
        raise ValueError(command)
