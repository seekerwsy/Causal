.libPaths(c('.codex-runtime/r-lib', .libPaths()))
suppressPackageStartupMessages(library(pcalg))
suppressPackageStartupMessages(library(jsonlite))
input <- file('stdin', open='r')
marks <- c('NONE', 'CIRCLE', 'ARROW', 'TAIL')

emit <- function(value) {
  cat(toJSON(value, auto_unbox=TRUE, null='null', digits=16), '\n', sep='')
  flush(stdout())
}

repeat {
  line <- readLines(input, n=1L, warn=FALSE)
  if (!length(line)) break
  request <- fromJSON(line)
  prompt_states <- !is.null(request$labels)
  if (prompt_states) {
    labels <- request$labels
    stopifnot(length(labels) >= 2L, labels[1] == 'C', tail(labels, 1) == 'Y',
              !anyDuplicated(labels), request$jci %in% c('0', '1', '12'))
    contexts <- if (is.null(request$context_labels)) 1L else match(request$context_labels, labels)
    stopifnot(length(contexts) >= 1L, !anyNA(contexts), !anyDuplicated(contexts),
              identical(as.integer(contexts), seq_along(contexts)),
              !length(labels) %in% contexts)
  } else {
    d <- request$d
    stopifnot(d %in% c(3L, 6L))
    labels <- c('C', paste0('M', seq_len(d)), 'Y')
  }
  p <- length(labels)
  gaps <- matrix(FALSE, p, p)
  if (!prompt_states) gaps[1, 2:(p-1)] <- gaps[2:(p-1), 1] <- TRUE
  if (prompt_states && length(contexts) > 1L) {
    gaps[contexts, contexts] <- TRUE
    diag(gaps) <- FALSE
  }
  warnings <- character()
  checked_ci <- function(x, y, S, suffStat) {
    emit(list(type='query', x=labels[x], y=labels[y], conditioned=as.list(labels[S]),
              r_process_cpu_seconds=sum(proc.time()[1:2])))
    answer <- fromJSON(readLines(input, n=1L, warn=FALSE))
    if (answer$status == 'cpu_budget_exhausted') {
      stop(structure(list(message=answer$reason, call=NULL), class=c('cpu_budget_exhausted', 'condition')))
    }
    if (answer$status == 'statistically_undetermined') {
      stop(structure(list(message=answer$key, call=NULL), class=c('statistical_undetermined', 'condition')))
    }
    stopifnot(answer$status == 'determined', length(answer$p_value) == 1L,
              is.finite(answer$p_value), answer$p_value >= 0, answer$p_value <= 1)
    answer$p_value
  }
  compute <- function() {
    graph <- fci(suffStat=list(), indepTest=checked_ci, alpha=.05, labels=labels,
                 skel.method='stable', fixedGaps=gaps, NAdelete=FALSE,
                 m.max=Inf, pdsep.max=Inf, rules=rep(!prompt_states, 10), doPdsep=TRUE,
                 selectionBias=FALSE, jci=if (prompt_states) '0' else '1',
                 contextVars=if (prompt_states) NULL else seq_len(p-1), verbose=FALSE)
    pag <- graph@amat
    rules <- rep(TRUE, 10)
    rules[5:7] <- FALSE
    if (prompt_states) {
      # 从完整 FCI 骨架开始，同时输入时间背景和 context 背景，再执行 R0-R10。
      pag <- 1L * (pag != 0)
      pag[pag[,p] != 0, p] <- 2L
      for (context in contexts) {
        if (request$jci != '0') pag[context, pag[context,] != 0] <- 2L
        if (request$jci == '12') pag[pag[,context] != 0, context] <- 3L
      }
      pag <- udag2pag(pag, graph@sepset, rules=rules, jci=request$jci,
                     contextVars=if (request$jci == '0') NULL else contexts, orientCollider=TRUE)
    } else {
      for (iteration in seq_len(100)) {
        previous <- pag
        pag <- udag2pag(pag, graph@sepset, rules=rules, jci='1', contextVars=seq_len(p-1), orientCollider=FALSE)
        pag <- udag2pag(pag, graph@sepset, rules=rules, jci='12', contextVars=1L, orientCollider=FALSE)
        if (identical(previous, pag)) break
        stopifnot(iteration < 100)
      }
    }
    edges <- list()
    for (i in seq_len(p-1)) for (j in seq.int(i+1L, p)) {
      if (pag[i,j] != 0L || pag[j,i] != 0L)
        edges[[length(edges)+1L]] <- c(labels[i], marks[pag[j,i]+1L], marks[pag[i,j]+1L], labels[j])
    }
    list(status='determined', edges=edges)
  }
  result <- withCallingHandlers(tryCatch(compute(), statistical_undetermined=function(condition) {
    list(status='statistically_undetermined', edges=NULL, undetermined_query=condition$message)
  }, cpu_budget_exhausted=function(condition) {
    list(status='cpu_budget_exhausted', edges=NULL, stop_reason=condition$message)
  }), warning=function(warning) {
    warnings <<- c(warnings, conditionMessage(warning))
    invokeRestart('muffleWarning')
  })
  result$type <- 'result'
  result$identity <- request$identity
  result$warnings <- as.list(unique(warnings))
  result$pcalg <- as.character(packageVersion('pcalg'))
  result$r_process_cpu_seconds <- sum(proc.time()[1:2])
  emit(result)
}
close(input)
