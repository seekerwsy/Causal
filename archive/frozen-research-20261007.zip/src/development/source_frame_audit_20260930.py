from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import time
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urlsplit

from prompt_mechanism_study.artifact_io import (
    file_sha256, read_canonical_jsonl, read_json, require_sha256, verify_bundle, write_bundle,
)
from prompt_mechanism_study.records import canonical_json, content_hash


ROOT = Path('data/method/graph-guided-20260930/source-audit')
POOL = Path('data/dataset-curation/research-candidate-pool-v4/tasks.json')
DATASET = Path('data/dataset-curation/reviewer-task-unit-dataset-v5')
RESERVATIONS = Path('data/dataset-curation/future-evaluation-reservation-v1/reservations.json')
INVENTORY = Path('data/method/graph-guided-20260929/inventory/inventory.json')
SEED = '20260930-source-frame-outcome-blind'


def read_jsonl(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line]


def order_hash(purpose, identity):
    return hashlib.sha256(f'{SEED}:{purpose}:{identity}'.encode()).hexdigest()


def freeze():
    # 此步骤只导出身份与保护元数据，来源提示和结果字段不进入输出。
    tasks = [row for row in read_json(POOL) if row['language'] == 'python']
    roles = {row['task_unit_id']: row for row in read_jsonl(DATASET / 'task-roles.jsonl')}
    reservations = {row['task_unit_id']: row for row in read_json(RESERVATIONS)}
    reserved_groups = {row['near_duplicate_group_id'] for row in reservations.values()}
    units = {row['task_unit_id']: row for row in read_jsonl(DATASET / 'task-units.jsonl')}
    inventories = {row['task_unit_id']: row for row in read_json(INVENTORY)}
    identities = []
    for task in tasks:
        identity = task['task_unit_id']
        role = roles[identity]
        unit = units[identity]
        previous = inventories.get(identity)
        identities.append({
            'task_unit_id': identity,
            'near_duplicate_group_id': task['near_duplicate_group_id'],
            'source_lineage_id': task['source_lineage_id'],
            'source_prompt_sha256': task['prompt_sha256'],
            'source_task_record_sha256': task['source_task_record_sha256'],
            'source_record_ids': [member['record_id'] for member in unit['source_members']],
            'source_locators': [member['source_locator'] for member in unit['source_members']],
            'source_dataset_ids': sorted({member['dataset_id'] for member in unit['source_members']}),
            'curation_exposure_status': role['exposure_status'],
            'curation_data_role': role['data_role'],
            'reservation_status': reservations.get(identity, {}).get('reservation_status'),
            'protected_near_duplicate_group': task['near_duplicate_group_id'] in reserved_groups,
            'previous_inventory_status': previous['exposure_status'] if previous else None,
            'previous_inventory_evidence_paths': previous['prior_semantic_or_result_records'] if previous else [],
            'audit_order_hash': order_hash('audit', identity),
            'replication_order_hash': order_hash('replication', identity),
        })
    source_order = sorted({row['source_lineage_id'] for row in identities}, key=lambda x: order_hash('source', x))
    buckets = {source: sorted([row for row in identities if row['source_lineage_id'] == source],
                             key=lambda row: row['audit_order_hash']) for source in source_order}
    ordered, seen_groups = [], set()
    while any(buckets.values()):
        for source in source_order:
            while buckets[source]:
                row = buckets[source].pop(0)
                if row['near_duplicate_group_id'] not in seen_groups:
                    seen_groups.add(row['near_duplicate_group_id'])
                    ordered.append(row)
                    break
    started = datetime.now(timezone.utc)
    inputs = [POOL, DATASET / 'task-units.jsonl', DATASET / 'task-roles.jsonl',
              DATASET / 'source-lineages.jsonl', DATASET / 'near-duplicate-groups.jsonl',
              RESERVATIONS, INVENTORY]
    protocol = {
        'status': 'FROZEN_METADATA_ONLY_SOURCE_FRAME',
        'frozen_at_utc': started.isoformat(),
        'source_audit_deadline_utc': (started + timedelta(hours=2)).isoformat(),
        'identity_limit': 60,
        'seed': SEED,
        'language': 'python',
        'language_reason': '本轮代码生成与程序测量限定 Python；其他语言不进入本轮来源框。',
        'input_sha256': {path.as_posix(): file_sha256(path) for path in inputs},
        'source_round_robin_order': source_order,
        'audit_order': '各来源按 SHA256(seed:audit:task_unit_id) 排序，来源按固定哈希顺序轮转，每近重复组最多一个身份。',
        'replication_selection': '来源与类别资格完成后，按独立适用任务支持数选最大类别，并列按六字段规范 JSON SHA256；类别内按 replication_order_hash 取最多12项。',
        'open_selection': '移除复现身份和相同近重复组后，沿已冻结来源轮转顺序取最多12项；保持实际数量。',
        'protected_rule': '具有封存评价预留或受保护近重复组的身份仅审计元数据；未获得具体释放授权前不读取来源提示，不分配研究角色。',
        'exposure_rule': 'NO_RECORD 不提供新评价资格；历史研究输入、语义准备、生成或结果路径均需核实，确认为方法用途者排除新评价。',
        'natural_lineage_rule': '公共基准来源限定为基准研究框；独立自然开发者请求谱系缺乏证据时记 UNKNOWN。',
        'measurement_rule': '测量实现缺口单列；不据此拒绝可解释来源。',
        'formal_protocol_status': 'SPECIFIED_DRAFT',
    }
    write_bundle(ROOT / 'frame', {
        'protocol.json': protocol,
        'all-identities.json': identities,
        'audit-order.json': [dict(audit_position=i + 1, **row) for i, row in enumerate(ordered[:60])],
        'metadata-counts.json': {
            'python_source_identities': len(identities),
            'deduplicated_identity_frame': len(ordered),
            'source_counts': dict(Counter(row['source_lineage_id'] for row in identities)),
            'reserved_identity_count': sum(row['reservation_status'] is not None for row in identities),
            'reserved_near_duplicate_count': sum(row['protected_near_duplicate_group'] for row in identities),
        },
    })
    print(json.dumps(read_json(ROOT / 'frame' / 'metadata-counts.json'), ensure_ascii=False))


def scan():
    verify_bundle(ROOT / 'frame')
    identities = read_json(ROOT / 'frame' / 'audit-order.json')
    token_to_identity = defaultdict(set)
    for row in identities:
        for token in [row['task_unit_id'], row['near_duplicate_group_id'], row['source_prompt_sha256'],
                      row['source_task_record_sha256'], *row['source_record_ids']]:
            token_to_identity[token].add(row['task_unit_id'])
    command = ['rg', '--json', '--only-matching', '--fixed-strings', '--glob', '!graph-guided-20260930/**']
    for token in token_to_identity:
        command.extend(['-e', token])
    command.extend(['data/method', 'docs/experiments'])
    result = subprocess.run(command, capture_output=True, text=True, encoding='utf-8', check=True)
    matches = defaultdict(lambda: defaultdict(set))
    for line in result.stdout.splitlines():
        event = json.loads(line)
        if event['type'] != 'match':
            continue
        data = event['data']
        path = data['path']['text'].replace('\\', '/')
        if '/graph-guided-20260930/' in path or path.endswith('2026-09-30-source-frame-audit.md'):
            continue
        for submatch in data['submatches']:
            token = submatch['match']['text']
            for identity in token_to_identity[token]:
                matches[identity][path].add(token)
    records = []
    for row in identities:
        records.append({
            'task_unit_id': row['task_unit_id'],
            'audit_position': row['audit_position'],
            'path_matches': [{'path': path, 'matched_identity_tokens': sorted(tokens)}
                             for path, tokens in sorted(matches[row['task_unit_id']].items())],
            'source_content_read': False,
            'generated_content_read': False,
            'result_values_read': False,
        })
    write_bundle(ROOT / 'identity-path-audit', {'records.json': records, 'metadata.json': {
        'completed_at_utc': datetime.now(timezone.utc).isoformat(),
        'search_roots': ['data/method', 'docs/experiments'],
        'search_mode': 'rg --json --only-matching --fixed-strings; only identity substrings and paths retained',
        'audited_identity_count': len(records),
    }})
    print(json.dumps({'identities': len(records), 'path_references': sum(len(r['path_matches']) for r in records)}))


def finish():
    verify_bundle(ROOT / 'frame')
    verify_bundle(ROOT / 'identity-path-audit')
    order = read_json(ROOT / 'frame/audit-order.json')
    rules = read_json(ROOT / 'source-review-rules.json')
    reviews = read_json(ROOT / 'manual-source-review.json')
    classes = read_json(ROOT / 'semantic-classes.json')
    paths = {row['audit_position']: row for row in read_json(ROOT / 'identity-path-audit/records.json')}
    source = {row['task_unit_id']: row for row in read_json(POOL)}
    screening_path = POOL.parent / 'screening.json'
    screening = {row['task_unit_id']: row for row in read_json(screening_path)}
    reserved_root = Path('data/method/qwen37flash-qualification-source-review-candidates-v1')
    concrete = [read_json(reserved_root / f'qual-{role}-selection.json') for role in ('dev', 'accept')]
    protected_ids = {row['task_unit_id'] for selection in concrete for row in selection['task_units']}
    protected_groups = {row['near_duplicate_group_id'] for selection in concrete for row in selection['task_units']}
    protected_groups.update(row['near_duplicate_group_id'] for row in screening.values()
                            if row['decision'] == 'PRESERVE_PROTECTED_INPUT')
    evidence_paths = {
        1: 'data/method/graph-guided-20260928/prepared/case-0118/case.json',
        7: 'data/method/graph-guided-20260929/development-preparation/assignments.json',
        9: 'data/method/full-chain-development-v1/run/graphs/sample-39/graph.json',
        10: 'data/method/prompt-tsg-adjudicated-holdout-gold-v2.json',
        11: 'data/method/source-hypotheses-20260927/development-panel/preoutcome/assignments.json',
        13: 'data/method/structure-binding-development-20260926/development-exposure.json',
        14: 'data/method/structure-binding-development-20260926/development-exposure.json',
        16: 'data/method/full-chain-development-v1/run/graphs/sample-41/graph.json',
        18: 'data/method/full-chain-development-v1/run/graphs/sample-07/graph.json',
        21: 'data/method/source-hypotheses-20260927/development-extension/preoutcome/assignments.json',
        22: 'data/method/graph-guided-20260928/representation-preparation-audit/graphs.json',
        26: 'data/method/prompt-tsg-adjudicated-holdout-gold-v1.json',
        28: 'data/method/full-chain-development-v1/run/graphs/sample-26/graph.json',
        29: 'data/method/graph-guided-20260928/prepared/case-0122/case.json',
        32: 'data/method/source-hypotheses-20260927/development-panel/preoutcome/assignments.json',
        33: 'data/method/graph-guided-20260929/development-preparation/assignments.json',
        34: 'data/method/results/prompt-tsg-evidence-occurrence-qualification-v4/case-results.json',
        35: 'data/method/full-chain-development-v1/run/graphs/sample-25/graph.json',
        42: 'data/method/graph-guided-20260929/development-preparation/assignments.json',
        43: 'data/method/graph-guided-20260929/evaluation-preparation/assignments.json',
        46: 'data/method/source-hypotheses-20260927/development-panel/preoutcome/assignments.json',
        47: 'data/method/full-chain-development-v1/run/graphs/sample-24/graph.json',
        49: 'data/method/graph-guided-20260929/development-preparation/assignments.json',
        56: 'data/method/structure-binding-development-20260926/development-exposure.json',
        60: 'data/method/source-hypotheses-20260927/development-panel/preoutcome/assignments.json',
    }
    decisions = []
    assert [row['position'] for row in reviews['reviews']] == list(range(1, 61))
    assert len(order) == 60
    for frame, review in zip(order, reviews['reviews'], strict=True):
        position = frame['audit_position']
        identity = frame['task_unit_id']
        assert position == review['position']
        protected = identity in protected_ids or frame['near_duplicate_group_id'] in protected_groups
        assert screening[identity]['decision'] == 'INCLUDED_RESEARCH_POOL'
        if protected:
            raise ValueError('审计名单包含具体保护身份')
        evidence = []
        if position in evidence_paths:
            path = evidence_paths[position]
            reference = [row for row in paths[position]['path_matches'] if row['path'] == path]
            assert len(reference) == 1 and reference[0]['matched_identity_tokens']
            evidence.append(dict(reference[0], purpose='PRIOR_METHOD_PREPARATION_OR_EXECUTION', sha256=file_sha256(Path(path))))
        if position == 40:
            evidence.append({'path': evidence_paths[33], 'purpose': 'INHERITED_FROM_MANUALLY_VERIFIED_NEAR_DUPLICATE',
                             'linked_audit_position': 33, 'sha256': file_sha256(Path(evidence_paths[33]))})
        historical = bool(evidence)
        if historical:
            disposition = 'EXCLUDED_PRIOR_METHOD_EXPOSURE'
        elif not review['source_usable']:
            disposition = 'EXCLUDED_SOURCE_LANGUAGE'
        elif review['endpoint'] is None or review['endpoint'].endswith('_unresolved'):
            disposition = 'SOURCE_USABLE_ENDPOINT_UNRESOLVED'
        else:
            disposition = 'ELIGIBLE_BOUNDED_EVALUATION_SOURCE'
        decisions.append(dict(frame, source_content_read=True, generated_content_read=False,
            result_values_read=False, concrete_protected=False, generic_reservation_preserved=True,
            historical_method_evidence=evidence, historical_method_exposed=historical,
            source_semantics=review, disposition=disposition,
            natural_request_lineage='UNKNOWN_PUBLIC_BENCHMARK_FRAME',
            measurement_implementation='REQUIRES_ENDPOINT_SPECIFIC_QUALIFICATION',
            tsg_preparation='NOT_PERFORMED'))
    eligible = {row['audit_position']: row for row in decisions
                if row['disposition'] == 'ELIGIBLE_BOUNDED_EVALUATION_SOURCE'}
    class_rows = []
    for row in classes['classes']:
        definition = {field: row[field] for field in classes['class_identity_fields']}
        digest = hashlib.sha256(canonical_json(definition).encode()).hexdigest()
        support = [position for position in row['source_positions'] if position in eligible]
        if not support:
            continue
        class_rows.append(dict(row, semantic_class_sha256=digest,
            eligible_source_positions=support, independent_task_support=len(support)))
    ranked = sorted(class_rows, key=lambda row: (-row['independent_task_support'], row['semantic_class_sha256']))
    winner = ranked[0]
    v_rows = sorted([eligible[position] for position in winner['eligible_source_positions']],
                    key=lambda row: row['replication_order_hash'])[:12]
    v_ids = {row['task_unit_id'] for row in v_rows}
    o_rows = [row for row in decisions if row['audit_position'] in eligible and row['task_unit_id'] not in v_ids][:12]
    assert len(v_ids) == len(v_rows) and not v_ids.intersection(row['task_unit_id'] for row in o_rows)
    assert len({row['near_duplicate_group_id'] for row in v_rows + o_rows}) == len(v_rows) + len(o_rows)
    now = datetime.now(timezone.utc)
    deadline = datetime.fromisoformat(read_json(ROOT / 'frame/protocol.json')['source_audit_deadline_utc'])
    assert now <= deadline
    panel = []
    for role, rows in [('V', v_rows), ('O', o_rows)]:
        for row in rows:
            original = source[row['task_unit_id']]
            assert original['prompt_sha256'] == row['source_prompt_sha256']
            panel.append(dict(role=role, audit_position=row['audit_position'], task_unit_id=row['task_unit_id'],
                near_duplicate_group_id=row['near_duplicate_group_id'], source_lineage_id=row['source_lineage_id'],
                prompt=original['prompt'], prompt_sha256=original['prompt_sha256'],
                source_locators=row['source_locators'], endpoint=row['source_semantics']['endpoint'],
                common_ordinary_witness=row['source_semantics']['witness'],
                measurement_need=row['source_semantics']['measurement_need'],
                semantic_class_id=winner['class_id'] if role == 'V' else None,
                semantic_class_sha256=winner['semantic_class_sha256'] if role == 'V' else None,
                role_scope='PROSPECTIVE_BOUNDED_DEVELOPMENT_ONLY', formal_role_assigned=False,
                generic_future_formal_reservation_preserved=True, natural_request_lineage='UNKNOWN'))
    counts = Counter(row['disposition'] for row in decisions)
    report = dict(status='SOURCE_AUDIT_AND_PROSPECTIVE_PANEL_FROZEN', completed_at_utc=now.isoformat(),
        stopping_reason='FIXED_60_SOURCE_IDENTITIES_COMPLETED', audited_identity_count=60,
        source_text_count=60, concrete_protected_identity_intersection=0, concrete_protected_group_intersection=0,
        specific_qual_dev_accept_intersection=0, generic_future_formal_reservation_intersection=60,
        direct_historical_method_exposure_count=len(evidence_paths), inherited_historical_method_exposure_count=1,
        out_of_python_source_count=3, out_of_python_and_historically_exposed_count=1,
        source_disposition_counts=dict(counts), eligible_independent_task_count=len(eligible),
        selected_class=winner['class_id'], selected_class_sha256=winner['semantic_class_sha256'],
        maximum_independent_class_support=winner['independent_task_support'],
        tied_maximum_classes=[row['class_id'] for row in ranked if row['independent_task_support'] == winner['independent_task_support']],
        v_task_count=len(v_rows), o_task_count=len(o_rows), v_positions=[row['audit_position'] for row in v_rows],
        o_positions=[row['audit_position'] for row in o_rows],
        unselected_eligible_positions=[position for position in eligible if position not in {row['audit_position'] for row in v_rows + o_rows}],
        parent_task_uses_status='PARENT_BUNDLE_ABSENT; FROZEN_INCLUDED_RESEARCH_POOL_AND_SPECIFIC_PROTECTION_VERIFIED',
        population_inference='DISABLED; FIXED_PUBLIC_BENCHMARK_PANEL_ONLY', model_calls=0,
        provider_calls=0, generated_outputs_read=0, result_values_read=0, formal_roles_assigned=0,
        scope_limit='Source applicability and prospective bounded-development roles; prepared policies, observer qualification and generation remain pending.')
    write_bundle(ROOT / 'completed', {'source-decisions.json': decisions, 'semantic-classes.json': ranked,
        'panel.json': panel, 'report.json': report,
        'source-rules.json': rules, 'manual-source-review.json': reviews,
        'input-identity.json': {path.as_posix(): file_sha256(path) for path in [
            POOL, screening_path, ROOT / 'source-review-rules.json', ROOT / 'manual-source-review.json',
            ROOT / 'semantic-classes.json', reserved_root / 'qual-dev-selection.json',
            reserved_root / 'qual-accept-selection.json', Path(__file__)]}})
    verify_bundle(ROOT / 'completed')
    print(json.dumps(report, ensure_ascii=False))


def freeze_controlled_natural_round():
    root = Path('data/method/controlled-semantic-20260930')
    verify_bundle(root / 'launch')
    launch = read_json(root / 'launch/launch.json')
    cutoff = int(datetime.fromisoformat(launch['t0_utc']).timestamp())
    specifications = [dict(family=family, parameters=dict(site='stackoverflow', tagged='python',
        body=family, q='subprocess', sort='creation', order='desc', todate=cutoff,
        pagesize=25, filter='withbody')) for family in ('find', 'grep', 'tar', 'git')]
    write_bundle(root / 'natural-source-round', {'protocol.json': dict(
        status='FROZEN_SINGLE_OUTCOME_BLIND_ACQUISITION_ROUND',
        frozen_utc=datetime.now(timezone.utc).isoformat(), endpoint='https://api.stackexchange.com/2.3/search/advanced',
        specifications=specifications, pages_per_query=5, maximum_source_identities=500,
        maximum_eligible_tasks=60, source_created_no_later_than_utc=launch['t0_utc'],
        source_minimum_date=None, acquisition_deadline_utc=launch['deadline_utc'],
        order='family round-robin in find/grep/tar/git order; within family descending creation order returned by frozen API query; first occurrence of each question id',
        acquisition_basis='Python tag, declared command family in question body, subprocess operation; no semantic-state or outcome acquisition filters',
        no_replenishment=True, discovery_outcomes_seen=False, selector_results_seen=False,
        screening='real developer request, interpretable operation and command-execution boundary, source/protection/exposure/near-duplicate review before any preparation',
        applicability='record all three policy sets before D outcomes; missing semantic or measurement facts remain unresolved',
        provenance='retain complete API body, original link, owner attribution, dates, licence, exact request and retrieval time',
        api_documentation=['https://api.stackexchange.com/docs/advanced-search',
                           'https://api.stackexchange.com/docs/filters', 'https://api.stackexchange.com/docs/throttle']),
        'implementation.json': dict(sha256=file_sha256(Path(__file__)), source=Path(__file__).read_text(encoding='utf-8'))})


def acquire_controlled_natural_round():
    import requests

    root = Path('data/method/controlled-semantic-20260930')
    verify_bundle(root / 'natural-source-round')
    protocol = read_json(root / 'natural-source-round/protocol.json')
    output = root / 'natural-source-acquisition'
    output.mkdir(parents=True, exist_ok=False)
    raw, buckets, identities = {}, {}, set()
    with requests.Session() as session:
        session.headers['User-Agent'] = 'PromptMechanismStudy/1.6 (bounded academic source acquisition)'
        for specification in protocol['specifications']:
            family = specification['family']
            buckets[family] = []
            for page in range(1, protocol['pages_per_query'] + 1):
                if datetime.now(timezone.utc) >= datetime.fromisoformat(protocol['acquisition_deadline_utc']):
                    raise TimeoutError('自然来源取得超过研究窗口')
                parameters = dict(specification['parameters'], page=page)
                reply = session.get(protocol['endpoint'], params=parameters, timeout=60)
                reply.raise_for_status()
                payload = reply.json()
                if 'error_id' in payload:
                    raise RuntimeError(canonical_json(payload))
                name = f'{family}-{page}.json'
                record = dict(request_url=reply.url, retrieved_utc=datetime.now(timezone.utc).isoformat(),
                              status_code=reply.status_code, response=payload)
                (output / name).write_text(canonical_json(record) + '\n', encoding='utf-8')
                raw[name] = file_sha256(output / name)
                for item in payload['items']:
                    identities.add(item['question_id'])
                    if len(identities) > protocol['maximum_source_identities']:
                        raise ValueError('自然来源身份超过冻结上限')
                    if 'python' not in item['tags'] or item['creation_date'] > specification['parameters']['todate']:
                        raise ValueError('实际 API 来源未符合冻结语言或时间条件')
                    buckets[family].append(item)
                print(json.dumps(dict(family=family, page=page, received=len(payload['items']),
                                      unique_identities=len(identities))), flush=True)
                if 'backoff' in payload:
                    time.sleep(payload['backoff'])
                if not payload['has_more']:
                    break
    finish_controlled_natural_round()


def finish_controlled_natural_round():
    from bs4 import BeautifulSoup

    root = Path('data/method/controlled-semantic-20260930')
    verify_bundle(root / 'natural-source-round')
    protocol = read_json(root / 'natural-source-round/protocol.json')
    output = root / 'natural-source-acquisition'
    raw, buckets = {}, {}
    for specification in protocol['specifications']:
        family = specification['family']
        buckets[family] = []
        for page in range(1, protocol['pages_per_query'] + 1):
            path = output / f'{family}-{page}.json'
            record = read_json(path)
            assert record['status_code'] == 200
            raw[path.name] = file_sha256(path)
            buckets[family].extend(record['response']['items'])
            if not record['response']['has_more']:
                break
    ordered, seen = [], set()
    for index in range(max(map(len, buckets.values()), default=0)):
        for family in ('find', 'grep', 'tar', 'git'):
            if index >= len(buckets[family]):
                continue
            item = buckets[family][index]
            if item['question_id'] in seen:
                continue
            seen.add(item['question_id'])
            ordered.append(dict(source_position=len(ordered)+1, acquisition_family=family,
                source_id=f'stackoverflow:{item["question_id"]}', source_kind='PUBLIC_DEVELOPER_QUESTION',
                original_url=item['link'], title=BeautifulSoup(item['title'], 'html.parser').get_text(),
                original_body_html=item['body'], source_text=BeautifulSoup(item['body'], 'html.parser').get_text('\n'),
                attribution=item.get('owner'), content_license=item.get('content_license'),
                licence_metadata_status='PROVIDED' if 'content_license' in item else 'UNKNOWN_IN_CAPTURED_RESPONSE',
                creation_date=item['creation_date'], last_activity_date=item['last_activity_date'],
                source_snapshot_sha256=hashlib.sha256(item['body'].encode()).hexdigest(),
                source_qualification='PENDING_SOURCE_PROTECTION_EXPOSURE_AND_SEMANTIC_REVIEW'))
    write_bundle(output / 'frame', {'sources.json': ordered, 'identity.json': dict(
        protocol_manifest_sha256=file_sha256(root / 'natural-source-round/manifest.json'),
        raw_response_sha256=raw, independent_question_ids=len(ordered),
        retrieved_utc=datetime.now(timezone.utc).isoformat(), discovery_outcomes_seen=False,
        selector_results_seen=False, source_rounds=1,
        assembler_sha256=file_sha256(Path(__file__)))})


def scan_controlled_natural_identities():
    root = Path('data/method/controlled-semantic-20260930')
    verify_bundle(root / 'natural-source-acquisition/frame')
    sources = read_json(root / 'natural-source-acquisition/frame/sources.json')
    identities = {row['source_id'].split(':')[1]: row['source_id'] for row in sources}
    pattern = r'https?://(?:www\.)?stackoverflow\.com/(?:questions|q)/(' + '|'.join(identities) + r')\b'
    command = ['rg', '--json', '--only-matching', '--glob', '!controlled-semantic-20260930/**',
               '-e', pattern, 'data/method', 'data/dataset-curation', 'docs/experiments']
    result = subprocess.run(command, capture_output=True, text=True, encoding='utf-8')
    if result.returncode not in (0, 1):
        raise RuntimeError(result.stderr)
    matches = defaultdict(lambda: defaultdict(set))
    for line in result.stdout.splitlines():
        event = json.loads(line)
        if event['type'] != 'match':
            continue
        data = event['data']
        path = data['path']['text'].replace('\\', '/')
        if '/controlled-semantic-20260930/' in path:
            continue
        for submatch in data['submatches']:
            url = submatch['match']['text']
            identity = identities[urlsplit(url).path.split('/')[2]]
            matches[identity][path].add(url)
    metadata_paths = [DATASET / 'task-units.jsonl', DATASET / 'task-roles.jsonl',
                      DATASET / 'near-duplicate-groups.jsonl', RESERVATIONS, POOL.parent / 'screening.json']
    specific = Path('data/method/qwen37flash-qualification-source-review-candidates-v1')
    metadata_paths.extend(specific / f'qual-{role}-selection.json' for role in ('dev', 'accept'))
    records = [dict(source_id=row['source_id'], source_position=row['source_position'],
        reference_matches=[dict(path=path, urls=sorted(urls)) for path, urls in sorted(matches[row['source_id']].items())],
        source_identity_status='EXISTING_REFERENCE_REQUIRES_DISPOSITION' if matches[row['source_id']] else 'NO_EXISTING_URL_REFERENCE',
        semantic_near_duplicate_status='PENDING_CONTRACT_REVIEW') for row in sources]
    write_bundle(root / 'natural-source-identity-audit', {'records.json': records,
        'metadata.json': dict(source_identities=len(records),
            sources_with_existing_references=sum(bool(row['reference_matches']) for row in records),
            metadata_sha256={str(p): file_sha256(p) for p in metadata_paths},
            source_manifest_sha256=file_sha256(root / 'natural-source-acquisition/frame/manifest.json'),
            completed_utc=datetime.now(timezone.utc).isoformat(),
            search='exact original Stack Overflow question URL identities; paths and matching URL tokens only',
            limitation='URL independence does not establish semantic near-duplicate independence',
            protected_source_text_used_for_preparation=False, result_values_read=False)})
    print(json.dumps(dict(identities=len(records), matched=sum(bool(r['reference_matches']) for r in records))))


def contract_fingerprint(identity, functional_fields, unrecorded_fields):
    if not identity['task_unit_id'] or not functional_fields:
        raise ValueError('合同指纹需要任务身份和来源功能字段')
    require_sha256(identity['source_record_sha256'])
    if not isinstance(unrecorded_fields, list) or any(not isinstance(value, str) for value in unrecorded_fields):
        raise ValueError('合同缺失信息需要逐项保存')
    core = dict(identity=identity, functional_fields=functional_fields,
                unrecorded_fields=unrecorded_fields,
                functional_fields_sha256=content_hash(functional_fields),
                semantic_near_duplicate_status='PENDING_CONTRACT_REVIEW')
    return dict(core, fingerprint_sha256=content_hash(core))


def controlled_natural_contract_fingerprints(root):
    verify_bundle(root / 'natural-source-acquisition/frame')
    verify_bundle(root / 'development-sources')
    sources = read_json(root / 'natural-source-acquisition/frame/sources.json')
    review_path = root / 'natural-source-review.json'
    reviews = read_json(review_path)['reviews']
    by_position = {row['position']: row for row in reviews}
    if (len(by_position) != len(reviews) or len(reviews) != len(sources)
            or set(by_position) != {row['source_position'] for row in sources}):
        raise ValueError('合同指纹需要覆盖原顺序全部自然来源')
    records = []
    for source in sources:
        review = by_position[source['source_position']]
        fields = {key: review[key] for key in (
            'status', 'basis', 'family', 'contract', 'target_input',
            'requirements_to_preserve', 'reason') if key in review}
        missing = list(review.get('unresolved', []))
        missing.extend(key for key in ('contract', 'target_input', 'requirements_to_preserve')
                       if not review.get(key))
        records.append(contract_fingerprint(dict(task_unit_id=source['source_id'],
            source_position=source['source_position'], original_url=source['original_url'],
            source_record_sha256=source['source_snapshot_sha256'],
            origin='natural-source-review', source_review_sha256=content_hash(review)), fields, missing))
    development = read_json(root / 'development-sources/records.json')
    exposure = read_json(root / 'development-sources/exposure.json')
    if {row['base_task_identity'] for row in development} != set(exposure['tasks']):
        raise ValueError('开发参照任务必须完整覆盖原开发暴露记录')
    for row in development:
        records.append(contract_fingerprint(dict(task_unit_id=row['task_id'],
            near_duplicate_group_id=row['near_duplicate_group_id'],
            source_record_sha256=content_hash(row), origin='controlled-development',
            excluded_roles=exposure['roles_excluded']),
            dict(blueprint=row['blueprint'], source_versions=row['versions']), []))
    paths = ['natural-source-acquisition/frame/manifest.json', 'natural-source-review.json',
             'development-sources/manifest.json']
    return dict(status='PREPARED_CONTRACT_COMPARISON_INPUTS',
        input_sha256={name: file_sha256(root / name) for name in paths},
        implementation_sha256=file_sha256(Path(__file__)),
        natural_source_count=len(sources), current_development_count=len(development),
        reference_contracts_included=False, semantic_comparisons_performed=0,
        protected_contract_content_read=False, result_values_read=False, records=records)


def controlled_reference_contract_fingerprints(dataset):
    # 此入口需要已有功能合同内容的单独读取授权；只导出比较字段。
    manifest = read_json(dataset / 'manifest.json')
    names = ('functional-contracts.jsonl', 'task-roles.jsonl', 'near-duplicate-groups.jsonl')
    if manifest['schema_version'] != '5.0':
        raise ValueError('参照合同需要当前来源数据格式')
    hashes = {name: file_sha256(dataset / name) for name in names}
    if any(hashes[name] != manifest['files'][name]['sha256'] for name in names):
        raise ValueError('参照合同或角色身份与原冻结记录不符')
    tables = {name: read_canonical_jsonl(dataset / name, name) for name in names}
    if any(len(tables[name]) != manifest['files'][name]['record_count'] for name in names):
        raise ValueError('参照合同数量与原冻结记录不符')
    roles = {row['task_unit_id']: row for row in tables['task-roles.jsonl']}
    contracts = tables['functional-contracts.jsonl']
    if (len(roles) != len(tables['task-roles.jsonl']) or len(roles) != len(contracts)
            or set(roles) != {row['task_unit_id'] for row in contracts}):
        raise ValueError('参照合同必须完整覆盖全部既有角色')
    groups = {}
    for group in tables['near-duplicate-groups.jsonl']:
        for task_id in group['task_unit_ids']:
            if task_id in groups:
                raise ValueError('参照任务重复出现在已有近重复组')
            groups[task_id] = group['near_duplicate_group_id']
    if set(groups) != set(roles):
        raise ValueError('已有近重复组没有完整覆盖参照任务')
    records = []
    for contract in contracts:
        task_id = contract['task_unit_id']
        role = roles[task_id]
        core = {key: value for key, value in contract.items() if key != 'functional_contract_record_sha256'}
        if (contract['schema_version'] != 'functional-contract-reviewer-5.0'
                or contract['functional_contract_record_sha256'] != content_hash(core)
                or role['near_duplicate_group_id'] != groups[task_id]):
            raise ValueError('参照合同内容或近重复组身份不符')
        fields = {key: contract[key] for key in ('entrypoint', 'requirements', 'inputs', 'outputs',
                  'side_effects', 'environment_dependencies')}
        for key, value in fields.items():
            if key == 'entrypoint':
                valid = value is None or isinstance(value, str) and bool(value.strip())
            else:
                valid = isinstance(value, list) and all(isinstance(item, str) and item.strip() for item in value)
            if not valid:
                raise ValueError('参照合同功能字段格式不符')
        review = contract['review']
        records.append(contract_fingerprint(dict(task_unit_id=task_id,
            near_duplicate_group_id=groups[task_id], origin='existing-functional-contract',
            source_record_sha256=contract['functional_contract_record_sha256'],
            source_prompt_sha256=contract['source_prompt_sha256'], contract_id=contract['contract_id'],
            data_role=role['data_role'], exposure_status=role['exposure_status'],
            resolution_status=contract['resolution_status'],
            contract_status=review['contract_status'], evidence_status=review['evidence_status'],
            terminal_quality_decision=review['terminal_quality_decision']),
            fields, [key for key, value in fields.items() if value is None or value == []]))
    return dict(status='PREPARED_CONTRACT_COMPARISON_INPUTS',
        dataset_manifest_sha256=file_sha256(dataset / 'manifest.json'), input_sha256=hashes,
        implementation_sha256=file_sha256(Path(__file__)),
        reference_task_count=len(records), reference_group_count=len(set(groups.values())),
        semantic_comparisons_performed=0, protected_contract_content_read=True,
        protected_prompt_file_read=False, result_values_read=False, records=records)


def write_controlled_contract_fingerprints(scope, output):
    root = Path('data/method/controlled-semantic-20260930')
    if scope not in ('natural', 'existing'):
        raise ValueError('合同指纹需要明确指定自然来源或既有参照')
    if output.exists():
        raise FileExistsError(output)
    payload = (controlled_natural_contract_fingerprints(root) if scope == 'natural'
               else controlled_reference_contract_fingerprints(DATASET))
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(canonical_json(payload) + '\n')
    print(json.dumps(dict(output=output.as_posix(), sha256=file_sha256(output),
                         records=len(payload['records']), semantic_comparisons_performed=0)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['freeze', 'scan', 'finish',
                                          'controlled-natural-freeze', 'controlled-natural-acquire',
                                          'controlled-natural-frame', 'controlled-natural-identities',
                                          'controlled-contract-fingerprints'])
    parser.add_argument('--scope', choices=('natural', 'existing'))
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if args.command == 'controlled-contract-fingerprints':
        if args.scope is None or args.output is None:
            parser.error('合同指纹需要明确指定 --scope 和 --output')
        write_controlled_contract_fingerprints(args.scope, args.output)
    else:
        if args.scope is not None or args.output is not None:
            parser.error('--scope 和 --output 仅用于合同指纹')
        {'freeze': freeze, 'scan': scan, 'finish': finish,
         'controlled-natural-freeze': freeze_controlled_natural_round,
         'controlled-natural-acquire': acquire_controlled_natural_round,
         'controlled-natural-frame': finish_controlled_natural_round,
         'controlled-natural-identities': scan_controlled_natural_identities}[args.command]()
