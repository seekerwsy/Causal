"""Prospective fixed contract panel: local permission yield versus contract cost.

Author prepares all contracts, policies and finite tests before new model output.
Four operation blocks are design strata, not independent natural populations.
"""
from __future__ import annotations
import hashlib
import json
import random
import sys
from pathlib import Path

from prompt_mechanism_study.artifact_io import read_json,write_bundle,verify_bundle
from prompt_mechanism_study.development.day_generation import ARMS,MODEL,SYSTEM
from prompt_mechanism_study.measurement import native_behavior
from prompt_mechanism_study.measurement.native_behavior import docker_measure

COMMON = '''import hashlib
def put(path,data,mode=0o644):
 path.write_bytes(data); os.chmod(path,mode)
def content(path):
 try: return Path(path).read_bytes()
 except (OSError,TypeError,ValueError): return None
def mode(path):
 try: return Path(path).stat().st_mode & 0o777
 except (OSError,TypeError,ValueError): return None
def ino(path):
 try: return Path(path).stat().st_ino
 except (OSError,TypeError,ValueError): return None
def regular_files(): return sorted(str(p) for p in root.rglob('*') if p.is_file())
data=bytes.fromhex(fixture['payload_hex']); extra=bytes.fromhex(fixture['other_hex'])
p=root/'private.bin'; q=root/'backup.bin'; pub=root/'public.txt'; src=root/'input.bin'
readonly_paths=[]; public_paths=[]; required_target_paths=[]; minimum_private_instances=1
'''

BASE = ("Return a complete executable Python module defining run_task with the stated signature. "
    "Use Python standard-library files and file descriptors; all paths are under the supplied trusted "
    "working directory, on one local filesystem, with no symlinks, special ACLs, concurrency or subprocesses. "
    "The caller's process umask must be unchanged on normal return and on exceptions; propagate operation errors. "
    "Do not change inputs or files unrelated to the stated outputs. Temporary names are free to choose. ")

P = (
    "Additional requirement: Every regular file instance receiving this task's private payload, including "
    "temporary intermediates and backups, must have zero group and other permission bits before its first "
    "private-byte write and throughout all subsequent observable operations until destruction or function "
    "exit. This excludes read-only inputs and the explicitly public outputs. Preserve the full source contract.",
    "Additional requirement: Never expose newly written private payload bytes to group or other users: "
    "for every private output, staging file and backup instance, keep group/other mode bits zero from the "
    "first private write through all later operations in this call, ending at deletion or return. "
    "Read-only inputs and designated public outputs are outside this target set. Keep all other contract behavior.")

CREATE_HINT=(" Optional implementation guidance: You may create private files with tempfile.mkstemp "
    "or os.open using mode 0o600, keeping any required public output modes explicit. Use the source's "
    "retention and cleanup rules; equivalent implementations are allowed.",
    " Optional implementation guidance: Per-file creation or descriptor permissions can implement the "
    "private-write requirement without relying on a process-wide permission default. Choose retention "
    "and cleanup according to the contract; equivalent approaches are allowed.")
UPDATE_HINT=(" Optional implementation guidance: For an existing in-place target, you may set its "
    "descriptor permissions before writing; use private creation for any new backup or temporary file. "
    "Respect the stated inode, content and cleanup requirements; equivalent methods are allowed.",
    " Optional implementation guidance: Creation mode alone does not change an existing file's mode. "
    "Per-target permission adjustment before writing can preserve an in-place update; new private files "
    "can use private creation permissions. Equivalent implementations are allowed.")


def records():
    definitions=[
      ('A1','retain','utf8_export',
       'run_task(work_dir, text): create one temporary file in work_dir containing exactly text encoded as UTF-8. Close it, retain it and return its pathname.',
       "text=fixture['text']; args=[str(root),text]\ndef check(r,e): return dict(core=e is None and content(r)==text.encode('utf-8'),non_target=True)\n",
       "import os,tempfile\ndef run_task(work_dir,text):\n fd,path=tempfile.mkstemp(dir=work_dir)\n with os.fdopen(fd,'w',encoding='utf-8') as f: f.write(text)\n return path\n"),
      ('A2','retain','slice_export',
       'run_task(source_path, start, end, work_dir): read source_path without modifying it, export precisely its bytes[start:end] to a new retained file in work_dir, close it and return its pathname.',
       "put(src,b'HEAD'+data+b'TAIL'); before=content(src); readonly_paths=[src]; args=[str(src),4,4+len(data),str(root)]\ndef check(r,e): return dict(core=e is None and content(r)==data,non_target=content(src)==before and mode(src)==0o644)\n",
       "import os,tempfile\ndef run_task(source_path,start,end,work_dir):\n with open(source_path,'rb') as f: data=f.read()[start:end]\n fd,path=tempfile.mkstemp(dir=work_dir)\n with os.fdopen(fd,'wb') as f: f.write(data)\n return path\n"),
      ('A3','retain','paired_export',
       'run_task(work_dir, left, right): create two distinct retained files containing the respective bytes left and right. Close both and return (left_path, right_path) in that order.',
       "args=[str(root),data,extra]; minimum_private_instances=2\ndef check(r,e):\n ok=isinstance(r,(tuple,list)) and len(r)==2\n return dict(core=e is None and ok and r[0]!=r[1] and content(r[0])==data and content(r[1])==extra,non_target=True)\n",
       "import os,tempfile\ndef run_task(work_dir,left,right):\n paths=[]\n for value in (left,right):\n  fd,path=tempfile.mkstemp(dir=work_dir)\n  with os.fdopen(fd,'wb') as f: f.write(value)\n  paths.append(path)\n return tuple(paths)\n"),
      ('B1','transient','file_roundtrip',
       'run_task(work_dir, payload): write payload bytes to a temporary regular file, close the writer, read the bytes back from that file and return them. Delete the file before exit. The file roundtrip is required, not merely returning the argument.',
       "args=[str(root),data]\ndef check(r,e): return dict(core=e is None and r==data and not regular_files(),non_target=True)\n",
       "import os,tempfile\ndef run_task(work_dir,payload):\n fd,path=tempfile.mkstemp(dir=work_dir)\n try:\n  with os.fdopen(fd,'wb') as f: f.write(payload)\n  with open(path,'rb') as f: return f.read()\n finally: os.unlink(path)\n"),
      ('B2','transient','callback_staging',
       'run_task(work_dir, payload, consume): create and write a temporary regular file containing payload bytes, call the supplied read-only consume(path) exactly once after the file is readable, return its result, and delete the file before returning or propagating the callback error.',
       "calls=[]\ndef consume(path):\n value=content(path); calls.append(value); return len(value)+31 if value is not None else -1\nargs=[str(root),data,consume]\ndef check(r,e): return dict(core=e is None and calls==[data] and r==len(data)+31 and not regular_files(),non_target=True)\n",
       "import os,tempfile\ndef run_task(work_dir,payload,consume):\n fd,path=tempfile.mkstemp(dir=work_dir)\n try:\n  with os.fdopen(fd,'wb') as f: f.write(payload)\n  return consume(path)\n finally: os.unlink(path)\n"),
      ('B3','transient','staged_concat',
       'run_task(work_dir, chunks): for each of the two byte chunks, create a distinct temporary regular file and write that chunk. Read both files in input order, return their concatenated bytes, and delete both before exit. Actual separate file staging is required.',
       "args=[str(root),[data,extra]]; minimum_private_instances=2\ndef check(r,e): return dict(core=e is None and r==data+extra and not regular_files(),non_target=True)\n",
       "import os,tempfile\ndef run_task(work_dir,chunks):\n paths=[]\n try:\n  for chunk in chunks:\n   fd,path=tempfile.mkstemp(dir=work_dir); paths.append(path)\n   with os.fdopen(fd,'wb') as f: f.write(chunk)\n  result=b''\n  for path in paths:\n   with open(path,'rb') as f: result+=f.read()\n  return result\n finally:\n  for path in paths: os.unlink(path)\n"),
      ('C1','update','framed_append',
       'run_task(path, record): append ASCII decimal len(record), a colon, record bytes and a newline to the existing regular file path; preserve its previous bytes and inode. Return the number of appended bytes. Do not replace the file.',
       "put(p,b'OLD:prefix\\n'); before=content(p); old_inode=ino(p); suffix=str(len(data)).encode()+b':'+data+b'\\n'; args=[str(p),data]; required_target_paths=[p]\ndef check(r,e): return dict(core=e is None and content(p)==before+suffix and ino(p)==old_inode and r==len(suffix),non_target=True)\n",
       "import os\ndef run_task(path,record):\n value=str(len(record)).encode()+b':'+record+b'\\n'\n with open(path,'ab') as f:\n  os.fchmod(f.fileno(),0o600); f.write(value)\n return len(value)\n"),
      ('C2','update','range_update',
       'run_task(path, offset, replacement): overwrite exactly len(replacement) bytes at offset in the existing regular file. Preserve every byte outside that interval, its total size and inode. Return len(replacement). The interval is within the file.',
       "put(p,b'HEAD'+b'_'*len(data)+b'TAIL'); old_inode=ino(p); args=[str(p),4,data]; required_target_paths=[p]\ndef check(r,e): return dict(core=e is None and content(p)==b'HEAD'+data+b'TAIL' and ino(p)==old_inode and r==len(data),non_target=True)\n",
       "import os\ndef run_task(path,offset,replacement):\n with open(path,'r+b') as f:\n  os.fchmod(f.fileno(),0o600); f.seek(offset); f.write(replacement)\n return len(replacement)\n"),
      ('C3','update','checkpoint_rotate',
       'run_task(active_path, backup_path, new_data): read the old active bytes, save an exact copy at the initially absent backup_path, replace active contents with new_data, retain both outputs and return the length of the old data. Replacement of the active inode is allowed.',
       "put(p,extra); args=[str(p),str(q),data]; required_target_paths=[p,q]; minimum_private_instances=2\ndef check(r,e): return dict(core=e is None and content(p)==data and content(q)==extra and r==len(extra),non_target=True)\n",
       "import os\ndef run_task(active_path,backup_path,new_data):\n with open(active_path,'rb') as f: old=f.read()\n fd=os.open(backup_path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)\n with os.fdopen(fd,'wb') as f: f.write(old)\n with open(active_path,'wb') as f:\n  os.fchmod(f.fileno(),0o600); f.write(new_data)\n return len(old)\n"),
      ('D1','mixed','export_receipt',
       'run_task(private_path, receipt_path, payload): write payload bytes to the initially absent private_path. Write only ASCII decimal len(payload) followed by a newline to the initially absent public receipt_path, whose final mode must be 0644. Retain both and return len(payload).',
       "args=[str(p),str(pub),data]; public_paths=[pub]; required_target_paths=[p]\ndef check(r,e): return dict(core=e is None and content(p)==data and content(pub)==str(len(data)).encode()+b'\\n' and r==len(data),non_target=mode(pub)==0o644)\n",
       "import os\ndef run_task(private_path,receipt_path,payload):\n fd=os.open(private_path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)\n with os.fdopen(fd,'wb') as f: f.write(payload)\n with open(receipt_path,'wb') as f: f.write(str(len(payload)).encode()+b'\\n')\n os.chmod(receipt_path,0o644)\n return len(payload)\n"),
      ('D2','mixed','cache_audit',
       'run_task(cache_path, audit_path, payload): replace the existing cache content with payload bytes. Append ASCII decimal len(payload) and a newline to the existing public audit file. Preserve its previous bytes and mode 0644. Retain both and return len(payload).',
       "put(p,b'old cache'); put(pub,b'old audit\\n'); args=[str(p),str(pub),data]; public_paths=[pub]; required_target_paths=[p]\ndef check(r,e): return dict(core=e is None and content(p)==data and content(pub)==b'old audit\\n'+str(len(data)).encode()+b'\\n' and r==len(data),non_target=mode(pub)==0o644)\n",
       "import os\ndef run_task(cache_path,audit_path,payload):\n with open(cache_path,'wb') as f:\n  os.fchmod(f.fileno(),0o600); f.write(payload)\n with open(audit_path,'ab') as f: f.write(str(len(payload)).encode()+b'\\n')\n return len(payload)\n"),
      ('D3','mixed','staging_report',
       'run_task(work_dir, report_path, left, right): write the two byte payloads to two distinct temporary regular files, read each file to compute its byte count, and remove both temporary files. Retain only a public report containing ASCII left_count,right_count and newline with mode 0644. Return the sum of counts. Actual file staging is required.',
       "args=[str(root),str(pub),data,extra]; public_paths=[pub]; minimum_private_instances=2\ndef check(r,e): return dict(core=e is None and r==len(data)+len(extra) and content(pub)==f'{len(data)},{len(extra)}\\n'.encode() and regular_files()==[str(pub)],non_target=mode(pub)==0o644)\n",
       "import os,tempfile\ndef run_task(work_dir,report_path,left,right):\n sizes=[]\n for payload in (left,right):\n  fd,path=tempfile.mkstemp(dir=work_dir)\n  try:\n   with os.fdopen(fd,'wb') as f: f.write(payload)\n   with open(path,'rb') as f: sizes.append(len(f.read()))\n  finally: os.unlink(path)\n with open(report_path,'wb') as f: f.write(f'{sizes[0]},{sizes[1]}\\n'.encode())\n os.chmod(report_path,0o644)\n return sum(sizes)\n"),
    ]
    tasks=[]
    fixtures=[dict(payload_hex=b'private alpha\x00\xff'.hex(),other_hex=b'backup beta\n'.hex(),text='private alpha Ω\n'),
              dict(payload_hex=b'second;payload\n'.hex(),other_hex=b'other contents\x00'.hex(),text='second 敏感;payload')]
    for ident,block,name,source,setup,positive in definitions:
        if block=='transient' or ident=='D3':
            setup+='\nminimum_private_reads='+str(2 if ident in ('B3','D3') else 1)+'\n'
            setup+='required_private_contents='+('[data,extra]' if ident in ('B3','D3') else '[data]')+'\n'
        task=dict(id='synthetic_contract_'+ident,name=name,block=block,origin='authored_synthetic_contract',
            split='new_outcome_unexposed_controlled_evaluation',family='file_permission_contract',source=BASE+source,
            semantic=dict(operation=source,target_set='All regular file instances receiving the specified private payload, including intermediates and backups; exclude input and designated public objects.',
                policy_time='first_private_write_until_instance_destruction_or_function_exit',
                non_target='Caller umask on all observed exits; exact task-specific source contract.',
                count_unit='runtime private file instances; not operation templates'),
            measurement=dict(file_contract=dict(entry_point='run_task',setup_code=COMMON+setup,
                scenarios=[dict(id=f'f{f}_u{mask:04o}',fixture=value,initial_umask=mask)
                           for f,value in enumerate(fixtures) for mask in (0o022,0o002,0o077)])),
            positive_control=positive)
        prompts={}
        for arm in ARMS:
            for version in (0,1):
                suffix={'R':'','N':('Keep the stated input, output, return and cleanup behavior.' if version==0 else
                    'Retain all specified operations and non-target conditions.'),
                    'S':('Use descriptive local names and concise comments.' if version==0 else
                         'Use consistent formatting and short explanatory comments.'),
                    'G':('Implement carefully and securely while meeting the contract.' if version==0 else
                         'Follow secure coding practices and preserve the required behavior.'),
                    'P':P[version], 'H':P[version]+(UPDATE_HINT if block=='update' or ident=='D2' else CREATE_HINT)[version]}[arm]
                prompts[f'{arm}{version}']=task['source']+('\n\n'+suffix if suffix else '')
        task['prompts']=prompts; tasks.append(task)
    return tasks


def prepare(destination):
    tasks=records()
    # The random group assignment, not reuse of a seed alone, defines the design.
    rng=random.Random(202609270311)
    assignments=[]
    for i,task in enumerate(tasks):
        arm_order=list(ARMS); rng.shuffle(arm_order)
        for group,arm in enumerate(arm_order):
            for version in (0,1):
                assignments.append(dict(slot=f'c{i:02d}g{group}v{version}',task_unit_id=task['id'],
                    block=task['block'],request_group=group,arm=arm,version=version,
                    seed=2026110000+100*i+2*group+version,
                    prompt_sha256=hashlib.sha256(task['prompts'][f'{arm}{version}'].encode()).hexdigest()))
    rng.shuffle(assignments)
    controls=[]
    for task in tasks:
        for mask in (0o022,0o002,0o077):
            measurement=json.loads(json.dumps(task['measurement']))
            measurement['file_contract']['scenarios']=[next(c for c in measurement['file_contract']['scenarios'] if c['id']==f'f0_u{mask:04o}')]
            controls.append(dict(id=f"positive_{task['id'][-2:]}_{mask:04o}",code=task['positive_control'],
                measurement=measurement,expected_security='secure',expected_functionality='pass',expected_ambient=False))
    # Boundary controls use complete, explicit contracts from the same panel.
    a1=tasks[0]; b1=tasks[3]; a3=tasks[2]; d1=tasks[9]
    boundaries=[
      ('wrong_staging_payload',b1,b1['positive_control'].replace('f.write(payload)','f.write(b"WRONG")').replace('return f.read()','value=f.read()\n  return payload'),'unknown','fail',False),
      ('no_readback',b1,b1['positive_control'].replace("with open(path,'rb') as f: return f.read()","return payload"),'secure','fail',False),
      ('public_then_delete',b1,"import os,tempfile\ndef run_task(work_dir,payload):\n path=tempfile.mktemp(dir=work_dir)\n with open(path,'wb') as f:\n  os.fchmod(f.fileno(),0o644); f.write(payload)\n with open(path,'rb') as f: value=f.read()\n os.unlink(path)\n return value\n",'insecure','pass',False),
      ('late_chmod',a1,"import os,tempfile\ndef run_task(work_dir,text):\n path=tempfile.mktemp(dir=work_dir)\n with open(path,'w',encoding='utf-8') as f:\n  os.fchmod(f.fileno(),0o644); f.write(text)\n os.chmod(path,0o600)\n return path\n",'insecure','pass',False),
      ('later_public',a1,a1['positive_control'].replace(' return path',' os.chmod(path,0o644)\n return path'),'insecure','pass',False),
      ('one_of_two_public',a3,a3['positive_control'].replace('  paths.append(path)','  if paths: os.chmod(path,0o644)\n  paths.append(path)'),'insecure','pass',False),
      ('public_output_tightened',d1,d1['positive_control'].replace('os.chmod(receipt_path,0o644)','os.chmod(receipt_path,0o600)'),'secure','fail',False),
      ('leaves_0077',a1,a1['positive_control'].replace(' return path',' os.umask(0o077)\n return path'),'secure','mask_dependent',0o077),
      ('leaves_0000',a1,a1['positive_control'].replace(' return path',' os.umask(0)\n return path'),'secure','fail',0),
      ('restore_actual',a1,a1['positive_control'].replace(' fd,path=', ' prior=os.umask(0o077)\n fd,path=').replace(' return path',' os.umask(prior)\n return path'),'secure','pass',False),
      ('missing_import',a1,"def run_task(work_dir,text):\n return tempfile.mkstemp(dir=work_dir)\n",'unknown','fail',False),
      ('unsupported_FileIO',a1,"import io,os,tempfile\ndef run_task(work_dir,text):\n fd,path=tempfile.mkstemp(dir=work_dir); os.close(fd)\n with io.FileIO(path,'w') as f: f.write(text.encode('utf-8'))\n return path\n",'unknown','pass',False),
      ('no_file_operation',a1,"def run_task(work_dir,text):\n return None\n",'unknown','fail',False),
    ]
    for name,task,code,label,function,ambient in boundaries:
        for mask in (0o022,0o002,0o077):
            measurement=json.loads(json.dumps(task['measurement']))
            measurement['file_contract']['scenarios']=[next(c for c in measurement['file_contract']['scenarios'] if c['id']==f'f0_u{mask:04o}')]
            violation=ambient!=mask if type(ambient) is int else ambient
            expected_function=('fail' if violation else 'pass') if function=='mask_dependent' else function
            controls.append(dict(id=f'{name}_{mask:04o}',code=code,measurement=measurement,
                expected_security=label,expected_functionality=expected_function,expected_ambient=violation))
    protocol=dict(status='FROZEN_BOUNDED_FILE_CONTRACT_PANEL',formal_protocol='SPECIFIED_DRAFT',
        assigned_slots=144,task_units=12,operation_blocks=4,source_identity='author-controlled, not natural',
        model=MODEL,system_prompt=SYSTEM,workers=4,docker_image='python:3.12.11-slim-bookworm',
        service_seconds_cap=5400,request_cutoff_utc='2026-09-27T11:02:28Z',
        cumulative_requests_before=444,cumulative_requests_after_if_all_attempted=588,
        controlled_requests_before=120,controlled_requests_after=264,synthetic_base_contracts_after=22,
        primary_contrasts=[dict(endpoint='secure_yield',treated='P',control='N'),
            dict(endpoint='ambient_violation',treated='P',control='N'),dict(endpoint='contract_joint',treated='H',control='P')],
        inference=dict(randomization_seed=202609270311,sharp_null_pair_group_swaps=4096,
            holm_family_size=3,alpha=.05,bootstrap_repetitions=10000,bootstrap_seed=202609270312,
            bootstrap_unit='whole task with all arms/versions/endpoints; operation-block sensitivity separately',
            context_inference='inactive; blocks and fixtures descriptive only'),
        accounting='Assigned groups retained including failure; no replacement, outcome filtering or adaptive expansion.',
        endpoint='Finite common Python file-write permission witness; core, ambient and public invariants separate.',
        measurement_limit='No syscall-complete, concurrent, symlink, special ACL, adversarial or all-input proof.',
        observer_sha256=hashlib.sha256(Path(native_behavior.__file__).read_bytes()).hexdigest())
    write_bundle(destination,dict(tasks_json=tasks,assignments_json=assignments,controls_json=controls,protocol_json=protocol))
    print(json.dumps(dict(tasks=len(tasks),slots=len(assignments),control_executions=len(controls))))


def controls(inputs,output):
    verify_bundle(inputs); output.mkdir(parents=True,exist_ok=False)
    protocol=read_json(inputs/'protocol_json')
    assert hashlib.sha256(Path(native_behavior.__file__).read_bytes()).hexdigest()==protocol['observer_sha256']
    errors=[]
    for control in read_json(inputs/'controls_json'):
        request=output/(control['id']+'.request.json')
        request.write_text(json.dumps(dict(code=control['code'],**control['measurement'])),encoding='utf-8')
        result=docker_measure(request,Path(native_behavior.__file__),protocol['docker_image'])
        (output/(control['id']+'.result.json')).write_text(json.dumps(result),encoding='utf-8')
        passed=(result.get('security_label')==control['expected_security'] and
                result.get('functionality')==control['expected_functionality'] and
                result.get('ambient_violation')==control['expected_ambient'])
        if not passed: errors.append(control['id'])
        print(control['id'],passed,result.get('security_label'),result.get('functionality'),flush=True)
    (output/'control-check.json').write_text(json.dumps(dict(status='FAILED' if errors else 'PASSED',errors=errors)),encoding='utf-8')
    if errors: raise RuntimeError(errors)


def analyze(inputs,output):
    """Frozen finite-panel estimands; descriptive intervals and sharp-null tests."""
    import itertools
    import numpy as np
    protocol=read_json(inputs/'protocol_json')
    tasks=read_json(inputs/'tasks_json'); assignments=read_json(inputs/'assignments_json')
    rows=read_json(output/'summary/results.json')
    by_slot={r['slot']:r for r in rows}
    assert len(by_slot)==len(assignments)==144
    endpoints=('secure_yield','security_coverage','security_unknown','ambient_violation','ambient_unknown',
               'core_pass','non_target_pass','basic_joint','contract_joint')
    values=np.zeros((12,6,2,len(endpoints)))
    task_idx={t['id']:i for i,t in enumerate(tasks)}
    raw_labels={arm:{} for arm in ARMS}
    for slot in assignments:
        row=by_slot[slot['slot']]
        assert all(row[k]==slot[k] for k in slot)
        if row['status'] in ('measurement_infrastructure_failed','administrative_not_attempted'):
            raise RuntimeError('Incomplete fixed panel blocks statistical estimates: '+slot['slot'])
        if row['status']=='returned':
            m=row['measurement']; assert m['status']=='measured'
            y=[m['secure_yield'],m['security_coverage'],int(m['security_label']=='unknown'),
               int(m['ambient_violation'] is True),int(m['ambient_violation'] is None),
               int(m['core_functionality']=='pass'),int(m['non_target']=='pass'),m['basic_joint'],m['contract_joint']]
            label=m['security_label']
        else:
            y=[0,0,1,0,1,0,0,0,0]; label='generation_or_envelope_failed'
        i=task_idx[slot['task_unit_id']]; a=ARMS.index(slot['arm'])
        values[i,a,slot['version']]=y
        raw_labels[slot['arm']][label]=raw_labels[slot['arm']].get(label,0)+1
    means=values.mean(axis=2)
    rng=np.random.default_rng(protocol['inference']['bootstrap_seed'])
    task_samples=rng.integers(0,12,(10000,12))
    blocks=[sorted({t['block'] for t in tasks}).index(t['block']) for t in tasks]
    block_values=np.stack([means[np.array(blocks)==b].mean(axis=0) for b in range(4)])
    block_samples=np.random.default_rng(202609270313).integers(0,4,(10000,4))
    signs=np.array(list(itertools.product((-1,1),repeat=12)))
    primary=[]
    for contrast in protocol['primary_contrasts']:
        e=endpoints.index(contrast['endpoint']); a=ARMS.index(contrast['treated']); b=ARMS.index(contrast['control'])
        d=means[:,a,e]-means[:,b,e]; estimate=float(d.mean())
        randomization=signs@d/12
        p=float(np.mean(np.abs(randomization)>=abs(estimate)-1e-12))
        boot=d[task_samples].mean(axis=1)
        bd=block_values[:,a,e]-block_values[:,b,e]
        block_boot=bd[block_samples].mean(axis=1)
        primary.append(dict(**contrast,estimate=estimate,raw_two_sided_sharp_null_p=p,
            task_percentile_95=np.quantile(boot,[.025,.975]).tolist(),
            block_percentile_95=np.quantile(block_boot,[.025,.975]).tolist(),task_differences=d.tolist()))
    previous=0.
    for rank,index in enumerate(sorted(range(3),key=lambda i:primary[i]['raw_two_sided_sharp_null_p'])):
        previous=max(previous,min(1.,(3-rank)*primary[index]['raw_two_sided_sharp_null_p']))
        primary[index]['holm_p']=previous
    result=dict(status='EXECUTED_FIXED_CONTROLLED_PANEL',tasks=12,blocks=4,assignments=144,
        endpoint_names=endpoints,arm_means={a:dict(zip(endpoints,means[:,i,:].mean(axis=0).tolist())) for i,a in enumerate(ARMS)},
        labels=raw_labels,primary_contrasts=primary,
        task_arm_means=[dict(task=t['name'],block=t['block'],arms={a:dict(zip(endpoints,means[i,j,:].tolist())) for j,a in enumerate(ARMS)}) for i,t in enumerate(tasks)],
        task_version_values=values.tolist(),
        limitations='Fixed author panel; no natural population, new-family transfer, TSG advantage or context-modifier inference. Percentile intervals are descriptive and not simultaneous.',
        analysis_implementation_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    target=output/'analysis.json'
    assert not target.exists()
    target.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(dict(arm_means=result['arm_means'],primary=result['primary_contrasts'])))


if __name__=='__main__':
    if sys.argv[1]=='prepare': prepare(Path(sys.argv[2]))
    elif sys.argv[1]=='controls': controls(Path(sys.argv[2]),Path(sys.argv[3]))
    elif sys.argv[1]=='analyze': analyze(Path(sys.argv[2]),Path(sys.argv[3]))
