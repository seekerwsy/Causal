from __future__ import annotations

import argparse
import hashlib
import json
from copy import deepcopy
from collections import defaultdict
from pathlib import Path

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from prompt_mechanism_study.artifact_io import read_json, verify_bundle, write_bundle
from prompt_mechanism_study.development.source_hypotheses import RUN_ROOT, SOURCE_ROOT, inventory
from prompt_mechanism_study.tsg.candidate_construction import (
    knowledge_add_candidate, source_participant_query, source_requirement_query, source_remove_candidate,
)


def source_audit(repo: Path) -> None:
    destination = repo / RUN_ROOT / "source-audit"
    if destination.exists():
        raise FileExistsError(destination)
    verify_bundle(repo / RUN_ROOT / "registration")
    selected = read_json(repo / RUN_ROOT / "registration/selection.json")["selected"]
    eligible, summary = inventory(repo)
    new_ids = {row["task_unit_id"] for row in eligible}
    source = [row for row in read_json(repo / SOURCE_ROOT / "tasks.json") if row["language"] == "python"]
    source.sort(key=lambda row: row["task_unit_id"])
    selected_by_id = {row["task_unit_id"]: row for row in selected}
    normalized = [" ".join(row["prompt"].split()) for row in source]
    exact = defaultdict(list)
    for row, prompt in zip(source, normalized, strict=True):
        exact[hashlib.sha256(prompt.encode()).hexdigest()].append(row["task_unit_id"])
    decisions = {}
    groups = []
    for digest, identities in exact.items():
        registered = [selected_by_id[key] for key in identities if key in selected_by_id]
        if not registered:
            continue
        registered.sort(key=lambda row: row["index"])
        exposed = [key for key in identities if key not in new_ids]
        canonical = registered[0]["task_unit_id"] if not exposed else None
        for row in registered:
            status = "prior_content_exposure" if exposed else (
                "duplicate_content" if row["task_unit_id"] != canonical else "content_unique_in_registered_frame")
            decisions[row["index"]] = dict(index=row["index"], task_unit_id=row["task_unit_id"],
                                          normalized_content_sha256=digest, status=status,
                                          representative_task_unit_id=canonical,
                                          historical_content_matches=exposed)
        if len(identities) > 1:
            groups.append(dict(normalized_content_sha256=digest, task_unit_ids=identities,
                               registered_indices=[row["index"] for row in registered],
                               historical_content_matches=exposed))

    # 相似度只产生人工复核清单，不依据分数认定独立性或挑选候选。
    vectorizer = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), lowercase=False)
    similarity = cosine_similarity(vectorizer.fit_transform(normalized))
    pairs = []
    for left in range(len(source)):
        for right in range(left + 1, len(source)):
            a, b = source[left]["task_unit_id"], source[right]["task_unit_id"]
            if a not in selected_by_id and b not in selected_by_id:
                continue
            if normalized[left] == normalized[right] or similarity[left, right] < 0.92:
                continue
            pairs.append(dict(left_task_unit_id=a, right_task_unit_id=b,
                              left_index=selected_by_id[a]["index"] if a in selected_by_id else None,
                              right_index=selected_by_id[b]["index"] if b in selected_by_id else None,
                              cosine_similarity=float(similarity[left, right]), decision="author_review_required"))
    report = dict(status="SOURCE_ONLY_CONTENT_AUDIT", outcomes_visible=False,
                  exact_rule="Whitespace normalization only; retain earliest registered index; any historical identity match excludes new-content status.",
                  similarity_rule="Character word-boundary TF-IDF 3-5 grams, cosine >=0.92 flags review only.",
                  inventory=summary, exact_groups=groups, similarity_review=pairs,
                  records=[decisions[index] for index in range(len(selected))])
    write_bundle(destination, {"audit.json": report})
    verify_bundle(destination)
    print(json.dumps(dict(exact_groups=len(groups), similarity_pairs=len(pairs),
                          excluded_indices=[row["index"] for row in report["records"]
                                            if row["status"] != "content_unique_in_registered_frame"],
                          similarity_review=pairs), ensure_ascii=False))


def prepare_case(repo: Path, index: int) -> None:
    root = repo / RUN_ROOT
    card = read_json(root / f"preparation/case-{index:04d}.json")
    selection = read_json(root / "registration/selection.json")["selected"][index]
    if card['index'] != index or card['representation'] != selection['representation']:
        raise ValueError('case does not match its frozen representation assignment')
    task = next(row for row in read_json(repo / SOURCE_ROOT / 'tasks.json')
                if row['task_unit_id'] == selection['task_unit_id'])
    prompt = task['prompt']
    baseline = prompt + '\n\n' + card['interface_adaptation']
    compiled = []
    for slot in card['candidate_slots']:
        if slot['status'] != 'eligible':
            compiled.append(slot)
            continue
        query, ablated = None, None
        if card['representation'] == 'TSG':
            query_function = source_requirement_query if slot['direction'] == 'REMOVE' else source_participant_query
            query = query_function(prompt, card['source_records'], **slot['query'])
            if query['state'] != 'supported':
                raise ValueError('eligible candidate lacks relational binding support')
            recipient = slot.get('binding_recipient', 'participants')
            if recipient not in {'participants', 'operation'}:
                raise ValueError('unknown direct recipient of the policy requirement')
            binding = dict(slot['binding'], targets=query['targets'] if recipient == 'participants' else [],
                           operations=query['operations'] if slot['direction'] == 'REMOVE' else [query['operation_id']])
            if slot['direction'] == 'REMOVE':
                binding['conditions'] = [row['concept']['definition'] for row in query['conditions']]
        elif card['representation'] == 'Raw':
            if card['source_records']['operations'] or card['source_records']['requirements']:
                raise ValueError('Raw preparation admits target quotations without a source relation graph')
            binding = slot['binding']
        else:
            raise ValueError('unknown preparation representation')
        if slot['direction'] not in {'ADD', 'REMOVE'}:
            raise ValueError('only Atomic ADD and REMOVE are active')
        compile_candidate = knowledge_add_candidate if slot['direction'] == 'ADD' else source_remove_candidate
        proposal = compile_candidate(source_prompt=prompt, source_records=card['source_records'],
                                     knowledge=slot['knowledge'], binding=binding, assessment=slot['assessment'])
        if proposal['decision'] != 'include':
            raise ValueError('authored candidate failed common binding validation')
        if binding['targets'] != slot['semantic_check']['complete_target_set']:
            raise ValueError('queried participants differ from authored semantic check')
        if len(slot['realizations']) != 3 or len({r['id'] for r in slot['realizations']}) != 3:
            raise ValueError('three distinct authored realizations are required')
        edited = []
        for realization in slot['realizations']:
            required = {'id', 'P', 'N', 'S', 'G'}
            if slot['direction'] == 'REMOVE':
                required.add('source_replacements')
            if set(realization) != required:
                raise ValueError('complete realization arms are required')
            arm_sources = {arm: prompt for arm in ('P', 'N', 'S', 'G')}
            if slot['direction'] == 'REMOVE':
                replacements = realization['source_replacements']
                if not replacements or any(set(row) != {'source', 'replacement'} for row in replacements):
                    raise ValueError('REMOVE needs explicit source-fragment substitutions')
                changed = prompt
                for replacement in replacements:
                    old = replacement['source']
                    if not old or changed.count(old) != 1:
                        raise ValueError('REMOVE source fragment must occur exactly once')
                    changed = changed.replace(old, replacement['replacement'], 1)
                if changed == prompt:
                    raise ValueError('REMOVE did not edit the source requirement')
                arm_sources.update(P=changed, G=changed)
            edited.append(dict(id=realization['id'], prompts={
                arm: arm_sources[arm]+'\n\n'+card['interface_adaptation']+'\n\n'+realization[arm]
                for arm in ('P', 'N', 'S', 'G')}))
        if query is not None:
            removed = deepcopy(card['source_records'])
            if slot['direction'] == 'REMOVE':
                requirement = next(row for row in removed['requirements'] if row['record_id'] == query['requirement_id'])
                requirement['subjects'], requirement['operations'], requirement['relations'] = [], [], []
                ablated = source_requirement_query(prompt, removed, **slot['query'])
            else:
                operation = next(row for row in removed['operations'] if row['record_id'] == query['operation_id'])
                operation['inputs'] = [row for row in operation['inputs'] if row['role'] != query['participant_role']]
                ablated = source_participant_query(prompt, removed, **slot['query'])
            if ablated['state'] != 'unresolved':
                raise ValueError('removed participant relations still supplied a binding')
        compiled.append(dict(slot=slot['slot'], status='prepared', proposal=proposal,
                             relation_query=query, relation_removal=ablated,
                             realization_prompts=edited,
                             semantic_check=slot['semantic_check']))
    destination = root / f'prepared/case-{index:04d}'
    if destination.exists():
        raise FileExistsError(destination)
    write_bundle(destination, {'case.json': dict(source=task, assignment=selection, author_card=card,
                                                baseline_prompt=baseline, candidates=compiled)})
    verify_bundle(destination)
    print(json.dumps(dict(index=index, prepared=sum(row['status']=='prepared' for row in compiled),
                          empty=sum(row['status']=='empty' for row in compiled),
                          model_outcomes_seen=False, output=str(destination))))


def qualification_inputs(repo: Path, family: str, untraced: bool = False, revision: str = '') -> None:
    root = repo / RUN_ROOT
    security_family = 'expression' if family == 'process-expression' else family
    tests = {name: (root / f'measurement/{security_family if name == "security" else family}-{name}.py').read_text(encoding='utf-8')
             for name in ('security', 'functionality')}
    control_family = 'apiurl' if family in {'apidomain', 'apiendpoint'} else family
    controls = (root / f'measurement/{control_family}-controls.py').read_text(encoding='utf-8')
    requests = {f'{name}.json': dict(code=controls, entry_point=name, tests=tests)
                for name in ('secure', 'vulnerable', 'reject_all', 'overrestrictive')}
    if family in {'apidomain', 'apiendpoint'}:
        requests['vulnerable.json']['entry_point'] = f'{"domain" if family == "apidomain" else "endpoint"}_vulnerable'
    if family == 'xpath':
        requests['alternate_predicate.json'] = dict(code=controls,
            entry_point='alternate_predicate', tests=tests)
    if untraced:
        requests = {name: dict(request, trace_assertions=False, channel_timeout_seconds=60)
                    for name, request in requests.items()}
    if revision not in {'', 'v2'}:
        raise ValueError('unknown qualification input revision')
    suffix = ('-untraced-60s' if untraced else '') + (f'-{revision}' if revision else '')
    write_bundle(root / f'measurement/{family}-qualification{suffix}-inputs', requests)
    print(json.dumps(dict(controls=list(requests), generated_model_calls=0)))


def select_execution_sources(repo: Path) -> None:
    root = repo / RUN_ROOT
    qualification = read_json(root / 'source-qualification.json')
    registered = read_json(root / 'registration/selection.json')['selected']
    indices = qualification['qualified_indices']
    if len(indices) != len(set(indices)) or any(index not in range(len(registered)) for index in indices):
        raise ValueError('source qualification contains duplicate or unregistered indices')
    excluded = set(qualification['out_of_language_scope'] + qualification['source_requires_simulated_external_dependency'])
    excluded.update(row['index'] for row in qualification['historical_content_exclusions'])
    excluded.update(index for group in qualification['semantic_duplicate_groups'] for index in group['excluded'])
    if excluded.intersection(indices):
        raise ValueError('qualified source overlaps an excluded semantic identity or scope')
    admitted = []
    counts = defaultdict(int)
    for row in registered:
        if row['index'] in indices and counts[row['role']] < 48:
            admitted.append(dict(row, source_origin=qualification['origin_classification'][row['source_lineage_id']]))
            counts[row['role']] += 1
    manifest = dict(status='SOURCE_PANEL_FIXED_BEFORE_GENERATION', tasks=admitted,
                    selection_rule=qualification['selection_rule'], role_counts=dict(counts),
                    required_per_role=48, natural_request_status='not_verified',
                    verified_untouched_natural_requests=0,
                    source_shortfall={role: 48-counts[role] for role in ('development', 'heldout')},
                    source_qualification=qualification)
    write_bundle(root / 'source-panel', {'panel.json': manifest})
    print(json.dumps(dict(tasks=len(admitted), role_counts=dict(counts),
                          heldout_indices=[row['index'] for row in admitted if row['role']=='heldout'],
                          verified_untouched_natural_requests=0)))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("source-audit", "prepare", "qualification-inputs", "select"))
    parser.add_argument("repo", type=Path)
    parser.add_argument("--index", type=int)
    parser.add_argument("--family", choices=('sqlite', 'header', 'dsa', 'xpath', 'xxe', 'redirect', 'mathweb', 'infopage', 'urlredirect', 'tarpath', 'expression', 'process-expression', 'upload', 'apidomain', 'apiendpoint', 'htmltext', 'sessionfull', 'queryparagraph', 'filetemplate', 'viewtemplate', 'jinjafile'), default='sqlite')
    parser.add_argument("--untraced", action='store_true')
    parser.add_argument("--revision", default='')
    args = parser.parse_args()
    if args.mode == 'source-audit':
        source_audit(args.repo.resolve())
    elif args.mode == 'qualification-inputs':
        qualification_inputs(args.repo.resolve(), args.family, args.untraced, args.revision)
    elif args.mode == 'select':
        select_execution_sources(args.repo.resolve())
    else:
        if args.index is None:
            raise ValueError('prepare requires a registered source index')
        prepare_case(args.repo.resolve(), args.index)


if __name__ == "__main__":
    main()
