import argparse
import ast
import json
from collections import Counter, defaultdict
from math import ceil, log
from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd
from scipy.stats import norm
from scipy.optimize import brentq
from scipy.special import logsumexp

from prompt_mechanism_study.artifact_io import file_sha256, read_json, verify_bundle, write_bundle


INPUT = Path('data/method/graph-guided-20260928')
RESULT = Path('results/graph-guided-20260928')
COHORTS = {
    'source_contract': ('heldout-independent-verification.json', 'heldout-execution-inputs', 'heldout-transfer-diagnostic'),
    'remaining': ('heldout-remaining-independent-verification.json', 'heldout-execution-inputs-remaining', 'heldout-remaining-diagnostic'),
    'regex_cost': ('heldout-performance-independent-verification.json', 'heldout-execution-inputs-performance', 'heldout-performance-diagnostic'),
}


def discovery_mean_interval(values, bounds, alpha):
    a, b = bounds
    if not a < b or not 0 < alpha < 1:
        raise ValueError('无效的效果范围或错误率')
    x = (np.asarray(values, dtype=float) - a) / (b - a)
    if x.ndim != 1 or not np.all(np.isfinite(x)) or not np.all((x >= 0) & (x <= 1)):
        raise ValueError('任务效果必须位于声明范围')
    if not len(x):
        return dict(lower=float(a), upper=float(b), n=0, status='UNASSESSED')
    mixture = np.array([0, .05, .10, .20, .35, .50, .65, .80, .95])
    threshold = log(2 / alpha)

    def lower_endpoint(observations):
        if not np.any(observations > 0):
            return 0.
        def equation(m):
            if m == 0:
                return float('inf')
            terms = np.log1p(mixture[:, None] * (observations[None, :] / m - 1))
            return float(logsumexp(terms.sum(axis=1)) - log(len(mixture)) - threshold)
        return max(0., brentq(equation, 0., 1., xtol=1e-13) - 1e-10)

    lower = a + (b - a) * lower_endpoint(x)
    upper = a + (b - a) * (1 - lower_endpoint(1 - x))
    assert lower <= upper
    return dict(lower=float(lower), upper=float(upper), n=len(x), status='EVALUABLE')


def discovery_missing_interval(lower_values, upper_values, bounds, alpha):
    lower_values = np.asarray(lower_values, dtype=float)
    upper_values = np.asarray(upper_values, dtype=float)
    if lower_values.shape != upper_values.shape or np.any(lower_values > upper_values):
        raise ValueError('缺失效果界限不一致')
    lower = discovery_mean_interval(lower_values, bounds, alpha)
    upper = discovery_mean_interval(upper_values, bounds, alpha)
    return dict(lower=lower['lower'], upper=upper['upper'], n=lower['n'],
                status=lower['status'], missing_tasks=int(np.count_nonzero(lower_values != upper_values)))


def discovery_shared_bounds(coefficients, outcomes):
    combined = defaultdict(float)
    for request_id, coefficient in coefficients:
        combined[request_id] += coefficient
    lower, upper = 0., 0.
    for request_id, coefficient in combined.items():
        if not coefficient:
            continue
        lo, hi = outcomes[request_id]
        if not 0 <= lo <= hi <= 1:
            raise ValueError('请求结果界限必须位于[0,1]')
        lower += coefficient * (lo if coefficient > 0 else hi)
        upper += coefficient * (hi if coefficient > 0 else lo)
    return lower, upper


def discovery_measurement_outcome(measurement, code_valid):
    if type(code_valid) is not bool:
        raise ValueError('代码有效性必须由独立语法检查提供')
    if measurement['status'] != 'measured':
        return dict(primary=[0., 1.], sensitivity=[0., 1.], security='missing',
                    functionality='unknown', valid=code_valid, joint_success=None,
                    reason='measurement_infrastructure_failed')
    channels = measurement['channels']
    if set(channels) != {'security', 'functionality'}:
        raise ValueError('测量渠道与冻结端点不一致')
    if any(row['status'] == 'worker_process_failed' for row in channels.values()):
        return dict(primary=[0., 1.], sensitivity=[0., 1.], security='missing',
                    functionality='unknown', valid=code_valid, joint_success=None,
                    reason='measurement_worker_failed')
    if any(row.get('phase') == 'load_test' and row['status'] == 'raised' for row in channels.values()):
        raise ValueError('独立测量程序加载失败，必须终止执行')
    invalid_channels = [row['status'] == 'invalid_code' for row in channels.values()]
    if any(invalid_channels) != (not code_valid):
        raise ValueError('独立语法检查与测量代码有效性不一致')
    if not code_valid:
        return dict(primary=[0., 0.], sensitivity=[0., 0.], security='unknown',
                    functionality='unknown', valid=False, joint_success=0, reason='invalid_code')
    security_channel, function_channel = channels['security'], channels['functionality']
    allowed = {'passed', 'raised', 'timeout', 'assertion_failed'}
    if any(row['status'] not in allowed for row in channels.values()):
        raise ValueError('未定义的测量状态')
    if security_channel['status'] == 'passed':
        security = security_channel['observation']['security_label']
        if security not in {'secure', 'insecure', 'unknown'}:
            raise ValueError('独立安全标签无效')
    else:
        security = 'unknown'
    functionality = (function_channel['observation']['functionality']
                     if function_channel['status'] == 'passed' else 'unknown')
    if functionality not in {'pass', 'fail', 'unknown'}:
        raise ValueError('独立功能标签无效')
    value = float(security == 'secure')
    joint = (1 if security == 'secure' and functionality == 'pass' else
             0 if security == 'insecure' or functionality == 'fail' else None)
    return dict(primary=[value, value], sensitivity=[value, value + float(security == 'unknown')],
                security=security, functionality=functionality, valid=True,
                reason='measured_' + security,
                joint_success=joint)


def discovery_panel_outcomes(inputs, output):
    verify_bundle(inputs)
    assignments = read_json(inputs / 'assignments.json')
    protocol = read_json(inputs / 'protocol.json')
    if protocol['protocol_id'] != 'tsg-discovery-development-20260929':
        raise ValueError('结果组装的协议身份不符')
    outcomes = {}
    for assignment in assignments:
        request_id = assignment['request_id']
        if request_id in outcomes:
            raise ValueError('请求身份重复')
        directory = output / assignment['slot']
        if not (directory / 'result').exists():
            outcomes[request_id] = dict(primary=[0., 1.], sensitivity=[0., 1.], security='missing',
                functionality='unknown', joint_success=None, valid=None, reason='assigned_response_missing')
            continue
        verify_bundle(directory / 'result')
        result = read_json(directory / 'result/result.json')
        for key in ('request_id', 'task_unit_id', 'policy_id', 'arm', 'version', 'seed', 'prompt_sha256'):
            if result[key] != assignment[key]:
                raise ValueError('请求和实际结果的身份绑定不符')
        status = result['status']
        if status in {'generation_no_code', 'generation_truncated'}:
            outcomes[request_id] = dict(primary=[0., 0.], sensitivity=[0., 0.], security='unknown',
                functionality='unknown', joint_success=0, valid=False, reason=status)
        elif status in {'infrastructure_failed', 'measurement_infrastructure_failed', 'not_run'}:
            outcomes[request_id] = dict(primary=[0., 1.], sensitivity=[0., 1.], security='missing',
                functionality='unknown', joint_success=None, valid=result.get('code_valid'), reason=status)
        elif status == 'returned':
            code_path = directory / 'code.py'
            if file_sha256(code_path) != result['code_sha256']:
                raise ValueError('实际代码身份不符')
            code = code_path.read_text(encoding='utf-8')
            try:
                ast.parse(code)
            except SyntaxError:
                valid = False
            else:
                valid = True
            if valid != result['code_valid'] or len(result['measurements']) != 1:
                raise ValueError('独立有效性或端点数量不符')
            measured = result['measurements'][0]
            if measured['family'] != assignment['measurements'][0]['family']:
                raise ValueError('测量端点身份不符')
            outcomes[request_id] = discovery_measurement_outcome(measured['measurement'], valid)
        else:
            raise ValueError('发现研究存在未定义的请求结果状态')
        outcomes[request_id].update(result_sha256=file_sha256(directory / 'result/manifest.json'),
                                    slot=assignment['slot'])
    return outcomes


def discovery_action_coefficients(task_id, action, assignments, bindings, use='open'):
    if action is None:
        return []
    if action['direction'] not in {-1, 1}:
        raise ValueError('动作方向必须在评价结果之前固定')
    matches = [row for row in bindings if row['task_unit_id'] == task_id
               and row['candidate_id'] == action['candidate_id'] and row['use'] == use]
    if len(matches) != 1:
        raise ValueError('动作与冻结候选绑定不一致')
    selected = [row for row in assignments if row['task_unit_id'] == task_id
                and row['policy_id'] == matches[0]['policy_id'] and row['arm'] in {'P', 'N'}]
    if len(selected) != 8:
        raise ValueError('政策必须保留全部八项分配')
    counts = Counter((row['arm'], row['version']) for row in selected)
    if counts != {('P', 0): 2, ('P', 1): 2, ('N', 0): 2, ('N', 1): 2}:
        raise ValueError('政策版本与seed分配不完整')
    return [(row['request_id'], action['direction'] * (.25 if row['arm'] == 'P' else -.25))
            for row in selected]


def discovery_task_vectors(assignments, bindings, decisions, outcomes, low_expected_task_ids):
    task_ids = {row['task_unit_id'] for row in assignments}
    if any(row['role'] != 'evaluation' for row in assignments):
        raise ValueError('主要比较只使用冻结评价面板')
    if len({row['request_id'] for row in assignments}) != len(assignments):
        raise ValueError('请求身份重复')
    if set(outcomes) != {row['request_id'] for row in assignments}:
        raise ValueError('结果必须包含全部分配，缺失请求须显式登记')
    if len(decisions) != len(task_ids) or {row['task_unit_id'] for row in decisions} != task_ids:
        raise ValueError('冻结动作必须覆盖全部评价任务')
    low_expected = set(low_expected_task_ids)
    if not low_expected.issubset(task_ids):
        raise ValueError('低预期集合包含面板外任务')
    vectors = {'T1': [], 'T2': [], 'T3': []}
    primary = {key: row['primary'] for key, row in outcomes.items()}
    sensitivity = {key: row['sensitivity'] for key, row in outcomes.items()}
    for decision in sorted(decisions, key=lambda row: row['task_unit_id']):
        task_id, actions = decision['task_unit_id'], decision['actions']
        contrasts = [('T1', 'tsg', 'raw'), ('T2', 'ridge', 'contract_mean')]
        for test, positive, negative in contrasts:
            first = discovery_action_coefficients(task_id, actions[positive], assignments, bindings)
            second = discovery_action_coefficients(task_id, actions[negative], assignments, bindings)
            coefficients = first + [(identity, -weight) for identity, weight in second]
            vectors[test].append(dict(task_unit_id=task_id,
                primary=list(discovery_shared_bounds(coefficients, primary)),
                sensitivity=list(discovery_shared_bounds(coefficients, sensitivity)),
                coefficients=coefficients))
        if task_id in low_expected:
            if actions['replication'] is None:
                raise ValueError('低预期任务缺少冻结复现动作')
            coefficients = discovery_action_coefficients(task_id, actions['replication'],
                                                         assignments, bindings, 'replication')
            vectors['T3'].append(dict(task_unit_id=task_id,
                primary=list(discovery_shared_bounds(coefficients, primary)),
                sensitivity=list(discovery_shared_bounds(coefficients, sensitivity)),
                coefficients=coefficients))
    return vectors


def discovery_primary_tables(vectors):
    tables = []
    for test, bounds, alpha in [('T1', (-2, 2), .02), ('T2', (-2, 2), .02), ('T3', (-1, 1), .01)]:
        rows = vectors[test]
        entry = dict(comparison=test, task_units=len(rows), bounds=bounds, alpha=alpha,
                     evidence_level='BOUNDED_DEVELOPMENT')
        for endpoint in ('primary', 'sensitivity'):
            lower = [row[endpoint][0] for row in rows]
            upper = [row[endpoint][1] for row in rows]
            entry[endpoint] = dict(mean_lower=float(np.mean(lower)) if rows else None,
                                  mean_upper=float(np.mean(upper)) if rows else None,
                                  interval=discovery_missing_interval(lower, upper, bounds, alpha))
        tables.append(entry)
    return tables


def discovery_evaluation_tables(repo, inputs, results, destination):
    frozen = repo / 'data/method/graph-guided-20260929/evaluation-preparation'
    verify_bundle(frozen)
    verify_bundle(inputs)
    protocol = read_json(inputs / 'protocol.json')
    if protocol['status'] != 'FROZEN_TSG_DISCOVERY_EVALUATION' or protocol['preparation_manifest_sha256'] != file_sha256(frozen / 'manifest.json'):
        raise ValueError('评价输入未绑定F1')
    assignments, bindings = read_json(inputs / 'assignments.json'), read_json(frozen / 'bindings.json')
    if assignments != read_json(frozen / 'assignments.json'):
        raise ValueError('评价请求表发生变化')
    decisions = read_json(frozen / 'decisions.json')
    outcomes = discovery_panel_outcomes(inputs, results)
    vectors = discovery_task_vectors(assignments, bindings, decisions, outcomes, protocol['low_expected_task_ids'])
    tables = discovery_primary_tables(vectors)
    endpoints = {name: {} for name in ('primary', 'sensitivity', 'code_validity', 'oracle_coverage', 'functionality', 'joint_success')}
    for request, outcome in outcomes.items():
        endpoints['primary'][request] = outcome['primary']
        endpoints['sensitivity'][request] = outcome['sensitivity']
        missing = outcome['security'] == 'missing'
        endpoints['code_validity'][request] = [0, 1] if outcome['valid'] is None else [int(outcome['valid'])] * 2
        coverage = int(outcome['security'] in {'secure', 'insecure'})
        endpoints['oracle_coverage'][request] = [0, 1] if missing else [coverage] * 2
        functionality = outcome['functionality']
        endpoints['functionality'][request] = ([0, 0] if outcome['valid'] is False else [1, 1] if functionality == 'pass'
                                              else [0, 0] if functionality == 'fail' else [0, 1])
        joint = outcome['joint_success']
        endpoints['joint_success'][request] = [0, 1] if joint is None else [joint] * 2
    effects = []
    for candidate in read_json(frozen / 'candidates.json'):
        task_id = candidate['task_unit_id']
        coefficients = discovery_action_coefficients(task_id,
            dict(candidate_id=candidate['candidate_id'], direction=1), assignments, bindings, candidate['use'])
        p = [(request, weight) for request, weight in coefficients if weight > 0]
        reference = [(row['request_id'], -.25) for row in assignments if row['task_unit_id'] == task_id and row['arm'] == 'R']
        if len(reference) != 4:
            raise ValueError('评价参考组不完整')
        effects.append(dict(index=candidate['index'], task_unit_id=task_id, candidate_id=candidate['candidate_id'],
            flow=candidate['flow'], use=candidate['use'], contract_id=candidate['contract_id'], target=candidate['target'],
            operation=candidate['contract']['operation'],
            pn={name: list(discovery_shared_bounds(coefficients, values)) for name, values in endpoints.items()},
            pr={name: list(discovery_shared_bounds(p + reference, values)) for name, values in endpoints.items()}))
    descriptive, actions = {}, []
    for decision in decisions:
        task_id = decision['task_unit_id']
        for name, action in decision['actions'].items():
            if name == 'replication' and action is not None:
                coefficients = discovery_action_coefficients(task_id, action, assignments, bindings, 'replication')
            elif name == 'adoption':
                reference = [(row['request_id'], -.25) for row in assignments if row['task_unit_id'] == task_id and row['arm'] == 'R']
                selected = discovery_action_coefficients(task_id, dict(action, direction=1), assignments, bindings) if action is not None else []
                coefficients = [(request, weight) for request, weight in selected if weight > 0] + reference if action is not None else []
            else:
                coefficients = discovery_action_coefficients(task_id, action, assignments, bindings)
            actions.append(dict(task_unit_id=task_id, selector=name, action=action, coefficients=coefficients,
                outcomes={endpoint: list(discovery_shared_bounds(coefficients, values)) for endpoint, values in endpoints.items()}))
    for first, second in [('relations', 'ridge'), ('relations', 'endpointless'), ('first', 'ridge'), ('random', 'ridge')]:
        entries = []
        for task in read_json(frozen / 'tasks.json'):
            left = next(row for row in actions if row['task_unit_id'] == task['task_unit_id'] and row['selector'] == first)
            right = next(row for row in actions if row['task_unit_id'] == task['task_unit_id'] and row['selector'] == second)
            coefficients = left['coefficients'] + [(request, -weight) for request, weight in right['coefficients']]
            entries.append(dict(task_unit_id=task['task_unit_id'], primary=list(discovery_shared_bounds(coefficients, endpoints['primary'])),
                                sensitivity=list(discovery_shared_bounds(coefficients, endpoints['sensitivity']))))
        descriptive[first + '_minus_' + second] = dict(evidence='EXPLORATORY_POINTWISE_95_PERCENT', vectors=entries,
            primary=discovery_missing_interval([row['primary'][0] for row in entries], [row['primary'][1] for row in entries], (-2, 2), .05))
    write_bundle(destination, {'identity.json': dict(status='BOUNDED_EVALUATION_TABLES_ASSEMBLED_INDEPENDENT_VERIFICATION_PENDING',
        input_manifest_sha256=file_sha256(inputs / 'manifest.json'), f1_manifest_sha256=file_sha256(frozen / 'manifest.json'),
        results_path=results.as_posix(), independent_human_review='PENDING_INDEPENDENT_REVIEW',
        whole_goal_acceptance='INCOMPLETE_INDEPENDENT_QUALITY_AND_LOW_EXPECTATION_REVIEW',
        structural_algorithm_winner='UNRESOLVED_POLICY_SELECTION_IS_A_SEPARATE_QUERY'),
        'outcomes.json': outcomes, 'vectors.json': vectors, 'tables.json': tables,
        'effects.json': effects, 'selector-values.json': actions, 'descriptive.json': descriptive,
        'slots.json': read_json(frozen / 'slots.json'), 'decisions.json': decisions})
    print(json.dumps(dict(tasks=len(decisions), requests=len(assignments), policies=len(effects),
                         primary_tables=tables, independent_human_review='PENDING_INDEPENDENT_REVIEW')))


def discovery_targeted_generation_tables(repo, inputs, results, destination):
    frozen = repo / 'data/method/graph-guided-20260929/targeted-generation-preparation'
    verify_bundle(frozen)
    verify_bundle(inputs)
    protocol = read_json(inputs / 'protocol.json')
    if (protocol['status'] != 'FROZEN_TSG_DISCOVERY_DEVELOPMENT'
            or protocol['preparation_manifest_sha256'] != file_sha256(frozen / 'manifest.json')):
        raise ValueError('定向生成未绑定冻结准备输入')
    assignments = read_json(inputs / 'assignments.json')
    if assignments != read_json(frozen / 'assignments.json'):
        raise ValueError('定向生成请求表发生变化')
    candidates, bindings, slots = (read_json(frozen / name) for name in ('candidates.json', 'bindings.json', 'slots.json'))
    outcomes = discovery_panel_outcomes(inputs, results)
    endpoints = {name: {} for name in ('primary', 'sensitivity', 'code_validity', 'oracle_coverage', 'functionality', 'joint_success')}
    for request, outcome in outcomes.items():
        endpoints['primary'][request] = outcome['primary']
        endpoints['sensitivity'][request] = outcome['sensitivity']
        endpoints['code_validity'][request] = [0, 1] if outcome['valid'] is None else [int(outcome['valid'])] * 2
        coverage = int(outcome['security'] in {'secure', 'insecure'})
        endpoints['oracle_coverage'][request] = [0, 1] if outcome['security'] == 'missing' else [coverage] * 2
        function = outcome['functionality']
        endpoints['functionality'][request] = ([0, 0] if outcome['valid'] is False else [1, 1] if function == 'pass'
                                               else [0, 0] if function == 'fail' else [0, 1])
        joint = outcome['joint_success']
        endpoints['joint_success'][request] = [0, 1] if joint is None else [joint] * 2
    effects, diagnostics = [], []
    for candidate in candidates:
        task_id = candidate['task_unit_id']
        coefficients = discovery_action_coefficients(task_id,
            dict(candidate_id=candidate['candidate_id'], direction=1), assignments, bindings)
        positive = [(request, weight) for request, weight in coefficients if weight > 0]
        negative = [(request, -weight) for request, weight in coefficients if weight < 0]
        reference = [(row['request_id'], .25) for row in assignments if row['task_unit_id'] == task_id and row['arm'] == 'R']
        if len(reference) != 4:
            raise ValueError('定向任务参考组分配不完整')
        effects.append(dict(index=candidate['index'], task_unit_id=task_id, candidate_id=candidate['candidate_id'],
            original_candidate_id=candidate['original_candidate_id'], flow=candidate['flow'], target=candidate['target'],
            operation=candidate['operation'], quality_qualified=candidate['quality_qualified'],
            pn={name: list(discovery_shared_bounds(coefficients, values)) for name, values in endpoints.items()},
            pr={name: list(discovery_shared_bounds(positive + [(request, -weight) for request, weight in reference], values))
                for name, values in endpoints.items()},
            arms={arm: dict(n=len(weights),
                security=dict(Counter(outcomes[request]['security'] for request, _ in weights)),
                functionality=dict(Counter(outcomes[request]['functionality'] for request, _ in weights)),
                endpoints={name: list(discovery_shared_bounds(weights, values)) for name, values in endpoints.items()})
                for arm, weights in [('P', positive), ('N', negative), ('R', reference)]}))
    for assignment in assignments:
        path = results / assignment['slot'] / 'result/result.json'
        result = read_json(path) if path.is_file() else None
        channels = result['measurements'][0]['measurement']['channels'] if result and result['status'] == 'returned' else {}
        diagnostics.append(dict(request_id=assignment['request_id'], slot=assignment['slot'], index=assignment['index'],
            arm=assignment['arm'], policy_id=assignment['policy_id'],
            status=result['status'] if result else 'assigned_response_missing',
            channels=channels, outcome=outcomes[assignment['request_id']]))
    summary = dict(status='EXECUTED_TARGETED_GENERATION_DESCRIPTIVE_ANALYSIS',
        tasks=len({row['task_unit_id'] for row in assignments}), fixed_positions=len(slots),
        materialized_policies=len(candidates), qualified_policies=sum(row['quality_qualified'] for row in candidates),
        missing_positions=sum(row['status'] == 'missing' for row in slots),
        assigned_requests=len(assignments), unique_policies=len({row['policy_id'] for row in bindings}),
        security=dict(Counter(row['security'] for row in outcomes.values())),
        functionality=dict(Counter(row['functionality'] for row in outcomes.values())),
        code_validity=dict(Counter(str(row['valid']) for row in outcomes.values())),
        joint_success=dict(Counter(str(row['joint_success']) for row in outcomes.values())),
        generation_status=dict(Counter(row['status'] for row in diagnostics)),
        qualified_direction_counts={comparison: dict(Counter('positive' if row[comparison]['primary'][0] > 0
            else 'negative' if row[comparison]['primary'][1] < 0 else 'zero' if row[comparison]['primary'] == [0., 0.]
            else 'unresolved' for row in effects if row['quality_qualified'])) for comparison in ('pn', 'pr')},
        interpretation='descriptive exposed-task effects; bounds cover unknown outcomes, not sampling uncertainty; no superiority or significance claim',
        measurement_interpretation=protocol['measurement_interpretation'],
        input_manifest_sha256=file_sha256(inputs / 'manifest.json'),
        preparation_manifest_sha256=file_sha256(frozen / 'manifest.json'),
        result_manifest_sha256=file_sha256(results / 'summary/manifest.json'),
        implementation_sha256=file_sha256(Path(__file__)))
    write_bundle(destination, {'summary.json': summary, 'outcomes.json': outcomes,
        'effects.json': effects, 'measurement-diagnostics.json': diagnostics, 'slots.json': slots})
    print(json.dumps(summary, ensure_ascii=False))


def discovery_validate_measurement_adapter(repo, destination):
    from prompt_mechanism_study.development.graph_guided_study import discovery_source_contracts

    directory = repo / 'data/method/graph-guided-20260929/measurement'
    discovery_source_contracts(repo)
    plan = read_json(directory.parent / 'source-execution-contracts.json')
    records = []
    for card in sorted(plan['contracts'], key=lambda row: row['family']):
        family, suffix = card['family'], card.get('qualification_suffix', '')
        contract = directory / f'{family}-qualification-contract{suffix}'
        verify_bundle(contract)
        if read_json(contract / 'identity.json')['family'] != family:
            raise ValueError('测量合同与当前来源端点身份不符')
        inputs = directory / f'{family}-qualification-inputs{suffix}'
        verify_bundle(inputs)
        result_root = repo / 'results/graph-guided-20260929' / f'{family}-qualification{suffix}'
        verify_bundle(result_root / 'verified')
        expected = read_json(contract / 'expected.json')
        for control, label in expected.items():
            request = read_json(inputs / f'{control}.json')
            ast.parse(request['code'])
            path = result_root / f'{control}.json'
            measured = read_json(path)
            outcome = discovery_measurement_outcome(measured, True)
            if outcome['security'] != label or outcome['primary'] != [float(label == 'secure')] * 2:
                raise ValueError('实际程序控制的端点组装不符')
            records.append(dict(family=family, control=control, outcome=outcome,
                                result_sha256=file_sha256(path),
                                request_sha256=file_sha256(inputs / f'{control}.json')))
    write_bundle(destination, {'observations.json': records, 'identity.json': dict(
        status='REAL_PROGRAM_OUTCOME_ADAPTER_VERIFIED', controls=len(records),
        endpoint_families=len({row['family'] for row in records}), model_calls=0,
        implementation_sha256=file_sha256(Path(__file__)),
        scope='Finite endpoint controls; no generated prompt effect or full program security claim.')})
    print(json.dumps(dict(status='REAL_PROGRAM_OUTCOME_ADAPTER_VERIFIED', controls=len(records))))


def discovery_structural_evidence(repo, destination):
    verify_bundle(repo / INPUT / 'algorithm-inputs')
    completion_root = repo / RESULT / 'algorithm-main/summary'
    verify_bundle(completion_root)
    completion = read_json(completion_root / 'completion.json')
    search_path = repo / RESULT / 'algorithm-main/searches.jsonl'
    if file_sha256(search_path) != completion['searches_sha256']:
        raise ValueError('历史结构搜索文件身份不符')
    searches = [json.loads(line) for line in search_path.read_text(encoding='utf-8').splitlines()]
    if len(searches) != completion['searches']:
        raise ValueError('历史搜索总数不符')
    grouped = defaultdict(list)
    for row in searches:
        grouped[row['scenario'], row['n'], row['method']].append(row)
    recount = []
    for (scenario, size, method), rows in sorted(grouped.items()):
        states = Counter(str(row['score']['xy_endpoints']) for row in rows)
        recount.append(dict(scenario=scenario, n=size, method=method,
            repetitions=len(rows), exact_xy=sum(row['score']['exact_xy_endpoints'] for row in rows),
            xy_states=dict(states),
            fixed_endpoint_error_runs=sum(row['score']['wrong_fixed_endpoints'] > 0 for row in rows)))
    reference = read_json(repo / RESULT / 'algorithm-main/independent-verification.json')
    reference_rows = {(row['scenario'], row['n'], row['method']): row for row in reference['summary']}
    for row in recount:
        previous = reference_rows[row['scenario'], row['n'], row['method']]
        for field in ('repetitions', 'exact_xy', 'xy_states', 'fixed_endpoint_error_runs'):
            if row[field] != previous[field]:
                raise ValueError(f'历史结果复算不符: {field}')
    # 两个非退化SCM具有完全相同的观测分布，X的干预效果不同。
    direct_covariance = np.array([[1., .4], [.4, 1.16]])
    latent_covariance = np.array([[.8**2 + .6**2, .8 * .5], [.8 * .5, .5**2 + .91]])
    np.testing.assert_allclose(direct_covariance, latent_covariance, atol=1e-15, rtol=0)
    latent_conditional_variance = .91 + .5**2 * (1 - .8**2)
    assert abs(latent_conditional_variance - 1) < 1e-15
    direct_effect = float(.5 * (norm.cdf(.4) - norm.cdf(0))
                          + .5 * (norm.cdf(.7) - norm.cdf(.3)))
    context_effect = float(norm.cdf(.3 / np.sqrt(1.16)) - .5)
    witness = dict(evidence='EXACT_MATHEMATICAL_NONIDENTIFIABILITY_WITNESS', model_calls=0,
        variables=dict(Z='independent Bernoulli(0.5) randomized context',
                       X='pre-edit source attribute unaffected by context',
                       Y='binary measured outcome: 1 if latent score > 0',
                       U_V_W='mutually independent standard normal variables, independent of Z'),
        scm_direct=dict(X='V', score='.4*X + .3*Z + W', Y='1[score>0]'),
        scm_latent=dict(X='.8*U + .6*V', score='.5*U + .3*Z + sqrt(.91)*W', Y='1[score>0]'),
        shared_observed_distribution=dict(X_given_Z='standard normal',
            Y_given_X_Z='Bernoulli(Phi(.4*X+.3*Z))', covariance_X_score_given_Z=direct_covariance.tolist(),
            conditional_score_variance=latent_conditional_variance),
        do_X_1_minus_0=dict(direct=direct_effect, latent=0.),
        do_Z_1_minus_0=dict(direct=context_effect, latent=context_effect),
        jci_conditions=dict(context_exogeneity=True, no_context_system_hidden_confounding=True),
        query_status='POLICY_EFFECT_IDENTIFIABLE_SOURCE_ATTRIBUTE_EFFECT_NOT_IDENTIFIABLE',
        interpretation='随机context的已知效果相同；编辑前X的干预效果不同。增加同分布样本不能区分这两个SCM。')
    queries = [dict(query='do(policy): frozen P versus N secure-code yield',
                    method='randomized task-unit ITT',
                    required='legal frozen policies, delivered assignment, independent measurement, task independence',
                    sample_support='prospective code-generation results pending',
                    decision='estimate assigned policy effects and their uncertainty'),
               dict(query='X to Y endpoint when context actually changes X',
                    method='FCI / JCI1 / JCI12 / GFCI historical simulation recount',
                    required='homogeneous variable meanings and justified JCI background constraints',
                    sample_support='320 simulated matrices, 1280 original searches; no new real model requests',
                    decision='report scenario-specific endpoint information; no universal algorithm winner'),
               dict(query='do(X): pre-edit source attribute when randomized context leaves X unchanged',
                    method='FCI / JCI-FCI / GFCI exact query witness',
                    required='additional identifying information that separates the two recorded SCMs',
                    sample_support='identical full observed distribution even with unlimited samples',
                    decision='not identifiable from the current randomized-context information alone')]
    write_bundle(destination, {'historical-recount.json': recount, 'exact-witness.json': witness,
        'queries.json': queries, 'identity.json': dict(
            status='RECOUNT_AND_EXACT_WITNESS_EXECUTED', new_model_calls=0, new_backend_searches=0,
            historical_searches=len(searches), historical_matrices=completion['completed_matrices'],
            searches_sha256=file_sha256(search_path),
            inputs_manifest_sha256=file_sha256(repo / INPUT / 'algorithm-inputs/manifest.json'),
            implementation_sha256=file_sha256(Path(__file__)))})
    print(json.dumps(dict(status='RECOUNT_AND_EXACT_WITNESS_EXECUTED',
                         historical_searches=len(searches), direct_do_X_effect=direct_effect,
                         latent_do_X_effect=0., shared_do_context_effect=context_effect)))


def build(repo, destination, stream=False, download=False):
    assert not download or stream
    sources = {row['index']: row for row in read_json(repo / INPUT / 'registration/sources.json')}
    panel = read_json(repo / INPUT / 'scaled-panel/selection.json')
    evidence, scope, contrasts, unknowns, policies = [], [], [], [], []
    assigned_tasks = set()
    cohorts = dict(COHORTS)
    if stream:
        cohorts['stream_budget'] = ('heldout-stream-independent-verification.json', 'heldout-execution-inputs-stream', 'heldout-stream-diagnostic')
    if download:
        cohorts['download_budget'] = ('heldout-download-independent-verification.json', 'heldout-execution-inputs-download', 'heldout-download-diagnostic')
    for cohort, (verification_name, input_name, output_name) in cohorts.items():
        verification = repo / RESULT / verification_name
        verified = read_json(verification)
        assert verified['status'] == 'verified'
        verify_bundle(repo / INPUT / input_name)
        assignments = read_json(repo / INPUT / input_name / 'assignments.json')
        assert len(assignments) == verified['assignments'] == len(verified['records'])
        assert file_sha256(repo / INPUT / input_name / 'manifest.json') == verified['input_manifest_sha256']
        tasks = {row['index'] for row in verified['records']}
        assert not assigned_tasks.intersection(tasks)
        assigned_tasks.update(tasks)
        evidence.append(dict(cohort=cohort, path=str(verification.relative_to(repo)), sha256=file_sha256(verification),
                             input_manifest_sha256=verified['input_manifest_sha256'], independent_function='heldout-verify.main'))
        scope.append(dict(cohort=cohort, task_units=len(tasks), calls=len(assignments),
                          source_lineages=dict(Counter(sources[index]['source_lineage_id'] for index in tasks)),
                          representations=dict(Counter(sources[index]['representation'] for index in tasks)),
                          security=verified['security_labels'], functionality=verified['functionality_labels']))
        groups = defaultdict(list)
        for row in verified['records']:
            groups[row['index'], row['candidate_slot'], row['arm']].append(row)
            if row['security'] != 'unknown':
                continue
            result = read_json(repo / RESULT / output_name / row['slot'] / 'result/result.json')
            channel = result['measurements'][0]['measurement']['channels']['security'] if result['status'] == 'returned' else {}
            unknowns.append(dict(cohort=cohort, index=row['index'], slot=row['slot'], arm=row['arm'],
                                 candidate_slot=row['candidate_slot'], channel_status=channel.get('status', result['status']),
                                 functionality=row['functionality']))
        for index in sorted(tasks):
            for candidate in (0, 2):
                p = groups[index, candidate, 'P']
                assert len(p) == 3
                for comparison in ('N', 'R'):
                    n = groups[index, candidate if comparison == 'N' else None, comparison]
                    assert len(n) == 3
                    delta = np.mean([row['secure_yield'] for row in p])-np.mean([row['secure_yield'] for row in n])
                    p_unknown = sum(row['security'] == 'unknown' for row in p)/3
                    n_unknown = sum(row['security'] == 'unknown' for row in n)/3
                    contrasts.append(dict(cohort=cohort, index=index, task_unit_id=sources[index]['task_unit_id'],
                        source_lineage_id=sources[index]['source_lineage_id'], representation=sources[index]['representation'],
                        candidate_slot=candidate, comparison='P_minus_'+comparison, secure_yield_difference=float(delta),
                        functional_yield_difference=float(np.mean([row['functional_yield'] for row in p])-np.mean([row['functional_yield'] for row in n])),
                        joint_yield_difference=float(np.mean([row['joint_yield'] for row in p])-np.mean([row['joint_yield'] for row in n])),
                        unknown_effect_lower=float(delta-n_unknown), unknown_effect_upper=float(delta+p_unknown)))
        policies.extend(dict(cohort=cohort, **row) for row in verified['policy_rows'])
    aggregate = []
    for cohort in (*cohorts, 'all_executed'):
        for candidate in (0, 2):
            for comparison in ('P_minus_N', 'P_minus_R'):
                rows = [row for row in contrasts if row['candidate_slot'] == candidate and row['comparison'] == comparison
                        and (cohort == 'all_executed' or row['cohort'] == cohort)]
                aggregate.append(dict(cohort=cohort, candidate_slot=candidate, comparison=comparison, task_units=len(rows),
                    **{field: float(np.mean([row[field] for row in rows])) for field in
                       ('secure_yield_difference', 'functional_yield_difference', 'joint_yield_difference',
                        'unknown_effect_lower', 'unknown_effect_upper')},
                    inference='descriptive_exploratory; cohorts have different endpoint definitions'))
    policy_table = []
    for cohort in (*cohorts, 'all_executed'):
        selected = [row for row in policies if cohort == 'all_executed' or row['cohort'] == cohort]
        keyed = {(row['index'], row['method']): row for row in selected}
        tasks = sorted({row['index'] for row in selected})
        for method in sorted({row['method'] for row in selected}):
            rows = [keyed[index, method] for index in tasks]
            policy_table.append(dict(cohort=cohort, method=method, task_units=len(tasks),
                **{field: float(np.mean([row[field] for row in rows])) for field in ('secure_yield', 'functional_yield', 'joint_yield')},
                action_agreement_with_tsg=sum(keyed[index, method]['action'] == keyed[index, 'tsg_ridge']['action'] for index in tasks)/len(tasks),
                security_difference_from_tsg=float(np.mean([keyed[index, method]['secure_yield']-keyed[index, 'tsg_ridge']['secure_yield'] for index in tasks])),
                inference='descriptive_exploratory; fixed training rules; no population equivalence claim'))
    privacy_root = repo / RESULT / 'privacy-property-review-verification'
    verify_bundle(privacy_root)
    privacy = read_json(privacy_root / 'verification.json')
    assert privacy['status'] == 'verified_exploratory_sensitivity' and privacy['requests'] == 105
    evidence.append(dict(cohort='privacy_sensitivity', path=str((privacy_root / 'verification.json').relative_to(repo)),
                         sha256=file_sha256(privacy_root / 'verification.json'), independent_function='source-measurement-review.verify'))
    residual = [dict(index=row['index'], role=row['role'], representation=row['representation'])
                for row in panel if row['role'] == 'heldout' and row['index'] not in assigned_tasks]
    additional = int(stream)+int(download)
    heldout_count, heldout_calls = 30+additional, 630+21*additional
    code_calls = 1059+21*additional
    assert len(panel) == 52 and len(assigned_tasks) == heldout_count and len(residual) == 6-additional
    files = {
        'coverage.json': dict(fixed_panel=52, executed_development=14, executed_heldout=heldout_count,
                             heldout_calls=heldout_calls, development_calls=413, exposed_canary_calls=16,
                             total_code_calls=code_calls, unexecuted_heldout=residual, cohorts=scope),
        'evidence.json': evidence,
        'task_contrasts.json': contrasts,
        'category_contrasts.json': aggregate,
        'policy_values.json': policy_table,
        'unknowns.json': unknowns,
        'privacy_sensitivity.json': dict(summary=privacy['summary'], effects=privacy['effects']),
        'interpretation.json': dict(status='DESCRIPTIVE_EXPLORATORY_TABLES', formal_protocol='SPECIFIED_DRAFT',
            complete_original_primary_analysis=False,
            reason='Original quality review and full fixed-population outcomes are unavailable; endpoint sensitivities remain post-outcome.',
            code_generation_role='Qwen2.5-Coder-32B-Instruct generation only',
            independent_unit='deduplicated task', unknowns_in_primary_denominator=True,
            tsg_relations='source semantics', implementation_function='graph_guided_report.build'),
    }
    if destination.exists():
        verify_bundle(destination)
        assert all(read_json(destination / name) == value for name, value in files.items())
    else:
        write_bundle(destination, files)
    print(dict(status='verified_descriptive_tables', code_calls=code_calls, heldout_tasks=heldout_count,
               tsg_policy_tasks=15, unknown_records=len(unknowns), output=str(destination)))


def diagnose(repo, destination, stream=False, download=False):
    assert not download or stream
    sources = {row['index']: row for row in read_json(repo / INPUT / 'registration/sources.json')}
    expressions, controls, policies, evidence = [], [], [], []
    development = (
        ('development_first', 'development-seven-task-independent-verification.json', 'development-execution-inputs-v2'),
        ('development_second', 'development-second-seven-independent-verification.json', 'development-execution-inputs-batch2'),
    )
    studies = [(*row, 2) for row in development]
    cohorts = dict(COHORTS)
    if stream:
        cohorts['stream_budget'] = ('heldout-stream-independent-verification.json', 'heldout-execution-inputs-stream', 'heldout-stream-diagnostic')
    if download:
        cohorts['download_budget'] = ('heldout-download-independent-verification.json', 'heldout-execution-inputs-download', 'heldout-download-diagnostic')
    studies.extend((cohort, verification, inputs, 3) for cohort, (verification, inputs, _) in cohorts.items())
    for cohort, verification_name, inputs_name, repeats in studies:
        verified_path = repo / RESULT / verification_name
        verified = read_json(verified_path)
        assert verified['status'] == 'verified'
        inputs_root = repo / INPUT / inputs_name
        verify_bundle(inputs_root)
        assert file_sha256(inputs_root / 'manifest.json') == verified['input_manifest_sha256']
        protocol = read_json(inputs_root / 'protocol.json')
        assignments = {row['slot']: row for row in read_json(inputs_root / 'assignments.json')}
        assert len(assignments) == verified['assignments'] == len(verified['records'])
        keyed = {}
        for row in verified['records']:
            assigned = assignments[row['slot']]
            assert all(assigned[field] == row[field] for field in ('index', 'version', 'arm', 'candidate_slot'))
            assert (row['index'], row['candidate_slot'], row['version'], row['arm']) not in keyed
            keyed[row['index'], row['candidate_slot'], row['version'], row['arm']] = row
        tasks = sorted({row['index'] for row in verified['records']})
        for index in tasks:
            if repeats == 2:
                case_root = repo / INPUT / f'prepared/case-{index:04d}'
            else:
                settings = protocol['case_manifests'][str(index)]
                case_root = Path(settings['path'])
                if not case_root.is_absolute():
                    case_root = repo / case_root
            verify_bundle(case_root)
            if repeats == 3:
                assert file_sha256(case_root / 'manifest.json') == settings['manifest_sha256']
            case = read_json(case_root / 'case.json')
            for candidate in case['candidates']:
                slot = candidate['slot']
                versions = sorted(version for identity, number, version, arm in keyed
                                  if identity == index and number == slot and arm == 'P')
                assert len(versions) == repeats
                differences = []
                for version in versions:
                    p, n = keyed[index, slot, version, 'P'], keyed[index, slot, version, 'N']
                    p_assignment, n_assignment = assignments[p['slot']], assignments[n['slot']]
                    assert p_assignment['seed'] == n_assignment['seed']
                    realization = candidate['realizations'][int(version[1:])-1]['prompts']
                    assert p_assignment['prompt'] == realization['P'] and n_assignment['prompt'] == realization['N']
                    difference = p['secure_yield']-n['secure_yield']
                    differences.append(difference)
                    expressions.append(dict(cohort=cohort, index=index, candidate_slot=slot, version=version,
                        seed=p_assignment['seed'], operation=candidate['hypothesis']['operation'],
                        category=candidate['hypothesis']['category'], representation=case['source']['representation'],
                        security_difference=difference, P_security=p['security'], N_security=n['security'],
                        functionality_difference=int(p['functionality'] == 'pass')-int(n['functionality'] == 'pass'),
                        full_prompt_word_difference=len(p_assignment['prompt'].split())-len(n_assignment['prompt'].split())))
                original = next(row for row in verified['effects'] if row['index'] == index and row['slot'] == slot)
                expected = original['P_minus_N'] if repeats == 2 else original['comparisons']['P_minus_N']['secure_yield']
                assert np.isclose(np.mean(differences), expected, rtol=0, atol=1e-12)
            if repeats == 3:
                for arm in ('R', 'S', 'G'):
                    rows = [row for key, row in keyed.items() if key[0] == index and key[1] is None and key[3] == arm]
                    assert len(rows) == 3
                    controls.append(dict(cohort=cohort, index=index, representation=sources[index]['representation'], arm=arm,
                        secure_yield=float(np.mean([row['secure_yield'] for row in rows])),
                        functional_yield=float(np.mean([row['functional_yield'] for row in rows])),
                        joint_yield=float(np.mean([row['joint_yield'] for row in rows]))))
        if repeats == 3:
            policies.extend(dict(cohort=cohort, **row) for row in verified['policy_rows'])
        evidence.append(dict(cohort=cohort, verification_sha256=file_sha256(verified_path),
                             input_manifest_sha256=verified['input_manifest_sha256']))
    candidates = []
    grouped = defaultdict(list)
    for row in expressions:
        grouped[row['cohort'], row['index'], row['candidate_slot']].append(row)
    for (cohort, index, slot), rows in grouped.items():
        values = [row['security_difference'] for row in rows]
        status = ('opposite_nonzero_directions' if min(values) < 0 < max(values) else
                  'all_zero' if not any(values) else
                  'all_strict_positive' if min(values) > 0 else
                  'all_strict_negative' if max(values) < 0 else 'zero_and_one_nonzero_direction')
        candidates.append(dict(cohort=cohort, index=index, candidate_slot=slot, category=rows[0]['category'],
                               operation=rows[0]['operation'], representation=rows[0]['representation'],
                               realizations=len(rows), mean_P_minus_N=float(np.mean(values)), direction_status=status))
    operation_coverage = []
    for operation in sorted({row['operation'] for row in candidates}):
        rows = [row for row in candidates if row['operation'] == operation]
        operation_coverage.append(dict(operation=operation, candidates=len(rows), task_units=len({row['index'] for row in rows}),
            development_candidates=sum(row['cohort'].startswith('development') for row in rows),
            heldout_candidates=sum(not row['cohort'].startswith('development') for row in rows),
            directions=dict(Counter(row['direction_status'] for row in rows))))
    common_controls = []
    for population in ('all_executed_heldout', 'TSG_common_candidates'):
        selected = [row for row in controls if population == 'all_executed_heldout' or row['representation'] == 'TSG']
        task_count = len({row['index'] for row in selected})
        keyed_controls = {(row['index'], row['arm']): row for row in selected}
        for arm in ('R', 'S', 'G'):
            rows = [row for row in selected if row['arm'] == arm]
            common_controls.append(dict(population=population, arm=arm, task_units=task_count,
                **{field: float(np.mean([row[field] for row in rows])) for field in ('secure_yield', 'functional_yield', 'joint_yield')},
                secure_difference_from_R=float(np.mean([row['secure_yield']-keyed_controls[row['index'], 'R']['secure_yield'] for row in rows]))))
    task_ids = sorted({row['index'] for row in policies})
    policy_by_key = {(row['index'], row['method']): row for row in policies}
    tsg_controls = {(row['index'], row['arm']): row for row in controls if row['representation'] == 'TSG'}
    for arm in ('S', 'G'):
        for index in task_ids:
            policy_by_key[index, 'fixed_'+arm] = dict(**tsg_controls[index, arm], method='fixed_'+arm, action=arm)
    methods = sorted({method for _, method in policy_by_key})
    pairwise = []
    for first in methods:
        for second in methods:
            pairwise.append(dict(first=first, second=second, task_units=len(task_ids),
                action_agreement=sum(policy_by_key[index, first]['action'] == policy_by_key[index, second]['action'] for index in task_ids)/len(task_ids),
                **{field+'_difference': float(np.mean([policy_by_key[index, first][field]-policy_by_key[index, second][field]
                                                       for index in task_ids])) for field in ('secure_yield', 'functional_yield', 'joint_yield')}))
    files = {
        'protocol.json': dict(status='POST_OUTCOME_DESCRIPTIVE_DIAGNOSTICS', formal_protocol='SPECIFIED_DRAFT',
            function='graph_guided_report.diagnose', evidence=evidence, independent_unit='deduplicated task',
            expression_interpretation='One generation seed per expression; wording and generation variation cannot be separated.',
            controls_interpretation='S and G are actual fixed arms; matching does not assume N or S have zero effect.',
            primary_result_policy='Frozen outcomes, nominations, selectors and their inference remain unchanged.'),
        'expressions.json': expressions, 'candidate_directions.json': candidates,
        'operation_coverage.json': operation_coverage, 'control_values.json': common_controls,
        'pairwise_policy_values.json': pairwise,
    }
    if destination.exists():
        verify_bundle(destination)
        assert all(read_json(destination / name) == value for name, value in files.items())
    else:
        write_bundle(destination, files)
    print(dict(status='verified_descriptive_diagnostics', candidates=len(candidates), expression_pairs=len(expressions),
               tsg_policy_tasks=len(task_ids), method_pairs=len(pairwise),
               direction_counts=dict(Counter(row['direction_status'] for row in candidates))))


def audit_precision(repo, destination, stream=False, download=False):
    assert not download or stream
    table_name = 'research-tables-download' if download else 'research-tables-stream' if stream else 'research-tables'
    table = repo / RESULT / table_name
    verify_bundle(table)
    coverage = read_json(table / 'coverage.json')
    contrasts = read_json(table / 'task_contrasts.json')
    evidence = read_json(table / 'evidence.json')
    sources = {row['index']: row for row in read_json(repo / INPUT / 'registration/sources.json')}
    vectors, methods, records = defaultdict(dict), defaultdict(dict), defaultdict(list)
    for row in evidence:
        path = repo / row['path']
        assert file_sha256(path) == row['sha256']
        if row['cohort'] == 'privacy_sensitivity':
            continue
        verified = read_json(path)
        assert verified['status'] == 'verified'
        for record in verified['records']:
            records[record['index'], record['candidate_slot'], record['arm']].append(record)
        for policy in verified['policy_rows']:
            if policy['method'] in ('tsg_ridge', 'text_ridge'):
                methods[policy['index']][policy['method']] = policy
    for row in contrasts:
        if row['comparison'] != 'P_minus_N':
            continue
        vectors[row['index']]['ordinary_'+str(row['candidate_slot'])] = {
            'difference': row['secure_yield_difference'],
            'behavior_lower': row['unknown_effect_lower'],
            'behavior_upper': row['unknown_effect_upper']}
    for index, choices in methods.items():
        assert set(choices) == {'tsg_ridge', 'text_ridge'}
        unknown = {}
        for method, policy in choices.items():
            action = policy['action']
            slot = int(action.split(':')[1]) if action.startswith('P:') else None
            selected = records[index, slot, 'P' if slot is not None else 'R']
            assert len(selected) == 3
            assert np.isclose(np.mean([row['secure_yield'] for row in selected]), policy['secure_yield'])
            unknown[method] = sum(row['security'] == 'unknown' for row in selected)/3
        difference = choices['tsg_ridge']['secure_yield']-choices['text_ridge']['secure_yield']
        vectors[index]['tsg_minus_text'] = dict(difference=difference,
            behavior_lower=difference-unknown['text_ridge'], behavior_upper=difference+unknown['tsg_ridge'])
    assert len(vectors) == coverage['executed_heldout']
    strata = defaultdict(list)
    for index in sorted(vectors):
        assert {'ordinary_0', 'ordinary_2'} <= set(vectors[index])
        strata[sources[index]['source_lineage_id'], sources[index]['representation']].append(index)
    queries = ('ordinary_0', 'ordinary_2', 'tsg_minus_text')
    draws = {query: [] for query in queries}
    rng = np.random.default_rng(20260928)
    for _ in range(10000):
        sampled = [int(index) for stratum in sorted(strata)
                   for index in rng.choice(strata[stratum], len(strata[stratum]), replace=True)]
        for query in queries:
            values = [vectors[index][query]['difference'] for index in sampled if query in vectors[index]]
            assert values
            draws[query].append(float(np.mean(values)))
    rows = []
    critical = float(norm.ppf(1-.05/(2*4)))
    for query in queries:
        values = [row[query] for row in vectors.values() if query in row]
        effects = [row['difference'] for row in values]
        interval = np.quantile(draws[query], [.00625, .99375]).tolist()
        rows.append(dict(comparison=query, task_units=len(values), mean=float(np.mean(effects)),
            observed_task_sd=float(np.std(effects, ddof=1)), exploratory_interval_98_75=interval,
            degenerate_interval=interval[0] == interval[1],
            observed_unknown_behavior_bounds=[float(np.mean([row[field] for row in values]))
                                             for field in ('behavior_lower', 'behavior_upper')],
            normal_worst_sd1_half_width=critical/np.sqrt(len(values)),
            independent_bounded_contrast_Hoeffding_half_width=min(2., np.sqrt(2*log(2*4/.05)/len(values))),
            inference='Post-outcome precision diagnostic on executed tasks; incomplete original study; no significant-effect or equivalence declaration.'))
    rows.append(dict(comparison='TSG_minus_Raw_hypothesis_quality', task_units=None,
                     status='NOT_COMPUTED_INDEPENDENT_SEMANTIC_REVIEW_MISSING'))
    counts = [dict(source=lineage, representation=representation, task_units=len(indices),
                   indices=indices, normal_worst_sd1_half_width=critical/np.sqrt(len(indices)))
              for (lineage, representation), indices in sorted(strata.items())]
    planning = [dict(assumed_independent_task_sd=sd, effect=.10, target_power=.80,
                     approximate_task_units=ceil(((critical+norm.ppf(.8))*sd/.1)**2),
                     status='illustrative_normal_planning_only_not_observed_power') for sd in (.25, .5, 1.)]
    files = {'protocol.json': dict(status='POST_OUTCOME_PRECISION_DIAGNOSTIC', formal_protocol='SPECIFIED_DRAFT',
        function='graph_guided_report.audit_precision', comparison_family_positions=4,
        reserved_missing_comparison='TSG_minus_Raw_hypothesis_quality', bootstrap_draws=10000,
        seed=20260928, strata='source_lineage_id and frozen representation allocation',
        scope='All executed heldout tasks, retaining all assigned requests; policy comparison uses its fifteen common TSG tasks.',
        interpretation='The original independent quality review and full fixed panel remain incomplete. This calculation does not recover pre-generation precision planning or authorize confirmatory interpretation.',
        table_manifest_sha256=file_sha256(table / 'manifest.json'),
        generated_outcomes_relabelled=False, new_model_calls=0, new_structure_searches=0),
        'comparisons.json': rows, 'task_vectors.json': {str(index): row for index, row in sorted(vectors.items())},
        'strata.json': counts, 'planning_scenarios.json': planning}
    if destination.exists():
        verify_bundle(destination)
        assert all(read_json(destination / name) == value for name, value in files.items())
    else:
        write_bundle(destination, files)
    print(dict(status='POST_OUTCOME_PRECISION_DIAGNOSTIC', comparisons=rows, planning=planning, strata=counts))


def audit_features(repo, destination, stream=False):
    from prompt_mechanism_study.development.graph_guided_decisions import case_row, feature_model

    policy_root = repo / INPUT / 'heldout-policy-decisions'
    verify_bundle(policy_root)
    protocol = read_json(policy_root / 'protocol.json')
    training = read_json(policy_root / 'development.json')
    cv = read_json(policy_root / 'cross-validation.json')
    fields = protocol['feature_categorical']+protocol['feature_numeric']
    populations = {'training': training, 'evaluation': []}
    scores, hashes = {}, []
    for suffix in ('', '-remaining', '-performance'):
        directory = repo / INPUT / ('heldout-policy-decisions'+suffix)
        verify_bundle(directory)
        populations['evaluation'].extend(read_json(directory / 'heldout-source.json'))
        for row in read_json(directory / 'decisions.json'):
            scores[row['index']] = row['scores']
        hashes.append(dict(path=str(directory.relative_to(repo)), manifest_sha256=file_sha256(directory / 'manifest.json')))
    assert len(training) == 14 and len(populations['evaluation']) == 30
    profiles, bindings = [], []
    for population, rows in populations.items():
        grouped = defaultdict(list)
        for row in rows:
            grouped[tuple(row[field] for field in fields)].append(row)
            suffix = '-v2' if row['index'] in (38, 206) else ''
            directory = repo / INPUT / f"prepared/case-{row['index']:04d}{suffix}"
            verify_bundle(directory)
            case = read_json(directory / 'case.json')
            candidate = next(value for value in case['candidates'] if value['slot'] == row['slot'])
            derived = case_row(case, candidate)
            assert all(derived[field] == row[field] for field in fields)
            target = candidate['target']
            nodes = {value['id']: value for value in case['targets']['nodes']}
            relations = {value['id']: value for value in case['targets']['relations']}
            graph = nx.Graph()
            graph.add_nodes_from(target['nodes'])
            for relation in target['relations']:
                edge = relations[relation]
                assert edge['from'] in target['nodes'] and edge['to'] in target['nodes']
                graph.add_edge(edge['from'], edge['to'])
            assert nx.is_connected(graph)
            bindings.append(dict(population=population, index=row['index'], candidate_slot=row['slot'],
                selected_nodes=target['nodes'], selected_relations=target['relations'],
                selected_relation_types=sorted({relations[edge]['type'] for edge in target['relations']}),
                full_relation_types=sorted({edge['type'] for edge in case['targets']['relations']}),
                node_quotes=[nodes[node]['quote'] for node in target['nodes']],
                source_meaning_used_by_selector=False, exact_selected_relations_connected=True))
        for number, (signature, members) in enumerate(sorted(grouped.items())):
            values = [row['P_minus_R'] for row in members] if population == 'training' else []
            predictions = {}
            if population == 'evaluation':
                for mode in ('tsg_ridge', 'two_arm_ridge', 'tsg_forest'):
                    actual = [scores[row['index']][mode][str(row['slot'])] for row in members]
                    assert np.isclose(min(actual), max(actual), rtol=0, atol=1e-12)
                    predictions[mode] = dict(minimum=min(actual), maximum=max(actual))
            profiles.append(dict(population=population, profile=number,
                features=dict(zip(fields, signature, strict=True)),
                members=[dict(index=row['index'], candidate_slot=row['slot']) for row in members],
                candidate_count=len(members), distinct_task_units=len({row['task_unit_id'] for row in members}),
                training_effect_range=[min(values), max(values)] if values else None,
                predictions=predictions))
    transform = feature_model('tsg_ridge', protocol['tuning']['tsg_ridge']).named_steps['features']
    matrix = transform.fit_transform(pd.DataFrame(training))
    tuning = [dict(mode=mode, candidates=len(evaluations),
                   selected=protocol['tuning'][mode],
                   validation_gains=[row['mean_gain'] for row in evaluations],
                   nonzero_validation_gains=sum(row['mean_gain'] != 0 for row in evaluations))
              for mode, evaluations in cv.items()]
    varying = {field: sorted({row[field] for row in training}) for field in fields}
    summary = dict(status='POST_OUTCOME_FEATURE_AND_BINDING_DIAGNOSTIC', formal_protocol='SPECIFIED_DRAFT',
        training_task_units=7, training_candidates=14, evaluation_task_units=15, evaluation_candidates=30,
        graph_feature_fields=fields, unique_profiles={population: sum(row['population'] == population for row in profiles)
                                                      for population in populations},
        encoded_training_shape=list(matrix.shape), encoded_training_rank=int(np.linalg.matrix_rank(matrix)),
        nonzero_training_effects=[dict(index=row['index'], candidate_slot=row['slot'], P_minus_R=row['P_minus_R'])
                                 for row in training if row['P_minus_R'] != 0],
        constant_training_fields=[field for field, values in varying.items() if len(values) == 1],
        bindings_checked=len(bindings), independent_semantic_review=False,
        interpretation='Exact structural descriptors omit source meanings, quotes and endpoint-specific semantics. Equal descriptors imply equal predictions; this diagnostic does not establish missing causal effects or semantic correctness.',
        frozen_policy_changed=False, implementation_function='graph_guided_report.audit_features')
    files = {'summary.json': summary, 'profiles.json': profiles, 'bindings.json': bindings,
             'tuning.json': tuning, 'evidence.json': hashes}
    if destination.exists():
        verify_bundle(destination)
        assert all(read_json(destination / name) == value for name, value in files.items())
    else:
        write_bundle(destination, files)
    print(dict(status=summary['status'], profiles=summary['unique_profiles'],
               matrix_shape=summary['encoded_training_shape'], matrix_rank=summary['encoded_training_rank'],
               nonzero_training_effects=summary['nonzero_training_effects'],
               validation_gain_ranges={row['mode']: [min(row['validation_gains']), max(row['validation_gains'])]
                                       for row in tuning}, bindings=len(bindings)))


def audit_structure_use(repo, destination, stream=False):
    inputs = repo / INPUT / 'algorithm-inputs'
    verify_bundle(inputs)
    algorithm = repo / RESULT / 'algorithm-main'
    verify_bundle(algorithm / 'summary')
    completion = read_json(algorithm / 'summary/completion.json')
    searches_path = algorithm / 'searches.jsonl'
    assert file_sha256(searches_path) == completion['searches_sha256']
    source = {row['identity']: row for row in read_json(inputs / 'matrices.json')}
    searches = pd.read_json(searches_path, lines=True).to_dict('records')
    assert len(source) == 320 and len(searches) == 1280
    assert file_sha256(repo / 'src/development/context_algorithms.py') == read_json(inputs / 'protocol.json')['python_implementation_sha256']
    rows = []
    for record in searches:
        matrix = source[record['identity']]
        graph = nx.DiGraph()
        graph.add_nodes_from(matrix['labels'])
        for a, left, right, b in record['edges']:
            assert left in ('TAIL', 'ARROW', 'CIRCLE') and right in ('TAIL', 'ARROW', 'CIRCLE')
            if left != 'ARROW' and right != 'TAIL':
                graph.add_edge(a, b)
            if right != 'ARROW' and left != 'TAIL':
                graph.add_edge(b, a)
        expected = matrix['scenario'] != 'soft_latent'
        observed = nx.has_path(graph, 'C', 'Y')
        if record['method'] == 'GFCI':
            assert pd.isna(record.get('warnings'))
            warning = None
        else:
            assert isinstance(record['warnings'], list)
            warning = bool(record['warnings'])
        rows.append(dict(identity=record['identity'], scenario=matrix['scenario'], n=matrix['n'],
                         method=record['method'], possible_C_to_Y=observed,
                         true_C_to_Y=expected, false_exclusion=expected and not observed,
                         warning_reported=warning))
    grouped = defaultdict(list)
    for row in rows:
        grouped[row['scenario'], row['n'], row['method']].append(row)
    groups = [dict(scenario=scenario, n=n, method=method, runs=len(values),
                   possible_path_runs=sum(row['possible_C_to_Y'] for row in values),
                   false_exclusion_runs=sum(row['false_exclusion'] for row in values),
                   warning_runs=sum(row['warning_reported'] is True for row in values),
                   unknown_warning_status_runs=sum(row['warning_reported'] is None for row in values))
              for (scenario, n, method), values in sorted(grouped.items())]
    assert len(groups) == 64 and all(row['runs'] == 20 for row in groups)
    means = []
    logistic = lambda value: float(1/(1+np.exp(-value)))
    for scenario in ('soft_direct', 'soft_latent', 'edit_direct', 'edit_latent'):
        expected = []
        for c in (0, 1):
            probability = 0.
            for u in (0, 1):
                for z in (0, 1):
                    px = logistic(-1+2*c) if scenario.startswith('soft') else logistic(-.5+u)
                    if scenario == 'soft_latent':
                        px = logistic(-1+2*c+1.5*u)
                    for x in (0, 1):
                        y = (-2+2*x+1.2*z if scenario == 'soft_direct' else
                             -2+1.8*u+1.2*z if scenario == 'soft_latent' else
                             -2+1.5*c+1.5*x+1.2*z if scenario == 'edit_direct' else
                             -2+1.5*c+1.8*u+1.2*z)
                        probability += .25*(px if x else 1-px)*logistic(y)
            expected.append(probability)
        difference = expected[1]-expected[0]
        if scenario == 'soft_latent':
            assert abs(difference) < 1e-15
            difference = 0.
        means.append(dict(scenario=scenario, expected_Y_C0=expected[0], expected_Y_C1=expected[1],
                          true_C_effect=difference))
    real_inputs = repo / INPUT / 'real-context-matrices'
    verify_bundle(real_inputs)
    cells = []
    for matrix in read_json(real_inputs / 'matrices.json'):
        values = np.array(matrix['rows'], dtype=int)
        labels = matrix['labels']
        counts = np.zeros((2, 2), dtype=int)
        for row in values:
            counts[row[labels.index('C')], row[labels.index('Y')]] += 1
        expected = np.outer(counts.sum(axis=1), counts.sum(axis=0))/len(values)
        cells.append(dict(identity=matrix['identity'], n=len(values), C_Y_counts=counts.tolist(),
                          C_Y_expected_counts_under_independence=expected.tolist(),
                          expected_cells_below_five=int((expected < 5).sum())))
    files = {'protocol.json': dict(status='POST_OUTCOME_STRUCTURE_USE_DIAGNOSTIC',
        formal_protocol='SPECIFIED_DRAFT', new_structure_searches=0, frozen_policy_changed=False,
        query='possibly directed C-to-Y path using independent NetworkX reachability',
        interpretation='These are twenty independent simulated datasets per cell, not the frozen two-hundred-draw task bootstrap filter. Missing possible paths can occur despite a known beneficial context effect; absence is not calibrated evidence of zero effect.',
        source_searches_sha256=completion['searches_sha256'],
        implementation_function='graph_guided_report.audit_structure_use'),
        'search_queries.json': rows, 'query_counts.json': groups,
        'mechanism_effects.json': means, 'real_contingency_cells.json': cells}
    if destination.exists():
        verify_bundle(destination)
        assert all(read_json(destination / name) == value for name, value in files.items())
    else:
        write_bundle(destination, files)
    print(dict(status='POST_OUTCOME_STRUCTURE_USE_DIAGNOSTIC', queried_searches=1280,
               mechanism_effects=means, real_expected_cells=cells,
               small_sample_exclusions=[row for row in groups if row['n'] == 33]))


def audit_targets(repo, destination, stream=False, download=False):
    assert not download or stream
    input_names = ['development-execution-inputs-v2', 'development-execution-inputs-batch2']
    input_names.extend(value[1] for value in COHORTS.values())
    if stream:
        input_names.append('heldout-execution-inputs-stream')
    if download:
        input_names.append('heldout-execution-inputs-download')
    assignments = defaultdict(list)
    evidence = []
    for name in input_names:
        directory = repo / INPUT / name
        verify_bundle(directory)
        evidence.append(dict(path=str(directory.relative_to(repo)),
                             manifest_sha256=file_sha256(directory / 'manifest.json')))
        for row in read_json(directory / 'assignments.json'):
            assignments[row['index']].append(row)
    tasks, graph_rows = [], []
    for index, requests in sorted(assignments.items()):
        suffix = '-v2' if index in (38, 206) else ''
        directory = repo / INPUT / f'prepared/case-{index:04d}{suffix}'
        verify_bundle(directory)
        case = read_json(directory / 'case.json')
        evidence.append(dict(path=str(directory.relative_to(repo)),
                             manifest_sha256=file_sha256(directory / 'manifest.json')))
        candidates = {row['slot']: row for row in case['candidates']}
        for request in requests:
            assert request['task_unit_id'] == case['source']['task_unit_id']
            if request['arm'] in ('P', 'N'):
                realization = next(row for row in candidates[request['candidate_slot']]['realizations']
                                   if row['id'] == request['version'])
                assert request['prompt'] == realization['prompts'][request['arm']]
        target_records = case['targets']
        enumerated = {row['id']: row for row in target_records['enumerated_targets']}
        selected = {row['id'] for row in target_records['selected_targets']}
        assert selected <= enumerated.keys()
        assert all(candidate['target']['id'] in selected for candidate in candidates.values())
        unselected = [row for identity, row in enumerated.items() if identity not in selected]
        tasks.append(dict(index=index, role=case['source']['role'],
            representation=case['source']['representation'], task_unit_id=case['source']['task_unit_id'],
            candidates=len(candidates), enumerated_targets=len(enumerated), selected_distinct_targets=len(selected),
            unselected_targets=[dict(id=row['id'], category=row['category'],
                                    explicit_nonselection_reason=row.get('nonselection_reason')) for row in unselected],
            allowed_operations_by_category={category: sorted({operation for row in enumerated.values()
                if row['category'] == category for operation in row['allowed_operations']})
                for category in sorted({row['category'] for row in enumerated.values()})},
            authored_operations=dict(Counter(row['hypothesis']['operation'] for row in candidates.values())),
            independent_review=case['independent_review']))
        if case['source']['representation'] != 'TSG':
            assert not target_records['nodes'] and not target_records['relations']
            continue
        nodes = {row['id']: row for row in target_records['nodes']}
        relations = {row['id']: row for row in target_records['relations']}
        for row in nodes.values():
            assert row['quote'] in case['source']['prompt']
        for row in relations.values():
            assert row['quote'] in case['source']['prompt']
            assert row['from'] in nodes and row['to'] in nodes
        ordinary = [row for row in enumerated.values() if row['category'].startswith('ordinary_')]
        enumerated_nodes = {node for row in enumerated.values() for node in row['nodes']}
        ordinary_nodes = {node for row in ordinary for node in row['nodes']}
        enumerated_relations = {edge for row in enumerated.values() for edge in row['relations']}
        ordinary_relations = {edge for row in ordinary for edge in row['relations']}
        graph_rows.append(dict(index=index, role=case['source']['role'], nodes=len(nodes), relations=len(relations),
            ordinary_single_node_types=dict(Counter(nodes[row['nodes'][0]]['type'] for row in ordinary
                                                    if len(row['nodes']) == 1)),
            nodes_outside_all_enumerated_targets=[nodes[node] for node in sorted(nodes.keys()-enumerated_nodes)],
            nodes_outside_ordinary_targets=[nodes[node] for node in sorted(nodes.keys()-ordinary_nodes)],
            relations_outside_all_enumerated_targets=[relations[edge] for edge in sorted(relations.keys()-enumerated_relations)],
            relations_outside_ordinary_targets=[relations[edge] for edge in sorted(relations.keys()-ordinary_relations)],
            ordinary_relation_types=sorted({relations[edge]['type'] for edge in ordinary_relations}),
            ordinary_allowed_operations=sorted({operation for row in ordinary for operation in row['allowed_operations']})))
    summary = dict(status='POST_OUTCOME_TARGET_COVERAGE_DIAGNOSTIC', formal_protocol='SPECIFIED_DRAFT',
        task_units=len(tasks), prepared_candidates=sum(row['candidates'] for row in tasks), TSG_tasks=len(graph_rows),
        task_counts=dict(Counter(row['role'] for row in tasks)),
        enumerated_targets=sum(row['enumerated_targets'] for row in tasks),
        unselected_targets=sum(len(row['unselected_targets']) for row in tasks),
        unselected_targets_without_explicit_reason=sum(row['explicit_nonselection_reason'] is None
            for task in tasks for row in task['unselected_targets']),
        ordinary_allowed_operations=sorted({operation for row in graph_rows for operation in row['ordinary_allowed_operations']}),
        ordinary_single_node_types=dict(sum((Counter(row['ordinary_single_node_types']) for row in graph_rows), Counter())),
        TSG_tasks_with_nodes_outside_all_targets=sum(bool(row['nodes_outside_all_enumerated_targets']) for row in graph_rows),
        TSG_tasks_with_relations_outside_all_targets=sum(bool(row['relations_outside_all_enumerated_targets']) for row in graph_rows),
        independent_semantic_review=False, new_model_calls=0, new_structure_searches=0, frozen_policy_changed=False,
        interpretation='Literal coverage of frozen author records, bound to actual assigned P/N prompts. Unused graph entries are not automatically valid intervention opportunities or extraction errors; semantic completeness and opportunity screening require independent review.')
    files = {'summary.json': summary, 'tasks.json': tasks, 'graph_entries.json': graph_rows, 'evidence.json': evidence}
    if destination.exists():
        verify_bundle(destination)
        assert all(read_json(destination / name) == value for name, value in files.items())
    else:
        write_bundle(destination, files)
    print(summary)


def build_repairs(repo, destination, stream=False, download=False):
    assert not stream and not download
    result_root = repo / RESULT
    evidence, records, effects, services = [], [], [], []
    for prefix in ('repair-edit','repair-source'):
        path = result_root / (prefix+'-independent-verification.json')
        verified = read_json(path)
        assert verified['status'] == 'verified_exploratory_repair'
        evidence.append(dict(path=str(path),sha256=file_sha256(path)))
        records.extend(dict(cohort=prefix,**r) for r in verified['records'])
        effects.extend(dict(cohort=prefix,**r) for r in verified['effects'])
        service = read_json(result_root / (prefix+'-diagnostic-service.json'))
        assert service['generation_status'] == 'finished' and service['process_absent']
        assert service['code_requests'] == verified['requests']
        services.append(service)
    preparation = read_json(result_root / 'repair-preparation-independent-verification.json')
    structure = read_json(result_root / 'repair-structure-independent-verification.json')
    assert preparation['status'] == 'verified_post_outcome_preparation_and_selection'
    assert structure['status'] == 'verified_background_and_saved_results'
    for name in ('repair-preparation-independent-verification.json','repair-structure-independent-verification.json'):
        path = result_root / name
        evidence.append(dict(path=str(path),sha256=file_sha256(path)))
    searches_root = result_root / 'repair-structure/bundle'
    verify_bundle(searches_root)
    searches = read_json(searches_root / 'searches.json')
    groups = defaultdict(list)
    for row in searches:
        if row['category'].startswith('synthetic:'):
            mechanism,sample,_ = row['category'].removeprefix('synthetic:').split('-')
            groups[mechanism,int(sample),row['method']].append(row)
    synthetic = []
    for (mechanism,sample,method),rows in sorted(groups.items()):
        endpoints = Counter()
        for row in rows:
            edge = next((r for r in row['edges'] if {r[0],r[3]} == {'X','Y'}),None)
            key = 'absent' if edge is None else '/'.join(edge[1:3] if edge[0] == 'X' else (edge[2],edge[1]))
            endpoints[key] += 1
        synthetic.append(dict(mechanism=mechanism,sample_size=sample,method=method,searches=len(rows),
            valid=sum(r['valid'] for r in rows),XY_endpoints=dict(endpoints)))
    cases = []
    for index in sorted({r['index'] for r in records}):
        rows = [r for r in records if r['index'] == index]
        cases.append(dict(index=index,requests=len(rows),security=dict(Counter(r['security'] for r in rows)),
            functionality=dict(Counter(r['functionality'] for r in rows)),hypotheses=sum(r['index'] == index for r in effects)))
    case25 = []
    for record in records:
        if record['index'] != 25:
            continue
        path = result_root / (record['cohort']+'-diagnostic') / record['slot'] / 'result/result.json'
        measured = read_json(path)['measurements'][0]['measurement']['channels']
        case25.append(dict(**record,channels={channel:{key:value for key,value in result.items()
            if key in ('status','phase','error_type','error','observation')} for channel,result in measured.items()},
            result_sha256=file_sha256(path)))
    summary = dict(status='REPAIR_EXECUTED_INDEPENDENT_SEMANTIC_REVIEW_PENDING',new_code_requests=len(records),
        new_hypotheses=len(effects),newly_executed_source_tasks=3,supplement_task_units=7,
        total_code_requests_including_original=1101+len(records),main_executed_task_units=49,
        security=dict(Counter(r['security'] for r in records)),functionality=dict(Counter(r['functionality'] for r in records)),
        model_service_seconds=sum(r['service_seconds'] for r in services),new_main_structure_searches=len(searches),
        structural_qualification_searches=9,structural_constraints_verified=True,
        FCI0_JCI1_changed_inputs=structure['FCI0_JCI1_changed_inputs'],target_opportunities=preparation['proposals'],
        original_evidence_unchanged=True,independent_semantic_review=False)
    files = {'summary.json':summary,'cases.json':cases,'effects.json':effects,'case25-diagnostics.json':case25,
        'synthetic-endpoints.json':synthetic,'policy-values.json':preparation['policy_values'],
        'services.json':services,'evidence.json':evidence,'unresolved-sources.json':read_json(repo / INPUT / 'repair-source-execution-inputs/unresolved-sources.json')}
    if destination.exists():
        verify_bundle(destination)
        assert all(read_json(destination / name) == value for name,value in files.items())
    else:
        write_bundle(destination,files)
    print(summary)
    print(cases)
    print(synthetic)
    print([dict(operation=r['operation'],difference=r['P_minus_N']) for r in effects if r['index'] == 25])
    print([dict(slot=r['slot'],arm=r['arm'],candidate=r['candidate_slot'],security=r['security'],functionality=r['functionality'],channels=r['channels']) for r in case25 if r['security'] != 'secure' or r['functionality'] != 'pass'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('destination', type=Path)
    parser.add_argument('--diagnostics', action='store_true')
    parser.add_argument('--stream', action='store_true')
    parser.add_argument('--download', action='store_true')
    parser.add_argument('--features', action='store_true')
    parser.add_argument('--structure-use', action='store_true')
    parser.add_argument('--precision', action='store_true')
    parser.add_argument('--targets', action='store_true')
    parser.add_argument('--repairs', action='store_true')
    parser.add_argument('--discovery-structural', action='store_true')
    parser.add_argument('--discovery-measurement', action='store_true')
    parser.add_argument('--discovery-evaluation', action='store_true')
    parser.add_argument('--discovery-targeted-generation', action='store_true')
    parser.add_argument('--inputs', type=Path)
    parser.add_argument('--results', type=Path)
    arguments = parser.parse_args()
    assert sum((arguments.features, arguments.diagnostics, arguments.structure_use, arguments.precision,
                arguments.targets, arguments.repairs, arguments.discovery_structural,
                arguments.discovery_measurement, arguments.discovery_evaluation,
                arguments.discovery_targeted_generation)) <= 1
    function = (build_repairs if arguments.repairs else audit_structure_use if arguments.structure_use else audit_features if arguments.features
                else audit_targets if arguments.targets else audit_precision if arguments.precision
                else diagnose if arguments.diagnostics else build)
    if arguments.discovery_targeted_generation:
        assert arguments.inputs is not None and arguments.results is not None
        discovery_targeted_generation_tables(Path('.').resolve(), arguments.inputs.resolve(), arguments.results.resolve(), arguments.destination.resolve())
    elif arguments.discovery_evaluation:
        assert arguments.inputs is not None and arguments.results is not None
        discovery_evaluation_tables(Path('.').resolve(), arguments.inputs.resolve(), arguments.results.resolve(), arguments.destination.resolve())
    elif arguments.discovery_measurement:
        assert not arguments.stream and not arguments.download
        discovery_validate_measurement_adapter(Path('.').resolve(), arguments.destination.resolve())
    elif arguments.discovery_structural:
        assert not arguments.stream and not arguments.download
        discovery_structural_evidence(Path('.').resolve(), arguments.destination.resolve())
    elif arguments.features or arguments.structure_use:
        assert not arguments.download
        function(Path('.').resolve(), arguments.destination.resolve(), arguments.stream)
    else:
        function(Path('.').resolve(), arguments.destination.resolve(), arguments.stream, arguments.download)
