from __future__ import annotations

import hashlib
import json
import os
import signal
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

from prompt_mechanism_study.artifact_io import read_json, verify_bundle, write_bundle


ROOT = Path('/home/wsy/work/prompt-mechanism-study')
INPUTS = ROOT / 'inputs/graph-guided-20260930/development-case82-generation-inputs-v2'
RESULTS = ROOT / 'results/graph-guided-20260930'
DESTINATION = RESULTS / 'development-case82-main'
PYTHON = Path('/home/wsy/miniconda3/envs/purp/bin/python')
MODEL = Path('/home/ubuntu/RAID5/data/model_zoo/CodeLLMs/Qwen2.5-Coder-32B-Instruct')
SOURCE = ROOT / 'inputs/src/prompt_mechanism_study/development/source_generation.py'
NATIVE = ROOT / 'inputs/graph-guided-20260930/measurement/native_behavior.py'


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run() -> None:
    verify_bundle(INPUTS)
    protocol = read_json(INPUTS / 'protocol.json')
    if (protocol['status'] != 'FROZEN_SEMANTIC_DISCOVERY_CASE82_DEVELOPMENT'
            or protocol['code_requests'] != 12 or protocol['development_request_limit'] != 32
            or protocol['generation_implementation_sha256'] != digest(SOURCE)
            or protocol['native_worker_sha256'] != digest(NATIVE)
            or DESTINATION.exists()):
        raise ValueError('冻结输入、运行实现或目的位置不符')
    runtime_root = RESULTS / 'development-case82-runtime-freeze-v3'
    work = ROOT / 'results/d83'
    work.mkdir(parents=True, exist_ok=False)
    for name in ('scratch', 'cuda-cache', 'torch-cache', 'triton-cache'):
        (work / name).mkdir()
    argv = [str(PYTHON), '-m', 'vllm.entrypoints.openai.api_server',
            '--model', str(MODEL), '--served-model-name', 'Qwen2.5-Coder-32B-Instruct',
            '--host', '127.0.0.1', '--port', '18584', '--tensor-parallel-size', '2',
            '--dtype', 'bfloat16', '--max-model-len', '8192', '--max-num-seqs', '4',
            '--gpu-memory-utilization', '0.58', '--enforce-eager',
            '--no-enable-prefix-caching', '--disable-custom-all-reduce',
            '--generation-config', 'vllm', '--seed', '20260930']
    environment = {**os.environ, 'CUDA_VISIBLE_DEVICES': '0,1',
        'PYTHONPATH': str(ROOT / 'inputs/src'), 'HF_HUB_OFFLINE': '1',
        'TRANSFORMERS_OFFLINE': '1', 'TMPDIR': str(work / 'scratch'),
        'CUDA_CACHE_PATH': str(work / 'cuda-cache'),
        'TORCHINDUCTOR_CACHE_DIR': str(work / 'torch-cache'),
        'TRITON_CACHE_DIR': str(work / 'triton-cache')}
    runtime = dict(status='FROZEN_BEFORE_MODEL_GENERATION',
        input_manifest_sha256=digest(INPUTS / 'manifest.json'),
        source_generation_sha256=digest(SOURCE), native_worker_sha256=digest(NATIVE),
        runner_sha256=digest(Path(__file__)), argv=argv,
        environment={key: environment[key] for key in
                     ('CUDA_VISIBLE_DEVICES', 'PYTHONPATH', 'HF_HUB_OFFLINE',
                      'TRANSFORMERS_OFFLINE', 'TMPDIR', 'CUDA_CACHE_PATH',
                      'TORCHINDUCTOR_CACHE_DIR', 'TRITON_CACHE_DIR')},
        model_service_seconds_limit=1200, call_limit=12,
        frozen_utc=datetime.now(timezone.utc).isoformat())
    write_bundle(runtime_root, {'runtime.json': runtime})
    started = time.monotonic()
    record = dict(runtime_manifest_sha256=digest(runtime_root / 'manifest.json'),
                  started_utc=datetime.now(timezone.utc).isoformat())
    with (RESULTS / 'development-case82-vllm-v3.log').open('w', encoding='utf-8') as log:
        service = subprocess.Popen(argv, env=environment, cwd=work,
                                   stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=True)
        record['pid'] = service.pid
        try:
            ready = False
            for _ in range(180):
                if service.poll() is not None:
                    raise RuntimeError('vLLM 启动期间终止')
                probe = subprocess.run(['curl', '--silent', '--fail', '--max-time', '2',
                    'http://127.0.0.1:18584/v1/models'], capture_output=True)
                if probe.returncode == 0:
                    listed = json.loads(probe.stdout)
                    if not any(row['id'] == 'Qwen2.5-Coder-32B-Instruct'
                               for row in listed['data']):
                        raise ValueError('模型服务身份不符')
                    ready = True
                    break
                time.sleep(2)
            if not ready:
                raise TimeoutError('模型服务未在启动时限内就绪')
            remaining = 1200 - (time.monotonic() - started)
            if remaining <= 0:
                raise TimeoutError('模型服务预算已经耗尽')
            command = [str(PYTHON), str(SOURCE), 'run', str(INPUTS),
                       str(DESTINATION), str(NATIVE)]
            with (RESULTS / 'development-case82-generation-v3.log').open('w', encoding='utf-8') as generation_log:
                subprocess.run(command, cwd=work, env=environment, check=True,
                               timeout=remaining, stdout=generation_log,
                               stderr=subprocess.STDOUT)
            record['generation_status'] = 'finished'
        finally:
            if service.poll() is None:
                os.killpg(service.pid, signal.SIGTERM)
                service.wait(timeout=60)
            record.update(stopped_utc=datetime.now(timezone.utc).isoformat(),
                          service_seconds=time.monotonic() - started,
                          process_absent=service.poll() is not None)
            (RESULTS / 'development-case82-service-v3.json').write_text(
                json.dumps(record, ensure_ascii=False, sort_keys=True), encoding='utf-8')
    print(json.dumps(record, ensure_ascii=False))


if __name__ == '__main__':
    run()
