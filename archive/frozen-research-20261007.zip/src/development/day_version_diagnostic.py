"""Matched-seed stability diagnostic across all five frozen file contracts.

No new prompts, semantic bindings or outcomes are chosen here. Repetition tests
within-contract generation variability; it does not add independent task units.
"""
from __future__ import annotations

import hashlib
import json
import random
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from prompt_mechanism_study.artifact_io import read_json, verify_bundle, write_bundle
from prompt_mechanism_study.development.day_generation import MODEL, SYSTEM
from prompt_mechanism_study.llm import complete_chat
from prompt_mechanism_study.measurement.native_behavior import docker_measure
from prompt_mechanism_study.measurement import native_behavior


ARMS=('N','P','H')
VERSIONS=(0,1)
REPEATS=tuple(range(8))
SEED_BASE=2026092900
SHUFFLE_SEED=2026092609


def prepare(initial: Path, followup: Path, output: Path):
    verify_bundle(initial);verify_bundle(followup)
    original=[t for t in read_json(initial/'tasks.json') if t['id']=='synthetic_save_bundle_v1']
    subsequent=read_json(followup/'tasks_json')
    tasks=original+subsequent
    assert len(tasks)==5 and len({t['id'] for t in tasks})==5
    rows=[]
    for task in tasks:
        for arm in ARMS:
            for version in VERSIONS:
                prompt=task['prompts'][f'{arm}{version}']
                for repeat in REPEATS:
                    rows.append(dict(task_unit_id=task['id'],arm=arm,version=version,
                        repeat=repeat,seed=SEED_BASE+repeat,
                        prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest()))
    assert len(rows)==240
    random.Random(SHUFFLE_SEED).shuffle(rows)
    for index,row in enumerate(rows): row['slot']=f'v{index:03d}'
    protocol=dict(status='FROZEN_MATCHED_VERSION_DIAGNOSTIC',formal_protocol='SPECIFIED_DRAFT',
        evidence_role='outcome-informed exploratory stability check on all five file contracts',
        source_task_units=5,independent_family_count=1,assigned_slots=240,
        arms=ARMS,versions=VERSIONS,repeats_per_version=8,shuffle_seed=SHUFFLE_SEED,
        seed_base=SEED_BASE,workers=4,model=MODEL,system_prompt=SYSTEM,
        docker_image='python:3.12.11-slim-bookworm',
        inference='Within-contract response frequencies only; no iid N=240 or natural transfer')
    write_bundle(output,dict(tasks_json=tasks,assignments_json=rows,protocol_json=protocol,
        source_manifests=dict(initial=read_json(initial/'manifest.json'),
                              followup=read_json(followup/'manifest.json'))))
    print(json.dumps(dict(tasks=5,requests=240)))


def run(inputs: Path, output: Path, initial_controls: Path, followup_controls: Path):
    verify_bundle(inputs)
    protocol=read_json(inputs/'protocol_json')
    tasks={t['id']:t for t in read_json(inputs/'tasks_json')}
    assignments=read_json(inputs/'assignments_json')
    assert len(assignments)==protocol['assigned_slots']==240
    # The control result identities are passed explicitly, not inferred from
    # later outcomes. Stage 1 has known secure/insecure/unknown controls; each
    # stage-2 base contract also has a secure functional positive control.
    initial_expected={'secure_private_replace':('secure','pass'),
        'late_chmod_exposure':('insecure','pass'),
        'omitted_private_target':('unknown','fail'),
        'secure_but_audit_drift':('secure','fail'),
        'invalid_syntax':('invalid','unknown')}
    for name,(security,functionality) in initial_expected.items():
        measured=read_json(initial_controls/(name+'.result.json'))
        assert measured['security_label']==security and measured['functionality']==functionality
    for task in tasks.values():
        if task['id']!='synthetic_save_bundle_v1':
            measured=read_json(followup_controls/(task['id']+'.result.json'))
            assert measured['security_label']=='secure' and measured['functionality']=='pass'
    output.mkdir(parents=True,exist_ok=False)
    write_bundle(output/'preoutcome',dict(assignments=assignments,protocol=protocol,
                                         input_manifest=read_json(inputs/'manifest.json')))
    def one(slot):
        task=tasks[slot['task_unit_id']]
        dest=output/slot['slot'];dest.mkdir()
        row={**slot,'started_unix':time.time(),'status':'not_run'}
        prompt=task['prompts'][f"{slot['arm']}{slot['version']}"]
        def trace(kind,data): (dest/(kind+'.json')).write_bytes(data)
        try:
            raw=complete_chat({'task':prompt},{**protocol['model'],'seed':slot['seed']},
                              protocol['system_prompt'],trace=trace)
            (dest/'content.json').write_bytes(raw)
            code=json.loads(raw)['code']
            if not isinstance(code,str): raise ValueError('non-string code')
            (dest/'code.py').write_text(code,encoding='utf-8')
            request=dest/'measurement-request.json'
            request.write_text(json.dumps(dict(code=code,**task['measurement'])),encoding='utf-8')
            measured=docker_measure(request,Path(native_behavior.__file__),protocol['docker_image'])
            row.update(status='returned' if measured.get('status')=='measured' else 'measurement_infrastructure_failed',
                       code_sha256=hashlib.sha256(code.encode()).hexdigest(),measurement=measured)
        except Exception as error:
            row.update(status='generation_or_envelope_failed',error=f'{type(error).__name__}: {error}')
        row['ended_unix']=time.time()
        write_bundle(dest/'result',{'result.json':row})
        print(slot['slot'],task['name'],slot['arm'],slot['version'],slot['repeat'],row['status'],flush=True)
        return row
    with ThreadPoolExecutor(max_workers=protocol['workers']) as pool:
        rows=list(pool.map(one,assignments))
    write_bundle(output/'summary',{'results.json':rows})
    print(json.dumps(dict(assigned=len(rows),returned=sum(row['status']=='returned' for row in rows))),flush=True)


if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='prepare': prepare(Path(sys.argv[2]),Path(sys.argv[3]),Path(sys.argv[4]))
    elif mode=='run': run(Path(sys.argv[2]),Path(sys.argv[3]),Path(sys.argv[4]),Path(sys.argv[5]))
