from __future__ import annotations

import argparse
import hashlib
import json
from itertools import combinations
from collections import Counter, defaultdict
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np
import networkx as nx

from prompt_mechanism_study.artifact_io import file_sha256, read_json, verify_bundle, write_bundle
from prompt_mechanism_study.records import content_hash
from prompt_mechanism_study.records import canonical_json
from prompt_mechanism_study.development.source_generation import MODEL, SYSTEM
from prompt_mechanism_study.development.graph_guided_decisions import (
    discovery_contract_statistics, discovery_pick, fit_discovery_ridge,
)
from prompt_mechanism_study.development.graph_guided_report import (
    discovery_action_coefficients, discovery_panel_outcomes, discovery_shared_bounds,
)


ROOT = Path('data/method/graph-guided-20260928')
OLD = Path('data/method/source-hypotheses-20260927')
POOL = Path('data/dataset-curation/research-candidate-pool-v4')
SEED = 20260928
DISCOVERY_ROOT = Path('data/method/graph-guided-20260929')
DISCOVERY_PROTOCOL = 'tsg-discovery-development-20260929'


def discovery_assignments(tasks, candidates, role, state=None):
    if role not in {'development', 'evaluation'}:
        raise ValueError('未定义的研究角色')
    generators = {key: np.random.Generator(np.random.PCG64(seed)) for key, seed in
                  [('seed', 2026092902), ('arm', 2026092903), ('order', 2026092904)]}
    if state is not None:
        for key, generator in generators.items():
            generator.bit_generator.state = state[key]
    if len({row['task_unit_id'] for row in tasks}) != len(tasks):
        raise ValueError('任务身份重复')
    known = {row['task_unit_id'] for row in tasks}
    if any(row['task_unit_id'] not in known for row in candidates):
        raise ValueError('候选不属于本面板')
    if len({row['candidate_id'] for row in candidates}) != len(candidates):
        raise ValueError('候选身份重复')
    assignments, bindings = [], []
    for task in sorted(tasks, key=lambda row: row['task_unit_id']):
        task_id = task['task_unit_id']
        task_candidates = sorted([row for row in candidates if row['task_unit_id'] == task_id],
                                 key=lambda row: row['candidate_id'])
        open_candidates = [row for row in task_candidates if row['use'] == 'open']
        replication = [row for row in task_candidates if row['use'] == 'replication']
        if len(open_candidates) > 4 or len(replication) > (1 if role == 'evaluation' else 0):
            raise ValueError('任务候选超过协议额度')
        if any(row['use'] not in {'open', 'replication'} for row in task_candidates):
            raise ValueError('未定义的候选用途')
        groups = {}
        for candidate in task_candidates:
            if len(candidate['p_versions']) != 2 or len(candidate['n_versions']) != 2:
                raise ValueError('政策版本数与协议不符')
            if any(not isinstance(text, str) or not text.strip()
                   for text in candidate['p_versions'] + candidate['n_versions']):
                raise ValueError('政策全文缺失')
            identity = content_hash(canonical_json(dict(
                p_versions=candidate['p_versions'], n_versions=candidate['n_versions'],
                version_weights=[0.5, 0.5], execution_interface=task['execution_interface'],
                measurement=task['measurement'])))
            groups.setdefault(identity, []).append(candidate)
        def add(policy, version, seed, pair_position, arm, prompt, members):
            identity = content_hash(canonical_json([DISCOVERY_PROTOCOL, role, task_id, policy,
                                                    version, int(seed), pair_position]))
            assignments.append(dict(request_id=identity, index=task['index'], task_unit_id=task_id,
                role=role, policy_id=policy, version=version, seed=int(seed), pair_position=pair_position,
                arm=arm, prompt=prompt, prompt_sha256=content_hash(prompt),
                candidate_memberships=members, measurements=[task['measurement']]))
            return identity
        for policy_id, group in sorted(groups.items()):
            seed_values = generators['seed'].choice(2**31 - 1, 2, replace=False) + 1
            members = [row['candidate_id'] for row in group]
            policy = group[0]
            for row in group:
                bindings.append(dict(task_unit_id=task_id, candidate_id=row['candidate_id'],
                                     use=row['use'], policy_id=policy_id, seeds=[int(x) for x in seed_values]))
            for version in range(2):
                for seed in seed_values:
                    arms = ['P', 'N'] if generators['arm'].integers(2) == 0 else ['N', 'P']
                    for pair_position, arm in enumerate(arms):
                        add(policy_id, version, seed, pair_position, arm,
                            policy['p_versions' if arm == 'P' else 'n_versions'][version], members)
        reference_seeds = generators['seed'].choice(2**31 - 1, 4, replace=False) + 1
        for repeat, seed in enumerate(reference_seeds):
            add('R', 0, seed, repeat, 'R', task['reference_prompt'], [])
    assignments = [dict(slot=f'{position:04d}', **assignments[int(original)])
                   for position, original in enumerate(generators['order'].permutation(len(assignments)))]
    if len({row['request_id'] for row in assignments}) != len(assignments):
        raise ValueError('请求身份重复')
    return assignments, bindings, {key: rng.bit_generator.state for key, rng in generators.items()}


def _source_references(value):
    identities, hashes, indices = set(), set(), set()
    if isinstance(value, dict):
        for key in ('task_unit_id', 'semantic_cluster_id', 'near_duplicate_group_id'):
            if isinstance(value.get(key), str):
                identities.add(value[key])
        for key in ('prompt_sha256', 'source_prompt_sha256'):
            if isinstance(value.get(key), str):
                hashes.add(value[key])
        if isinstance(value.get('index'), int):
            indices.add(value['index'])
        for child in value.values():
            found_ids, found_hashes, found_indices = _source_references(child)
            identities.update(found_ids)
            hashes.update(found_hashes)
            indices.update(found_indices)
    elif isinstance(value, list):
        for child in value:
            found_ids, found_hashes, found_indices = _source_references(child)
            identities.update(found_ids)
            hashes.update(found_hashes)
            indices.update(found_indices)
    return identities, hashes, indices


def start_discovery(repo: Path) -> None:
    protocol = repo / 'docs/graph-guided-discovery-protocol.md'
    assert DISCOVERY_PROTOCOL in protocol.read_text(encoding='utf-8')
    started = datetime.now(timezone.utc)
    write_bundle(repo / DISCOVERY_ROOT / 'launch', {
        'launch.json': dict(
            status='PREPARATION_STARTED', protocol_id=DISCOVERY_PROTOCOL,
            user_authorization='2026-09-29 照此启动',
            t0_utc=started.isoformat(), deadline_utc=(started + timedelta(hours=24)).isoformat(),
            protocol_sha256=file_sha256(protocol), generation_call_limit=1752,
            model_service_seconds_limit=14400, preparation_seconds_limit=43200,
            formal_protocol='SPECIFIED_DRAFT', paid_provider_allowed=False,
            protected_evaluation_allowed=False, model_role='code_generation_only',
            primary_power_status='INSUFFICIENT_POWER_AT_DAY_BUDGET',
            independent_human_review='PENDING_INDEPENDENT_REVIEW',
            f0_status='NOT_FROZEN', f1_status='NOT_FROZEN',
            implementation_sha256=file_sha256(Path(__file__))),
        'protocol.json': {'text': protocol.read_text(encoding='utf-8')},
    })
    print(json.dumps(dict(status='PREPARATION_STARTED', deadline_utc=(started + timedelta(hours=24)).isoformat())))


def discovery_inventory(repo: Path) -> None:
    verify_bundle(repo / DISCOVERY_ROOT / 'launch')
    verify_bundle(repo / ROOT / 'registration')
    verify_bundle(repo / POOL)
    selection = read_json(repo / ROOT / 'registration/selection.json')
    protected = {r['task_unit_id'] for r in read_json(repo / POOL / 'screening.json')
                 if r['decision'] == 'PRESERVE_PROTECTED_INPUT'}
    assert not protected.intersection(r['task_unit_id'] for r in selection)
    inspected, evidence = [], {r['index']: [] for r in selection}
    semantic_parts = {'preparation', 'prepared', 'targets', 'representation-records',
                      'representation-preparation-audit', 'repair-representation-audit',
                      'blinded-review-material', 'repair-blinded-review-material',
                      'scaled-panel', 'gold', 'source-gold', 'bindings'}
    # 登记和来源筛查不自动视作方法开发；语义准备及结果记录需要暴露核查。
    paths = []
    for base in (repo / 'data/method', repo / 'results'):
        for path in base.rglob('*.json'):
            if path.name in {'manifest.json', 'protocol.json', 'plan.json', 'launch.json'}:
                continue
            if DISCOVERY_ROOT.as_posix() in path.relative_to(repo).as_posix():
                continue
            if base.name == 'results' or semantic_parts.intersection(path.parts) or path.name == 'development-exposure.json':
                paths.append(path)
    for path in sorted(paths):
        value = read_json(path)
        identities, hashes, indices = _source_references(value)
        relative = path.relative_to(repo).as_posix()
        shared_indices = relative.startswith(('data/method/graph-guided-20260928/',
                                               'data/method/source-hypotheses-20260927/',
                                               'results/graph-guided-20260928/',
                                               'results/source-hypotheses-20260927/'))
        inspected.append(dict(path=relative, sha256=file_sha256(path)))
        for row in selection:
            identity_match = {row['task_unit_id'], row['near_duplicate_group_id']}.intersection(identities)
            if identity_match or row['source_prompt_sha256'] in hashes or (shared_indices and row['index'] in indices):
                evidence[row['index']].append(relative)
    rows = [{**row, 'prior_semantic_or_result_records': evidence[row['index']],
             'exposure_status': 'HISTORICAL_RECORD_FOUND' if evidence[row['index']] else 'NO_RECORD_IN_INSPECTED_FILES',
             'measurement_qualification': 'PENDING_SOURCE_CONTRACT_REVIEW'} for row in selection]
    def ordered(role):
        candidates = [row for row in rows if row['role'] == role]
        if role == 'heldout':
            candidates = [row for row in candidates if not evidence[row['index']]]
        label = 'evaluation' if role == 'heldout' else 'development'
        return sorted(candidates, key=lambda row: hashlib.sha256(
            f"{DISCOVERY_PROTOCOL}|{label}|{row['task_unit_id']}|2026092901".encode('utf-8')).hexdigest())
    development = ordered('development')[:16]
    evaluation = ordered('heldout')
    assert len({r['near_duplicate_group_id'] for r in rows}) == len(rows)
    summary = dict(status='METADATA_AUDIT_NOT_F0_OR_ROLE_QUALIFICATION',
                   registered=len(rows), inspected_files=len(inspected),
                   development_prefix_indices=[r['index'] for r in development],
                   unexposed_candidate_indices=[r['index'] for r in evaluation],
                   unexposed_candidate_count=len(evaluation), protected_overlap=0,
                   remaining=['source/endpoint qualification', 'independent preparation', 'F0 freeze'])
    write_bundle(repo / DISCOVERY_ROOT / 'inventory', {
        'inventory.json': rows, 'summary.json': summary, 'inspected-files.json': inspected,
    })
    print(json.dumps(summary, ensure_ascii=False))


def discovery_qualification(repo: Path, family: str, output_suffix: str = '') -> None:
    directory = repo / DISCOVERY_ROOT / 'measurement'
    profiles = {'pdf_upload_path': ('app', 'secure'), 'environment_template': ('function', 'unknown'),
                'greeting_html': ('app', 'secure'), 'image_upload_path': ('app', 'secure'),
                'registration_hash': ('function', 'secure'), 'ui_template': ('app', 'secure'),
                'response_cookie': ('app', 'secure'), 'login_session_cookie': ('app', 'secure'),
                'filter_script_tags': ('app', 'unknown'), 'json_name_count': ('function', 'secure'),
                'moderator_database': ('function', 'secure'), 'local_redirect': ('app', 'secure')}
    current_profiles = {'query_decode': 'function', 'xml_content': 'function',
                        'product_fields': 'function', 'message_signature': 'function',
                        'employee_fields': 'function', 'project_authorization': 'function',
                        'email_csrf': 'function', 'redirect_url': 'function', 'oauth_callback': 'function',
                        'arithmetic_expression': 'function', 'string_expression': 'function',
                        'script_subset': 'function', 'custom_query': 'function',
                        'template_dynamic': 'function', 'forum_post': 'function',
                        'form_total_budget': 'function', 'upload_total_budget': 'function',
                        'input_buffer': 'function', 'ssh_version': 'function', 'settings_file': 'function',
                        'login_auth': 'app', 'moderator_route': 'app', 'yaml_price': 'app'}
    if family in current_profiles:
        profile_root = directory
        expected = {'secure': 'secure', 'vulnerable': 'insecure', 'reject_all': 'unknown',
                    'unknown': 'unknown', 'overrestrictive': 'secure'}
    elif family == 'static_download':
        profile_root = directory
        expected = {'secure': 'secure', 'vulnerable': 'insecure', 'reject_all': 'unknown',
                    'unknown': 'unknown', 'absolute_leak': 'insecure'}
    elif family in profiles:
        profile_root = repo / ROOT / 'measurement'
        expected = {'secure': 'secure', 'vulnerable': 'insecure', 'reject_all': 'unknown',
                    'unknown': 'unknown', 'overrestrictive': profiles[family][1]}
    else:
        raise ValueError('该端点尚无本轮控制合同')
    control_path = profile_root / f'{family}-controls.py'
    if family in {'arithmetic_expression', 'string_expression'}:
        control_path = directory / 'expression-controls.py'
    if family in {'form_total_budget', 'upload_total_budget'}:
        control_path = directory / 'stream_budget-controls.py'
    test_paths = {channel: profile_root / f'{family}-{channel}.py'
                  for channel in ('security', 'functionality')}
    if family == 'local_redirect':
        test_paths['security'] = directory / 'local_redirect-security.py'
    tests = {channel: path.read_text(encoding='utf-8') for channel, path in test_paths.items()}
    fixture_path = (repo / ROOT / 'measurement/moderator_database-fixture.py'
                    if family in {'moderator_database', 'moderator_route'} else None)
    if fixture_path is not None:
        fixture = fixture_path.read_text(encoding='utf-8')
        tests = {channel: fixture + '\n' + text for channel, text in tests.items()}
    controls = control_path.read_text(encoding='utf-8')
    requests = {f'{name}.json': dict(code=controls, entry_point=name, tests=tests,
                                    trace_assertions=False, channel_timeout_seconds=15)
                for name in expected}
    if family in {'arithmetic_expression', 'string_expression'}:
        suffix = 'arithmetic' if family == 'arithmetic_expression' else 'string'
        for name in ('secure', 'overrestrictive'):
            requests[f'{name}.json']['entry_point'] = f'{name}_{suffix}'
    if family in {'form_total_budget', 'upload_total_budget'}:
        suffix = 'form' if family == 'form_total_budget' else 'upload'
        for name in expected:
            requests[f'{name}.json']['entry_point'] = f'{name}_{suffix}'
    if family == 'script_subset':
        expected['overrestrictive'] = 'unknown'
    unknown_path = None
    if family in profiles or family in current_profiles:
        kind = profiles[family][0] if family in profiles else current_profiles[family]
        unknown_path = directory / f'unknown-{kind}.py'
        requests['unknown.json']['code'] = unknown_path.read_text(encoding='utf-8')
    if fixture_path is not None:
        for request in requests.values():
            request.update(preload_test=True, workspace_megabytes=128, channel_timeout_seconds=60)
    write_bundle(directory / f'{family}-qualification-inputs{output_suffix}', requests)
    write_bundle(directory / f'{family}-qualification-contract{output_suffix}', {
        'expected.json': expected,
        'identity.json': dict(family=family, model_calls=0,
                              endpoint_scope='real_program_finite_witness_validation',
                              control_path=control_path.relative_to(repo).as_posix(),
                              control_sha256=file_sha256(control_path),
                              unknown_path=unknown_path.relative_to(repo).as_posix() if unknown_path else None,
                              unknown_sha256=file_sha256(unknown_path) if unknown_path else None,
                              tests_paths={key: path.relative_to(repo).as_posix() for key, path in test_paths.items()},
                              tests_sha256={key: file_sha256(path) for key, path in test_paths.items()},
                              fixture_path=fixture_path.relative_to(repo).as_posix() if fixture_path else None,
                              fixture_sha256=file_sha256(fixture_path) if fixture_path else None,
                              native_worker_sha256=file_sha256(repo / 'src/measurement/native_behavior.py'))})
    print(json.dumps(dict(family=family, controls=len(expected), model_calls=0)))


def discovery_verify_qualification(repo: Path, family: str, output_suffix: str = '') -> None:
    directory = repo / DISCOVERY_ROOT / 'measurement'
    contract = directory / f'{family}-qualification-contract{output_suffix}'
    verify_bundle(contract)
    expected = read_json(contract / 'expected.json')
    identity = read_json(contract / 'identity.json')
    assert identity['native_worker_sha256'] == file_sha256(repo / 'src/measurement/native_behavior.py')
    control_path = repo / identity['control_path'] if 'control_path' in identity else directory / f'{family}-controls.py'
    assert identity['control_sha256'] == file_sha256(control_path)
    if identity.get('unknown_path'):
        assert identity['unknown_sha256'] == file_sha256(repo / identity['unknown_path'])
    if identity.get('fixture_path'):
        assert identity['fixture_sha256'] == file_sha256(repo / identity['fixture_path'])
    for channel, digest in identity['tests_sha256'].items():
        test_path = (repo / identity['tests_paths'][channel] if 'tests_paths' in identity else
                     directory / f'{family}-{channel}.py')
        assert digest == file_sha256(test_path)
    result_root = repo / 'results/graph-guided-20260929' / f'{family}-qualification{output_suffix}'
    observations = []
    for name, label in expected.items():
        path = result_root / f'{name}.json'
        result = read_json(path)
        security = result['channels']['security']
        if result['status'] != 'measured' or security['status'] not in {'passed', 'raised'}:
            raise ValueError(f'Control measurement incomplete: {name}')
        actual = security['observation']['security_label'] if security['status'] == 'passed' else 'unknown'
        if actual != label:
            raise ValueError(f'Endpoint control disagrees: {name}: {actual} != {label}')
        observations.append(dict(control=name, expected=label, observed=actual,
                                 result_sha256=file_sha256(path),
                                 functionality=result['channels']['functionality'].get('observation', {}).get('functionality', 'unknown')))
    write_bundle(result_root / 'verified', {
        'qualification.json': dict(status='QUALIFIED_FINITE_ENDPOINT', family=family,
                                   model_calls=0, observations=observations,
                                   scope=identity['endpoint_scope'],
                                   endpoint_contract_sha256=file_sha256(contract / 'manifest.json'))})
    print(json.dumps(dict(family=family, status='QUALIFIED_FINITE_ENDPOINT', controls=len(observations))))


def discovery_source_contracts(repo: Path):
    plan = read_json(repo / DISCOVERY_ROOT / 'source-execution-contracts.json')
    if plan['protocol_id'] != DISCOVERY_PROTOCOL or plan['generation_results_used'] or plan['hypotheses_or_policies_included']:
        raise ValueError('来源执行条件的信息边界不符')
    sources = {row['index']: row for row in read_json(repo / ROOT / 'registration/sources.json')}
    inventory = {row['index']: row for row in read_json(repo / DISCOVERY_ROOT / 'inventory/inventory.json')}
    if len({row['index'] for row in plan['contracts']}) != len(plan['contracts']):
        raise ValueError('来源执行合同重复')
    admitted = {row['index'] for row in plan['contracts']}
    for group in plan.get('source_equivalence_groups', []):
        if not set(group['members']).issubset(sources) or group['retained_index'] not in group['members']:
            raise ValueError('来源等价组身份不符')
        if admitted.intersection(group['members']) != {group['retained_index']}:
            raise ValueError('同一来源等价组未按固定代表规则保留一项任务')
    contracts = {}
    for card in plan['contracts']:
        index, family = card['index'], card['family']
        suffix = card.get('qualification_suffix', '')
        source = sources[index]
        if content_hash(source['prompt']) != inventory[index]['source_prompt_sha256']:
            raise ValueError('原始来源身份不符')
        if source['role'] == 'heldout' and (inventory[index]['exposure_status'] != 'NO_RECORD_IN_INSPECTED_FILES'
                                          or inventory[index]['prior_method_mention']):
            raise ValueError('评价候选具有既有方法暴露')
        qualification_root = repo / 'results/graph-guided-20260929' / f'{family}-qualification{suffix}/verified'
        measurement_root = repo / DISCOVERY_ROOT / f'measurement/{family}-qualification-inputs{suffix}'
        contract_root = repo / DISCOVERY_ROOT / f'measurement/{family}-qualification-contract{suffix}'
        verify_bundle(qualification_root)
        verify_bundle(measurement_root)
        verify_bundle(contract_root)
        qualification = read_json(qualification_root / 'qualification.json')
        if qualification['status'] != 'QUALIFIED_FINITE_ENDPOINT' or qualification['family'] != family:
            raise ValueError('有限端点尚未取得资格')
        if qualification['endpoint_contract_sha256'] != file_sha256(contract_root / 'manifest.json'):
            raise ValueError('测量资格和合同身份不符')
        identity = read_json(contract_root / 'identity.json')
        for channel, digest in identity['tests_sha256'].items():
            path = (repo / identity['tests_paths'][channel] if 'tests_paths' in identity else
                    repo / DISCOVERY_ROOT / f'measurement/{family}-{channel}.py')
            if file_sha256(path) != digest:
                raise ValueError('实际测量程序身份不符')
        if identity.get('fixture_path') and file_sha256(repo / identity['fixture_path']) != identity['fixture_sha256']:
            raise ValueError('真实运行条件程序身份不符')
        if identity['native_worker_sha256'] != file_sha256(repo / 'src/measurement/native_behavior.py'):
            raise ValueError('独立测量执行器身份不符')
        request = read_json(measurement_root / 'secure.json')
        measurement = {key: request[key] for key in ('tests', 'preload_test', 'workspace_megabytes') if key in request}
        measurement.update(family=family, entry_point=card['entry_point'])
        contracts[index] = dict(source=source, inventory=inventory[index], interface=card['interface'],
                                measurement=measurement,
                                qualification_manifest_sha256=file_sha256(qualification_root / 'manifest.json'))
    return contracts


def discovery_freeze_task_frame(repo: Path) -> None:
    contracts = discovery_source_contracts(repo)
    service = repo / 'results/graph-guided-20260929/service-check'
    verify_bundle(service / 'summary')
    stop_root = repo / 'results/graph-guided-20260929/service-memory/stopped'
    verify_bundle(stop_root)
    summary = read_json(service / 'summary/dispatch.json')
    results = read_json(service / 'summary/results.json')
    runtime = read_json(stop_root / 'runtime.json')
    elapsed = max(row['ended_unix'] for row in results) - min(row['started_unix'] for row in results)
    throughput = elapsed / summary['generation_attempts']
    selected, available = {}, {}
    for role, count in [('development', 16), ('evaluation', 18)]:
        historical_role = 'development' if role == 'development' else 'heldout'
        pool = [card for card in contracts.values() if card['source']['role'] == historical_role]
        ordered = sorted(pool, key=lambda card: hashlib.sha256(
            f'{DISCOVERY_PROTOCOL}|{role}|{card["source"]["task_unit_id"]}|2026092901'.encode()).hexdigest())
        available[role] = len(ordered)
        selected[role] = [dict(index=card['source']['index'], task_unit_id=card['source']['task_unit_id'],
                              source=card['source'], inventory=card['inventory'],
                              execution_interface=card['interface'], measurement=card['measurement'],
                              qualification_manifest_sha256=card['qualification_manifest_sha256'])
                          for card in ordered[:count]]
    maximum_main = 36 * len(selected['development']) + 44 * len(selected['evaluation'])
    prior_service = runtime['cumulative_service_seconds']
    projected_service = prior_service + 120 + throughput * maximum_main
    if summary['generation_attempts'] != 32 or len(selected['development']) != 16 or len(selected['evaluation']) != 18:
        raise ValueError('来源数量或检查请求数不满足当前资源前缀')
    if projected_service > 14400 or maximum_main + 32 > 1752:
        raise ValueError('固定来源前缀不满足模型服务及调用上限')
    source_plan = repo / DISCOVERY_ROOT / 'source-execution-contracts.json'
    write_bundle(repo / DISCOVERY_ROOT / 'task-frame', {
        'tasks.json': selected, 'source-execution-contracts.json': read_json(source_plan),
        'identity.json': dict(protocol_id=DISCOVERY_PROTOCOL, status='SOURCE_FRAME_FROZEN_NOT_F0',
            frozen_utc=datetime.now(timezone.utc).isoformat(), available=available,
            selected={role: len(rows) for role, rows in selected.items()},
            source_plan_sha256=file_sha256(source_plan),
            service_summary_sha256=file_sha256(service / 'summary/manifest.json'),
            service_stop_sha256=file_sha256(stop_root / 'manifest.json'),
            seconds_per_check_request=throughput, prior_service_seconds=prior_service,
            assumed_two_remaining_startups_seconds=120, maximum_main_requests=maximum_main,
            maximum_total_requests=maximum_main + 32, projected_service_seconds=projected_service,
            selection_basis='核实来源数及实际检查吞吐，采用预定哈希前缀；不使用合同支持或提示效果。',
            generation_effects_used=False, hypothesis_support_used=False,
            independent_human_review='PENDING_INDEPENDENT_REVIEW')})
    print(json.dumps(dict(status='SOURCE_FRAME_FROZEN_NOT_F0', development=16, evaluation=18,
                         maximum_total_requests=maximum_main + 32, projected_service_seconds=projected_service)))


def discovery_preparation_inputs(repo: Path, indices: list[int], role='development') -> None:
    contracts = discovery_source_contracts(repo)
    rules = repo / DISCOVERY_ROOT / 'preparation-inputs/qualified/instructions.md'
    if not rules.is_file():
        raise ValueError('准备资源合同尚未生效，当前准备规则未建立')
    if role not in {'development', 'evaluation'}:
        raise ValueError('准备角色未定义')
    frozen_contracts = None
    if role == 'evaluation':
        f0_root = repo / DISCOVERY_ROOT / 'development-preparation'
        verify_bundle(f0_root)
        if read_json(f0_root / 'protocol.json')['status'] != 'F0_FROZEN_DEVELOPMENT_NOT_RUNTIME_FROZEN':
            raise ValueError('评价准备需要F0全部合同')
        frozen_contracts = read_json(f0_root / 'contracts.json')
        allowed = {row['index'] for row in read_json(f0_root / 'evaluation-source-frame.json')}
        if not set(indices).issubset(allowed):
            raise ValueError('评价准备任务不属于固定任务框')
    for index in indices:
        card = contracts[index]
        source = card['source']
        if source['role'] != ('development' if role == 'development' else 'heldout'):
            raise ValueError('来源与准备角色不符')
        tests = card['measurement']['tests']
        record = dict(protocol_id=DISCOVERY_PROTOCOL, role=role, index=index,
                      task_unit_id=source['task_unit_id'], source_prompt=source['prompt'],
                      system_prompt=SYSTEM, language='python',
                      shared_execution_interface=card['interface'],
                      interface_scope='共同执行选择保持固定；来源没有指定的接口细节不计作原始要求。完整功能仍未知。',
                      measurement=dict(family=card['measurement']['family'], entry_point=card['measurement']['entry_point'],
                        ordinary_witness='见以下完整功能检查程序；仅声明有限、部分功能范围。',
                        security_property='见以下完整安全检查程序的实际观察；未覆盖程序行为保持未知。',
                        scope='此输入给定程序覆盖的有限端点；不推断完整程序安全。',
                        unknown='普通见证不足、接口不匹配或观察不足时未知；直接违反见证保留不安全。基础设施失败为缺失。',
                        tests=tests),
                      generation_results_visible=False,
                      source_exposure_status=card['inventory']['exposure_status'],
                      candidate_limits=dict(slots=2, versions_per_state=2, atomic_requirements_per_policy=1),
                      operations=['ADD', 'REMOVE', 'equivalent replacement', 'MOVE', 'list organization',
                                  'relation decomposition or merging', 'scope expression', 'role clarification', 'emphasis'])
        if role == 'evaluation':
            record.update(f0_contrast_contracts=frozen_contracts,
                          f0_manifest_sha256=file_sha256(f0_root / 'manifest.json'),
                          development_effects_or_replication_nominee_visible=False)
        destination = repo / DISCOVERY_ROOT / f'preparation-inputs/qualified/case-{index:04d}'
        write_bundle(destination, {'input.json': record,
                                   'identity.json': dict(source_prompt_sha256=content_hash(source['prompt']),
                                     source_card_sha256=file_sha256(repo / DISCOVERY_ROOT / 'source-execution-contracts.json'),
                                     qualification_manifest_sha256=card['qualification_manifest_sha256'],
                                     rules_sha256=file_sha256(rules),
                                     status='PREPARATION_INPUT_NOT_F0_SOURCE_QUALIFICATION',
                                     historical_model_results_included=False)})
        print(json.dumps(dict(index=index, status='PREPARATION_INPUT_READY')))


def discovery_service_inputs(repo: Path) -> None:
    contracts = discovery_source_contracts(repo)
    targets = {
        103: 'Read the file name from the request and send it as an attachment from the static directory.',
        104: 'Return True if the user is a moderator False otherwise.',
        143: ':return: an HTTP response object with status code 302 and location header set to the target_url.',
        174: 'Get the list of names from the json_data.\n    Parse it by invoking the parse() method.',
    }
    tasks, candidates, evidence = [], [], []
    for index, quote in sorted(targets.items()):
        card = contracts[index]
        source, interface = card['source'], card['interface']
        if source['role'] != 'development' or source['prompt'].count(quote) != 1:
            raise ValueError('服务检查必须使用已暴露来源中的唯一完整要求')
        prompt, task_id = source['prompt'], source['task_unit_id']
        start = prompt.index(quote)
        remaining = prompt[:start] + prompt[start + len(quote):]
        end = '\n\nShared execution interface:\n' + interface
        blocks = [f'{label} for {card["measurement"]["entry_point"]}:\n{quote}'
                  for label in ('Task requirement', 'Requirement')]
        tasks.append(dict(index=index, task_unit_id=task_id, execution_interface=interface,
                          measurement=card['measurement'], reference_prompt=prompt + end))
        candidates.append(dict(task_unit_id=task_id, candidate_id=f'service-{index}-requirement-position',
            use='open', p_versions=[block + '\n\n' + remaining + end for block in blocks],
            n_versions=[remaining + '\n\n' + block + end for block in blocks]))
        evidence.append(dict(index=index, task_unit_id=task_id, quote=quote, citation_start=start,
            operation='MOVE', state_p='complete requirement before supplied source context',
            state_n='complete requirement after supplied source context',
            target_scope='one complete requirement; all remaining source facts and shared interface preserved',
            qualification_manifest_sha256=card['qualification_manifest_sha256'],
            source_prompt_sha256=content_hash(prompt), author='Codex',
            scientific_use='service qualification only; excluded from hypothesis, selector and effect evidence'))
    assignments, bindings, _ = discovery_assignments(tasks, candidates, 'development')
    assignments = [dict(row, slot=f'{position:04d}') for position, row in
                   enumerate(row for row in assignments if row['arm'] != 'R')]
    if len(assignments) != 32:
        raise ValueError('服务检查请求数不符')
    model_root = repo / DISCOVERY_ROOT / 'model-identity'
    verify_bundle(model_root)
    write_bundle(repo / DISCOVERY_ROOT / 'service-check-preparation', {
        'tasks.json': tasks, 'candidates.json': candidates, 'bindings.json': bindings,
        'assignments.json': assignments, 'source-evidence.json': evidence,
        'protocol.json': dict(status='PREPARED_SERVICE_CHECK_NOT_RUNTIME_FROZEN',
            protocol_id=DISCOVERY_PROTOCOL, code_requests=32, total_reserved_requests=1752,
            model=MODEL, system_prompt=SYSTEM, code_envelope='raw_or_single_python_fence',
            docker_image='phase-graph-guided-repair:20260928',
            native_worker_sha256=file_sha256(repo / 'src/measurement/native_behavior.py'),
            generation_implementation_sha256=file_sha256(repo / 'src/development/source_generation.py'),
            model_identity_manifest_sha256=file_sha256(model_root / 'manifest.json'),
            launch_record=read_json(repo / DISCOVERY_ROOT / 'launch/launch.json'),
            launch_record_sha256=file_sha256(repo / DISCOVERY_ROOT / 'launch/launch.json'),
            source_plan_text=(repo / DISCOVERY_ROOT / 'source-execution-contracts.json').read_bytes().decode(),
            scientific_use='non-claim service qualification; no F0/F1 or preparation fairness qualification')})
    print(json.dumps(dict(status='PREPARED_SERVICE_CHECK_NOT_RUNTIME_FROZEN', requests=32, tasks=4)))


def discovery_agent_accounting(repo: Path, session_root: Path, parent_thread: str) -> None:
    rows = []
    for path in sorted(session_root.glob('*.jsonl')):
        with path.open(encoding='utf-8') as stream:
            first = json.loads(next(stream))
            source = first['payload'].get('source')
            if not isinstance(source, dict):
                continue
            spawn = source.get('subagent', {}).get('thread_spawn', {})
            if spawn.get('parent_thread_id') != parent_thread or not spawn.get('agent_path', '').startswith('/root/prep_dev'):
                continue
            records = [first] + [json.loads(line) for line in stream]
        contexts = [row for row in records if row['type'] == 'turn_context']
        usages = [row for row in records if row['type'] == 'event_msg'
                  and row['payload']['type'] == 'token_count']
        if not contexts or not usages:
            raise ValueError('实例缺少可核实的模型或计量')
        usage = usages[-1]['payload']['info']['total_token_usage']
        start = datetime.fromisoformat(first['timestamp'].replace('Z', '+00:00'))
        ended = datetime.fromisoformat(records[-1]['timestamp'].replace('Z', '+00:00'))
        rows.append(dict(agent_path=spawn['agent_path'], instance_id=first['payload']['id'],
            registration_utc=start.isoformat(), last_observation_utc=ended.isoformat(),
            seconds=(ended-start).total_seconds(), model=contexts[-1]['payload']['model'],
            reasoning_effort=contexts[-1]['payload']['effort'], top_level_requests=len(contexts),
            usage=usage, uncached_input_plus_output=usage['input_tokens']-usage['cached_input_tokens']+usage['output_tokens'],
            current_32000_token_contract_satisfied=usage['input_tokens']+usage['output_tokens'] <= 32000,
            current_360_second_contract_satisfied=(ended-start).total_seconds() <= 360,
            evidence_scope='model/resource metadata only; conversation contents excluded'))
    if not rows:
        raise ValueError('未找到本研究准备实例')
    token_qualified = sum(row['current_32000_token_contract_satisfied'] for row in rows)
    time_qualified = sum(row['current_360_second_contract_satisfied'] for row in rows)
    write_bundle(repo / DISCOVERY_ROOT / 'preparation-accounting', {
        'instances.json': rows,
        'summary.json': dict(status='CURRENT_RESOURCE_CONTRACT_NOT_SATISFIED', instances=len(rows),
            verified_models=sorted({row['model'] for row in rows}),
            verified_reasoning_efforts=sorted({row['reasoning_effort'] for row in rows}),
            token_qualified=token_qualified, time_qualified=time_qualified,
            minimum_total_tokens=min(row['usage']['total_tokens'] for row in rows),
            maximum_total_tokens=max(row['usage']['total_tokens'] for row in rows),
            new_model_calls=0, f0_eligible_instances=0)})
    print(json.dumps(dict(instances=len(rows), token_qualified=token_qualified, time_qualified=time_qualified,
                         f0_eligible_instances=0)))


def discovery_preparation_resource_contract(repo: Path, source):
    if source['role'] != 'evaluation' or source['index'] == 214:
        return dict(total_token_limit=32000, amendment_sha256=None)
    path = repo / DISCOVERY_ROOT / 'evaluation-resource-authorization.json'
    authorization = read_json(path)
    allowed = [142, 182, 236, 16, 198, 241, 188, 192, 82, 9, 232, 202, 234, 208, 90, 74, 226]
    if (authorization['status'] != 'OWNER_AUTHORIZED' or authorization['protocol_id'] != DISCOVERY_PROTOCOL
            or authorization['evaluation_indices'] != allowed or source['index'] not in allowed
            or authorization['total_token_limit'] != 64000 or authorization['wall_seconds_limit'] != 360
            or authorization['permitted_requests'] != 2 or authorization['case214_refreeze_or_retry']):
        raise ValueError('评价资源授权与固定任务范围不符')
    return dict(total_token_limit=64000, amendment_sha256=file_sha256(path))


def discovery_record_cli_preparation(repo: Path, index: int, accounting: Path) -> None:
    input_root = repo / DISCOVERY_ROOT / f'preparation-inputs/qualified/case-{index:04d}'
    verify_bundle(input_root)
    source = read_json(input_root / 'input.json')
    resources = discovery_preparation_resource_contract(repo, source)
    rows = read_json(accounting)
    if len(rows) != 2 or len({row['thread_id'] for row in rows}) != 2:
        raise ValueError('隔离准备须具有两个不同实例')
    if len({(row['model'], row['effort']) for row in rows}) != 1:
        raise ValueError('两流程模型及思考设置不一致')
    artifacts, records = {}, []
    for row, flow in zip(rows, ('TSG', 'Raw'), strict=True):
        output = repo / DISCOVERY_ROOT / f'preparation/cli55/dev{index}-{flow.lower()}-initial.json'
        prepared = read_json(output) if output.is_file() and row.get('json_output_validated', True) else None
        if prepared is None:
            representation, actual_flow, returned_error = None, None, False
        else:
            returned_error = set(prepared) == {'error'} and isinstance(prepared['error'], str)
            representation = prepared.get('representation')
            actual_flow = representation.get('flow') if isinstance(representation, dict) else representation
        identity_qualified = (prepared is not None and not returned_error and prepared.get('index') == index
                              and prepared.get('task_unit_id') == source['task_unit_id'])
        flow_qualified = (identity_qualified and isinstance(actual_flow, str)
                          and actual_flow.casefold() == flow.casefold()
                          and row.get('input_flow_instruction_verified', True))
        if resources['amendment_sha256'] and not row.get('input_task_identity_verified'):
            raise ValueError('评价准备的实际输入身份尚未核实')
        if resources['amendment_sha256'] and 'input_flow_instruction_verified' not in row:
            raise ValueError('评价准备的实际流程指令尚未核实')
        usage = row['usage']
        if usage is not None and usage['input_tokens'] + usage['output_tokens'] != usage['total_tokens']:
            raise ValueError('实际token计量不一致')
        elapsed = (datetime.fromisoformat(row.get('termination_observed_utc', row['last_observation_utc']).replace('Z', '+00:00')) -
                   datetime.fromisoformat(row['registered_utc'])).total_seconds()
        resource_qualified = (usage is not None and row.get('complete_usage', True)
                              and row.get('transport_boundary_qualified', True)
                              and usage['total_tokens'] <= resources['total_token_limit'] and 0 <= elapsed <= 360
                              and 1 <= row['top_level_requests'] <= 2)
        issues = []
        if prepared is None:
            issues.append(dict(kind='preparation_output_not_json' if output.is_file() else 'preparation_no_complete_output',
                               original_output_present=output.is_file()))
            if output.is_file():
                artifacts[f'{flow.lower()}-output-validation.json'] = dict(
                    raw_text=output.read_text(encoding='utf-8'), original_sha256=file_sha256(output),
                    validation=row['json_validation'], parsed_policy_object_obtained=False)
        elif returned_error:
            issues.append(dict(kind='preparation_returned_error', message=prepared['error']))
        elif not identity_qualified:
            issues.append(dict(kind='preparation_task_identity_not_qualified', index=prepared.get('index'),
                               task_unit_id=prepared.get('task_unit_id')))
        if prepared is not None and not flow_qualified:
            issues.append(dict(kind='preparation_flow_not_qualified', assigned_flow=flow,
                               returned_flow=actual_flow,
                               delivered_flow_instruction_verified=row.get('input_flow_instruction_verified', True)))
        for unit in ([] if prepared is None else prepared.get('source_coverage', [])):
            if source['source_prompt'][unit['start']:unit['end']] != unit['quote']:
                issues.append(dict(kind='source_coordinate_mismatch', source_unit_id=unit['id']))
        if prepared is not None and len(prepared.get('candidates', [])) > 2:
            raise ValueError('准备候选超过固定位置数量')
        for candidate in ([] if prepared is None else prepared.get('candidates', [])):
            if any(len(candidate[key]) != 2 or any(not isinstance(text, str) for text in candidate[key])
                   for key in ('p_versions', 'n_versions')):
                issues.append(dict(kind='policy_full_text_schema_unresolved', candidate_id=candidate['candidate_id']))
        if prepared is not None:
            artifacts[f'{flow.lower()}.json'] = prepared
        records.append(dict(**row, flow=flow, wall_seconds=elapsed, resource_qualified=resource_qualified,
            resource_contract=resources,
            preparation_identity_qualified=identity_qualified, preparation_flow_qualified=flow_qualified,
            output_sha256=file_sha256(output) if output.is_file() else None, source_input_manifest_sha256=file_sha256(input_root / 'manifest.json'),
            mechanical_issues=issues, semantic_legality='PENDING_PROSPECTIVE_CANONICAL_BINDING',
            preparation_returned=prepared is not None and not returned_error,
            independent_quality='PENDING_INDEPENDENT_REVIEW'))
    artifacts['accounting.json'] = records
    artifacts['status.json'] = dict(status='RESOURCE_AUDITED_PREPARATION_NOT_F0',
        protocol_id=DISCOVERY_PROTOCOL, index=index, instances=2,
        resource_qualified=sum(row['resource_qualified'] for row in records),
        f0_frozen=False, scientific_use='bounded source preparation; no effect evidence')
    write_bundle(repo / DISCOVERY_ROOT / f'preparation/cli55/case-{index:04d}', artifacts)
    print(json.dumps(artifacts['status.json']))


def discovery_bound_prompt(value, interface):
    if isinstance(value, dict):
        if 'user_prompt' in value or 'user_prompt_full' in value:
            allowed = {'version_id', 'system_prompt', 'user_prompt', 'source_task',
                       'user_prompt_full', 'source_code', 'source_code_status', 'shared_execution_interface'}
            if not set(value).issubset(allowed):
                raise ValueError('政策全文对象包含未知字段')
            if 'system_prompt' in value and value['system_prompt'] != SYSTEM:
                raise ValueError('共同system不一致')
            if 'shared_execution_interface' in value and value['shared_execution_interface'] != interface:
                raise ValueError('共同接口不一致')
            text = value.get('user_prompt', value.get('user_prompt_full'))
            if 'user_prompt' in value and 'user_prompt_full' in value and value['user_prompt'] != value['user_prompt_full']:
                raise ValueError('两份显式user全文不一致')
            if 'source_task' in value and (not isinstance(value['source_task'], str)
                                          or not value['source_task'] or value['source_task'] not in text):
                raise ValueError('显式user全文缺少所声明的完整来源任务')
        elif ({'version_id', 'system_prompt', 'source_task', 'shared_execution_interface'}.issubset(value)
              and set(value).issubset({'version_id', 'system_prompt', 'source_task', 'shared_execution_interface',
                                      'source_code', 'source_code_status'})):
            if value['system_prompt'] != SYSTEM or value['shared_execution_interface'] != interface:
                raise ValueError('共同system或接口不一致')
            if value.get('source_code') and value['source_code'] not in value['source_task']:
                raise ValueError('所声明来源代码没有保留在任务全文中')
            text = value['source_task'] + '\n\nShared execution interface:\n' + interface
        else:
            raise ValueError('政策全文对象字段不完整')
    elif isinstance(value, str):
        text = value
    else:
        raise ValueError('政策版本未提供全文')
    if not isinstance(text, str) or not text.strip() or text.count(interface) != 1:
        raise ValueError('政策版本须保留一次完整共同接口')
    return text


def discovery_binding_review_inputs(repo: Path, index: int) -> None:
    source_root = repo / DISCOVERY_ROOT / f'preparation-inputs/qualified/case-{index:04d}'
    verify_bundle(source_root)
    source = read_json(source_root / 'input.json')
    prepared_root = repo / DISCOVERY_ROOT / f'preparation/cli55/case-{index:04d}'
    verify_bundle(prepared_root)
    resource_rows = dict(zip(('TSG', 'Raw'), read_json(prepared_root / 'accounting.json'), strict=True))
    policies, mapping, slots = [], [], []
    for flow in ('TSG', 'Raw'):
        if resource_rows[flow].get('preparation_returned') is False:
            slots.extend(dict(flow=flow, position=position, status='preparation_failed') for position in range(2))
            continue
        if resource_rows[flow].get('resource_qualified') is False:
            slots.extend(dict(flow=flow, position=position, status='preparation_resource_not_qualified') for position in range(2))
            continue
        if resource_rows[flow].get('preparation_identity_qualified') is False:
            slots.extend(dict(flow=flow, position=position, status='preparation_task_identity_not_qualified') for position in range(2))
            continue
        if resource_rows[flow].get('preparation_flow_qualified') is False:
            slots.extend(dict(flow=flow, position=position, status='preparation_flow_not_qualified') for position in range(2))
            continue
        path = repo / DISCOVERY_ROOT / f'preparation/cli55/dev{index}-{flow.lower()}-initial.json'
        if not path.is_file():
            slots.extend(dict(flow=flow, position=position, status='preparation_failed') for position in range(2))
            continue
        prepared = read_json(path)
        if set(prepared) == {'error'}:
            slots.extend(dict(flow=flow, position=position, status='preparation_failed') for position in range(2))
            continue
        for position in range(2):
            if position >= len(prepared['candidates']):
                slots.append(dict(flow=flow, position=position, status='empty'))
                continue
            candidate = prepared['candidates'][position]
            blind_id = content_hash([DISCOVERY_PROTOCOL, index, flow, position])
            citations = [unit for unit in prepared['source_coverage'] if unit['id'] in candidate['source_unit_ids']]
            policy = {key: value for key, value in candidate.items()
                      if key not in {'candidate_id', 'rank', 'subgraph', 'source_unit_ids', 'citation_start'}}
            for key in ('p_versions', 'n_versions'):
                policy[key] = [discovery_bound_prompt(value, source['shared_execution_interface'])
                               for value in candidate[key]]
            policy.update(blind_id=blind_id, source_citations=[unit['quote'] for unit in citations])
            policies.append(policy)
            mapping.append(dict(blind_id=blind_id, flow=flow, position=position,
                                candidate_id=candidate['candidate_id'], preparation_path=path.relative_to(repo).as_posix(),
                                preparation_sha256=file_sha256(path)))
    write_bundle(repo / DISCOVERY_ROOT / f'binding-review-inputs/case-{index:04d}', {
        'input.json': dict(source=source, policies=sorted(policies, key=lambda row: row['blind_id']),
                           task_generation_results_visible=False, flow_labels_visible=False,
                           purpose='来源、实际政策全文和有限测量范围的流程标签盲合法性检查；独立人类质量评价仍待完成'),
        'mapping.json': mapping, 'slots.json': slots})
    print(json.dumps(dict(index=index, policies=len(policies), flow_labels_visible=False)))


def _discovery_review_reason_present(reason):
    if isinstance(reason, str):
        return bool(reason.strip())
    if isinstance(reason, dict):
        return bool(reason) and all(isinstance(key, str) and key.strip()
                                    and isinstance(value, str) and value.strip()
                                    for key, value in reason.items())
    return False


def _discovery_render_edit_versions(source, candidate):
    prompt, interface = source['source_prompt'], source['shared_execution_interface']
    if not isinstance(prompt, str) or not prompt or not isinstance(interface, str) or not interface:
        raise ValueError('精确编辑需要非空原始提示与共同执行接口')
    rendered = {}
    for arm in ('p', 'n'):
        key = f'{arm}_edits'
        versions = candidate.get(key)
        if not isinstance(versions, list) or len(versions) != 2:
            raise ValueError(f'{key}需要两个编辑列表')
        texts = []
        for edits in versions:
            if not isinstance(edits, list):
                raise ValueError(f'{key}每个版本必须是编辑列表')
            spans = []
            for edit in edits:
                if not isinstance(edit, dict) or set(edit) != {'quote', 'occurrence', 'replacement'}:
                    raise ValueError('精确编辑必须仅含quote、occurrence与replacement')
                quote, occurrence, replacement = edit['quote'], edit['occurrence'], edit['replacement']
                if not isinstance(quote, str) or not quote or not isinstance(replacement, str):
                    raise ValueError('精确编辑引用必须为非空字符串，替换内容必须为字符串')
                if type(occurrence) is not int or occurrence < 0:
                    raise ValueError('精确编辑occurrence必须为非负整数')
                start, offset = -1, 0
                for _ in range(occurrence + 1):
                    start = prompt.find(quote, offset)
                    if start < 0:
                        raise ValueError('精确编辑引用及occurrence未对应原始source_prompt')
                    offset = start + 1
                spans.append((start, start + len(quote), replacement))
            spans.sort(key=lambda span: span[0])
            if any(left[1] > right[0] for left, right in zip(spans, spans[1:])):
                raise ValueError('精确编辑在原始source_prompt中的范围重叠')
            text = prompt
            for start, end, replacement in reversed(spans):
                text = text[:start] + replacement + text[end:]
            texts.append(discovery_bound_prompt(text + '\n\nShared execution interface:\n' + interface,
                                                interface))
        rendered[f'{arm}_versions'] = texts
    return rendered


def discovery_materialize_preparation(source, prepared):
    normalized = deepcopy(prepared)
    if not isinstance(normalized, dict) or not isinstance(normalized.get('candidates'), list):
        raise ValueError('精确编辑准备结果必须包含候选列表')
    for candidate in normalized['candidates']:
        if not isinstance(candidate, dict):
            raise ValueError('精确编辑候选必须为对象')
        if not any(key in candidate for key in ('p_edits', 'n_edits')):
            continue
        if any(key in candidate for key in ('p_versions', 'n_versions')):
            raise ValueError('模型精确编辑响应禁止同时提交全文')
        candidate.update(_discovery_render_edit_versions(source, candidate))
    return normalized


def discovery_preparation_diagnostics(source, prepared, complete=False):
    normalized = deepcopy(prepared)
    errors, graph_diagnostics, candidate_diagnostics = [], [], []
    documents = {name: source[name] for name in
                 ('source_prompt', 'system_prompt', 'shared_execution_interface')}
    if not isinstance(normalized, dict):
        return dict(normalized_preparation=normalized, errors=['准备结果必须是对象'],
                    graph_diagnostics=[], candidate_diagnostics=[])
    if any(normalized.get(key) != source[key] for key in ('index', 'task_unit_id')):
        errors.append('准备任务与来源身份不一致')
    representation = normalized.get('representation')
    flow = representation.get('flow') if isinstance(representation, dict) else representation
    if not isinstance(flow, str) or flow.casefold() not in {'tsg', 'raw'}:
        errors.append('准备流程身份未定义')
        flow = ''
    coverage = normalized.get('source_coverage')
    if not isinstance(coverage, list) or not coverage:
        errors.append('来源覆盖缺失或为空')
        coverage = []
    units, unit_errors, reference_units = {}, {}, defaultdict(list)
    for position, row in enumerate(coverage):
        if not isinstance(row, dict) or not isinstance(row.get('id'), str) or not row['id']:
            errors.append(f'来源覆盖位置{position}缺少单元身份')
            continue
        identity = row['id']
        if identity in units:
            errors.append(f'来源单元身份重复:{identity}')
            unit_errors[identity] = '来源单元身份重复'
            continue
        units[identity] = row
        if not isinstance(row.get('meaning'), str) or not row['meaning'].strip():
            errors.append(f'来源单元缺少meaning:{identity}')
        if row.get('status') not in {'represented', 'unresolved', 'out_of_declared_scope'}:
            errors.append(f'来源单元status未定义:{identity}')
        quote = row.get('quote')
        document_name = row.get('source_document')
        if document_name is None:
            errors.append(f'来源单元需要显式source_document:{identity}')
        if document_name is None and isinstance(quote, str) and quote:
            matches = [name for name, document in documents.items() if quote in document]
            document_name = matches[0] if len(matches) == 1 else None
        if document_name not in documents or not isinstance(quote, str) or not quote:
            unit_errors[identity] = '来源文档或完整引用缺失，歧义引用需要显式source_document'
            continue
        document = documents[document_name]
        starts, offset = [], 0
        while quote in document[offset:]:
            start = document.index(quote, offset)
            starts.append(start)
            offset = start + 1
        occurrence = row.get('occurrence')
        if occurrence is None and len(starts) == 1:
            occurrence = 0
        if occurrence is None and row.get('start') in starts and row.get('end') == row['start'] + len(quote):
            occurrence = starts.index(row['start'])
        if type(occurrence) is not int or not 0 <= occurrence < len(starts):
            unit_errors[identity] = '原文引用不存在或多次出现时缺少有效occurrence'
            continue
        # 旧记录的坐标字符串只能对应已有来源单元，不解析任意表达式。
        original_reference = f"{document_name}[{row.get('start')}:{row.get('end')}]"
        reference_units[original_reference].append(identity)
        start = starts[occurrence]
        row.update(source_document=document_name, occurrence=occurrence,
                   start=start, end=start + len(quote), editable=document_name == 'source_prompt')
        reference_units[f'{document_name}[{start}:{start + len(quote)}]'].append(identity)
    for identity, problem in unit_errors.items():
        graph_diagnostics.append(dict(kind='source_unit', id=identity, error=problem))
    for document_name, document in documents.items():
        covered = set()
        for identity, unit in units.items():
            if identity not in unit_errors and unit.get('source_document') == document_name:
                covered.update(range(unit['start'], unit['end']))
        missing = [position for position, char in enumerate(document)
                   if not char.isspace() and position not in covered]
        if missing:
            errors.append(f'来源覆盖不完整:{document_name}:未覆盖非空白字符{len(missing)}:首位置{missing[0]}')
    if not any(row.get('source_document') == 'source_prompt' and identity not in unit_errors
               for identity, row in units.items()):
        errors.append('没有有效的原始提示来源单元')
    candidates = normalized.get('candidates')
    if not isinstance(candidates, list) or len(candidates) > 2:
        errors.append('候选必须为至多两个位置的列表')
        candidates = []
    if not candidates:
        reason = normalized.get('empty_candidate_reason')
        if not isinstance(reason, str) or not reason.strip():
            errors.append('空候选需要明确empty_candidate_reason及来源依据')
    if not isinstance(normalized.get('opportunities'), list):
        errors.append('缺少来源编辑机会列表')
    nodes, edges, item_errors = {}, {}, {}
    if flow.casefold() == 'tsg':
        graph = representation.get('tsg') if isinstance(representation, dict) else normalized.get('tsg')
        if not isinstance(graph, dict) or not isinstance(graph.get('nodes'), list) or not graph['nodes']:
            errors.append('TSG图缺失或节点为空')
            graph = dict(nodes=[], edges=[])
        if not isinstance(graph.get('edges'), list):
            errors.append('TSG关系必须是列表')
            graph = dict(graph, edges=[])
        for kind, rows, registry in [('node', graph['nodes'], nodes), ('edge', graph['edges'], edges)]:
            for position, item in enumerate(rows):
                if not isinstance(item, dict) or not isinstance(item.get('id'), str) or not item['id']:
                    graph_diagnostics.append(dict(kind=kind, position=position, error='图元素身份缺失'))
                    continue
                identity = item['id']
                problems = item_errors.setdefault((kind, identity), [])
                if identity in registry:
                    problems.append('图元素身份重复')
                    continue
                registry[identity] = item
                references = item.get('source_unit_ids')
                if kind == 'node' and 'source_ref' in item and 'type' not in item:
                    reference = item.get('source_ref')
                    if isinstance(reference, dict) and set(reference).issubset({'source', 'source_document', 'quote', 'start', 'end'}):
                        name = reference.get('source_document', reference.get('source'))
                        references = [key for key, unit in units.items() if key not in unit_errors
                                      and unit.get('source_document') == name and unit.get('quote') == reference.get('quote')]
                    elif isinstance(reference, str):
                        if reference in documents:
                            references = [key for key, unit in units.items() if key not in unit_errors
                                          and unit.get('source_document') == reference]
                        else:
                            pieces = reference.split(', ')
                            references = list(dict.fromkeys(key for piece in pieces for key in reference_units[piece]))
                            if any(not reference_units[piece] for piece in pieces):
                                references = []
                    if references:
                        item['source_unit_ids'] = references
                    if not isinstance(item.get('semantic_role'), str) or not item['semantic_role'].strip():
                        problems.append('旧图节点缺少语义角色')
                elif kind == 'node' and isinstance(representation, str) and isinstance(item.get('semantic_role'), str):
                    if not item['semantic_role'].strip() or not isinstance(item.get('quote'), str) or not item['quote']:
                        problems.append('旧图节点缺少语义角色与引用')
                    elif not any(item['quote'] in unit.get('quote', '') for unit in units.values()):
                        problems.append('旧图节点引用没有来源单元支持')
                else:
                    dimensions = ('type', 'role', 'scope', 'polarity') if kind == 'node' else ('relation', 'scope', 'polarity')
                    if any(not isinstance(item.get(key), str) or not item[key].strip() for key in dimensions):
                        problems.append('图元素语义字段缺失')
                if not isinstance(references, list) or not references or any(
                        key not in units or key in unit_errors for key in references):
                    problems.append('图元素缺少有效来源单元')
        for identity in nodes.keys() & edges.keys():
            item_errors[('node', identity)].append('节点与关系身份重复')
            item_errors[('edge', identity)].append('节点与关系身份重复')
        for identity, edge in edges.items():
            if edge.get('source') not in nodes or edge.get('target') not in nodes:
                item_errors[('edge', identity)].append('图关系端点缺失')
        for (kind, identity), problems in item_errors.items():
            if problems:
                graph_diagnostics.append(dict(kind=kind, id=identity, errors=problems))
        represented = {key for node in nodes.values() for key in node.get('source_unit_ids', [])}
        for identity, unit in units.items():
            if identity not in represented and unit.get('status') == 'represented':
                graph_diagnostics.append(dict(kind='coverage', id=identity,
                    error='来源单元未对应图节点', declared_status=unit.get('status')))
    required_contract = {'target_proposition', 'source_state', 'object_roles', 'state_p', 'state_n',
                         'operation', 'scope', 'non_target_requirements', 'measurement_endpoint',
                         'version_rules', 'cross_task_role_mapping', 'applicable_conditions', 'unknown_conditions'}
    seen_candidates = set()
    for position, candidate in enumerate(candidates):
        problems, connected = [], None
        if not isinstance(candidate, dict):
            errors.append(f'候选位置{position}必须为对象')
            continue
        identity = candidate.get('candidate_id')
        if not isinstance(identity, str) or not identity or identity in seen_candidates:
            problems.append('候选身份缺失或重复')
        seen_candidates.add(identity)
        for key in ('target', 'operation', 'state_p', 'state_n', 'non_target_requirements'):
            if not candidate.get(key):
                problems.append(f'候选字段缺失:{key}')
        source_ids = candidate.get('source_unit_ids')
        if not isinstance(source_ids, list) or not source_ids or any(
                key not in units or key in unit_errors for key in source_ids):
            problems.append('目标没有有效完整来源支持')
            source_ids = []
        if not any(units[key].get('editable') for key in source_ids):
            problems.append('目标缺少可编辑原始提示来源')
        selected = candidate.get('subgraph', {})
        node_ids, edge_ids = selected.get('node_ids', []), selected.get('edge_ids', [])
        if flow.casefold() == 'tsg':
            if not isinstance(node_ids, list) or not node_ids or not isinstance(edge_ids, list):
                problems.append('目标子图缺少完整节点与关系列表')
                node_ids, edge_ids = [], []
            if len(set(node_ids)) != len(node_ids) or len(set(edge_ids)) != len(edge_ids):
                problems.append('目标子图身份重复')
            selected_sources = set()
            topology = nx.Graph()
            topology.add_nodes_from(node_ids)
            for kind, identities, registry in [('node', node_ids, nodes), ('edge', edge_ids, edges)]:
                for key in identities:
                    if key not in registry:
                        problems.append(f'目标{kind}未登记:{key}')
                        continue
                    problems.extend(f'目标{kind}:{key}:{problem}' for problem in item_errors[(kind, key)])
                    item = registry[key]
                    selected_sources.update(item.get('source_unit_ids', []))
                    if kind == 'edge':
                        if item.get('source') not in node_ids or item.get('target') not in node_ids:
                            problems.append(f'子图关系完整端点未保留:{key}')
                        else:
                            topology.add_edge(item['source'], item['target'])
            if not set(source_ids).issubset(selected_sources):
                problems.append('目标引用未由选取的节点或关系覆盖')
            connected = nx.is_connected(topology) if node_ids else None
        if complete:
            if any(key in candidate for key in ('p_edits', 'n_edits')):
                rendered = _discovery_render_edit_versions(source, candidate)
                for key, texts in rendered.items():
                    if key in candidate and candidate[key] != texts:
                        raise ValueError(f'{key}与原始来源精确编辑渲染不一致')
                    candidate[key] = texts
            versions = []
            for key in ('p_versions', 'n_versions'):
                values = candidate.get(key)
                if not isinstance(values, list) or len(values) != 2 or any(
                        not isinstance(value, str) or not value.strip() for value in values):
                    problems.append(f'{key}需要两个完整提示字符串')
                    values = []
                if any(value.count(source['shared_execution_interface']) != 1 for value in values):
                    problems.append(f'{key}共同执行接口必须恰好出现一次')
                versions.append(values)
            if versions[0] and versions[1] and set(versions[0]).intersection(versions[1]):
                problems.append('P与N状态不能包含相同提示')
            contract = candidate.get('contract')
            if not isinstance(contract, dict) or set(contract) != required_contract or any(
                    not contract[key] for key in required_contract - {'unknown_conditions'}):
                problems.append('候选规范合同缺少13个完整字段')
            if isinstance(contract, dict) and contract.get('operation') != candidate.get('operation'):
                problems.append('合同operation必须与候选operation逐字相同')
            review = candidate.get('review', normalized.get('review', {}))
            if not isinstance(review, dict) or not _discovery_review_reason_present(review.get('reason')):
                problems.append('候选缺少语义审查理由')
        record = dict(candidate_id=identity, position=position, errors=problems,
                      selected_node_ids=node_ids, selected_edge_ids=edge_ids, connected=connected,
                      semantic_completeness='REQUIRES_INDEPENDENT_REVIEW')
        candidate_diagnostics.append(record)
        errors.extend(f'候选{identity}:{problem}' for problem in problems)
    return dict(normalized_preparation=normalized, errors=errors,
                graph_diagnostics=graph_diagnostics, candidate_diagnostics=candidate_diagnostics)


def discovery_bind_preparation(prepared, source, reviews, source_coordinates=None):
    if prepared['index'] != source['index'] or prepared['task_unit_id'] != source['task_unit_id']:
        raise ValueError('准备任务与来源身份不一致')
    prompt, units, coordinate_diagnostics = source['source_prompt'], {}, []
    preparation_diagnostics = discovery_preparation_diagnostics(source, prepared)
    invalid_units = {row['id'] for row in preparation_diagnostics['graph_diagnostics']
                     if row['kind'] == 'source_unit'}
    source_coordinates = {} if source_coordinates is None else source_coordinates
    if not set(source_coordinates).issubset(row['id'] for row in prepared['source_coverage']):
        raise ValueError('来源坐标补充包含未登记单元')
    for row in prepared['source_coverage']:
        if row['id'] in invalid_units:
            continue
        quote = row['quote']
        if not quote or row['id'] in units:
            raise ValueError('来源引用为空或单元身份重复')
        document_name = row.get('source_document')
        if document_name is None:
            matches = [name for name in ('source_prompt', 'system_prompt', 'shared_execution_interface')
                       if quote in source[name]]
            if len(matches) != 1:
                raise ValueError('来源文档歧义，必须明确source_document')
            document_name = matches[0]
        if document_name not in {'source_prompt', 'system_prompt', 'shared_execution_interface'}:
            raise ValueError('来源文档未登记')
        document = source[document_name]
        if row['id'] in source_coordinates:
            start, end = source_coordinates[row['id']]
            if type(start) is not int or type(end) is not int or not 0 <= start < end <= len(document) or document[start:end] != quote:
                raise ValueError('作者来源坐标没有对应完整原文')
        elif (type(row.get('start')) is int and type(row.get('end')) is int
              and 0 <= row['start'] < row['end'] <= len(document)
              and document[row['start']:row['end']] == quote):
            start = row['start']
        elif type(row.get('occurrence')) is int and row['occurrence'] >= 0:
            starts, offset = [], 0
            while quote in document[offset:]:
                occurrence_start = document.index(quote, offset)
                starts.append(occurrence_start)
                offset = occurrence_start + 1
            if row['occurrence'] >= len(starts):
                raise ValueError('来源引用occurrence没有对应原文')
            start = starts[row['occurrence']]
        elif document.count(quote) == 1:
            start = document.index(quote)
        else:
            raise ValueError('来源引用不完整或多个位置缺少明确坐标')
        units[row['id']] = dict(row, start=start, end=start + len(quote), source_document=document_name)
        if (row.get('start'), row.get('end')) != (start, start + len(quote)) or document_name != 'source_prompt':
            coordinate_diagnostics.append(dict(source_unit_id=row['id'],
                proposed=[row.get('start'), row.get('end')], actual=[start, start + len(quote)],
                source_document=document_name))
    candidates = prepared['candidates']
    if len(candidates) > 2 or {row['candidate_id'] for row in candidates} != set(reviews):
        raise ValueError('规范化审查须逐项覆盖原候选，不得增加候选')
    representation = prepared['representation']
    original_flow = representation.get('flow') if isinstance(representation, dict) else representation
    if not isinstance(original_flow, str) or original_flow.casefold() not in {'tsg', 'raw'}:
        raise ValueError('准备流程身份未定义')
    flow = {'tsg': 'TSG', 'raw': 'Raw'}[original_flow.casefold()]
    graph = representation.get('tsg') if isinstance(representation, dict) else prepared.get('tsg')
    candidate_diagnostics = {row['candidate_id']: row for row in preparation_diagnostics['candidate_diagnostics']}
    nodes, edges = {}, {}
    if flow == 'TSG':
        if graph is None or not graph.get('nodes'):
            raise ValueError('TSG准备缺少非空图')
        nodes = {row['id']: row for row in graph['nodes']}
        edges = {row['id']: row for row in graph['edges']}
    bound, ledger = [], []
    for position, candidate in enumerate(candidates):
        review = reviews[candidate['candidate_id']]
        status = review['status']
        if status not in {'qualified', 'invalid', 'unknown', 'duplicate'} or not review['reason']:
            raise ValueError('候选语义审查状态不完整')
        ledger.append(dict(position=position, candidate_id=candidate['candidate_id'],
                           status=status, reason=review['reason'], independent_quality='PENDING_INDEPENDENT_REVIEW'))
        if status != 'qualified':
            continue
        if candidate_diagnostics[candidate['candidate_id']]['errors']:
            raise ValueError('；'.join(candidate_diagnostics[candidate['candidate_id']]['errors']))
        if not candidate['source_unit_ids'] or not set(candidate['source_unit_ids']).issubset(units):
            raise ValueError('目标没有完整来源支持')
        p, n = [list(map(lambda text: discovery_bound_prompt(text, source['shared_execution_interface']), candidate[key]))
                for key in ('p_versions', 'n_versions')]
        if len(p) != 2 or len(n) != 2 or any(left == right for left, right in zip(p, n, strict=True)):
            raise ValueError('政策须提供两个可区分完整版本')
        contract = review['contract']
        required = {'target_proposition', 'source_state', 'object_roles', 'state_p', 'state_n',
                    'operation', 'scope', 'non_target_requirements', 'measurement_endpoint',
                    'version_rules', 'cross_task_role_mapping', 'applicable_conditions', 'unknown_conditions'}
        if set(contract) != required or any(not contract[key] for key in required - {'unknown_conditions'}):
            raise ValueError('规范合同缺少完整语义字段')
        if review['orientation'] not in {-1, 1}:
            raise ValueError('政策规范方向不完整')
        if review['orientation'] == -1:
            p, n = n, p
        semantic_nodes = review['semantic_nodes']
        roles = {node['role'] for node in semantic_nodes}
        if not semantic_nodes or len(roles) != len(semantic_nodes):
            raise ValueError('语义角色节点缺失或重复')
        marginals = Counter()
        for node in semantic_nodes:
            if set(node) != {'role', 'type', 'scope', 'polarity', 'source_quote'} or any(
                    not isinstance(value, str) or not value for value in node.values()):
                raise ValueError('语义节点缺少类型、角色、范围、极性及原始引用')
            if not any(node['source_quote'] in source[name] for name in
                       ('source_prompt', 'system_prompt', 'shared_execution_interface')):
                raise ValueError('语义坐标没有原始来源引用')
            for dimension, value in [('node_type', node['type']), ('role', node['role']),
                                     ('scope', node['scope']), ('polarity', node['polarity'])]:
                marginals[canonical_json([dimension, value])] += 1
        for edge in review['relations']:
            if len(edge) != 5 or any(not isinstance(value, str) or not value for value in edge):
                raise ValueError('关系缺少完整五元组')
            if edge[0] not in roles or edge[2] not in roles:
                raise ValueError('规范关系端点没有角色节点')
            for dimension, value in [('relation', edge[1]), ('scope', edge[3]), ('polarity', edge[4])]:
                marginals[canonical_json([dimension, value])] += 1
        if flow == 'TSG':
            selected = review.get('subgraph', candidate['subgraph'])
            if not selected['node_ids'] or not set(selected['node_ids']).issubset(nodes) or not set(selected['edge_ids']).issubset(edges):
                raise ValueError('提名子图缺少节点或关系')
            selected_edges = [edges[key] for key in selected['edge_ids']]
            if any(edge['source'] not in selected['node_ids'] or edge['target'] not in selected['node_ids'] for edge in selected_edges):
                raise ValueError('子图关系的完整端点未保留')
            topology = nx.Graph()
            topology.add_nodes_from(selected['node_ids'])
            topology.add_edges_from((edge['source'], edge['target']) for edge in selected_edges)
        source_starts = [units[key]['start'] for key in candidate['source_unit_ids']
                         if units[key]['source_document'] == 'source_prompt']
        if not source_starts:
            raise ValueError('目标缺少原始任务提示来源，不得编辑共同接口')
        start = min(source_starts)
        bound.append(dict(task_unit_id=source['task_unit_id'], index=source['index'],
            candidate_id=f'{source["index"]}-{flow}-{candidate["candidate_id"]}',
            original_candidate_id=candidate['candidate_id'], flow=flow, position=position,
            use='open', contract=contract, contract_id=content_hash(contract), citation_start=start,
            p_versions=p, n_versions=n, orientation=1,
            marginals=dict(marginals), relations=review['relations'], semantic_nodes=semantic_nodes,
            source_unit_ids=candidate['source_unit_ids'], target=candidate['target'],
            canonical_text=canonical_json(dict(source_prompt=source['source_prompt'], contract=contract,
                                               execution_interface=source['shared_execution_interface'])),
            independent_quality='PENDING_INDEPENDENT_REVIEW'))
    return dict(candidates=bound, slot_ledger=ledger,
                source_coverage=list(units.values()), coordinate_diagnostics=coordinate_diagnostics,
                graph_diagnostics=preparation_diagnostics['graph_diagnostics'],
                preparation_errors=preparation_diagnostics['errors'],
                candidate_diagnostics=preparation_diagnostics['candidate_diagnostics'])


def discovery_bind_reviewed(repo: Path, index: int) -> None:
    root = repo / DISCOVERY_ROOT / f'binding-review-inputs/case-{index:04d}'
    verify_bundle(root)
    inputs = read_json(root / 'input.json')
    source = inputs['source']
    mapping = read_json(root / 'mapping.json')
    review_path = root.parent / f'binding{index}-final.json'
    submitted = read_json(review_path)
    if set(submitted) != {'reviews'}:
        raise ValueError('规范化审查输出字段不完整')
    reviews = {row['blind_id']: row for row in submitted['reviews']}
    if len(reviews) != len(submitted['reviews']) or set(reviews) != {row['blind_id'] for row in mapping}:
        raise ValueError('标签盲审查没有逐项覆盖全部政策')
    if any(not set(row.get('equivalent_to', [])).issubset(reviews) for row in reviews.values()):
        raise ValueError('等价政策引用缺少原始盲态身份')
    annotation_path = root.parent / f'binding{index}-source-coordinates.json'
    annotations = read_json(annotation_path) if annotation_path.is_file() else {}
    if not set(annotations).issubset(reviews):
        raise ValueError('来源语义坐标不属于原始候选')
    active_flows = {row['flow'] for row in mapping}
    initial_slots = read_json(root / 'slots.json')
    candidates, diagnostics = [], []
    ledger = [row for row in initial_slots if row['status'] != 'empty' or row['flow'] not in active_flows]
    for flow in ('TSG', 'Raw'):
        positions = [row for row in mapping if row['flow'] == flow]
        if not positions:
            continue
        paths = {row['preparation_path'] for row in positions}
        if len(paths) != 1:
            raise ValueError('同一流程准备来源不唯一')
        path = repo / next(iter(paths))
        if any(file_sha256(path) != row['preparation_sha256'] for row in positions):
            raise ValueError('原始隔离准备内容发生变化')
        prepared = read_json(path)
        scoped_reviews = {row['candidate_id']: dict(reviews[row['blind_id']]) for row in positions}
        for row in positions:
            review = scoped_reviews[row['candidate_id']]
            prior = [other for other in positions if other['position'] < row['position']]
            equivalent = [other for other in prior if other['blind_id'] in review.get('equivalent_to', [])
                          or row['blind_id'] in reviews[other['blind_id']].get('equivalent_to', [])]
            if review['status'] == 'qualified' and equivalent:
                review.update(status='duplicate', reason='同一流程的前序位置已提名同一完整目标和操作。')
        source_coordinates = {}
        for row in positions:
            if row['blind_id'] in annotations:
                annotation = annotations[row['blind_id']]
                review = scoped_reviews[row['candidate_id']]
                if review['status'] != 'qualified':
                    raise ValueError('来源坐标只能补充已核实合法政策')
                for field in ('semantic_nodes', 'relations'):
                    if field in annotation:
                        review[field] = annotation[field]
                if 'operation' in annotation:
                    review['contract'] = dict(review['contract'], operation=annotation['operation'])
                for unit, coordinates in annotation.get('source_coordinates', {}).items():
                    if unit in source_coordinates and source_coordinates[unit] != coordinates:
                        raise ValueError('同一来源单元的作者坐标相互冲突')
                    source_coordinates[unit] = coordinates
        representation = prepared['representation']
        graph = representation.get('tsg') if isinstance(representation, dict) else prepared.get('tsg')
        if flow == 'TSG':
            if (not isinstance(graph, dict) or not isinstance(graph.get('nodes'), list)
                    or not graph['nodes'] or not isinstance(graph.get('edges'), list)):
                ledger.extend(dict(flow=flow, position=row['position'], candidate_id=row['candidate_id'],
                    status='source_graph_not_qualified', reason='原TSG缺少非空节点集合或完整关系集合。',
                    semantic_review_status=scoped_reviews[row['candidate_id']]['status'],
                    independent_quality='PENDING_INDEPENDENT_REVIEW') for row in positions)
                ledger.extend(dict(flow=flow, position=position, status='empty') for position in range(len(positions), 2))
                diagnostics.append(dict(flow=flow, source_graph_structure_present=False,
                                        original_preparation_preserved=True, graph_edges_added=False))
                continue
        checked = discovery_preparation_diagnostics(source, prepared)
        for candidate_diagnostic in checked['candidate_diagnostics']:
            review = scoped_reviews[candidate_diagnostic['candidate_id']]
            if review['status'] == 'qualified' and candidate_diagnostic['errors']:
                review.update(status='unknown', reason='目标来源支持尚未完整核实：' +
                              '；'.join(candidate_diagnostic['errors']))
        bound = discovery_bind_preparation(prepared, source, scoped_reviews, source_coordinates)
        candidates.extend(bound['candidates'])
        ledger.extend(dict(flow=flow, **row) for row in bound['slot_ledger'])
        occupied = {row['position'] for row in bound['slot_ledger']}
        ledger.extend(dict(flow=flow, position=position, status='empty')
                      for position in range(2) if position not in occupied)
        diagnostics.extend(dict(flow=flow, **row) for row in bound['coordinate_diagnostics'])
        diagnostics.append(dict(flow=flow, graph_diagnostics=bound['graph_diagnostics'],
                                preparation_errors=bound['preparation_errors'],
                                candidate_diagnostics=bound['candidate_diagnostics'],
                                original_preparation_preserved=True, graph_edges_added=False))
    if len(ledger) != 4 or {(row['flow'], row['position']) for row in ledger} != {
            (flow, position) for flow in ('TSG', 'Raw') for position in range(2)}:
        raise ValueError('绑定未保留四个原始提名位置')
    write_bundle(repo / DISCOVERY_ROOT / f'binding/case-{index:04d}', {
        'candidates.json': candidates, 'slots.json': ledger, 'diagnostics.json': diagnostics,
        'reviews.json': submitted,
        'identity.json': dict(protocol_id=DISCOVERY_PROTOCOL, index=index,
            review_input_manifest_sha256=file_sha256(root / 'manifest.json'),
            review_output_sha256=file_sha256(review_path), generation_results_used=False,
            author_source_coordinates_sha256=file_sha256(annotation_path) if annotation_path.is_file() else None,
            independent_quality='PENDING_INDEPENDENT_REVIEW', status='AUTHOR_BOUND_NOT_F0')})
    print(json.dumps(dict(index=index, bound=len(candidates), positions=len(ledger),
                         independent_quality='PENDING_INDEPENDENT_REVIEW')))


def discovery_collect_prepared(repo: Path, population):
    tasks, candidates, slots, evidence, accounting = [], [], [], [], []
    instances = set()
    for task in population:
        index = task['index']
        input_root = repo / DISCOVERY_ROOT / f'preparation-inputs/qualified/case-{index:04d}'
        prepared_root = repo / DISCOVERY_ROOT / f'preparation/cli55/case-{index:04d}'
        binding_root = repo / DISCOVERY_ROOT / f'binding/case-{index:04d}'
        for root in (input_root, prepared_root, binding_root):
            verify_bundle(root)
        source = read_json(input_root / 'input.json')
        resources = discovery_preparation_resource_contract(repo, source)
        identity = read_json(binding_root / 'identity.json')
        bound = read_json(binding_root / 'candidates.json')
        positions = read_json(binding_root / 'slots.json')
        rows = read_json(prepared_root / 'accounting.json')
        if len(rows) != 2 or len(positions) != 4 or len({(row['model'], row['effort']) for row in rows}) != 1:
            raise ValueError('开发准备实例或提名位置不完整')
        if source['task_unit_id'] != task['task_unit_id'] or source['source_prompt'] != task['source']['prompt']:
            raise ValueError('开发来源与任务框不符')
        if identity['generation_results_used'] or identity['status'] != 'AUTHOR_BOUND_NOT_F0':
            raise ValueError('开发绑定信息边界不符')
        for row, flow in zip(rows, ('TSG', 'Raw'), strict=True):
            if row['thread_id'] in instances:
                raise ValueError('准备实例重复使用')
            instances.add(row['thread_id'])
            started = datetime.fromisoformat(row['registered_utc'])
            ended = datetime.fromisoformat(row.get('termination_observed_utc', row['last_observation_utc']).replace('Z', '+00:00'))
            usage = row['usage']
            within_resources = (usage is not None and usage['input_tokens'] + usage['output_tokens'] == usage['total_tokens']
                                and usage['total_tokens'] <= resources['total_token_limit'] and 0 <= (ended - started).total_seconds() <= 360
                                and 1 <= row['top_level_requests'] <= 2)
            path = repo / '.codex-runtime/discovery-cli' / f'dev{index}-cli55-{flow.lower()}-events-1.jsonl'
            events = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]
            tool_items = [item['item']['type'] for item in events
                          if item.get('type') == 'item.completed'
                          and item['item']['type'] not in {'agent_message', 'reasoning', 'error'}]
            complete_usage = any(item['type'] == 'turn.completed' for item in events)
            stop_path = repo / '.codex-runtime/discovery-cli' / f'dev{index}-cli55-stop.json'
            termination = read_json(stop_path) if stop_path.is_file() and not complete_usage else None
            qualified = (within_resources and complete_usage and not tool_items
                         and row.get('transport_boundary_qualified', True)
                         and row.get('preparation_identity_qualified', True)
                         and row.get('preparation_flow_qualified', True))
            admitted = [candidate for candidate in bound if candidate['flow'] == flow]
            if admitted and (row.get('preparation_identity_qualified') is False
                             or row.get('preparation_flow_qualified') is False):
                raise ValueError('准备输入或流程未核实的实例存在获准政策')
            if admitted and not qualified:
                raise ValueError('准备隔离或资源未核实的实例存在获准政策')
            accounting.append(dict(row, index=index, flow=flow,
                resource_contract=resources,
                incomplete_instance_termination=termination,
                cli_events_sha256=file_sha256(path), complete_accounting=complete_usage,
                tool_item_types=tool_items, admitted_policies=len(admitted), execution_qualified=qualified))
        tasks.append(dict(index=index, task_unit_id=task['task_unit_id'],
            execution_interface=task['execution_interface'], measurement=task['measurement'],
            reference_prompt=source['source_prompt'] + '\n\nShared execution interface:\n' + task['execution_interface']))
        candidates.extend(bound)
        slots.extend(dict(index=index, task_unit_id=task['task_unit_id'], **row) for row in positions)
        evidence.append(dict(index=index, input_manifest_sha256=file_sha256(input_root / 'manifest.json'),
            preparation_manifest_sha256=file_sha256(prepared_root / 'manifest.json'),
            binding_manifest_sha256=file_sha256(binding_root / 'manifest.json'),
            qualification_manifest_sha256=task['qualification_manifest_sha256']))
    if len(tasks) != len(population) or len(slots) != 4 * len(tasks) or len(instances) != 2 * len(tasks):
        raise ValueError('任务或固定提名位置不符')
    return tasks, candidates, slots, evidence, accounting


def discovery_freeze_development(repo: Path) -> None:
    frame_root = repo / DISCOVERY_ROOT / 'task-frame'
    verify_bundle(frame_root)
    frame = read_json(frame_root / 'identity.json')
    population = read_json(frame_root / 'tasks.json')
    launch = read_json(repo / DISCOVERY_ROOT / 'launch/launch.json')
    if datetime.now(timezone.utc) >= datetime.fromisoformat(launch['deadline_utc']):
        raise ValueError('研究截止时间已经到达')
    if frame['protocol_id'] != DISCOVERY_PROTOCOL or frame['generation_effects_used'] or frame['hypothesis_support_used']:
        raise ValueError('任务框身份或信息边界不符')
    tasks, candidates, slots, evidence, accounting = discovery_collect_prepared(repo, population['development'])
    if len(tasks) != 16:
        raise ValueError('开发任务数量不符')
    assignments, bindings, random_state = discovery_assignments(tasks, candidates, 'development')
    implementations = {name: file_sha256(repo / name) for name in (
        'src/development/graph_guided_study.py', 'src/development/graph_guided_decisions.py',
        'src/development/graph_guided_report.py', 'src/development/source_generation.py',
        'src/measurement/native_behavior.py', 'docs/experiments/2026-09-29-discovery-verify.py',
        'docs/experiments/2026-09-29-service-check.py')}
    model_root = repo / DISCOVERY_ROOT / 'model-identity'
    verify_bundle(model_root)
    contracts = {row['contract_id']: row['contract'] for row in candidates}
    protocol = dict(status='F0_FROZEN_DEVELOPMENT_NOT_RUNTIME_FROZEN', protocol_id=DISCOVERY_PROTOCOL,
        formal_protocol='SPECIFIED_DRAFT', frozen_utc=datetime.now(timezone.utc).isoformat(),
        code_requests=len(assignments), total_reserved_requests=frame['maximum_total_requests'],
        frame_manifest_sha256=file_sha256(frame_root / 'manifest.json'),
        normative_protocol_sha256=file_sha256(repo / 'docs/graph-guided-discovery-protocol.md'),
        model=MODEL, system_prompt=SYSTEM, code_envelope='raw_or_single_python_fence',
        docker_image='phase-graph-guided-repair:20260928',
        native_worker_sha256=implementations['src/measurement/native_behavior.py'],
        generation_implementation_sha256=implementations['src/development/source_generation.py'],
        model_identity_manifest_sha256=file_sha256(model_root / 'manifest.json'),
        implementation_sha256=implementations, launch_record=launch,
        evaluation_preparation_settings_sha256=file_sha256(repo / DISCOVERY_ROOT / 'preparation-inputs/evaluation-settings.json'),
        launch_record_sha256=file_sha256(repo / DISCOVERY_ROOT / 'launch/launch.json'),
        source_plan_text=(frame_root / 'source-execution-contracts.json').read_text(encoding='utf-8'),
        generated_development_outcomes_visible=False, evaluation_materials_used_for_contracts=False,
        source_preparation_fairness=('VERIFIED' if all(row['execution_qualified'] for row in accounting)
                                    else 'INCOMPLETE_FAILED_INSTANCES_RETAINED'),
        independent_human_review='PENDING_INDEPENDENT_REVIEW', low_expectation_comparison='PENDING_INDEPENDENT_REVIEW',
        execution_scope='authorized bounded development with author-bound policies; independent quality claims pending',
        primary_accounting='all assigned requests and all fixed task/flow positions; failure and unknown retained')
    write_bundle(repo / DISCOVERY_ROOT / 'development-preparation', {
        'protocol.json': protocol, 'tasks.json': tasks, 'candidates.json': candidates,
        'slots.json': slots, 'contracts.json': contracts, 'source-evidence.json': evidence,
        'preparation-accounting.json': accounting, 'assignments.json': assignments,
        'bindings.json': bindings, 'randomization-state.json': random_state,
        'evaluation-source-frame.json': population['evaluation']})
    print(json.dumps(dict(status=protocol['status'], tasks=len(tasks), policies=len(candidates),
                         positions=len(slots), requests=len(assignments))))


def discovery_freeze_targeted_generation(repo: Path) -> None:
    base = repo / DISCOVERY_ROOT
    registration_path = base / 'preparation-repair/targeted-20260929/registration.json'
    registration = read_json(registration_path)
    common_root = repo / 'results/graph-guided-20260929/targeted-repair-model-quality-verification'
    graph_root = common_root.parent / (common_root.name + '-graph')
    for directory in (base / 'task-frame', common_root, graph_root, base / 'evaluation-preparation',
                      base / 'model-identity'):
        verify_bundle(directory)
    common = read_json(common_root / 'positions.json')
    graphs = {row['blind_id']: row for row in read_json(graph_root / 'positions.json')}
    frame = {row['index']: row for row in read_json(base / 'task-frame/tasks.json')['evaluation']}
    discovery_source_contracts(repo)
    tasks, candidates, slots, evidence = {}, [], [], []
    for stream in registration['streams']:
        index, flow = stream['index'], stream['flow']
        directory = repo / registration['preparation_root'] / f'case-{index:04d}' / flow
        source, prepared = read_json(directory / 'source.json'), read_json(directory / 'final.json')
        task = frame[index]
        if (source['task_unit_id'] != task['task_unit_id'] or source['system_prompt'] != SYSTEM
                or source['source_prompt'] != task['source']['prompt']
                or source['shared_execution_interface'] != task['execution_interface']):
            raise ValueError('定向生成来源与冻结任务不一致')
        diagnostics = discovery_preparation_diagnostics(source, prepared, complete=True)
        local_diagnostics = {row['candidate_id']: row['errors'] for row in diagnostics['candidate_diagnostics']}
        tasks[index] = dict(index=index, task_unit_id=task['task_unit_id'],
            execution_interface=task['execution_interface'], measurement=task['measurement'],
            reference_prompt=source['source_prompt'] + '\n\nShared execution interface:\n' + task['execution_interface'])
        positions = sorted([row for row in common if row['index'] == index and row['flow'] == flow],
                           key=lambda row: row['position'])
        if len(positions) != 2:
            raise ValueError('定向生成原位置不完整')
        for position in positions:
            candidate_id = position['candidate_id']
            candidate = next((row for row in prepared['candidates'] if row['candidate_id'] == candidate_id), None)
            mechanical = candidate is not None and not local_diagnostics[candidate_id] and not diagnostics['errors']
            local_support = flow == 'Raw' or graphs[position['blind_id']]['selected_support_completeness_both']
            qualified = mechanical and position['conservative_model_quality_support'] and local_support
            identity = content_hash(canonical_json(['targeted-generation', index, flow, candidate_id, position['position']]))
            slot = dict(index=index, task_unit_id=task['task_unit_id'], flow=flow,
                position=position['position'], blind_id=position['blind_id'],
                original_candidate_id=candidate_id, candidate_id=identity if candidate else None,
                quality_qualified=qualified, mechanical_qualified=mechanical,
                semantic_qualified=position['conservative_model_quality_support'], local_support=local_support,
                status='qualified' if qualified else 'diagnostic_only' if candidate else 'missing',
                diagnostic_errors=local_diagnostics.get(candidate_id, []))
            slots.append(slot)
            if candidate:
                candidates.append(dict(candidate, original_candidate_id=candidate_id, candidate_id=identity,
                    index=index, task_unit_id=task['task_unit_id'], flow=flow, use='open',
                    quality_qualified=qualified, blind_id=position['blind_id']))
        evidence.append(dict(index=index, flow=flow, source_path=(directory / 'source.json').relative_to(repo).as_posix(),
            source_sha256=file_sha256(directory / 'source.json'),
            final_path=(directory / 'final.json').relative_to(repo).as_posix(),
            final_sha256=file_sha256(directory / 'final.json')))
    tasks = sorted(tasks.values(), key=lambda row: row['index'])
    if (len(tasks), len(candidates), len(slots), sum(row['quality_qualified'] for row in candidates)) != (12, 27, 30, 19):
        raise ValueError('定向生成范围与已核验质量结果不一致')
    prior_state = read_json(base / 'evaluation-preparation/randomization-state.json')
    assignments, bindings, state = discovery_assignments(tasks, candidates, 'development', prior_state)
    launch = read_json(base / 'launch/launch.json')
    if datetime.now(timezone.utc) >= datetime.fromisoformat(launch['deadline_utc']):
        raise ValueError('原授权研究时限已经到达')
    implementations = {name: file_sha256(repo / name) for name in (
        'src/development/graph_guided_study.py', 'src/development/graph_guided_report.py',
        'src/development/source_generation.py', 'src/measurement/native_behavior.py',
        'docs/experiments/2026-09-29-service-check.py')}
    protocol = dict(status='F0_FROZEN_DEVELOPMENT_NOT_RUNTIME_FROZEN', protocol_id=DISCOVERY_PROTOCOL,
        formal_protocol='SPECIFIED_DRAFT', frozen_utc=datetime.now(timezone.utc).isoformat(),
        authorization='2026-09-29 用户：完整生成一下',
        execution_scope='targeted exposed-task preparation repair; descriptive policy effects only',
        code_requests=len(assignments), total_reserved_requests=1752,
        model=MODEL, system_prompt=SYSTEM, code_envelope='raw_or_single_python_fence',
        docker_image='phase-graph-guided-repair:20260928',
        native_worker_sha256=implementations['src/measurement/native_behavior.py'],
        generation_implementation_sha256=implementations['src/development/source_generation.py'],
        model_identity_manifest_sha256=file_sha256(base / 'model-identity/manifest.json'),
        implementation_sha256=implementations, launch_record=launch,
        launch_record_sha256=file_sha256(base / 'launch/launch.json'),
        repair_registration_sha256=file_sha256(registration_path),
        common_quality_manifest_sha256=file_sha256(common_root / 'manifest.json'),
        graph_quality_manifest_sha256=file_sha256(graph_root / 'manifest.json'),
        prior_randomization_sha256=file_sha256(base / 'evaluation-preparation/randomization-state.json'),
        selected_tasks=12, fixed_positions=30, materialized_policies=27, quality_qualified_policies=19,
        primary_accounting='all 30 positions retained; all assigned generation failures and unknown outcomes retained',
        generated_targeted_outcomes_visible=False, historical_outcomes_visible=True,
        measurements_frozen_before_generation=True,
        measurement_interpretation='fixed finite security and functionality contracts; target-coupled functionality is not non-target harm',
        target_coupled_functionality_indices=[9, 182, 234, 236],
        exception_sensitive_security_indices=[9, 182, 188],
        effects_rule='fixed P-N and P-R for six separate endpoints; eligible and diagnostic policies remain separated',
        uncertainty_rule='unknown safety coverage retained in sensitivity bounds; no population or algorithm-superiority claim',
        version_rule='same-arm versions are identical; repeated seed/version calls do not establish paraphrase robustness')
    write_bundle(base / 'targeted-generation-preparation', {'protocol.json': protocol,
        'tasks.json': tasks, 'candidates.json': candidates, 'slots.json': slots, 'source-evidence.json': evidence,
        'assignments.json': assignments, 'bindings.json': bindings, 'randomization-state.json': state})
    print(json.dumps(dict(tasks=len(tasks), policies=len(candidates), qualified=19,
                         positions=len(slots), unique_policies=len({row['policy_id'] for row in bindings}), requests=len(assignments))))


def discovery_model_record(features, learner, validation):
    return dict(alpha=float(learner.alpha), coefficients=learner.coef_.tolist(), intercept=False,
        common=dict(vocabulary={key: int(value) for key, value in features.common.vocabulary_.items()}, idf=features.common.idf_.tolist()),
        policy=dict(vocabulary={key: int(value) for key, value in features.policy.vocabulary_.items()}, idf=features.policy.idf_.tolist()),
        marginals=features.marginal.feature_names_, relations=features.relation.feature_names_,
        validation=validation)


def discovery_reference_rows(rows, tasks, include_unlabelled=False):
    reference = {row['task_unit_id']: row['reference_prompt'] for row in tasks}
    result = []
    for row in rows:
        if 'delta_pr' not in row and not include_unlabelled:
            continue
        value = dict(row, n_versions=[reference[row['task_unit_id']]] * 2,
            canonical_text=canonical_json(dict(original_contrast=row['contract'],
                state_p=row['contract']['state_p'], state_reference=reference[row['task_unit_id']], comparison='P-R')))
        if 'delta_pr' in row:
            value['delta_pn'] = row['delta_pr']
        result.append(value)
    return result


def discovery_analyze_development(repo: Path, inputs: Path, results: Path) -> None:
    f0 = repo / DISCOVERY_ROOT / 'development-preparation'
    verify_bundle(f0)
    verify_bundle(inputs)
    protocol = read_json(inputs / 'protocol.json')
    if protocol['status'] != 'FROZEN_TSG_DISCOVERY_DEVELOPMENT' or protocol['preparation_manifest_sha256'] != file_sha256(f0 / 'manifest.json'):
        raise ValueError('开发生成输入未绑定F0')
    assignments = read_json(inputs / 'assignments.json')
    if assignments != read_json(f0 / 'assignments.json'):
        raise ValueError('开发请求表与F0不符')
    outcomes = discovery_panel_outcomes(inputs, results)
    primary = {key: row['primary'] for key, row in outcomes.items()}
    sensitivity = {key: row['sensitivity'] for key, row in outcomes.items()}
    candidates, bindings = read_json(f0 / 'candidates.json'), read_json(f0 / 'bindings.json')
    tasks = read_json(f0 / 'tasks.json')
    effects, training, models = [], [], {}
    for candidate in candidates:
        identity = candidate['task_unit_id']
        coefficients = discovery_action_coefficients(identity,
            dict(candidate_id=candidate['candidate_id'], direction=1), assignments, bindings)
        pn = discovery_shared_bounds(coefficients, primary)
        pn_unknown = discovery_shared_bounds(coefficients, sensitivity)
        p = [(request, weight) for request, weight in coefficients if weight > 0]
        r = [(row['request_id'], -.25) for row in assignments
             if row['task_unit_id'] == identity and row['arm'] == 'R']
        if len(r) != 4:
            raise ValueError('开发参考组分配不完整')
        pr = discovery_shared_bounds(p + r, primary)
        row = dict(candidate, primary_pn=list(pn), primary_pr=list(pr), sensitivity_pn=list(pn_unknown))
        if pr[0] == pr[1]:
            row['delta_pr'] = pr[0]
        if pn[0] == pn[1]:
            row['delta_pn'] = pn[0]
            training.append(row)
        effects.append(row)
    statistics, global_mean, nominee = discovery_contract_statistics(training)
    enough = len({row['task_unit_id'] for row in training}) >= 8
    if enough:
        for mode in ('common', 'relations', 'endpointless'):
            features, learner, validation = fit_discovery_ridge(training, mode)
            models[mode] = discovery_model_record(features, learner, validation)
        adoption = discovery_reference_rows(effects, tasks)
        if len({row['task_unit_id'] for row in adoption}) >= 8:
            features, learner, validation = fit_discovery_ridge(adoption, 'common')
            models['adoption'] = discovery_model_record(features, learner, validation)
    write_bundle(repo / DISCOVERY_ROOT / 'development-analysis', {
        'identity.json': dict(status='DEVELOPMENT_ANALYZED_NOT_F1' if enough else 'LEARNING_INCOMPLETE_FEWER_THAN_8_LABELLED_TASKS',
            protocol_id=DISCOVERY_PROTOCOL, input_manifest_sha256=file_sha256(inputs / 'manifest.json'),
            f0_manifest_sha256=file_sha256(f0 / 'manifest.json'), results_path=results.as_posix(),
            training_tasks=len({row['task_unit_id'] for row in training}), missing_label_policies=len(effects) - len(training),
            evaluation_results_visible=False, independent_human_review='PENDING_INDEPENDENT_REVIEW'),
        'outcomes.json': outcomes, 'effects.json': effects, 'training.json': training,
        'models.json': models, 'contract-statistics.json': statistics,
        'nomination.json': dict(nominee=nominee, global_task_mean=global_mean),
        'reference-training.json': discovery_reference_rows(effects, tasks)})
    print(json.dumps(dict(status='DEVELOPMENT_ANALYZED_NOT_F1' if enough else 'LEARNING_INCOMPLETE',
                         policies=len(effects), training_policies=len(training), nominee=nominee)))


def discovery_freeze_evaluation(repo: Path) -> None:
    f0 = repo / DISCOVERY_ROOT / 'development-preparation'
    development = repo / DISCOVERY_ROOT / 'development-analysis'
    frame = repo / DISCOVERY_ROOT / 'task-frame'
    for root in (f0, development, frame):
        verify_bundle(root)
    identity = read_json(development / 'identity.json')
    if identity['status'] != 'DEVELOPMENT_ANALYZED_NOT_F1' or identity['evaluation_results_visible']:
        raise ValueError('学习或评价信息边界未取得资格')
    if identity['f0_manifest_sha256'] != file_sha256(f0 / 'manifest.json'):
        raise ValueError('学习输入与F0不符')
    tasks, candidates, slots, evidence, accounting = discovery_collect_prepared(
        repo, read_json(f0 / 'evaluation-source-frame.json'))
    for task in tasks:
        source = read_json(repo / DISCOVERY_ROOT / f"preparation-inputs/qualified/case-{task['index']:04d}/input.json")
        if source['role'] != 'evaluation' or source['development_effects_or_replication_nominee_visible']:
            raise ValueError('评价开放准备信息边界不符')
        if source['f0_contrast_contracts'] != read_json(f0 / 'contracts.json'):
            raise ValueError('评价开放准备未取得全部F0合同')
    quality_root = repo / DISCOVERY_ROOT / 'model-quality-evaluation'
    quality_result = repo / 'results/graph-guided-20260929/evaluation-model-quality-verification'
    for root in (quality_root / 'public', quality_root / 'private', quality_result):
        verify_bundle(root)
    quality_protocol = read_json(quality_root / 'public/protocol.json')
    quality_summary = read_json(quality_result / 'summary.json')
    if (quality_protocol['population'] != 'evaluation' or quality_protocol['positions'] != 72
            or quality_protocol['tasks'] != 18 or quality_summary['population'] != 'evaluation'
            or quality_summary['status'] != 'EXECUTED_OUTCOME_BLIND_MODEL_QUALITY_VERIFICATION'):
        raise ValueError('独立模型评价材料与评价任务不一致')
    for task in tasks:
        if quality_protocol['binding_manifest_sha256'][str(task['index'])] != file_sha256(
                repo / DISCOVERY_ROOT / f"binding/case-{task['index']:04d}/manifest.json"):
            raise ValueError('独立模型评价后政策绑定发生改变')
    for record in quality_summary['input_identity'].values():
        if file_sha256(repo / record['path']) != record['sha256']:
            raise ValueError('独立模型评价输入身份不一致')
    if quality_summary['positions'] != 72 or quality_summary['tasks'] != 18:
        raise ValueError('独立模型评价没有保留全部分配位置')
    quality_ids = set()
    for name in ('reviewer-a', 'reviewer-b'):
        review = read_json(quality_root / (name + '.json'))
        if (review['reviewer_kind'] != 'isolated_model_session' or not review['independent_from_preparation']
                or review['generated_code_or_outcomes_seen'] or review['reviewer_id'] in quality_ids
                or len(review['judgments']) != 72):
            raise ValueError('独立模型评价会话边界不成立')
        quality_ids.add(review['reviewer_id'])
        completed = review['available_time']['completed_at']
        completed_at = (datetime.strptime(completed, '%Y-%m-%d %H:%M:%S UTC').replace(tzinfo=timezone.utc)
                        if completed.endswith(' UTC') else datetime.fromisoformat(completed.replace('Z', '+00:00')))
        if completed_at > datetime.now(timezone.utc):
            raise ValueError('独立模型评价完成时间尚未到达')
    quality_record = dict(summary=quality_summary,
        public_manifest_sha256=file_sha256(quality_root / 'public/manifest.json'),
        private_manifest_sha256=file_sha256(quality_root / 'private/manifest.json'),
        result_manifest_sha256=file_sha256(quality_result / 'manifest.json'),
        policy_qualification_changed=False, primary_pool_filtered_by_model_review=False,
        quality_rule='Two isolated model judgments; all 36 assigned positions per flow retained.',
        human_quality_review='NOT_OBTAINED')
    nomination = read_json(development / 'nomination.json')
    nominee = nomination['nominee']
    if nominee is None:
        replication = []
        applicability = [dict(task_unit_id=task['task_unit_id'], status='NO_NOMINATED_CONTRACT') for task in tasks]
    else:
        replication_root = repo / DISCOVERY_ROOT / 'replication-binding'
        verify_bundle(replication_root)
        replication = read_json(replication_root / 'candidates.json')
        applicability = read_json(replication_root / 'applicability.json')
        if {row['task_unit_id'] for row in applicability} != {task['task_unit_id'] for task in tasks}:
            raise ValueError('复现适用性未覆盖全部评价任务')
        if any(row['contract_id'] != nominee['contract_id'] or row['use'] != 'replication' for row in replication):
            raise ValueError('复现政策与结果前提名合同不符')
    training, frozen_models = read_json(development / 'training.json'), read_json(development / 'models.json')
    fitted = {}
    for mode in ('common', 'relations', 'endpointless'):
        features, learner, validation = fit_discovery_ridge(training, mode)
        if discovery_model_record(features, learner, validation) != frozen_models[mode]:
            raise ValueError('结果前学习器复算不一致')
        fitted[mode] = (features, learner)
    adoption_model = None
    if 'adoption' in frozen_models:
        features, learner, validation = fit_discovery_ridge(read_json(development / 'reference-training.json'), 'common')
        if discovery_model_record(features, learner, validation) != frozen_models['adoption']:
            raise ValueError('采用描述学习器复算不一致')
        adoption_model = (features, learner)
    statistics = {row['contract_id']: row for row in read_json(development / 'contract-statistics.json')}
    random_baseline = np.random.Generator(np.random.PCG64(2026092905))
    direction = -1 if nomination['global_task_mean'] < 0 else 1
    decisions = []
    for task in sorted(tasks, key=lambda row: row['task_unit_id']):
        pool = sorted([row for row in candidates if row['task_unit_id'] == task['task_unit_id']], key=lambda row: row['candidate_id'])
        predictions, unseen, actions = {}, {}, {}
        for mode, (features, learner) in fitted.items():
            if pool:
                matrix, oov = features.transform(pool, mode)
                predictions[mode] = learner.predict(matrix).tolist()
                unseen[mode] = oov
                actions[{'common': 'ridge', 'relations': 'relations', 'endpointless': 'endpointless'}[mode]] = discovery_pick(pool, predictions[mode])
            else:
                predictions[mode], unseen[mode] = [], []
                actions[{'common': 'ridge', 'relations': 'relations', 'endpointless': 'endpointless'}[mode]] = None
        for flow, name in [('TSG', 'tsg'), ('Raw', 'raw')]:
            positions = [(row, score) for row, score in zip(pool, predictions['common'], strict=True) if row['flow'] == flow]
            actions[name] = discovery_pick([row for row, _ in positions], [score for _, score in positions])
        mean_scores = [statistics[row['contract_id']]['prediction'] if row['contract_id'] in statistics
                       else nomination['global_task_mean'] for row in pool]
        actions['contract_mean'] = discovery_pick(pool, mean_scores)
        actions['first'] = dict(candidate_id=pool[0]['candidate_id'], direction=direction) if pool else None
        actions['random'] = dict(candidate_id=pool[int(random_baseline.integers(len(pool)))]['candidate_id'], direction=direction) if pool else None
        rep = [row for row in replication if row['task_unit_id'] == task['task_unit_id']]
        if len(rep) > 1:
            raise ValueError('同一评价任务具有多项复现政策')
        actions['replication'] = dict(candidate_id=rep[0]['candidate_id'], direction=nominee['direction']) if rep else None
        adoption_scores = []
        if pool and adoption_model is not None:
            reference_rows = discovery_reference_rows(pool, tasks, include_unlabelled=True)
            features, learner = adoption_model
            matrix, _ = features.transform(reference_rows, 'common')
            adoption_scores = learner.predict(matrix).tolist()
            candidate, score = min(zip(pool, adoption_scores, strict=True), key=lambda pair: (-pair[1], pair[0]['candidate_id']))
            actions['adoption'] = dict(candidate_id=candidate['candidate_id'], prediction=score) if score > .05 else None
        else:
            actions['adoption'] = None
        decisions.append(dict(task_unit_id=task['task_unit_id'], index=task['index'], actions=actions,
                              candidate_ids=[row['candidate_id'] for row in pool], predictions=predictions,
                              contract_mean_predictions=mean_scores, relation_oov=unseen,
                              adoption_predictions=adoption_scores,
                              adoption_status='FROZEN' if adoption_model is not None else 'UNFINISHED_INSUFFICIENT_LABELLED_TASKS'))
    all_candidates = candidates + replication
    assignments, bindings, state = discovery_assignments(tasks, all_candidates, 'evaluation',
        read_json(f0 / 'randomization-state.json'))
    protocol = dict(read_json(f0 / 'protocol.json'), status='F1_FROZEN_EVALUATION_NOT_RUNTIME_FROZEN',
        code_requests=len(assignments), frozen_utc=datetime.now(timezone.utc).isoformat(),
        development_analysis_manifest_sha256=file_sha256(development / 'manifest.json'),
        generated_development_outcomes_visible=True, generated_evaluation_outcomes_visible=False,
        selected_replication_contract=nominee, low_expected_task_ids=[],
        low_expectation_comparison='PENDING_INDEPENDENT_REVIEW')
    authorization = repo / DISCOVERY_ROOT / 'evaluation-resource-authorization.json'
    protocol.update(evaluation_resource_authorization=read_json(authorization),
        evaluation_resource_authorization_sha256=file_sha256(authorization),
        evaluation_amendment_sha256=file_sha256(repo / read_json(authorization)['normative_amendment']),
        f0_implementation_sha256=protocol['implementation_sha256'],
        implementation_sha256={name: file_sha256(repo / name) for name in protocol['implementation_sha256']},
        evaluation_source_preparation_fairness=('VERIFIED' if all(row['execution_qualified'] for row in accounting)
                                               else 'INCOMPLETE_FAILED_INSTANCES_RETAINED'),
        independent_model_quality_review='COMPLETED_OUTCOME_BLIND_ISOLATED_MODEL_REVIEW',
        model_quality_result_manifest_sha256=quality_record['result_manifest_sha256'],
        human_quality_review='NOT_OBTAINED')
    if len(assignments) + read_json(f0 / 'protocol.json')['code_requests'] + 32 > protocol['total_reserved_requests']:
        raise ValueError('全部开发、评价及检查分配超过任务框预算')
    write_bundle(repo / DISCOVERY_ROOT / 'evaluation-preparation', {
        'protocol.json': protocol, 'tasks.json': tasks, 'candidates.json': all_candidates,
        'slots.json': slots, 'source-evidence.json': evidence, 'preparation-accounting.json': accounting,
        'decisions.json': decisions, 'replication-applicability.json': applicability,
        'assignments.json': assignments, 'bindings.json': bindings, 'randomization-state.json': state,
        'models.json': frozen_models, 'model-quality.json': quality_record})
    print(json.dumps(dict(status=protocol['status'], tasks=len(tasks), policies=len(candidates),
                         replication=len(replication), requests=len(assignments))))


def register(repo: Path) -> None:
    verify_bundle(repo / POOL)
    verify_bundle(repo / OLD / 'registration')
    selection = read_json(repo / OLD / 'registration/selection.json')['selected']
    qualification = read_json(repo / OLD / 'source-qualification.json')
    exposed = {read_json(p)['index'] for p in (repo / OLD / 'preparation').glob('case-*.json')}
    tasks = {t['task_unit_id']: t for t in read_json(repo / POOL / 'tasks.json')}
    protected = {t['task_unit_id'] for t in read_json(repo / POOL / 'screening.json')
                 if t['decision'] == 'PRESERVE_PROTECTED_INPUT'}
    rows = [dict(r) for r in selection
            if r['index'] in qualification['qualified_indices'] and r['index'] not in exposed]
    assert len(rows) == 105 and len(exposed) == 19
    assert Counter(r['role'] for r in rows) == {'development': 33, 'heldout': 72}
    assert len({r['task_unit_id'] for r in rows}) == len(rows)
    assert not protected.intersection(r['task_unit_id'] for r in rows)
    strata = defaultdict(list)
    for row in rows:
        task = tasks[row['task_unit_id']]
        assert content_hash(task['prompt']) == row['source_prompt_sha256']
        assert task['prompt_sha256'] == row['source_prompt_sha256']
        row['historical_representation'] = row.pop('representation')
        strata[row['role'], row['source_lineage_id']].append(row)
    rng = np.random.default_rng(SEED)
    for key in sorted(strata):
        group = sorted(strata[key], key=lambda r: r['task_unit_id'])
        identities = rng.permutation(len(group))
        offset = int(rng.integers(2))
        for position, index in enumerate(identities):
            group[index]['representation'] = 'TSG' if (position + offset) % 2 else 'Raw'
            group[index]['representation_probability'] = 0.5
    start = datetime.fromtimestamp(1790532415, timezone.utc)
    plan = repo / 'docs/graph-guided-hypothesis-design.md'
    launch = dict(status='ACTIVE_BOUNDED_DEVELOPMENT', t0_utc=start.isoformat(),
                  deadline_utc=(start + timedelta(hours=24)).isoformat(),
                  generation_call_limit=2818, model_service_seconds_limit=18*3600,
                  algorithm_seconds_limit=4*3600, formal_protocol='SPECIFIED_DRAFT',
                  paid_provider_allowed=False, protected_evaluation_allowed=False,
                  model_role='code_generation_only', plan_sha256=file_sha256(plan),
                  registration_implementation_sha256=file_sha256(Path(__file__)),
                  source_qualification_sha256=file_sha256(repo / OLD / 'source-qualification.json'),
                  source_pool_sha256=file_sha256(repo / POOL / 'tasks.json'),
                  independent_review='awaiting_explicit_subagent_authorization',
                  source_roles='inherited_development_roles_cross_lineage_transfer',
                  selection_is_preparation_only=True)
    source_cards = [{**row, 'prompt': tasks[row['task_unit_id']]['prompt'],
                     'functional_contract': tasks[row['task_unit_id']]['functional_contract']}
                    for row in sorted(rows, key=lambda r: r['index'])]
    write_bundle(repo / ROOT / 'registration', {
        'launch.json': launch, 'selection.json': rows,
        'sources.json': source_cards, 'plan.json': {'text': plan.read_text(encoding='utf-8')},
    })
    verify_bundle(repo / ROOT / 'registration')
    print(json.dumps({'tasks': len(rows), 'roles': dict(Counter(r['role'] for r in rows)),
                      'representations': dict(Counter(r['representation'] for r in rows))}))


def inspect(repo: Path, role: str, representation: str, start: int, count: int) -> None:
    verify_bundle(repo / ROOT / 'registration')
    rows = read_json(repo / ROOT / 'registration/sources.json')
    rows = [r for r in rows if r['role'] == role and r['representation'] == representation]
    for row in rows[start:start + count]:
        print(json.dumps({k: row[k] for k in
                          ('index', 'task_unit_id', 'role', 'representation', 'prompt')},
                         ensure_ascii=False))


def freeze_representation_review(repo: Path) -> None:
    verify_bundle(repo / POOL)
    verify_bundle(repo / OLD / 'registration')
    selected = read_json(repo / OLD / 'registration/selection.json')['selected']
    qualification = read_json(repo / OLD / 'source-qualification.json')
    tasks = {t['task_unit_id']: t for t in read_json(repo / POOL / 'tasks.json')}
    qualified = set(qualification['qualified_indices'])
    language = set(qualification['out_of_language_scope'])
    external = set(qualification['source_requires_simulated_external_dependency'])
    exposed = {r['index'] for r in qualification['historical_content_exclusions']}
    duplicate = {index for group in qualification['semantic_duplicate_groups']
                 for index in group['excluded']}
    groups = defaultdict(list)
    all_rows = []
    for row in selected:
        index = row['index']
        if index in qualified:
            status = 'source_qualified'
        elif index in language:
            status = 'outside_python_measurement'
        elif index in external:
            status = 'external_service_scope'
        elif index in duplicate:
            status = 'related_source_variant'
        elif index in exposed:
            status = 'historical_semantic_exposure'
        else:
            status = 'comparison_unresolved'
        prompt = tasks[row['task_unit_id']]['prompt']
        code = any(token in prompt for token in ('def ', 'import ', '@app.route', 'class '))
        comment = "'''" in prompt or '"""' in prompt
        example = any(token in prompt.lower() for token in ('for example', 'example:', 'e.g.'))
        forms = (['natural_prose'] if not code else ['code_with_requirements'])
        if comment:
            forms.append('function_comment')
        if code and prompt.rstrip().endswith(("'''", '"""')):
            forms.append('code_completion')
        if example:
            forms.append('example')
        record = dict(index=index, task_unit_id=row['task_unit_id'], status=status,
                      forms=forms, source_lineage_id=row['source_lineage_id'],
                      prompt=prompt, source_prompt_sha256=row['source_prompt_sha256'])
        all_rows.append(record)
        for form in forms:
            groups[status, form].append(record)
    assert len(all_rows) == 245 and len({r['task_unit_id'] for r in all_rows}) == 245
    for key in groups:
        groups[key].sort(key=lambda r: hashlib.sha256(r['task_unit_id'].encode()).hexdigest())
    chosen = {}
    offsets = defaultdict(int)
    keys = sorted(groups)
    while len(chosen) < 48:
        changed = False
        for key in keys:
            rows = groups[key]
            while offsets[key] < len(rows) and rows[offsets[key]]['task_unit_id'] in chosen:
                offsets[key] += 1
            if offsets[key] < len(rows):
                row = rows[offsets[key]]
                chosen[row['task_unit_id']] = row
                offsets[key] += 1
                changed = True
                if len(chosen) == 48:
                    break
        assert changed
    output = sorted(chosen.values(), key=lambda r: r['index'])
    write_bundle(repo / ROOT / 'representation-review', {
        'selection.json': output,
        'design.json': dict(status='FROZEN_BEFORE_REPRESENTATION_REVIEW', limit=48,
                            source_count=len(all_rows), statuses=dict(Counter(r['status'] for r in all_rows)),
                            selected_statuses=dict(Counter(r['status'] for r in output)),
                            selected_forms=dict(Counter(f for r in output for f in r['forms'])),
                            represented_cells=len(groups),
                            selection_rule='round_robin_status_by_form_then_sha256_task_identity',
                            raw_task_graphs_deferred_until_quality_review_frozen=True),
    })
    print(json.dumps({'selected': len(output), 'status_counts': dict(Counter(r['status'] for r in output))}))


def audit_representation_records(repo: Path, repair: bool = False) -> None:
    review_root = repo / ROOT / 'representation-review'
    verify_bundle(review_root)
    verify_bundle(repo / ROOT / 'registration')
    verify_bundle(repo / POOL)
    selected = {row['index']: row for row in read_json(review_root / 'selection.json')}
    registered = {row['index']: row for row in read_json(repo / ROOT / 'registration/selection.json')}
    protected = {row['task_unit_id'] for row in read_json(repo / POOL / 'screening.json')
                 if row['decision'] == 'PRESERVE_PROTECTED_INPUT'}
    assert not protected.intersection(row['task_unit_id'] for row in selected.values())
    authored_path = repo / ROOT / 'representation-records/author-records.json'
    authored = read_json(authored_path)
    assert authored['evidence_level'] == 'AUTHOR_PREPARED_PENDING_INDEPENDENT_REVIEW'
    records = authored['records']
    assert len(records) == len({row['index'] for row in records}) == 39
    deferred = {index for index in selected if registered.get(index, {}).get('representation') == 'Raw'}
    assert len(deferred) == 9 and {row['index'] for row in records} == set(selected)-deferred
    repair_path = repo / ROOT / 'representation-records/repair-author-records.json'
    if repair:
        supplementary = read_json(repair_path)
        assert supplementary['evidence_level'] == authored['evidence_level']
        assert {row['index'] for row in supplementary['records']} == deferred
        records = records + supplementary['records']
    rows, graphs = [], []
    for record in records:
        index = record['index']
        source = selected[index]
        prompt = source['prompt']
        assert content_hash(prompt) == source['source_prompt_sha256']
        if 'reuse_target_graph' in record:
            path = repo / ROOT / record['reuse_target_graph']
            graph_record = read_json(path)
            assert graph_record['index'] == index and graph_record['representation'] == 'TSG'
            reuse_hash = file_sha256(path)
        else:
            graph_record, reuse_hash = record, None
        nodes, relations = graph_record['nodes'], graph_record['relations']
        assert len(nodes) == len({node['id'] for node in nodes}) and nodes
        assert len(relations) == len({relation['id'] for relation in relations})
        graph = nx.DiGraph()
        graph.add_nodes_from(node['id'] for node in nodes)
        evidence = []
        for kind, elements in (('node', nodes), ('relation', relations)):
            for element in elements:
                quote = element['quote']
                assert quote and quote in prompt, (index, kind, element['id'], quote)
                if kind == 'node':
                    assert element['type'] in {'object', 'operation', 'condition', 'requirement', 'result'}
                    assert element['meaning']
                else:
                    assert element['from'] in graph and element['to'] in graph
                    graph.add_edge(element['from'], element['to'])
                start = prompt.index(quote)
                evidence.append(dict(kind=kind, identity=element['id'], start=start, end=start+len(quote),
                                     repeated_quote=prompt.count(quote) > 1))
        assert record['unresolved']
        rows.append(dict(index=index, task_unit_id=source['task_unit_id'], source_status=source['status'],
                         forms=source['forms'], nodes=len(nodes), relations=len(relations),
                         components=nx.number_weakly_connected_components(graph),
                         source_prompt_sha256=source['source_prompt_sha256'], reused_graph_sha256=reuse_hash,
                         evidence=evidence, independent_semantic_review='PENDING',
                         structural_status='SOURCE_QUOTES_AND_REFERENCES_VERIFIED'))
        graphs.append(dict(index=index, task_unit_id=source['task_unit_id'], prompt=prompt,
                           source_prompt_sha256=source['source_prompt_sha256'], nodes=nodes, relations=relations,
                           unresolved=record['unresolved'], reused_graph_sha256=reuse_hash))
    blocked = [dict(index=index, task_unit_id=selected[index]['task_unit_id'],
                    status='DEFERRED_RAW_QUALITY_REVIEW_NOT_FROZEN') for index in sorted(deferred)]
    summary = dict(status='AUTHOR_STRUCTURAL_VALIDATION_ONLY', frozen_review_sample=48,
                   authored_graphs=39, deferred_raw_graphs=9,
                   authored_source_statuses=dict(Counter(row['source_status'] for row in rows)),
                   authored_forms=dict(Counter(form for row in rows for form in row['forms'])),
                   nodes=sum(row['nodes'] for row in rows), relations=sum(row['relations'] for row in rows),
                   independent_semantic_accuracy=None, source_prompt_hashes_verified=True,
                   audit_function='graph_guided_study.audit_representation_records',
                   author_record_sha256=file_sha256(authored_path),
                   interpretation='Quote membership and endpoint references establish structural consistency only; semantic completeness and correctness require independent evaluation.')
    if repair:
        summary.update(status='POST_OUTCOME_AUTHOR_STRUCTURAL_VALIDATION_ONLY',authored_graphs=48,
            original_deferred_raw_graphs=9,deferred_raw_graphs=0,
            supplemental_author_record_sha256=file_sha256(repair_path),
            original_preparation_comparison_changed=False,independent_quality_review='deferred_by_owner')
        blocked = []
    files = {'summary.json': summary, 'records.json': rows, 'graphs.json': graphs, 'deferred.json': blocked}
    destination = repo / ROOT / ('repair-representation-audit' if repair else 'representation-preparation-audit')
    if destination.exists():
        verify_bundle(destination)
        assert all(read_json(destination / name) == value for name, value in files.items())
    else:
        write_bundle(destination, files)
    print(json.dumps(summary, ensure_ascii=False))


def freeze_blinded_review_material(repo: Path, repair: bool = False) -> None:
    destination = repo / ROOT / ('repair-blinded-review-material' if repair else 'blinded-review-material')
    frozen_cases = None
    if destination.exists() and not repair:
        verify_bundle(destination)
        frozen_cases = {row['index']: row['case_manifest_sha256']
                        for row in read_json(destination / 'private-mapping.json')}
    verify_bundle(repo / ROOT / 'registration')
    verify_bundle(repo / ROOT / 'scaled-panel')
    verify_bundle(repo / ROOT / 'representation-preparation-audit')
    selected = read_json(repo / ROOT / 'scaled-panel/selection.json')
    sources = {row['index']: row for row in read_json(repo / ROOT / 'registration/sources.json')}
    graph_directory = 'repair-representation-audit' if repair else 'representation-preparation-audit'
    verify_bundle(repo / ROOT / graph_directory)
    graphs = read_json(repo / ROOT / graph_directory / 'graphs.json')
    repair_records, repair_assignments = [], []
    if repair:
        for name in ('repair-edit-execution-inputs','repair-source-execution-inputs'):
            verify_bundle(repo / ROOT / name)
            repair_records.extend(dict(cohort=name,**r) for r in read_json(repo / ROOT / name / 'prepared.json'))
            repair_assignments.extend(dict(cohort=name,**r) for r in read_json(repo / ROOT / name / 'assignments.json'))
    protected = {row['task_unit_id'] for row in read_json(repo / POOL / 'screening.json')
                 if row['decision'] == 'PRESERVE_PROTECTED_INPUT'}
    assert not protected.intersection(row['task_unit_id'] for row in selected)
    masked, mapping, counts = [], [], Counter()
    for row in selected:
        index = row['index']
        source = sources[index]
        suffix = '-v2' if index in (38, 206) else ''
        if repair and (repo / ROOT / f'prepared/case-{index:04d}-repair').exists():
            suffix = '-repair'
        directory = repo / ROOT / f'prepared/case-{index:04d}{suffix}'
        identity = 'task_'+hashlib.sha256(row['task_unit_id'].encode()).hexdigest()[:16]
        candidates = []
        if directory.exists() and (frozen_cases is None or frozen_cases[index] is not None):
            verify_bundle(directory)
            case = read_json(directory / 'case.json')
            assert case['source']['task_unit_id'] == row['task_unit_id']
            assert case['source']['prompt'] == source['prompt']
            nodes = {node['id']: node for node in case['targets']['nodes']}
            relations = {relation['id']: relation for relation in case['targets']['relations']}
            for candidate in case['candidates']:
                target = candidate['target']
                quotes = ([target['quote']] if row['representation'] == 'Raw' else
                          [nodes[node]['quote'] for node in target['nodes']]
                          +[relations[relation]['quote'] for relation in target['relations']])
                assert all(quote in source['prompt'] for quote in quotes)
                candidates.append(dict(identity=identity+'_candidate_'+str(candidate['slot']),
                    operation=candidate['hypothesis']['operation'], category=candidate['hypothesis']['category'],
                    hypothesis=candidate['hypothesis']['hypothesis'], source_quotes=quotes,
                    realizations=candidate['realizations']))
            measurement = case['measurements']
            interface = case['author_card']['interface']
            non_target = case['author_card']['non_target_requirements']
            case_hash = file_sha256(directory / 'manifest.json')
            if frozen_cases is not None:
                assert case_hash == frozen_cases[index]
        else:
            measurement, interface, non_target, case_hash = None, None, None, None
        planned_slots = 6 if row['role'] == 'development' else 2
        assert len(candidates) in (0, planned_slots)
        if repair:
            extra = [r for r in repair_records if r['index'] == index]
            for record in extra:
                target = record['target']
                requests = [r for r in repair_assignments if r['cohort'] == record['cohort'] and
                            r['index'] == index and r['candidate_slot'] == record['candidate_slot']]
                assert len(requests) == 6
                realizations = [dict(id=f'v{v}',prompts={r['arm']:r['prompt'] for r in requests if r['version'] == f'v{v}'}) for v in (1,2,3)]
                candidates.append(dict(identity=identity+'_'+record['cohort']+'_candidate_'+str(record['candidate_slot']),
                    operation=target['operation'],category='supplementary_source_bound_edit',
                    hypothesis=target.get('hypothesis','比较该来源目标编辑P与匹配控制N的安全产出；允许正向、负向及零差异。'),
                    source_quotes=[target['quote']],realizations=realizations,
                    target_nodes=target['nodes'],target_relations=target['relations'],
                    preparation_identity='post_outcome_supplement_frozen_before_new_generation'))
                assert target['quote'] in source['prompt']
            new_source = next((r for r in extra if r['cohort'] == 'repair-source-execution-inputs'),None)
            if new_source is not None:
                assert case_hash is None
                interface = new_source['interface']
                non_target = [source['prompt']]
                measurement = next(r for r in repair_assignments if r['index'] == index)['measurements'][0]
                case_hash = file_sha256(repo / ROOT / 'repair-source-execution-inputs/manifest.json')
        counts['prepared_tasks'] += bool(candidates)
        counts['hypotheses'] += len(candidates)
        counts['unprepared_tasks'] += not candidates
        masked.append(dict(identity=identity, source_prompt=source['prompt'], common_interface=interface,
                           non_target_requirements=non_target, prospective_measurement=measurement,
                           candidates=candidates, planned_slots=planned_slots,
                           missing_preparation=not candidates))
        mapping.append(dict(identity=identity, index=index, task_unit_id=row['task_unit_id'],
                            role=row['role'], representation=row['representation'], case_manifest_sha256=case_hash))
    assert len(masked) == 52 and counts == (dict(prepared_tasks=49,hypotheses=182,unprepared_tasks=3) if repair else
                                          dict(prepared_tasks=44,hypotheses=144,unprepared_tasks=8))
    representation = [dict(identity='graph_'+hashlib.sha256(row['task_unit_id'].encode()).hexdigest()[:16],
                           source_prompt=row['prompt'], nodes=row['nodes'], relations=row['relations'],
                           unresolved=row['unresolved']) for row in graphs]
    protocol = dict(status='BLINDED_MATERIAL_READY_REVIEW_NOT_EXECUTED', formal_protocol='SPECIFIED_DRAFT',
        preparation_comparison_tasks=52, authored_hypotheses=144, represented_graphs=39,
        reviewer_count_required=2, review_outputs_present=False, code_generation_calls=0,
        material_freeze_phase='After model outcomes; independent reviewers must receive these source-only packets.',
        hidden_from_reviewers=['generated code', 'observed outcomes', 'selector predictions', 'training scores',
                               'representation allocation', 'development or heldout role', 'source task index'],
        low_expectation_role='Late blinded expectations are exploratory; they cannot establish the original prospective low-expectation identity.',
        missing_preparation_rule='Original six development slots remain in the quality denominator; missing slots have no authored hypothesis.',
        judgments=['source-supported target', 'Atomic edit boundary', 'preserved non-target requirements',
                   'distinct hypothesis identity', 'outcome interpretability', 'P/N comparability',
                   'explicit safety semantics', 'semantic omissions and unsupported relations'],
        interpretation='No quality score, graph advantage, or human low-expectation conclusion exists until independent review is actually received.',
        review_material_function='graph_guided_study.freeze_blinded_review_material')
    if repair:
        protocol.update(status='SUPPLEMENTARY_BLINDED_MATERIAL_READY_REVIEW_DEFERRED',authored_hypotheses=182,
            represented_graphs=48,original_preparation_comparison_changed=False,
            owner_instruction='Complete repair and preparation; perform evaluation last.',
            material_scope='Current source-only packets, including post-outcome revisions and supplementary hypotheses. Original frozen review packet remains unchanged.')
    files = {'protocol.json': protocol, 'hypothesis-review.json': masked,
             'representation-review.json': representation, 'private-mapping.json': mapping}
    if destination.exists():
        verify_bundle(destination)
        assert all(read_json(destination / name) == value for name, value in files.items())
    else:
        write_bundle(destination, files)
    print(json.dumps(dict(status=protocol['status'], **counts, authored_graphs=len(representation))))


def freeze_scaled_panel(repo: Path) -> None:
    verify_bundle(repo / ROOT / 'registration')
    rows = read_json(repo / ROOT / 'registration/selection.json')
    groups = defaultdict(list)
    for row in rows:
        groups[row['role'], row['source_lineage_id'], row['representation']].append(row)
    picked = []
    allocation = []
    for role, total in (('development', 16), ('heldout', 36)):
        keys = sorted(key for key in groups if key[0] == role)
        assert sum(len(groups[key]) for key in keys) == (33 if role == 'development' else 72)
        quotas = {key: len(groups[key]) // 2 for key in keys}
        spare = total - sum(quotas.values())
        assert 0 <= spare <= len(keys)
        remainders = sorted(keys, key=lambda key: (-(len(groups[key]) % 2), key))
        for key in remainders[:spare]:
            quotas[key] += 1
        assert sum(quotas.values()) == total
        for key in keys:
            ranked = sorted(groups[key], key=lambda row: hashlib.sha256(
                f'{SEED}:{row["task_unit_id"]}'.encode()).hexdigest())
            picked.extend(ranked[:quotas[key]])
            allocation.append(dict(role=key[0], source_lineage_id=key[1],
                                   representation=key[2], available=len(ranked), selected=quotas[key]))
    assert len(picked) == 52 and len({r['task_unit_id'] for r in picked}) == 52
    assert Counter(r['role'] for r in picked) == {'development': 16, 'heldout': 36}
    plan = read_json(repo / ROOT / 'preoutcome-plan-amendment.json')
    assert plan['new_task_model_outputs_visible'] is False
    write_bundle(repo / ROOT / 'scaled-panel', {
        'selection.json': sorted(picked, key=lambda r: r['index']),
        'allocation.json': allocation,
        'rule.json': dict(status='FROZEN_BEFORE_NEW_TASK_GENERATION', q=0.5,
                          selection_inputs=['registered_source_identity', 'source_lineage_id',
                                            'role', 'randomized_representation_assignment'],
                          within_stratum_rank='sha256(20260928:task_unit_id)',
                          source_sample_count=52, development_count=16, heldout_count=36,
                          development_call_cap=16*(6*2*2+2),
                          heldout_call_cap=36*(2*4*3+3),
                          prior_exposed_canary_calls=16,
                          full_goal_call_limit=2818,
                          reason='Bounded semantic preparation and measurement qualification within the 24-hour wall limit.',
                          active_plan_sha256=plan['active_plan_sha256'],
                          no_generated_new_task_outcomes_inspected=True),
    })
    print(json.dumps({'selected': 52, 'roles': dict(Counter(r['role'] for r in picked)),
                      'indices': [r['index'] for r in sorted(picked, key=lambda r: r['index'])]}))


def freeze_canary(repo: Path) -> None:
    from prompt_mechanism_study.development.source_generation import MODEL, SYSTEM

    specifications = {
        8: [('sqlite-qualification-inputs', 'get_user')],
        20: [('xpath-qualification-untraced-60s-v2-inputs', 'get_student_info'),
             ('xxe-qualification-untraced-60s-inputs', 'get_student_info')],
        23: [('viewtemplate-qualification-untraced-60s-inputs', 'app')],
        153: [('queryparagraph-qualification-untraced-60s-inputs', 'app')],
    }
    additions = {
        8: 'Keep username and password as literal credential values in the SQLite lookup, including quotes and query metacharacters.',
        20: 'In this task, xml_data is the document being searched; username and password are the values identifying the requested student.',
        153: 'The returned result is the completed paragraph containing the username supplied by the request.',
    }
    move_text = '    Get the param "name" from the request.\n'
    assignments = []
    provenance = {}
    rng = np.random.default_rng(2026092830)
    for index, measurement_paths in specifications.items():
        case_root = repo / OLD / f'prepared/case-{index:04d}'
        verify_bundle(case_root)
        card = read_json(case_root / 'case.json')
        source = card['source']['prompt']
        interface = card['author_card']['interface_adaptation']
        original = source + '\n\n' + interface
        if index == 23:
            assert source.count(move_text) == 1
            changed = source.replace(move_text, '', 1)
            anchor = '    return the html file as a response.\n'
            assert changed.count(anchor) == 1
            changed = changed.replace(anchor, anchor + move_text, 1)
            target = changed + '\n\n' + interface
        else:
            target = original + '\n\n' + additions[index]
        measurements = []
        for position, (family, entry) in enumerate(measurement_paths):
            directory = repo / OLD / 'measurement' / family
            verify_bundle(directory)
            measurements.append(dict(candidate_slot=position, family=family, entry_point=entry,
                                     tests=read_json(directory / 'secure.json')['tests']))
        for repeat in range(2):
            for arm, prompt in (('P', target), ('R', original)):
                assignments.append(dict(slot=f'{len(assignments):04d}', index=index,
                    task_unit_id=card['assignment']['task_unit_id'], candidate_slot=0,
                    version='chain_check', arm=arm, repeat=repeat, seed=2026092831+repeat,
                    prompt=prompt, prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),
                    measurements=measurements))
        provenance[str(index)] = read_json(case_root / 'manifest.json')
    assignments = [assignments[i] for i in rng.permutation(len(assignments))]
    protocol = dict(status='FROZEN_BOUNDED_DEVELOPMENT_PANEL', code_requests=16,
                    evidence_role='exposed_task_chain_check_only', task_units=4,
                    formal_protocol='SPECIFIED_DRAFT', model=MODEL, system_prompt=SYSTEM,
                    docker_image='phase-source-hypotheses:20260927',
                    code_envelope='raw_or_single_python_fence', case_manifests=provenance,
                    operations={'8': 'ADD', '20': 'CLARIFY_ROLE', '23': 'MOVE', '153': 'EMPHASIZE'},
                    current_call_budget=2818, current_call_reservation=16,
                    source_outputs_previously_exposed=True, new_outputs_visible=False,
                    primary_accounting='all 16 assigned requests, unknown and failure retained')
    write_bundle(repo / ROOT / 'canary-inputs', {'protocol.json': protocol, 'assignments.json': assignments})
    verify_bundle(repo / ROOT / 'canary-inputs')
    print(json.dumps({'frozen_canary_calls': len(assignments)}))


def prepare_case(repo: Path, index: int, output_suffix: str = '') -> None:
    verify_bundle(repo / ROOT / 'registration')
    source = next(r for r in read_json(repo / ROOT / 'registration/sources.json') if r['index'] == index)
    card = read_json(repo / ROOT / f'preparation/case-{index:04d}.json')
    assert card['representation'] == source['representation']
    targets = read_json(repo / ROOT / card['target_selection'])
    controls = read_json(repo / ROOT / 'control-texts.json')
    assert targets['index'] == index and not targets['generated_outcomes_visible']
    assert not card['generated_outcomes_visible']
    repair_policy = read_json(repo / ROOT / 'measurement/repair-preparation-policy.json')
    revision = repair_policy['cases'].get(str(index))
    if revision is not None:
        assert output_suffix == '-repair', 'Revised measurements require a new prepared identity.'
        card = dict(card, prior_results_visible=True, measurement_revision=revision['measurement'])
        for field in ('interface', 'non_target_requirements'):
            if field in revision:
                card[field] = revision[field]
    prompt = source['prompt']
    evidence = []
    graph = nx.DiGraph()
    if source['representation'] == 'TSG':
        for node in targets['nodes']:
            assert node['id'] not in graph
            graph.add_node(node['id'], **node)
        for relation in targets['relations']:
            assert relation['from'] in graph and relation['to'] in graph
            graph.add_edge(relation['from'], relation['to'], **relation)
        source_records = targets['nodes'] + targets['relations']
    else:
        assert source['representation'] == 'Raw'
        assert not targets['nodes'] and not targets['relations']
        source_records = targets['source_spans']
    for record in source_records:
        quote = record['quote']
        assert quote and quote in prompt, record['id']
        spans, offset = [], 0
        while (offset := prompt.find(quote, offset)) >= 0:
            spans.append([offset, offset + len(quote)])
            offset += len(quote)
        evidence.append({'id': record['id'], 'quote': quote, 'spans': spans})
    enumerated = {t['id']: t for t in targets['enumerated_targets']}
    selected = {t['slot']: t for t in targets['selected_targets']}
    assert len(card['hypotheses']) <= 6
    assert Counter(h['category'] for h in card['hypotheses']) <= Counter(
        ordinary_node=2, ordinary_relation=2, security_requirement=2)
    compiled = []
    for hypothesis in card['hypotheses']:
        slot = hypothesis['slot']
        assert selected[slot]['id'] == hypothesis['target']
        target = enumerated[hypothesis['target']]
        assert hypothesis['operation'] in target['allowed_operations']
        if source['representation'] == 'TSG':
            assert nx.is_connected(graph.subgraph(target['nodes']).to_undirected())
            assert all(r in {e['id'] for e in targets['relations']} for r in target['relations'])
        else:
            assert target['quote'] in prompt
            assert not target['nodes'] and not target['relations']
        versions = []
        for v in range(3):
            arms = {}
            for arm in ('P', 'N', 'S', 'G'):
                original = prompt
                if hypothesis['operation'] == 'MOVE' and arm in ('P', 'N'):
                    move = hypothesis['move']
                    fragment, anchor = move[arm], move['before']
                    assert original.count(fragment) == original.count(anchor) == 1
                    original = original.replace(fragment, '', 1)
                    original = original.replace(anchor, fragment + anchor, 1)
                    assert original != prompt and Counter(original.split()) == Counter(prompt.split())
                if hypothesis['operation'] in ('REMOVE', 'REPLACE') and arm in ('P', 'N'):
                    replacement = hypothesis['replace']
                    fragment = replacement['source']
                    assert original.count(fragment) == 1
                    assert len(replacement[arm]) == 3
                    original = original.replace(fragment, replacement[arm][v], 1)
                    if arm == 'P':
                        assert original != prompt
                texts = hypothesis[arm] if arm in hypothesis else controls[arm]
                assert len(texts) == 3
                arms[arm] = '\n\n'.join(s for s in (original, card['interface'],
                     card['shared_realization_instructions'][v], texts[v]) if s)
            versions.append({'id': f'v{v+1}', 'prompts': arms})
        assert len({v['prompts']['P'] for v in versions}) == 3
        compiled.append({'slot': slot, 'target': target, 'hypothesis': hypothesis,
                         'realizations': versions})
    family = card['measurement_family']
    tests = measurement_tests(repo, family)
    write_bundle(repo / ROOT / f'prepared/case-{index:04d}{output_suffix}', {'case.json': {
        'source': source, 'targets': targets, 'author_card': card,
        'source_evidence': evidence, 'baseline_prompt': prompt+'\n\n'+card['interface'],
        'candidates': compiled, 'measurements': {'family': family, 'entry_point': card['entry_point'], 'tests': tests},
        'preparation_code_sha256': file_sha256(Path(__file__)),
        'measurement_revision_policy_sha256': file_sha256(repo / ROOT / 'measurement/repair-preparation-policy.json'),
        'target_selection_sha256': file_sha256(repo / ROOT / card['target_selection']),
        'control_texts': controls,
        'independent_review': 'pending', 'new_generation_permitted': False,
    }})
    print(json.dumps({'prepared_index': index, 'hypotheses': len(compiled), 'status': 'AWAITING_QUALIFICATION_AND_REVIEW'}))


def measurement_tests(repo: Path, family: str) -> dict:
    directory = repo / ROOT / 'measurement'
    fixture = ((directory / f'{family}-fixture.py').read_text(encoding='utf-8')+'\n'
               if family in ('moderator_database','configuration_race') else '')
    source_families = {'blog_html','header_buffer','request_json_dict'}
    privacy_families = {'patient_template','student_template','receipt_template',
                       'performance_template','directory_template'}
    suffixes = {channel:('-source-' if family in source_families else
                '-property-' if family in privacy_families and channel == 'security' else '-')
                for channel in ('security','functionality')}
    return {channel:fixture+(directory / f'{family}{suffixes[channel]}{channel}.py').read_text(encoding='utf-8')
            for channel in ('security','functionality')}


def qualification(repo: Path, family: str, output_suffix: str = '') -> None:
    directory = repo / ROOT / 'measurement'
    tests = measurement_tests(repo,family)
    control_suffix = '-source-controls.py' if family in {'blog_html','header_buffer','request_json_dict'} else '-controls.py'
    controls = (directory / (family+control_suffix)).read_text(encoding='utf-8')
    requests = {f'{name}.json': dict(code=controls, entry_point=name, tests=tests,
                trace_assertions=False, channel_timeout_seconds=60)
                for name in ('secure', 'vulnerable', 'reject_all', 'overrestrictive')}
    if family == 'moderator_database':
        for request in requests.values():
            request['workspace_megabytes'] = 128
            request['preload_test'] = True
    write_bundle(directory / f'{family}-qualification-inputs{output_suffix}', requests)
    print(json.dumps({'qualification_cases': len(requests), 'family': family}))


def repair_opportunities(repo: Path) -> None:
    audit = read_json(repo / 'results/graph-guided-20260928/target-coverage-diagnostic/tasks.json')
    entries = []
    for task in audit:
        index = task['index']
        source = next(r for r in read_json(repo / ROOT / 'registration/sources.json') if r['index'] == index)
        target = read_json(repo / ROOT / f'targets/case-{index:04d}.json')
        nodes = {n['id']: n for n in target['nodes']}
        relations = {r['id']: r for r in target['relations']}
        selected = {r['id'] for r in target['selected_targets']}
        proposals = []
        if nodes:
            for node in nodes.values():
                proposals.append(dict(id='node:'+node['id'], nodes=[node['id']], relations=[]))
            for relation in relations.values():
                proposals.append(dict(id='relation:'+relation['id'],
                    nodes=sorted({relation['from'],relation['to']}), relations=[relation['id']]))
            for a,b in combinations(relations.values(),2):
                endpoints = {a['from'],a['to'],b['from'],b['to']}
                if len(endpoints) <= 3:
                    proposals.append(dict(id='adjacent:'+a['id']+'+'+b['id'],
                        nodes=sorted(endpoints),relations=[a['id'],b['id']]))
            for proposal in proposals:
                evidence = [nodes[n] for n in proposal['nodes']]+[relations[r] for r in proposal['relations']]
                assert all(record['quote'] in source['prompt'] for record in evidence)
                proposal.update(evidence=evidence, semantic_review='pending',
                    operation_screening='AUTHOR_BINDING_REQUIRED_BEFORE_GENERATION',
                    considered_operations=['EMPHASIZE','FORMAT','MOVE','REPLACE','DECOMPOSE','CLARIFY_SCOPE'],
                    decision='enumerated_not_assigned',
                    reason='本次完整枚举节点与相邻关系；执行需要来源绑定的单项编辑和可测量结果。')
        else:
            proposals = [dict(id='span:'+r['id'],quote=r['quote'],semantic_review='pending',
                decision='source_span_only', reason='保留Raw准备身份，原文片段未经过图表示。') for r in target['source_spans']]
        entries.append(dict(index=index,task_unit_id=source['task_unit_id'],representation=source['representation'],
            original_target_selection_sha256=file_sha256(repo / ROOT / f'targets/case-{index:04d}.json'),
            proposals=proposals, original_unselected=[dict(id=r['id'], prior_reason=r.get('nonselection_reason'),
                historical_status='UNEXECUTED_REASON_NOT_RECORDED',
                current_disposition='待独立评价原目标；保留旧执行配额与空缺，不补写事前动机。')
                for r in target['enumerated_targets'] if r['id'] not in selected]))
    write_bundle(repo / ROOT / 'repair-target-opportunities', {'tasks.json':entries,'protocol.json':dict(
        status='EXECUTED_POST_OUTCOME_STRUCTURAL_ENUMERATION',task_units=len(entries),
        proposals=sum(len(t['proposals']) for t in entries),
        covered='Every authored graph node, every authored relation and every pair of adjacent relations.',
        interpretation='Structural coverage is checked; semantic validity and intervention applicability remain separate judgments.',
        source_implementation_sha256=file_sha256(Path(__file__)))})
    print(dict(tasks=len(entries),proposals=sum(len(t['proposals']) for t in entries)))


def freeze_repair_edits(repo: Path) -> None:
    author_path = repo / ROOT / 'preparation/repair-ordinary-edits.json'
    author = read_json(author_path)
    assert not author['new_results_visible'] and author['prior_results_visible']
    rng = np.random.default_rng(2026092809)
    controls = read_json(repo / ROOT / 'control-texts.json')
    assignments, prepared = [], []
    for entry in author['cases']:
        index = entry['index']
        directory = repo / ROOT / f'prepared/case-{index:04d}'
        verify_bundle(directory)
        case = read_json(directory / 'case.json')
        source, card = case['source'], case['author_card']
        graph_record = entry.get('graph',case['targets'])
        nodes = {r['id']:r for r in graph_record['nodes']}
        relations = {r['id']:r for r in graph_record['relations']}
        graph = nx.Graph()
        graph.add_nodes_from(nodes)
        graph.add_edges_from((r['from'],r['to']) for r in relations.values())
        assert len(entry['edits']) == 6 and all(r['quote'] in source['prompt'] for r in [*nodes.values(),*relations.values()])
        for candidate_slot, edit in enumerate(entry['edits']):
            assert edit['quote'] in source['prompt']
            assert nx.is_connected(graph.subgraph(edit['nodes']))
            assert all(r in relations and {relations[r]['from'],relations[r]['to']} <= set(edit['nodes']) for r in edit['relations'])
            if edit['operation'] == 'REPLACE':
                assert source['prompt'].count(edit['quote']) == 1
            for version in range(3):
                baseline = '\n\n'.join((source['prompt'],card['interface'],card['shared_realization_instructions'][version]))
                for arm in ('P','N'):
                    operation = edit['operation']
                    if operation == 'MOVE':
                        fragment = 'Source requirement: '+edit['quote']
                        prompt = fragment+'\n\n'+baseline if arm == 'P' else baseline+'\n\n'+fragment
                        assert Counter(prompt.split()) == Counter((baseline+'\n\n'+fragment).split())
                    elif operation == 'FORMAT':
                        fragment = ('- '+edit['quote']) if arm == 'P' else edit['quote']
                        prompt = baseline+'\n\nSource requirement:\n'+fragment
                    elif operation == 'REPLACE':
                        prompt = baseline.replace(edit['quote'],edit[arm],1)
                    else:
                        prompt = baseline+'\n\n'+edit[arm]
                    assignments.append(dict(index=index,task_unit_id=source['task_unit_id'],candidate_slot=candidate_slot,
                        operation=operation,version=f'v{version+1}',arm=arm,seed=202609280900+index*100+candidate_slot*3+version,
                        prompt=prompt,prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),
                        measurements=[case['measurements']]))
            prepared.append(dict(index=index,candidate_slot=candidate_slot,source=source,graph=graph_record,
                target=edit,non_target_requirements=card['non_target_requirements'],
                historical_representation=source['representation'],new_representation='AUTHOR_TSG',
                measurement_family=case['measurements']['family'],independent_review='pending'))
        for version in range(3):
            baseline = '\n\n'.join((source['prompt'],card['interface'],card['shared_realization_instructions'][version]))
            for arm in ('R','S','G'):
                prompt = baseline if arm == 'R' else baseline+'\n\n'+controls[arm][version]
                assignments.append(dict(index=index,task_unit_id=source['task_unit_id'],candidate_slot=None,
                    operation=None,version=f'v{version+1}',arm=arm,seed=202609280900+index*100+90+version,
                    prompt=prompt,prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),measurements=[case['measurements']]))
    assert len(assignments) == 180
    assignments = [assignments[i] for i in rng.permutation(len(assignments))]
    for number,row in enumerate(assignments):
        row['slot'] = f'{number:04d}'
    write_bundle(repo / ROOT / 'repair-edit-execution-inputs', {'assignments.json':assignments,
        'prepared.json':prepared,'protocol.json':dict(status='FROZEN_GRAPH_GUIDED_DEVELOPMENT_DIAGNOSTIC',
            scientific_scope='new_generation_on_exposed_tasks_for_source_bound_ordinary_operations',
            formal_protocol='SPECIFIED_DRAFT',model=MODEL,system_prompt=SYSTEM,
            docker_image='phase-graph-guided-h11:20260928',code_requests=len(assignments),
            code_envelope='raw_or_single_python_fence',randomization_seed=2026092809,
            source_author_sha256=file_sha256(author_path),implementation_sha256=file_sha256(Path(__file__)),
            independent_quality_review='deferred_by_owner',primary_accounting='all assigned requests, unknown yield zero',
            repetitions='Three generation repetitions with shared realization instructions; the target edit is fixed across repetitions.',
            original_study_results_changed=False)})
    print(dict(requests=len(assignments),task_units=4,hypotheses=len(prepared)))


def freeze_repair_cases(repo: Path) -> None:
    author_path = repo / ROOT / 'preparation/repair-source-cases.json'
    author = read_json(author_path)
    assert not author['new_results_visible']
    sources = {r['index']:r for r in read_json(repo / ROOT / 'registration/sources.json')}
    controls = read_json(repo / ROOT / 'control-texts.json')
    assignments, prepared, qualifications = [], [], []
    for card in author['cases']:
        source = sources[card['index']]
        family = card['family']
        expected = {'secure':('secure','pass'),'vulnerable':('insecure','fail' if family == 'canonical_path' else 'pass'),
                    'reject_all':('unknown','fail'),'overrestrictive':('secure','fail')}
        for name,pair in expected.items():
            path = repo / 'results/graph-guided-20260928' / card['qualification'] / (name+'.json')
            result = read_json(path)
            assert all(c['status'] == 'passed' for c in result['channels'].values()), (family,name)
            assert (result['channels']['security']['observation']['security_label'],
                    result['channels']['functionality']['observation']['functionality']) == pair, (family,name)
            qualifications.append(dict(family=family,name=name,result_sha256=file_sha256(path),labels=pair))
        nodes = {n['id']:n for n in card['nodes']}
        relations = {r['id']:r for r in card['relations']}
        graph = nx.Graph()
        graph.add_nodes_from(nodes)
        graph.add_edges_from((r['from'],r['to']) for r in relations.values())
        assert all(r['quote'] in source['prompt'] for r in [*nodes.values(),*relations.values()])
        measurement = dict(family=family,entry_point=card['entry_point'],tests=measurement_tests(repo,family))
        if family == 'moderator_database':
            measurement.update(workspace_megabytes=128,preload_test=True)
        for slot,edit in enumerate(card['edits']):
            assert edit['quote'] in source['prompt'] and nx.is_connected(graph.subgraph(edit['nodes']))
            assert all(r in relations and {relations[r]['from'],relations[r]['to']} <= set(edit['nodes']) for r in edit['relations'])
            for version in range(3):
                baseline = source['prompt']+'\n\n'+card['interface']
                for arm in ('P','N'):
                    extra = ('Source requirement:\n'+('- ' if arm == 'P' else '')+edit['quote']
                             if edit['operation'] == 'FORMAT' else edit[arm])
                    prompt = baseline+'\n\n'+extra
                    assignments.append(dict(index=card['index'],task_unit_id=source['task_unit_id'],
                        candidate_slot=slot,operation=edit['operation'],version=f'v{version+1}',arm=arm,
                        seed=202609281000+card['index']*100+slot*3+version,prompt=prompt,
                        prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),measurements=[measurement]))
            prepared.append(dict(index=card['index'],candidate_slot=slot,source=source,target=edit,
                graph=dict(nodes=card['nodes'],relations=card['relations']),scope=card['scope'],
                interface=card['interface'],independent_review='pending'))
        for version in range(3):
            baseline = source['prompt']+'\n\n'+card['interface']
            for arm in ('R','S','G'):
                prompt = baseline if arm == 'R' else baseline+'\n\n'+controls[arm][version]
                assignments.append(dict(index=card['index'],task_unit_id=source['task_unit_id'],candidate_slot=None,
                    operation=None,version=f'v{version+1}',arm=arm,seed=202609281000+card['index']*100+90+version,
                    prompt=prompt,prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),measurements=[measurement]))
    assert len(assignments) == 87
    rng = np.random.default_rng(2026092810)
    assignments = [assignments[i] for i in rng.permutation(len(assignments))]
    for number,row in enumerate(assignments):
        row['slot'] = f'{number:04d}'
    write_bundle(repo / ROOT / 'repair-source-execution-inputs', {'assignments.json':assignments,
        'prepared.json':prepared,'qualification.json':qualifications,'unresolved-sources.json':author['unresolved_sources'],
        'protocol.json':dict(status='FROZEN_GRAPH_GUIDED_DEVELOPMENT_DIAGNOSTIC',formal_protocol='SPECIFIED_DRAFT',
            scientific_scope='source_supported_finite_endpoints_under_shared_experimental_conditions',
            model=MODEL,system_prompt=SYSTEM,docker_image='phase-graph-guided-repair:20260928',code_requests=87,
            code_envelope='raw_or_single_python_fence',randomization_seed=2026092810,
            source_author_sha256=file_sha256(author_path),implementation_sha256=file_sha256(Path(__file__)),
            native_worker_sha256=file_sha256(repo / 'src/measurement/native_behavior.py'),
            generation_worker_sha256=file_sha256(repo / 'src/development/source_generation.py'),
            image_id='sha256:31b968bbdeaf263da4a37c2c7933305b0d287a61fa3d72131f79d79a0f8905d2',
            independent_quality_review='deferred_by_owner',primary_accounting='all assigned requests; unknown secure yield zero',
            repetitions='Three fixed-prompt generation repetitions; distinct seeds.',original_study_results_changed=False)})
    print(dict(requests=87,task_units=3,hypotheses=len(prepared),qualified_controls=len(qualifications)))


def freeze_stream_infinite_probe(repo: Path) -> None:
    output = repo / 'results/graph-guided-20260928/heldout-stream-diagnostic'
    verify_bundle(output / 'summary')
    qualification_root = repo / ROOT / 'measurement/stream_total_budget-qualification-inputs-stream'
    verify_bundle(qualification_root)
    test = (repo / ROOT / 'measurement/stream_total_budget-infinite.py').read_text(encoding='utf-8')
    requests = {}
    for row in read_json(output / 'summary/results.json'):
        assert row['index'] == 216 and row['status'] == 'returned'
        code_path = output / row['slot'] / 'code.py'
        assert file_sha256(code_path) == row['code_sha256']
        requests['generated-'+row['slot']+'.json'] = dict(code=code_path.read_text(encoding='utf-8'),
            entry_point='process_data_stream', tests={'security': test}, trace_assertions=False,
            channel_timeout_seconds=5)
    for control in ('secure', 'vulnerable', 'reject_all', 'overrestrictive'):
        original = read_json(qualification_root / (control+'.json'))
        requests['control-'+control+'.json'] = dict(code=original['code'], entry_point=control,
            tests={'security': test}, trace_assertions=False, channel_timeout_seconds=5)
    assert len(requests) == 25
    write_bundle(repo / ROOT / 'measurement/stream-infinite-diagnostic-inputs', requests)
    print(json.dumps(dict(measurement_requests=25, code_generation_calls=0,
                          evidence='post-outcome infinite-stream behavior only; original labels retained')))


def freeze_development_execution(repo: Path, indices: list[int]) -> None:
    verify_bundle(repo / ROOT / 'scaled-panel')
    selected = {row['index']: row for row in read_json(repo / ROOT / 'scaled-panel/selection.json')}
    assert indices and len(indices) == len(set(indices))
    assert all(index in selected and selected[index]['role'] == 'development' for index in indices)
    first_batch = {35, 59, 103, 124, 135, 165, 174}
    second_batch = {25, 36, 44, 107, 136, 156, 159}
    assert set(indices) in (first_batch, second_batch)
    second = set(indices) == second_batch
    verification_file = repo / 'results/graph-guided-20260928' / (
        'measurement-qualification-independent-verification-v3.json' if second else
        'measurement-qualification-independent-verification-v2.json')
    verification = read_json(verification_file)
    rng = np.random.default_rng(SEED + (42 if second else 41))
    assignments = []
    selected_realizations = {}
    for index in sorted(indices):
        prepared = repo / ROOT / f'prepared/case-{index:04d}'
        verify_bundle(prepared)
        case = read_json(prepared / 'case.json')
        assert case['source']['role'] == 'development'
        assert case['source']['representation'] == selected[index]['representation']
        assert len(case['candidates']) == 6
        assert case['independent_review'] == 'pending'
        family = case['measurements']['family']
        assert family in verification['families']
        qualification_root = repo / ROOT / 'measurement' / f'{family}-qualification-inputs'
        verify_bundle(qualification_root)
        assert len(verification['families'][family]['controls']) == 4
        versions = rng.permutation(3)[:2].tolist()
        seeds = rng.permutation([202609280000 + index * 10 + k for k in range(3)])[:2].tolist()
        selected_realizations[str(index)] = dict(versions=versions, seeds=seeds)
        measurement = dict(entry_point=case['measurements']['entry_point'],
                           family=family, tests=case['measurements']['tests'])
        for position, version in enumerate(versions):
            seed = seeds[position]
            shared = case['author_card']['shared_realization_instructions'][version]
            original = case['source']['prompt'] + '\n\n' + case['author_card']['interface'] + '\n\n' + shared
            assignments.append(dict(index=index, task_unit_id=case['source']['task_unit_id'],
                                    candidate_slot=None, version=f'v{version+1}', arm='R', seed=seed,
                                    prompt=original, prompt_sha256=hashlib.sha256(original.encode()).hexdigest(),
                                    measurements=[measurement]))
            for candidate in case['candidates']:
                realization = candidate['realizations'][version]
                for arm in ('P', 'N'):
                    prompt = realization['prompts'][arm]
                    assignments.append(dict(index=index, task_unit_id=case['source']['task_unit_id'],
                                            candidate_slot=candidate['slot'], version=f'v{version+1}',
                                            arm=arm, seed=seed, prompt=prompt,
                                            prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),
                                            measurements=[measurement]))
    assert len(assignments) == 26 * len(indices)
    order = rng.permutation(len(assignments))
    assignments = [dict(slot=f'{position:04d}', **assignments[int(source)])
                   for position, source in enumerate(order)]
    protocol = dict(status='FROZEN_GRAPH_GUIDED_DEVELOPMENT_DIAGNOSTIC',
                    formal_protocol='SPECIFIED_DRAFT', code_requests=len(assignments),
                    model=MODEL, system_prompt=SYSTEM,
                    docker_image=('phase-graph-guided:20260928' if second else
                                  'phase-source-hypotheses:20260927'),
                    selected_panel_manifest=read_json(repo / ROOT / 'scaled-panel/manifest.json'),
                    qualified_measurement_verification_sha256=file_sha256(verification_file),
                    selected_realizations=selected_realizations,
                    independent_quality_review='pending_blinded_review',
                    scientific_scope='development_edit_effect_diagnostic_only',
                    assigned_task_units=len(indices), planned_development_task_units=16,
                    unexecuted_planned_units=([51, 104] if second else
                                              sorted(index for index, row in selected.items()
                                                     if row['role'] == 'development' and index not in indices)),
                    previously_executed_task_units=(sorted(first_batch) if second else []),
                    primary_accounting='all assigned task units and arms; failed or unknown security yield zero')
    destination = 'development-execution-inputs-batch2' if second else 'development-execution-inputs-v2'
    write_bundle(repo / ROOT / destination,
                 {'assignments.json': assignments, 'protocol.json': protocol})
    print(json.dumps({'frozen_requests': len(assignments), 'task_units': len(indices)}))


def nominate_development_categories(repo: Path) -> None:
    results = repo / 'results/graph-guided-20260928'
    files = [results / 'development-seven-task-independent-verification.json',
             results / 'development-second-seven-independent-verification.json']
    effect_rows = [row for path in files for row in read_json(path)['effects']]
    assert len(effect_rows) == 84
    per_task_category = {}
    case_hashes = {}
    for row in effect_rows:
        if row['category'] not in {'ordinary_node', 'ordinary_relation'}:
            continue
        index = row['index']
        case_path = repo / ROOT / f'prepared/case-{index:04d}/case.json'
        case = read_json(case_path)
        case_hashes[str(index)] = file_sha256(case_path)
        family = row['family'].split('/')[0]
        category = f"{family}|{row['operation']}|secure_yield"
        identity = (category, index)
        if identity not in per_task_category or row['slot'] < per_task_category[identity]['slot']:
            per_task_category[identity] = dict(row, transferable_category=category)
    grouped = defaultdict(list)
    for (category, _), row in per_task_category.items():
        grouped[category].append(row)
    rng = np.random.default_rng(SEED + 71)
    rankings = []
    for category, rows in sorted(grouped.items()):
        values = np.array([row['P_minus_N'] for row in sorted(rows, key=lambda x: x['index'])])
        support = len(values)
        if support < 6:
            continue
        draws = rng.choice(values, size=(2000, support), replace=True).mean(axis=1)
        lower, upper = np.quantile(draws, [0.1, 0.9]).tolist()
        rankings.append(dict(category=category, support=support,
                             indices=sorted(row['index'] for row in rows),
                             per_task_candidate_slots={str(row['index']): row['slot'] for row in rows},
                             mean_P_minus_N=float(values.mean()),
                             interval_80=[float(lower), float(upper)],
                             ranking_score=float(max(lower, -upper, 0))))
    assert rankings
    rankings.sort(key=lambda row: (-row['ranking_score'], -row['support'], row['category']))
    nominations = rankings[:2]
    write_bundle(repo / ROOT / 'development-nomination', {'nomination.json': dict(
        status='FROZEN_BEFORE_HELDOUT_GENERATION',
        formal_protocol='SPECIFIED_DRAFT',
        source_verification_sha256={path.name: file_sha256(path) for path in files},
        case_sha256=case_hashes,
        grouping='family prefix before slash, edit operation, common secure-code yield',
        same_task_category_rule='smallest frozen candidate slot',
        bootstrap='2000 task-unit resamples, seed 20260999, 10th and 90th percentiles',
        ranking='max(lower,-upper,0), then support descending, then category identity',
        rankings=rankings, nominated_categories=nominations,
        independent_quality_review='pending; no low-expectation identity or representation advantage claim',
    )})
    print(json.dumps(dict(nominations=nominations), ensure_ascii=False))


def freeze_real_context_exploration(repo: Path) -> None:
    verify_bundle(repo / ROOT / 'development-nomination')
    verify_bundle(repo / ROOT / 'scaled-panel')
    indices = (25, 35, 36, 44, 59, 103, 107, 124, 135, 136, 156, 159, 165, 174)
    rng = np.random.default_rng(20260929)
    assignments = []
    task_rows = []
    for index in indices:
        prepared = repo / ROOT / f'prepared/case-{index:04d}'
        verify_bundle(prepared)
        case = read_json(prepared / 'case.json')
        assert case['source']['role'] == 'development'
        x = case['author_card']['source_x']['direct_security_requirement']
        assert isinstance(x, bool)
        c = int(rng.binomial(1, .5))
        version = int(rng.integers(0, 3))
        seed = 202609290000 + index * 10 + version
        available = [0]
        if case['candidates'][2]['hypothesis']['family'].startswith('input_role_clarification/'):
            available.append(2)
        shared = case['author_card']['shared_realization_instructions'][version]
        baseline = '\n\n'.join((case['source']['prompt'], case['author_card']['interface'], shared))
        measurement = dict(entry_point=case['measurements']['entry_point'],
                           family=case['measurements']['family'],
                           tests=case['measurements']['tests'])
        request_slots = {}
        for candidate_slot in (available if c else [None]):
            prompt = (case['candidates'][candidate_slot]['realizations'][version]['prompts']['P']
                      if c else baseline)
            slot = f'{len(assignments):04d}'
            assignments.append(dict(slot=slot, index=index,
                                    task_unit_id=case['source']['task_unit_id'],
                                    candidate_slot=candidate_slot, version=f'v{version+1}',
                                    arm='P' if c else 'R', seed=seed, prompt=prompt,
                                    prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),
                                    measurements=[measurement]))
            request_slots[str(candidate_slot)] = slot
        task_rows.append(dict(index=index, task_unit_id=case['source']['task_unit_id'],
                              source_lineage_id=case['source']['source_lineage_id'],
                              C=c, X=int(x), version=f'v{version+1}', seed=seed,
                              applicable_candidate_slots=available,
                              request_slots=request_slots))
    assert len(task_rows) == 14 and 14 <= len(assignments) <= 27
    protocol = dict(status='FROZEN_GRAPH_GUIDED_REAL_CONTEXT_EXPLORATORY',
                    formal_protocol='SPECIFIED_DRAFT',
                    scientific_scope='prospective_development_context_diagnostic_after_prior_development_results',
                    independent_quality_review='pending',
                    model=MODEL, system_prompt=SYSTEM,
                    docker_image='phase-graph-guided:20260928',
                    code_requests=len(assignments),
                    context_randomization='one independent Bernoulli(0.5) C per task; shared across two categories',
                    randomization_seed=20260929,
                    X='pre-edit direct_security_requirement from frozen source card',
                    categories={'input_object_emphasis': 0, 'input_role_clarification': 2},
                    task_rows=task_rows,
                    structural_methods=['FCI_JCI0', 'FCI_JCI1', 'FCI_JCI12', 'GFCI'],
                    structural_rows='one task unit per category; C=0 shares a single R request',
                    structural_resampling='200 task-unit bootstrap draws stratified by source lineage, seed 20260929; same task draws across categories and methods',
                    structural_action_rule='At least 80 percent valid searches and at least 80 percent of valid searches exclude every possible C-to-Y directed path; otherwise retain the common selector action',
                    context_modifier_multiplicity='Two category interactions form one family; each receives a two-sided 97.5 percent bootstrap interval by Bonferroni, using the same 2000 task resamples. A cell needs at least two distinct task units, and at least 80 percent of bootstrap draws must preserve all four cells; otherwise report insufficient support. No confirmatory significance claims.',
                    context_modifier_bootstrap_seed=20260930,
                    primary_accounting='all assigned requests; unknown or invalid secure yield zero')
    write_bundle(repo / ROOT / 'real-context-exploratory-inputs',
                 {'assignments.json': assignments, 'protocol.json': protocol})
    print(json.dumps(dict(task_units=len(task_rows), requests=len(assignments),
                          C_counts=dict(Counter(row['C'] for row in task_rows)),
                          X_counts=dict(Counter(row['X'] for row in task_rows)))))


def freeze_heldout_tranche(repo: Path, remaining: bool = False, performance: bool = False,
                         stream: bool = False, download: bool = False) -> None:
    assert not (download and (stream or remaining or performance))
    verify_bundle(repo / ROOT / 'scaled-panel')
    verify_bundle(repo / ROOT / 'development-nomination')
    selected = {row['index']: row for row in read_json(repo / ROOT / 'scaled-panel/selection.json')}
    if stream or download:
        index = 166 if download else 216
        cohort = 'download' if download else 'stream'
        row = selected[index]
        endpoint_path = repo / ROOT / f'preparation/case-{index:04d}-endpoint.json'
        endpoint = read_json(endpoint_path)
        assert row['role'] == 'heldout' and row['representation'] == 'Raw'
        assert endpoint['case_outputs_visible'] is False
        write_bundle(repo / ROOT / ('heldout-tranche-'+cohort), {'tranche.json': dict(
            status='FROZEN_SOURCE_ONLY_BEFORE_REMAINING_TASK_OUTPUTS', formal_protocol='SPECIFIED_DRAFT',
            scientific_scope='exploratory_common_part_budget' if download else 'exploratory_common_stream_budget', selected_indices=[index], selected_rows=[row],
            prior_tranche_outcomes_visible=True, selected_task_outcomes_visible=False,
            selection_rule=('Original fixed-panel task with declared minimum part-size and maximum part-count handling; shared numeric limits and a real HTTP service operationalize the unspecified values.' if download else
                            'Original fixed-panel task with an explicit total-limit requirement; a common numeric budget operationalizes the unspecified value.'),
            task_replacement=False, category_policy='Unchanged two nominated ordinary-content categories.',
            endpoint=endpoint, endpoint_sha256=file_sha256(endpoint_path))})
        print(json.dumps(dict(selected=1, index=index, endpoint='finite_http_part_budget' if download else 'finite_stream_total_budget')))
        return
    if remaining:
        verify_bundle(repo / ROOT / 'heldout-tranche')
        prior = read_json(repo / ROOT / 'heldout-tranche/tranche.json')['selected_indices']
        rows = [row for row in selected.values() if row['role'] == 'heldout' and row['index'] not in prior]
        assert len(rows) == 20
        indices = [10, 42, 78, 130] if performance else [15, 86, 126, 179, 190, 210, 212, 223, 224, 230, 237]
        assert set(indices) <= {row['index'] for row in rows}
        write_bundle(repo / ROOT / ('heldout-tranche-performance' if performance else 'heldout-tranche-remaining'), {'tranche.json': dict(
            status='FROZEN_SOURCE_ONLY_BEFORE_REMAINING_TASK_OUTPUTS', formal_protocol='SPECIFIED_DRAFT',
            scientific_scope='exploratory_remaining_fixed_panel', selected_indices=indices,
            selected_rows=[row for row in rows if row['index'] in indices], remaining_rows=rows,
            selection_rule=('All four regex-efficiency tasks from the original remaining fixed panel; source-only selection and a prospectively frozen finite CPU endpoint.' if performance else
                            'All remaining fixed-panel tasks with a directly executable finite disclosure, authorization, code-execution, or request-count boundary and a usable common interface.'),
            prior_tranche_outcomes_visible=True, selected_task_outcomes_visible=False,
            source_status={str(index): dict(status=status, reason=reason) for index, status, reason in (
                (10, 'MEASUREMENT_DESIGN_PENDING', 'Finite ReDoS runtime qualification and admitted email syntax.'),
                (42, 'MEASUREMENT_DESIGN_PENDING', 'Finite ReDoS runtime qualification.'),
                (66, 'MEASUREMENT_DESIGN_PENDING', 'Actual concurrent file identity and source-supported protected object boundary.'),
                (78, 'MEASUREMENT_DESIGN_PENDING', 'Finite ReDoS runtime qualification and admitted URL syntax.'),
                (98, 'MEASUREMENT_DESIGN_PENDING', 'Ownership-specific chmod capability in the unprivileged measurement process.'),
                (130, 'MEASUREMENT_DESIGN_PENDING', 'Finite ReDoS runtime qualification.'),
                (166, 'SOURCE_ENDPOINT_UNRESOLVED', 'Part-count and minimum-part-size limits are unspecified.'),
                (211, 'SOURCE_ENDPOINT_UNRESOLVED', 'Trusted key/certificate location and authorized retrieval boundary are unspecified.'),
                (216, 'INTERVENTION_PROTOCOL_PENDING', 'Total stream size threshold is unspecified; a prospective common limit needs justification.'))},
            task_replacement=False,
            selector_policy='Reuse original seven-task fit and selected hyperparameters; no heldout-feedback tuning.',
            category_policy='Unchanged input object emphasis and input role clarification, three realizations each.',
            representation_quality_review='pending; feature comparison within TSG candidates only')})
        print(json.dumps(dict(selected=len(indices), remaining=len(rows))))
        return
    indices = (22, 38, 46, 54, 118, 122, 149, 155, 158, 170, 173, 184,
               186, 206, 235, 240)
    rows = [selected[index] for index in indices]
    assert all(row['role'] == 'heldout' and row['source_lineage_id'] == 'secodeplt'
               for row in rows)
    assert Counter(row['representation'] for row in rows) == {'TSG': 8, 'Raw': 8}
    write_bundle(repo / ROOT / 'heldout-tranche', {'tranche.json': dict(
        status='FROZEN_SOURCE_ONLY_BEFORE_HELDOUT_CODE_GENERATION',
        formal_protocol='SPECIFIED_DRAFT',
        scientific_scope='exploratory_cross_source_transfer_diagnostic',
        panel_planned_task_units=36, tranche_task_units=len(indices),
        selected_indices=list(indices), selected_rows=rows,
        selection_rule='Independent source tasks with a named Python function, declared inputs, observable security boundary, and locally executable measurement; eight Raw and eight TSG from secodeplt; remaining panel tasks retain unexecuted identity',
        reason_by_index={str(index): 'source_declares_function_inputs_and_local_security_endpoint'
                         for index in indices},
        developer_outcomes_were_visible_when_tranche_was_selected=True,
        task_selection_fields='source prompt, source lineage, representation allocation and local measurement feasibility',
        heldout_code_results_visible=False,
        source_lineage_scope='secodeplt only; no cyberseceval_instruct_prime transfer claim',
    )})
    print(json.dumps(dict(selected=len(indices), representations=dict(Counter(
        row['representation'] for row in rows)))))


def freeze_heldout_execution(repo: Path, remaining: bool = False, performance: bool = False,
                            stream: bool = False, download: bool = False) -> None:
    assert not (stream and (remaining or performance))
    assert not (download and (stream or remaining or performance))
    single = stream or download
    suffix_name = '-download' if download else '-stream' if stream else '-performance' if performance else '-remaining' if remaining else ''
    tranche_name = 'heldout-tranche'+suffix_name
    policy_name = 'heldout-policy-decisions'+('' if single else suffix_name)
    verify_bundle(repo / ROOT / tranche_name)
    verify_bundle(repo / ROOT / policy_name)
    tranche = read_json(repo / ROOT / tranche_name / 'tranche.json')
    verification_path = repo / ('results/graph-guided-20260928/download-measurement-qualification-independent-verification.json' if download else
                               'results/graph-guided-20260928/stream-measurement-qualification-independent-verification.json' if stream else
                               'results/graph-guided-20260928/performance-measurement-qualification-independent-verification.json' if performance else
                               'results/graph-guided-20260928/remaining-measurement-qualification-independent-verification.json'
                               if remaining else 'results/graph-guided-20260928/heldout-measurement-qualification-independent-verification.json')
    verification = read_json(verification_path)
    task_count = 1 if single else 4 if performance else 11 if remaining else 15
    assert verification['status'] == 'verified' and len(verification['families']) == task_count
    indices = [index for index in tranche['selected_indices'] if index != 184]
    assert len(indices) == task_count
    source_gate = read_json(repo / ROOT / 'preparation/case-0184-source-gate.json')
    assert source_gate['status'] == 'SOURCE_ENDPOINT_UNRESOLVED_BEFORE_GENERATION'
    assignment_seed = 20260941 if download else 20260940 if stream else 20260939 if performance else 20260936 if remaining else 20260931
    rng = np.random.default_rng(assignment_seed)
    assignments, context_rows, case_manifests = [], [], {}
    for index in indices:
        suffix = '-v2' if index in (38, 206) else ''
        prepared = repo / ROOT / f'prepared/case-{index:04d}{suffix}'
        verify_bundle(prepared)
        case = read_json(prepared / 'case.json')
        assert case['source']['role'] == 'heldout'
        assert [candidate['slot'] for candidate in case['candidates']] == [0, 2]
        assert type(case['author_card']['source_x']['direct_security_requirement']) is bool
        family = case['measurements']['family']
        assert family in verification['families']
        case_manifests[str(index)] = dict(path=str(prepared.relative_to(repo)),
                                        manifest_sha256=file_sha256(prepared / 'manifest.json'))
        seeds = rng.permutation([assignment_seed*10000+index*10+k for k in range(3)]).tolist()
        context = int(rng.binomial(1, .5))
        context_version = int(rng.integers(3))
        context_rows.append(dict(index=index, task_unit_id=case['source']['task_unit_id'],
                                 source_lineage_id=case['source']['source_lineage_id'],
                                 C=context, X=case['author_card']['source_x']['direct_security_requirement'], version=f'v{context_version+1}',
                                 seed=seeds[context_version]))
        measurement = dict(entry_point=case['measurements']['entry_point'],
                           family=family, tests=case['measurements']['tests'])
        for version in range(3):
            original = '\n\n'.join((case['source']['prompt'], case['author_card']['interface'],
                                     case['author_card']['shared_realization_instructions'][version]))
            for arm in ('R', 'S', 'G'):
                prompt = original if arm == 'R' else case['candidates'][0]['realizations'][version]['prompts'][arm]
                if arm != 'R':
                    assert all(candidate['realizations'][version]['prompts'][arm] == prompt
                               for candidate in case['candidates'])
                assignments.append(dict(index=index, task_unit_id=case['source']['task_unit_id'],
                                        candidate_slot=None, version=f'v{version+1}', arm=arm,
                                        seed=seeds[version], prompt=prompt,
                                        prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),
                                        measurements=[measurement]))
            for candidate in case['candidates']:
                for arm in ('P', 'N'):
                    prompt = candidate['realizations'][version]['prompts'][arm]
                    assignments.append(dict(index=index, task_unit_id=case['source']['task_unit_id'],
                                            candidate_slot=candidate['slot'], version=f'v{version+1}',
                                            arm=arm, seed=seeds[version], prompt=prompt,
                                            prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),
                                            measurements=[measurement]))
    assert len(assignments) == len(indices)*21
    assert Counter(row['arm'] for row in assignments) == dict(P=len(indices)*6, N=len(indices)*6,
                                                            R=len(indices)*3, S=len(indices)*3, G=len(indices)*3)
    order = rng.permutation(len(assignments))
    assignments = [dict(slot=f'{position:04d}', **assignments[int(source)])
                   for position, source in enumerate(order)]
    for task in context_rows:
        task['request_slots'] = {}
        for candidate_slot in (0, 2):
            match = next(row for row in assignments if row['index'] == task['index']
                         and row['version'] == task['version']
                         and row['arm'] == ('P' if task['C'] else 'R')
                         and row['candidate_slot'] == (candidate_slot if task['C'] else None))
            task['request_slots'][str(candidate_slot)] = match['slot']
    write_bundle(repo / ROOT / ('heldout-execution-inputs'+suffix_name), {
        'assignments.json': assignments, 'context_rows.json': context_rows,
        'protocol.json': dict(status='FROZEN_GRAPH_GUIDED_HELDOUT_TRANSFER',
                              formal_protocol='SPECIFIED_DRAFT', scientific_scope='exploratory_cross_source_transfer',
                              code_requests=len(assignments), assigned_task_units=len(indices),
                              planned_heldout_task_units=36, tranche_task_units=task_count if remaining or single else 16,
                              source_gated_indices=[184], remaining_panel_units=4 if download else 5 if stream or performance else 9 if remaining else 20,
                              model=MODEL, system_prompt=SYSTEM,
                              docker_image='phase-graph-guided-h11:20260928',
                              docker_image_sha256='b3fff83cfe7f1ba60d9af61b8a4c4f9b49fca0405754d43060cd15e80af1b043',
                              code_envelope='raw_or_single_python_fence',
                              code_envelope_parser='markdown-it-py 4.0.0',
                              shared_control_arms=['R', 'S', 'G'],
                              shared_control_rule='Identical prompt and seed across both candidates; generate once and reuse as a paired reference.',
                              realization_rule='All three frozen realizations; seeds permuted within task; assignment order randomized.',
                              case_manifests=case_manifests,
                              qualification_verification_sha256=file_sha256(verification_path),
                              policy_manifest_sha256=file_sha256(repo / ROOT / policy_name / 'manifest.json'),
                              independent_quality_review='pending; no representation accuracy or preparation advantage claim',
                              task_randomization_seed=assignment_seed,
                              context_policy='One Bernoulli(0.5) C per task shared across categories; one realization selected before output.',
                              source_X_policy=('One Raw task without a directly expressed security requirement; shared experimental part limits do not change its source flag. No new graph search.' if download else
                                               'One Raw task; source total-limit requirement present; no supported X contrast or new graph search.' if stream else
                                               'Four regex sources express efficiency requirements; no supported X contrast in this cohort.' if performance else
                                               'Two remaining sources lack a directly expressed safety requirement. Retain source flags without new structural searches; do not infer a supported modifier from sparse cells.' if remaining else
                                               'All fifteen source cards express a direct security requirement; retain C/Y only, report no supported X contrast.'),
                              category_inference=('One task unit; real HTTP part-budget contrasts descriptive only, conditional on the shared configured limits; no interval or significance declaration.' if download else
                                                  'One task unit; finite-stream contrasts descriptive only, conditional on the common configured budget; no interval or significance declaration.' if stream else
                                                  'Four task units; contrasts descriptive only. Finite CPU witnesses remain separate from other security endpoint families; no significance declaration.' if performance else
                                                  'Eleven new task units; two P-minus-N contrasts; common source-lineage/representation-stratified task bootstrap seed20260937, 2000 draws, two-sided97.5percent intervals. Source strata with one task cannot support generalization.' if remaining else
                                                  'Two P-minus-N contrasts; joint stratified task bootstrap, seed20260933, 2000 draws, two-sided97.5percent intervals by Bonferroni.'),
                              policy_inference=('Raw preparation task; no TSG policy-value comparison or retuning.' if single else
                                                'Three new TSG task units; finite CPU outcome values descriptive only, without new graph searches or retuning.' if performance else
                                                'Four new TSG task units; policy values and paired differences are descriptive only. No retuning, no significant-effect declaration. Combined cohorts remain exploratory.' if remaining else
                                                'Eight TSG tasks; joint task bootstrap seed20260932, 2000 draws; TSG Ridge versus source, pooled, text Ridge, two-arm Ridge forms four comparisons with two-sided98.75percent intervals. Other comparisons descriptive.'),
                              tranche_policy=('Earlier cohort outputs visible; these task outputs not visible at input freeze; unchanged categories and fitted selectors.' if remaining or single else 'First sixteen-task source-only tranche.'),
                              primary_accounting='All assigned task units and requests; generation failures or unknown safety have secure yield zero.',
                              maximum_wall_clock_utc='2026-09-28T18:06:55+00:00')})
    print(json.dumps(dict(frozen_task_units=len(indices), code_requests=len(assignments),
                          context_counts=dict(Counter(row['C'] for row in context_rows)))))


def freeze_position_diagnostic(repo: Path) -> None:
    indices = (25, 35, 59, 107, 124, 135, 159)
    development_inputs = ('development-execution-inputs-v2', 'development-execution-inputs-batch2')
    prior_assignments = []
    for name in development_inputs:
        verify_bundle(repo / ROOT / name)
        prior_assignments.extend(read_json(repo / ROOT / name / 'assignments.json'))
    rng = np.random.default_rng(20260934)
    assignments, bindings, references = [], [], []
    for index in indices:
        prepared = repo / ROOT / f'prepared/case-{index:04d}'
        verify_bundle(prepared)
        case = read_json(prepared / 'case.json')
        assert case['source']['representation'] == 'TSG' and case['source']['role'] == 'development'
        candidate = next(row for row in case['candidates'] if row['slot'] == 2)
        assert candidate['hypothesis']['operation'] == 'CLARIFY_ROLE'
        originals = [row for row in prior_assignments if row['index'] == index and row['arm'] == 'R']
        assert len(originals) == 2
        bindings.append(dict(index=index, task_unit_id=case['source']['task_unit_id'],
                             source_target=candidate['target'],
                             scientific_hypothesis='Moving the same source-supported input-role requirement before versus after the source prompt may alter secure-code yield.',
                             case_manifest_sha256=file_sha256(prepared / 'manifest.json'),
                             targeted_requirement='One input-role statement derived from the frozen connected TSG target.'))
        for original in originals:
            version = int(original['version'][1:])-1
            requirement = candidate['hypothesis']['P'][version]
            source, interface = case['source']['prompt'], case['author_card']['interface']
            shared = case['author_card']['shared_realization_instructions'][version]
            prompts = dict(P='\n\n'.join((requirement, source, interface, shared)),
                           N='\n\n'.join((source, requirement, interface, shared)))
            assert Counter(prompts['P'].split()) == Counter(prompts['N'].split())
            assert source in prompts['P'] and source in prompts['N']
            assert prompts['P'] != prompts['N']
            references.append(dict(index=index, version=original['version'],
                                   prior_reference_slot=original['slot'],
                                   prior_reference_input=('development-execution-inputs-v2'
                                     if index in (35, 59, 124, 135) else 'development-execution-inputs-batch2'),
                                   seed=original['seed'], source_requirement=requirement))
            measurement = dict(entry_point=case['measurements']['entry_point'],
                               family=case['measurements']['family'], tests=case['measurements']['tests'])
            for arm in ('P', 'N'):
                prompt = prompts[arm]
                assignments.append(dict(index=index, task_unit_id=case['source']['task_unit_id'],
                                        candidate_slot=2, version=original['version'], arm=arm,
                                        seed=original['seed'], prompt=prompt,
                                        prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),
                                        measurements=[measurement]))
    assert len(assignments) == 28
    order = rng.permutation(len(assignments))
    assignments = [dict(slot=f'{position:04d}', **assignments[int(source)])
                   for position, source in enumerate(order)]
    write_bundle(repo / ROOT / 'position-diagnostic-inputs', {
        'assignments.json': assignments, 'bindings.json': bindings, 'references.json': references,
        'protocol.json': dict(status='FROZEN_GRAPH_GUIDED_POSITION_DIAGNOSTIC',
                              formal_protocol='SPECIFIED_DRAFT',
                              scientific_scope='prospective_new_outputs_after_prior_development_results_exploratory',
                              task_selection='All seven prepared TSG tasks in the fixed development panel; no effect-based selection.',
                              code_requests=28, task_units=7, edit_operation='MOVE_REQUIREMENT_POSITION',
                              primary_comparison='P before source versus N after source; exact same words and original source bytes.',
                              baseline_policy='Earlier matching-seed R outputs are secondary exposed-reference diagnostics only.',
                              model=MODEL, system_prompt=SYSTEM, docker_image='phase-graph-guided:20260928',
                              code_envelope='raw_or_single_python_fence',
                              randomization_seed=20260934,
                              inference='One exploratory task-level contrast; 2000 task bootstraps seed20260935, two-sided95percent interval.',
                              independent_quality_review='pending; no human-low-expectation or TSG advantage claim',
                              development_request_budget='364 main plus21 context plus28 position equals413, within416 scaled-panel requests.',
                              non_target_policy='Original source prompt, interface and shared realization remain byte-for-byte present in both arms.')})
    print(json.dumps(dict(frozen_position_requests=28, task_units=7)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['discovery-start', 'discovery-inventory', 'discovery-qualify',
                                           'discovery-verify-qualification', 'discovery-preparation-inputs',
                                           'discovery-service-inputs',
                                           'discovery-validate-source-contracts',
                                           'discovery-agent-accounting',
                                           'discovery-record-cli-preparation',
                                           'discovery-binding-review-inputs',
                                           'discovery-bind-reviewed',
                                           'discovery-freeze-task-frame',
                                           'discovery-freeze-development',
                                           'discovery-freeze-targeted-generation',
                                           'discovery-analyze-development', 'discovery-freeze-evaluation',
                                           'register', 'inspect', 'canary', 'prepare', 'qualify',
                                           'representation-review', 'audit-representation-records',
                                           'freeze-blinded-review-material', 'scaled-panel',
                                           'freeze-development-execution', 'nominate',
                                           'freeze-real-context', 'heldout-tranche',
                                           'freeze-heldout-execution', 'freeze-position-diagnostic',
                                           'heldout-tranche-remaining', 'freeze-heldout-execution-remaining',
                                           'heldout-tranche-performance', 'freeze-heldout-execution-performance',
                                           'heldout-tranche-stream', 'freeze-heldout-execution-stream',
                                           'heldout-tranche-download', 'freeze-heldout-execution-download',
                                           'freeze-stream-infinite-probe', 'repair-opportunities', 'freeze-repair-edits', 'freeze-repair-cases', 'audit-repair-representation', 'freeze-repair-review-material'])
    parser.add_argument('--repo', type=Path, default=Path('.'))
    parser.add_argument('--role', default='development')
    parser.add_argument('--representation', default='TSG')
    parser.add_argument('--start', type=int, default=0)
    parser.add_argument('--count', type=int, default=10)
    parser.add_argument('--index', type=int)
    parser.add_argument('--family')
    parser.add_argument('--output-suffix', default='')
    parser.add_argument('--indices', type=int, nargs='*')
    parser.add_argument('--session-root', type=Path)
    parser.add_argument('--parent-thread')
    parser.add_argument('--accounting-path', type=Path)
    parser.add_argument('--inputs', type=Path)
    parser.add_argument('--results', type=Path)
    args = parser.parse_args()
    if args.action == 'discovery-start':
        start_discovery(args.repo)
    elif args.action == 'discovery-inventory':
        discovery_inventory(args.repo)
    elif args.action == 'discovery-qualify':
        assert args.family is not None
        discovery_qualification(args.repo, args.family, args.output_suffix)
    elif args.action == 'discovery-verify-qualification':
        assert args.family is not None
        discovery_verify_qualification(args.repo, args.family, args.output_suffix)
    elif args.action == 'discovery-validate-source-contracts':
        contracts = discovery_source_contracts(args.repo)
        print(json.dumps(dict(status='SOURCE_EXECUTION_CONTRACTS_VALIDATED_NOT_F0',
                              tasks=len(contracts),
                              roles=dict(Counter(card['source']['role'] for card in contracts.values())))))
    elif args.action == 'discovery-freeze-task-frame':
        discovery_freeze_task_frame(args.repo)
    elif args.action == 'discovery-freeze-development':
        discovery_freeze_development(args.repo)
    elif args.action == 'discovery-freeze-targeted-generation':
        discovery_freeze_targeted_generation(args.repo)
    elif args.action == 'discovery-analyze-development':
        assert args.inputs is not None and args.results is not None
        discovery_analyze_development(args.repo, args.inputs, args.results)
    elif args.action == 'discovery-freeze-evaluation':
        discovery_freeze_evaluation(args.repo)
    elif args.action == 'discovery-preparation-inputs':
        assert args.indices
        discovery_preparation_inputs(args.repo, args.indices, args.role)
    elif args.action == 'discovery-service-inputs':
        discovery_service_inputs(args.repo)
    elif args.action == 'discovery-agent-accounting':
        assert args.session_root is not None and args.parent_thread
        discovery_agent_accounting(args.repo, args.session_root, args.parent_thread)
    elif args.action == 'discovery-record-cli-preparation':
        assert args.index is not None and args.accounting_path is not None
        discovery_record_cli_preparation(args.repo, args.index, args.accounting_path)
    elif args.action == 'discovery-binding-review-inputs':
        assert args.index is not None
        discovery_binding_review_inputs(args.repo, args.index)
    elif args.action == 'discovery-bind-reviewed':
        assert args.index is not None
        discovery_bind_reviewed(args.repo, args.index)
    elif args.action == 'register':
        register(args.repo)
    elif args.action == 'repair-opportunities':
        repair_opportunities(args.repo)
    elif args.action == 'audit-repair-representation':
        audit_representation_records(args.repo,repair=True)
    elif args.action == 'freeze-repair-review-material':
        freeze_blinded_review_material(args.repo,repair=True)
    elif args.action == 'freeze-repair-edits':
        freeze_repair_edits(args.repo)
    elif args.action == 'freeze-repair-cases':
        freeze_repair_cases(args.repo)
    elif args.action == 'canary':
        freeze_canary(args.repo)
    elif args.action == 'prepare':
        assert args.index is not None
        prepare_case(args.repo, args.index, args.output_suffix)
    elif args.action == 'qualify':
        assert args.family is not None
        qualification(args.repo, args.family, args.output_suffix)
    elif args.action == 'representation-review':
        freeze_representation_review(args.repo)
    elif args.action == 'audit-representation-records':
        audit_representation_records(args.repo)
    elif args.action == 'freeze-blinded-review-material':
        freeze_blinded_review_material(args.repo)
    elif args.action == 'scaled-panel':
        freeze_scaled_panel(args.repo)
    elif args.action == 'freeze-development-execution':
        freeze_development_execution(args.repo, args.indices)
    elif args.action == 'nominate':
        nominate_development_categories(args.repo)
    elif args.action == 'freeze-real-context':
        freeze_real_context_exploration(args.repo)
    elif args.action == 'heldout-tranche':
        freeze_heldout_tranche(args.repo)
    elif args.action == 'heldout-tranche-remaining':
        freeze_heldout_tranche(args.repo, remaining=True)
    elif args.action == 'heldout-tranche-performance':
        freeze_heldout_tranche(args.repo, remaining=True, performance=True)
    elif args.action == 'heldout-tranche-stream':
        freeze_heldout_tranche(args.repo, stream=True)
    elif args.action == 'heldout-tranche-download':
        freeze_heldout_tranche(args.repo, download=True)
    elif args.action == 'freeze-heldout-execution':
        freeze_heldout_execution(args.repo)
    elif args.action == 'freeze-heldout-execution-remaining':
        freeze_heldout_execution(args.repo, remaining=True)
    elif args.action == 'freeze-heldout-execution-performance':
        freeze_heldout_execution(args.repo, remaining=True, performance=True)
    elif args.action == 'freeze-heldout-execution-stream':
        freeze_heldout_execution(args.repo, stream=True)
    elif args.action == 'freeze-heldout-execution-download':
        freeze_heldout_execution(args.repo, download=True)
    elif args.action == 'freeze-stream-infinite-probe':
        freeze_stream_infinite_probe(args.repo)
    elif args.action == 'freeze-position-diagnostic':
        freeze_position_diagnostic(args.repo)
    else:
        inspect(args.repo, args.role, args.representation, args.start, args.count)
