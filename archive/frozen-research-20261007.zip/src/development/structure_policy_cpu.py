from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import os
import platform
import subprocess
import time
from collections import Counter
from fractions import Fraction
from importlib.metadata import version
from importlib.resources import files
from pathlib import Path

import jpype
import numpy as np
from scipy.stats import hypergeom

from prompt_mechanism_study.artifact_io import file_sha256, read_json, verify_bundle, write_bundle


ROOT = Path('data/method/graph-guided-20260930/cpu')
OUTPUT = Path('results/graph-guided-20260930/cpu')
RWORKER = Path(__file__).with_suffix('.R')
RSCRIPT = Path('D:/R/R-4.3.1/bin/x64/Rscript.exe')
LABELS = ['C', *[f'M{i}' for i in range(1, 7)], 'Y']
ALPHA = .05
LAMBDAS = (.1, 1., 10., 100.)


def random_stream(*parts):
    payload = json.dumps([20260930, *parts], separators=(',', ':')).encode()
    seed = int.from_bytes(hashlib.sha256(payload).digest()[:16], 'big')
    return np.random.Generator(np.random.PCG64(seed))


def make_matrix(mechanism, n, repetition):
    rng = random_stream(mechanism, n, repetition, 'rows')
    c = rng.binomial(1, .5, n)
    m = rng.binomial(1, .5, (n, 6))
    if mechanism == 1:
        p = .4 + .1*m[:, 1] + c*(.5*m[:, 0] - .2)
    elif mechanism == 2:
        p = .2 + .3*m[:, 0] + .1*m[:, 1] + .15*c
    elif mechanism == 3:
        u = rng.binomial(1, .5, n)
        e = rng.binomial(1, .2, n)
        m[:, 0] = u ^ e
        p = .4 + .1*m[:, 1] + c*(.5*u - .2)
    else:
        raise ValueError(mechanism)
    assert np.all((p >= 0) & (p <= 1))
    y = (rng.random(n) < p).astype(int)
    permutation = random_stream(mechanism, n, repetition, 'folds').permutation(n)
    folds = np.empty(n, dtype=int)
    folds[permutation] = np.arange(n) % 5
    return dict(identity=f'm{mechanism}-n{n}-r{repetition:02}', mechanism=mechanism,
                n=n, repetition=repetition, rows=np.column_stack((c, m, y)).tolist(),
                labels=LABELS, folds=folds.tolist())


def conditional_mean(mechanism, c, m):
    if mechanism == 1:
        return Fraction(2, 5) + Fraction(m[1], 10) + c*(Fraction(m[0], 2)-Fraction(1, 5))
    if mechanism == 2:
        return Fraction(1, 5) + Fraction(3*m[0], 10) + Fraction(m[1], 10) + Fraction(3*c, 20)
    if mechanism == 3:
        return Fraction(2, 5) + Fraction(m[1], 10) + c*(Fraction(3*m[0], 10)-Fraction(1, 10))
    raise ValueError(mechanism)


def population_joint(mechanism):
    joint = []
    for state in itertools.product((0, 1), repeat=8):
        c, *m, y = state
        p = conditional_mean(mechanism, c, m)
        joint.append((state, (p if y else 1-p)/128))
    assert sum(p for _, p in joint) == 1
    return joint


class StatisticalUndetermined(Exception):
    pass


class CommonCI:
    def __init__(self, matrix=None, mechanism=None):
        self.matrix = matrix
        self.identity = matrix['identity'] if matrix else f'population-m{mechanism}'
        self.rows = np.asarray(matrix['rows']) if matrix else None
        self.joint = population_joint(mechanism) if matrix is None else None
        if self.rows is not None and (self.rows.ndim != 2 or self.rows.shape[1] != 8
                                     or not np.isin(self.rows, [0, 1]).all()):
            raise ValueError('binary matrix with C,M1,...,M6,Y required')
        if self.rows is not None:
            self.rows = self.rows.astype(int)
        self.cache = {}
        self.queries = []

    def query(self, x, y, conditioned):
        x, y = sorted((x, y))
        conditioned = sorted(conditioned)
        if x == y or len(set(conditioned)) != len(conditioned) or {x, y} & set(conditioned):
            raise ValueError('invalid CI variables')
        indices = [LABELS.index(v) for v in (x, y, *conditioned)]
        key = '|'.join((x, y, *conditioned))
        self.queries.append(key)
        if key not in self.cache:
            self.cache[key] = self._population(indices) if self.joint is not None else self._sample(indices, key)
            self.cache[key].update(key=key, x=x, y=y, conditioned=conditioned)
        return self.cache[key]

    def _population(self, indices):
        tables = {}
        for state, mass in self.joint:
            key = tuple(state[i] for i in indices[2:])
            table = tables.setdefault(key, [Fraction(0) for _ in range(4)])
            table[2*state[indices[0]] + state[indices[1]]] += mass
        independent = all(a*d == b*c for a, b, c, d in tables.values())
        return dict(status='determined', p_value=1. if independent else 0.,
                    mode='rational_population', independent=independent)

    def _sample(self, indices, key):
        rows = self.rows
        groups = np.zeros(len(rows), dtype=int)
        for index in indices[2:]:
            groups = 2*groups + rows[:, index]
        distributions = []
        observed = 0.
        minimum_p = 1.
        feasible = 1
        for group in np.unique(groups):
            values = rows[groups == group]
            cells = np.bincount(2*values[:, indices[0]]+values[:, indices[1]], minlength=4).reshape(2, 2)
            n, nx, ny, a = int(cells.sum()), int(cells[1].sum()), int(cells[:, 1].sum()), int(cells[1, 1])
            support = np.arange(max(0, nx+ny-n), min(nx, ny)+1)
            probabilities = hypergeom.pmf(support, n, ny, nx)
            expectation = nx*ny/n
            denominator = nx*ny*(n-nx)*(n-ny)/n**3
            statistics = (support-expectation)**2/denominator if denominator else np.zeros(len(support))
            observed += (a-expectation)**2/denominator if denominator else 0.
            maximum = statistics.max()
            minimum_p *= float(probabilities[np.isclose(statistics, maximum, rtol=0, atol=1e-12)].sum())
            feasible *= len(support)
            distributions.append((statistics, probabilities, n, nx, ny, expectation, denominator))
        result = dict(statistic=observed, minimum_attainable_p=minimum_p,
                      feasible_tables=feasible, strata=len(distributions))
        if minimum_p > ALPHA:
            return dict(result, status='statistically_undetermined', p_value=None, mode='attainability')
        if feasible <= 100000:
            statistics, probabilities = np.array([0.]), np.array([1.])
            for stats, probs, *_ in distributions:
                statistics = (statistics[:, None]+stats).ravel()
                probabilities = (probabilities[:, None]*probs).ravel()
            assert abs(float(probabilities.sum())-1) < 1e-10
            p = float(probabilities[statistics >= observed-1e-12].sum())
            mode = 'exact'
        else:
            rng = random_stream(self.identity, key, 'conditional_monte_carlo')
            simulated = np.zeros(9999)
            for _, _, n, nx, ny, expectation, denominator in distributions:
                if denominator:
                    draws = rng.hypergeometric(ny, n-ny, nx, 9999)
                    simulated += (draws-expectation)**2/denominator
            p = (1+int(np.count_nonzero(simulated >= observed-1e-12)))/10000
            mode = 'conditional_monte_carlo'
        if not math.isfinite(p) or p < -1e-12 or p > 1+1e-12:
            raise ValueError('invalid CI probability')
        return dict(result, status='determined', p_value=min(1., max(0., p)), mode=mode)


def start_java():
    if not jpype.isJVMStarted():
        jpype.startJVM(jpype.getDefaultJVMPath(), '-ea', '--enable-native-access=ALL-UNNAMED',
                       classpath=[str(files('pytetrad').joinpath('resources', 'tetrad-current.jar'))])


def java_data(rows, labels):
    start_java()
    variables = jpype.JClass('java.util.ArrayList')()
    for label in labels:
        variables.add(jpype.JClass('edu.cmu.tetrad.data.DiscreteVariable')(label, 2))
    box = jpype.JClass('edu.cmu.tetrad.data.IntDataBox')(len(rows), len(labels))
    for i, row in enumerate(rows):
        for j, value in enumerate(row):
            box.set(i, j, jpype.JClass('java.lang.Integer')(int(value)))
    return jpype.JClass('edu.cmu.tetrad.data.BoxDataSet')(box, variables)


class JavaCI:
    def __init__(self, ci, data):
        self.ci, self.data = ci, data

    def checkIndependence(self, x, y, conditioned):
        result = self.ci.query(str(x.getName()), str(y.getName()), [str(v.getName()) for v in conditioned])
        if result['status'] == 'statistically_undetermined':
            raise StatisticalUndetermined(result['key'])
        fact = jpype.JClass('edu.cmu.tetrad.graph.IndependenceFact')(x, y, conditioned)
        p = result['p_value']
        return jpype.JClass('edu.cmu.tetrad.search.test.IndependenceResult')(fact, p > ALPHA, p, ALPHA-p)

    def getVariables(self):
        return self.data.getVariables()

    def getData(self):
        return self.data

    def getSampleSize(self):
        return self.data.getNumRows()

    def getAlpha(self):
        return ALPHA

    def isPValueAProbability(self):
        return True

    def setVerbose(self, verbose):
        if verbose:
            raise ValueError('verbose CI disabled')

    def isVerbose(self):
        return False

    def toString(self):
        return 'Shared conditional Pearson exact/Monte Carlo CI'


def validate_edges(edges, d):
    for a, left, right, b in edges:
        if 'C' in (a, b) and any(v.startswith('M') for v in (a, b)):
            raise ValueError('C-M adjacency violates background')
        if 'Y' in (a, b):
            if (left if a == 'Y' else right) != 'ARROW':
                raise ValueError('Y endpoint violates time order')
            if 'C' in (a, b) and (left if a == 'C' else right) != 'TAIL':
                raise ValueError('C endpoint violates JCI12')
    return sorted(int(v[1:]) for edge in edges if 'Y' in (edge[0], edge[3])
                  for v in (edge[0], edge[3]) if v.startswith('M'))


def gfci_search(ci, d):
    labels = ['C', *[f'M{i}' for i in range(1, d+1)], 'Y']
    data = java_data(ci.rows[:, [*range(d+1), 7]], labels)
    proxy = jpype.JProxy('edu.cmu.tetrad.search.test.IndependenceTest', inst=JavaCI(ci, data))
    parameters = jpype.JClass('edu.cmu.tetrad.util.Parameters')()
    params = jpype.JClass('edu.cmu.tetrad.util.Params')
    parameters.set(params.PRIOR_EQUIVALENT_SAMPLE_SIZE, 10.)
    parameters.set(params.STRUCTURE_PRIOR, 0.)
    score = jpype.JClass('edu.cmu.tetrad.algcomparison.score.BdeuScore')().getScore(data, parameters)
    knowledge = jpype.JClass('edu.cmu.tetrad.data.Knowledge')()
    for m in labels[1:-1]:
        knowledge.setForbidden('C', m)
        knowledge.setForbidden(m, 'C')
        knowledge.setForbidden('Y', m)
    knowledge.setForbidden('Y', 'C')
    search = jpype.JClass('edu.cmu.tetrad.search.Gfci')(proxy, score)
    search.setKnowledge(knowledge)
    search.setDepth(-1)
    search.setMaxDegree(d+1)
    search.setFaithfulnessAssumed(False)
    search.setMaxDiscriminatingPathLength(-1)
    search.setMaxPossibleDsepPathLength(-1)
    search.setUsePossibleDsep(True)
    search.setCompleteRuleSetUsed(True)
    search.setExcludeSelectionBias(True)
    search.setParallelized(False)
    search.setNumThreads(1)
    search.setVerbose(False)
    try:
        graph = search.search()
        c, y = graph.getNode('C'), graph.getNode('Y')
        if graph.isAdjacentTo(c, y):
            # 随机C的背景仅定向已经存在的C-Y邻接。
            knowledge.setRequired('C', 'Y')
            strategy = jpype.JClass('edu.cmu.tetrad.search.utils.R0R4StrategyTestBased').defaultConfiguration(proxy, knowledge)
            orient = jpype.JClass('edu.cmu.tetrad.search.utils.FciOrient')(strategy)
            orient.setKnowledge(knowledge)
            orient.setCompleteRuleSetUsed(True)
            orient.setMaxDiscriminatingPathLength(-1)
            orient.setParallel(False)
            orient.fciOrientbk(knowledge, graph, graph.getNodes(), False)
            orient.finalOrientation(graph)
    except StatisticalUndetermined as condition:
        return dict(status='statistically_undetermined', edges=None,
                    selected=list(range(1, d+1)), undetermined_query=str(condition))
    edges = sorted([[str(e.getNode1().getName()), str(e.getEndpoint1()),
                     str(e.getEndpoint2()), str(e.getNode2().getName())] for e in graph.getEdges()])
    return dict(status='determined', edges=edges, selected=validate_edges(edges, d))


class RWorker:
    def __init__(self, stderr):
        self.process = subprocess.Popen([str(RSCRIPT), str(RWORKER)], stdin=subprocess.PIPE,
                                        stdout=subprocess.PIPE, stderr=stderr, text=True,
                                        encoding='utf-8', bufsize=1)

    def search(self, ci, d):
        process = self.process
        process.stdin.write(json.dumps(dict(identity=ci.identity, d=d))+'\n')
        process.stdin.flush()
        while True:
            line = process.stdout.readline()
            if not line:
                raise RuntimeError('R worker ended; inspect r-stderr.log')
            message = json.loads(line)
            if message['type'] == 'query':
                result = ci.query(message['x'], message['y'], message['conditioned'])
                process.stdin.write(json.dumps(result)+'\n')
                process.stdin.flush()
            else:
                assert message['type'] == 'result' and message['identity'] == ci.identity
                message.pop('type')
                if message['status'] == 'determined':
                    message['selected'] = validate_edges(message['edges'], d)
                else:
                    assert message['status'] == 'statistically_undetermined'
                    message['selected'] = list(range(1, d+1))
                return message

    def close(self):
        self.process.stdin.close()
        code = self.process.wait(timeout=30)
        if code:
            raise RuntimeError(f'R exited {code}')


def design(rows, selected):
    t = 2*rows[:, 0]-1
    z = 2*rows[:, 1:-1]-1
    return np.column_stack((np.ones(len(rows)), t, z, *[t*z[:, j-1] for j in selected]))


def ridge(rows, selected, penalty):
    if len(np.unique(rows[:, 0])) != 2:
        return None
    x = design(rows, selected)
    regularizer = np.eye(x.shape[1])*penalty
    regularizer[0, 0] = 0
    return np.linalg.solve(x.T@x+regularizer, x.T@rows[:, -1])


def effect(beta, m, selected):
    if beta is None:
        return np.zeros(len(m))
    d = m.shape[1]
    return np.full(len(m), 2*beta[1]) + sum(2*beta[d+2+k]*(2*m[:, j-1]-1) for k, j in enumerate(selected))


def select_penalty(rows, folds):
    selected = list(range(1, rows.shape[1]-1))
    losses = {}
    missing_arm_folds = set()
    for penalty in LAMBDAS:
        predictions = np.zeros(len(rows))
        for fold in range(5):
            valid = folds == fold
            beta = ridge(rows[~valid], selected, penalty)
            if beta is None:
                missing_arm_folds.add(fold)
            predictions[valid] = effect(beta, rows[valid, 1:-1], selected)
        loss = float(np.mean((2*(2*rows[:, 0]-1)*rows[:, -1]-predictions)**2))
        losses[penalty] = loss
    chosen = min(LAMBDAS, key=lambda value: (losses[value], -value))
    diagnostics = dict(status='determined', losses=losses)
    if missing_arm_folds:
        diagnostics['missing_arm_cv_folds'] = sorted(missing_arm_folds)
    return chosen, diagnostics


def evaluate_policy(rows, mechanism, selected, penalty):
    d = rows.shape[1]-2
    beta = ridge(rows, selected, penalty) if penalty is not None else None
    states = np.array(list(itertools.product((0, 1), repeat=d)))
    tau = effect(beta, states, selected)
    actions = (tau > 1e-12).astype(int)
    values = [conditional_mean(mechanism, int(c), list(map(int, m))) for c, m in zip(actions, states, strict=True)]
    optimal = [max(conditional_mean(mechanism, c, list(map(int, m))) for c in (0, 1)) for m in states]
    value, optimum = float(sum(values)/len(values)), float(sum(optimal)/len(optimal))
    return dict(selected=list(selected), value=value, regret=optimum-value, optimal_value=optimum,
                actions=actions.tolist(), tau=np.asarray(tau).tolist(),
                tie_states=int(np.count_nonzero(np.abs(tau) <= 1e-12)),
                status='missing_arm_abstention' if beta is None else 'fitted')


def consumers(matrix, d, structures):
    rows = np.asarray(matrix['rows'], dtype=int)[:, [*range(d+1), 7]]
    penalty, cv = select_penalty(rows, np.asarray(matrix['folds']))
    selected_sets = {'full': list(range(1, d+1)), 'empty': []}
    selected_sets.update({name: result['selected'] for name, result in structures.items()})
    fitted = {}
    def fit(selected):
        key = tuple(selected)
        if key not in fitted:
            fitted[key] = evaluate_policy(rows, matrix['mechanism'], selected, penalty)
        return fitted[key]
    policies = {name: fit(selected) for name, selected in selected_sets.items()}
    for k in sorted({len(result['selected']) for result in structures.values()}):
        subsets = [fit(selected) for selected in itertools.combinations(range(1, d+1), k)]
        policies[f'uniform_k{k}'] = dict(k=k, subsets=subsets,
            value=float(np.mean([p['value'] for p in subsets])), regret=float(np.mean([p['regret'] for p in subsets])))
    return dict(identity=matrix['identity'], mechanism=matrix['mechanism'], n=matrix['n'],
                repetition=matrix['repetition'], d=d, penalty=penalty, cv=cv, policies=policies)


def freeze():
    verify_bundle(Path('data/method/graph-guided-20260930/launch'))
    matrices = [make_matrix(m, n, r) for m in (1, 2, 3) for n in (512, 32, 128) for r in range(14)]
    jar = Path(str(files('pytetrad').joinpath('resources', 'tetrad-current.jar')))
    protocol = dict(status='FROZEN_SYNTHETIC_DEVELOPMENT', master_seed=20260930,
        mechanisms=['.4+.1*M2+C*(.5*M1-.2)', '.2+.3*M1+.1*M2+.15*C', '.4+.1*M2+C*(.5*U-.2)'],
        sizes=[32, 128, 512], repetitions=14, dimensions=[3, 6], searches=510, maximum_seconds=7200,
        execution_order='mechanism 1,2,3; N 512,32,128; repetition 0..13; d 3,6; FCI then GFCI',
        methods=['FCI_JCI12', 'GFCI_JCI12'], alpha=ALPHA, exact_maximum_tables=100000,
        conditional_draws=9999, minimum_attainable_p_rule='> .05 gives null and stops search; consumer uses full',
        lambda_candidates=LAMBDAS, folds=5, tie_penalty='larger', action_tolerance=1e-12,
        missing_arm_rule='abstain; choose C=0 for every M; preserve result and denominator',
        seed_derivation='SHA256 compact JSON [20260930,*parts], first 16 bytes big-endian, PCG64',
        paired_error='sample SD of 14 paired value differences / sqrt(14), descriptive mean +/- 1.96 MCSE',
        common_ci='identical matrix/name/query cache across dimensions and backends',
        background='C-M absent; Y cannot cause M or C; no C confounding; M-Y confounding allowed; M-M unconstrained',
        gfci=dict(score='BDeu', ESS=10, structure_prior=0, max_degree='d+1', faithfulness_assumed=False,
                  depth=-1, discriminating_path=-1, possible_dsep_path=-1, possible_dsep=True,
                  complete_rules=True, exclude_selection_bias=True, threads=1),
        fci=dict(backend='pcalg', skeleton='stable', depth='unlimited', possible_dsep=True,
                 complete_no_selection_rules=True, jci1_context='C and every M', jci12_context='C',
                 background_closure='iterate JCI1(C,M) and JCI12(C), no new edges'),
        python=platform.python_version(), platform=platform.platform(), java_home=os.environ.get('JAVA_HOME'),
        packages={p: version(p) for p in ('numpy', 'scipy', 'JPype1', 'py-tetrad')},
        implementation_sha256=file_sha256(Path(__file__)), r_sha256=file_sha256(RWORKER),
        jar_sha256=file_sha256(jar), launch_manifest_sha256=file_sha256(Path('data/method/graph-guided-20260930/launch/manifest.json')))
    write_bundle(ROOT, {'protocol.json': protocol, 'matrices.json': matrices})
    print(json.dumps(dict(frozen_matrices=len(matrices), searches=510, path=str(ROOT))), flush=True)


def append_json(sink, value):
    sink.write(json.dumps(value, ensure_ascii=False, allow_nan=False)+'\n')
    sink.flush()


def read_lines(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()] if path.exists() else []


def run(limit=None):
    verify_bundle(ROOT)
    protocol = read_json(ROOT/'protocol.json')
    assert file_sha256(Path(__file__)) == protocol['implementation_sha256']
    assert file_sha256(RWORKER) == protocol['r_sha256']
    OUTPUT.mkdir(parents=True, exist_ok=True)
    if (OUTPUT/'summary').exists():
        raise FileExistsError('completed CPU results already exist')
    old_searches = read_lines(OUTPUT/'searches.jsonl')
    old_policies = read_lines(OUTPUT/'policies.jsonl')
    completed = {(r['identity'], r['d'], r['method']) for r in old_searches}
    prior_seconds = read_json(OUTPUT/'checkpoint.json')['seconds'] if (OUTPUT/'checkpoint.json').exists() else 0.
    start = time.monotonic()
    with (OUTPUT/'r-stderr.log').open('a', encoding='utf-8') as stderr, \
         (OUTPUT/'searches.jsonl').open('a', encoding='utf-8') as searches, \
         (OUTPUT/'policies.jsonl').open('a', encoding='utf-8') as policies, \
         (OUTPUT/'ci.jsonl').open('a', encoding='utf-8') as ci_sink:
        worker = RWorker(stderr)
        for mechanism in (1, 2, 3):
            ci = CommonCI(mechanism=mechanism)
            for d in (3, 6):
                key = (ci.identity, d, 'FCI_JCI12')
                if key in completed:
                    continue
                t0 = time.monotonic()
                result = worker.search(ci, d)
                result.update(identity=ci.identity, mechanism=mechanism, d=d, method='FCI_JCI12',
                              population=True, seconds=time.monotonic()-t0, queries=list(ci.queries))
                append_json(searches, result)
                old_searches.append(result)
                completed.add(key)
                ci.queries.clear()
            if ci.cache:
                append_json(ci_sink, dict(identity=ci.identity, tests=list(ci.cache.values())))
        matrices = read_json(ROOT/'matrices.json')
        processed = 0
        for matrix in matrices:
            identity = matrix['identity']
            if all((identity, d, method) in completed for d in (3, 6) for method in protocol['methods']):
                continue
            if prior_seconds+time.monotonic()-start >= 7200:
                break
            ci = CommonCI(matrix)
            for d in (3, 6):
                structures = {}
                for method in protocol['methods']:
                    key = (identity, d, method)
                    if key in completed:
                        raise RuntimeError('partial matrix requires explicit audit before resuming')
                    t0 = time.monotonic()
                    result = worker.search(ci, d) if method == 'FCI_JCI12' else gfci_search(ci, d)
                    result.update(identity=identity, mechanism=matrix['mechanism'], n=matrix['n'],
                                  repetition=matrix['repetition'], d=d, method=method, population=False,
                                  seconds=time.monotonic()-t0, queries=list(ci.queries))
                    append_json(searches, result)
                    old_searches.append(result)
                    completed.add(key)
                    structures[method] = result
                    ci.queries.clear()
                population = next(r for r in old_searches if r['identity'] == f'population-m{matrix["mechanism"]}' and r['d'] == d)
                structures['population_FCI'] = population
                result = consumers(matrix, d, structures)
                append_json(policies, result)
                old_policies.append(result)
            append_json(ci_sink, dict(identity=identity, tests=list(ci.cache.values())))
            processed += 1
            print(json.dumps(dict(completed_searches=len(completed), matrix=identity,
                                  seconds=prior_seconds+time.monotonic()-start)), flush=True)
            if limit is not None and processed >= limit:
                break
        worker.close()
    seconds = prior_seconds+time.monotonic()-start
    checkpoint = dict(searches=len(completed), seconds=seconds,
                      status='EXECUTED_DEVELOPMENT' if len(completed) == 510 else 'PARTIAL_DEVELOPMENT')
    (OUTPUT/'checkpoint.json').write_text(json.dumps(checkpoint)+'\n', encoding='utf-8')
    if len(completed) == 510 or seconds >= 7200:
        summary = summarize(old_searches, old_policies)
        write_bundle(OUTPUT/'summary', {'completion.json': dict(checkpoint,
            input_manifest_sha256=file_sha256(ROOT/'manifest.json'),
            output_sha256={name: file_sha256(OUTPUT/name) for name in
                           ('checkpoint.json', 'searches.jsonl', 'policies.jsonl', 'ci.jsonl', 'r-stderr.log')}),
            'comparisons.json': summary})
    print(json.dumps(checkpoint), flush=True)


def summarize(searches, policies):
    groups = []
    for m in (1, 2, 3):
        for n in (32, 128, 512):
            for d in (3, 6):
                records = [r for r in policies if (r['mechanism'], r['n'], r['d']) == (m, n, d)]
                if not records:
                    continue
                comparisons = []
                pairs = [(name, baseline) for name in ('FCI_JCI12', 'GFCI_JCI12', 'population_FCI')
                         for baseline in ('full', 'empty', 'uniform')]
                pairs.append(('GFCI_JCI12', 'FCI_JCI12'))
                for method, baseline in pairs:
                    differences = []
                    for record in records:
                        p = record['policies']
                        comparator = f'uniform_k{len(p[method]["selected"])}' if baseline == 'uniform' else baseline
                        differences.append(p[method]['value']-p[comparator]['value'])
                    mean = float(np.mean(differences))
                    error = float(np.std(differences, ddof=1)/np.sqrt(len(differences))) if len(differences)>1 else None
                    comparisons.append(dict(method=method, baseline=baseline, value_difference=mean, paired_mcse=error,
                        descriptive_95=[mean-1.96*error, mean+1.96*error] if error is not None else None,
                        paired_differences=differences))
                status = {method: dict(Counter(r['status'] for r in searches if not r['population']
                          and (r['mechanism'], r['n'], r['d'], r['method']) == (m, n, d, method)))
                          for method in ('FCI_JCI12', 'GFCI_JCI12')}
                mean_values = {method: float(np.mean([r['policies'][method]['value'] for r in records]))
                               for method in ('full', 'empty', 'FCI_JCI12', 'GFCI_JCI12', 'population_FCI')}
                retention = {}
                for method in ('FCI_JCI12', 'GFCI_JCI12'):
                    selected = [r for r in searches if not r['population'] and
                                (r['mechanism'], r['n'], r['d'], r['method']) == (m, n, d, method)]
                    retention[method] = dict(denominator=len(selected),
                        attribute_counts={f'M{j}': sum(j in r['selected'] for r in selected) for j in range(1, d+1)},
                        any_irrelevant_count=sum(any(j >= 3 for j in r['selected']) for r in selected),
                        c_y_adjacency_count=sum(any({e[0], e[3]} == {'C', 'Y'} for e in r['edges'] or []) for r in selected))
                groups.append(dict(mechanism=m, n=n, d=d, independent_matrices=len(records),
                                   statuses=status, mean_values=mean_values, comparisons=comparisons,
                                   retention=retention))
    return dict(groups=groups, population=[r for r in searches if r['population']],
                inference='paired Monte Carlo descriptive uncertainty; 14 independent matrices per mechanism/N')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['freeze', 'run'])
    parser.add_argument('--limit', type=int)
    args = parser.parse_args()
    if args.action == 'freeze':
        freeze()
    else:
        run(args.limit)
