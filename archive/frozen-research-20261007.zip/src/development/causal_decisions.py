"""Bounded synthetic decision-value diagnostic, never a formal study selector."""

from __future__ import annotations

import csv
import hashlib
import json
import platform
import sys
from importlib.metadata import version
from pathlib import Path

import numpy as np
import pandas as pd

from prompt_mechanism_study.artifact_io import read_json, write_bundle

SCENARIOS = {
    "homogeneous": ([.3, .3], [.2, .2]),
    "null": ([.5, .5], [0., 0.]),
    "harmful": ([.5, .5], [-.2, -.2]),
    "localized": ([.3, .3], [.4, 0.]),
    "reversal": ([.5, .5], [.4, -.4]),
    "near_cancellation": ([.5, .5], [.4, -.3]),
    "prognostic": ([.2, .6], [.2, .2]),
}
SIZES = (64, 256, 1024)
SEEDS = tuple(range(7001, 7051))
LABELS = ["C", "X", "Z", "Y"]


def make_data(name, n, seed):
    rng = np.random.default_rng(seed)
    a, m, z = rng.binomial(1, .5, size=(3, n))
    base, tau = map(np.array, SCENARIOS[name])
    probability = base[m] + tau[m] * a + .1 * (z - .5)
    assert ((probability >= 0) & (probability <= 1)).all()
    return pd.DataFrame(dict(C=a, X=m, Z=z, Y=rng.binomial(1, probability)))


def estimate(frame):
    y1 = frame.loc[frame.C == 1, "Y"]
    y0 = frame.loc[frame.C == 0, "Y"]
    return float(y1.mean() - y0.mean()) if len(y1) and len(y0) else None


def decision(estimates):
    return [int(value is not None and value > 0) for value in estimates]


def score(name, action):
    tau = np.array(SCENARIOS[name][1])
    act = np.array(action)
    gain = float(np.mean(act * tau))
    return dict(gain=gain, regret=float(np.mean(np.maximum(tau, 0)) - gain),
                harmful_mass=float(np.mean(act * (tau < 0))),
                null_mass=float(np.mean(act * (tau == 0))))


def run(out):
    from pytetrad.tools.TetradSearch import TetradSearch
    from importlib.resources import files

    root = Path(__file__).resolve().parents[2]
    rfile = root / "docs/experiments/2026-09-26-decision-jci.R"
    plan = root / "docs/experiments/2026-09-26-decision-value-plan.md"
    jar = files("pytetrad").joinpath("resources", "tetrad-current.jar")
    with jar.open("rb") as stream:
        jar_hash = hashlib.file_digest(stream, "sha256").hexdigest()
    write_bundle(out / "frozen", {
        "design.json": dict(status="SYNTHETIC_DEVELOPMENT_ONLY", scenarios=SCENARIOS,
                            sizes=SIZES, seeds=SEEDS, alpha=.05,
                            ci="G-square", gfci_score="BDeu ESS10 prior0",
                            labels=LABELS, truth_evaluation="exact independent population expectation"),
        "implementation.json": dict(python=Path(__file__).read_text(encoding="utf-8"),
                                    R=rfile.read_text(encoding="utf-8"),
                                    plan=plan.read_text(encoding="utf-8")),
        "environment.json": dict(python=platform.python_version(), numpy=np.__version__,
                                 py_tetrad=version("py-tetrad"), jar_sha256=jar_hash,
                                 platform=platform.platform()),
    })
    matrices = []
    for name in SCENARIOS:
        for n in SIZES:
            for seed in SEEDS:
                matrices.append(make_data(name, n, seed).assign(scenario=name, n_total=n, seed=seed))
    pd.concat(matrices, ignore_index=True).to_csv(out / "input.csv", index=False)
    results = []
    for index, data in enumerate(matrices):
        name, n, seed = data.iloc[0][["scenario", "n_total", "seed"]]
        frame = data[LABELS]
        for method in ("FCI", "GFCI"):
            rec = dict(scenario=str(name), n_total=int(n), seed=int(seed), method=method,
                       error="", warnings=[], edges=[], adjacent=False)
            try:
                search = TetradSearch(frame)
                search.set_verbose(False)
                search.use_bdeu(sample_prior=10, structure_prior=0)
                search.use_g_square(alpha=.05)
                if method == "FCI":
                    search.run_fci(depth=-1, max_disc_path_length=-1)
                else:
                    search.run_gfci(depth=-1, max_degree=-1, max_disc_path_length=-1)
                for edge in search.get_java().getEdges():
                    a, b = str(edge.getNode1().getName()), str(edge.getNode2().getName())
                    rec["edges"].append([a, str(edge.getEndpoint1()), str(edge.getEndpoint2()), b])
                    if {a, b} == {"C", "Y"}:
                        rec["adjacent"] = True
            except Exception as error:
                rec["error"] = f"{type(error).__name__}: {error}"
            results.append(rec)
        if (index + 1) % 150 == 0:
            print(f"searched {index + 1}/{len(matrices)} matrices", flush=True)
    write_bundle(out / "tetrad", {"graphs.json": results,
                                 "input-identity.json": {"sha256": hashlib.sha256((out / "input.csv").read_bytes()).hexdigest()}})
    print(f"saved {len(results)} Tetrad searches", flush=True)


def summarize(out):
    # The scenario name "null" is a literal label, not a missing value.
    data = pd.read_csv(out / "input.csv", keep_default_na=False)
    graphs = read_json(out / "tetrad/graphs.json")
    with (out / "jci.csv").open(encoding="utf-8", newline="") as stream:
        for row in csv.DictReader(stream):
            graphs.append(dict(scenario=row["scenario"], n_total=int(row["n_total"]),
                seed=int(row["seed"]), method=row["method"], error=row["error"],
                warnings=[row["warnings"]] if row["warnings"] else [],
                adjacent=row["adjacent"] == "TRUE", matrix=row["matrix"]))
    graph_index = {(g["scenario"], g["n_total"], g["seed"], g["method"]): g for g in graphs}
    rows = []
    for (name, n, seed), frame in data.groupby(["scenario", "n_total", "seed"], sort=False):
        pooled = estimate(frame)
        leaves = [estimate(frame.loc[frame.X == m]) for m in (0, 1)]
        choices = [("no-edit", [0, 0], None, False),
                   ("pooled-RD", decision([pooled, pooled]), None, False),
                   ("strata-RD", decision(leaves), None, False)]
        for method in ("FCI", "GFCI", "JCI0", "JCI1", "JCI12"):
            graph = graph_index[(name, n, seed, method)]
            unusable = bool(graph["error"] or graph["warnings"])
            admitted = bool(graph["adjacent"] and not unusable)
            choices.append((method + "+strata-RD", decision(leaves) if admitted else [0, 0], admitted, unusable))
        for method, action, admitted, unusable in choices:
            rows.append(dict(scenario=name, n_total=int(n), seed=int(seed), method=method,
                pooled=pooled, leaves=leaves, action=action, admitted=admitted,
                graph_unusable=unusable, unsupported_leaves=sum(v is None for v in leaves),
                **score(name, action)))
    summary = []
    for (name, n, method), frame in pd.DataFrame(rows).groupby(["scenario", "n_total", "method"], sort=False):
        summary.append(dict(scenario=name, n_total=int(n), method=method, repetitions=len(frame),
            gain=float(frame.gain.mean()), gain_mcse=float(frame.gain.std(ddof=1)/np.sqrt(len(frame))),
            regret=float(frame.regret.mean()), harmful_mass=float(frame.harmful_mass.mean()),
            null_mass=float(frame.null_mass.mean()),
            admitted_count=int(frame.admitted.fillna(False).sum()),
            unusable_count=int(frame.graph_unusable.sum())))
    write_bundle(out / "analysis-corrected", {"decisions.json": rows, "summary.json": summary,
        "analysis-implementation.json": {"python": Path(__file__).read_text(encoding="utf-8"),
            "correction": "pandas default NA parser erased literal scenario null from aggregation; raw inputs and all 5250 graphs unchanged; original analysis retained as INVALID_MISSING_NULL_SCENARIO"},
        "accounting.json": dict(matrices=len(data.groupby(["scenario", "n_total", "seed"])),
            searches=len(graphs), errors=sum(bool(g["error"]) for g in graphs),
            warning_graphs=sum(bool(g["warnings"]) for g in graphs),
            unsupported_decisions=sum(r["unsupported_leaves"] > 0 for r in rows))})
    pd.DataFrame(summary).to_csv(out / "analysis-corrected/summary.csv", index=False)
    print(json.dumps(read_json(out / "analysis-corrected/accounting.json")), flush=True)


if __name__ == "__main__":
    mode, output = sys.argv[1:]
    {"run": run, "summarize": summarize}[mode](Path(output))
