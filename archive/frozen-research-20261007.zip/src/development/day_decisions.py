"""Bounded day-study policy rules on randomized synthetic data.

This module is a development diagnostic, not the normative study selector.
Old matrices calibrate rules; a distinct seed range is required for evaluation.
"""

from __future__ import annotations

import csv
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd


CS = (0.0, 0.5, 1.0, 1.64, 1.96)
DELTA = 0.05
GRAPH_METHODS = ("FCI", "GFCI", "JCI12")


def effect(rows):
    """Bernoulli risk difference and its two-arm standard error."""
    by_arm = {a: [y for c, x, z, y in rows if c == a] for a in (0, 1)}
    if min(map(len, by_arm.values())) < 2:
        return None, None
    p = {a: float(np.mean(ys)) for a, ys in by_arm.items()}
    variance = sum(float(np.var(ys, ddof=1)) / len(ys) for ys in by_arm.values())
    return p[1] - p[0], math.sqrt(variance)


def lower_bound_action(rows, c, delta=DELTA):
    estimate, se = effect(rows)
    return int(estimate is not None and estimate - c * se > delta)


def plain_action(rows):
    estimate, _ = effect(rows)
    return int(estimate is not None and estimate > 0)


def tree_action(rows, seed, minimum_arm=8, split_margin=0.02):
    """Depth-one adaptation: split discovery and leaf estimation are disjoint.

    Discovery chooses X or Z by its in-sample positive-value improvement over
    no split. Estimation assigns actions using only the held-out half. This is
    not a claim to reproduce a published honest-tree software implementation.
    """
    rng = np.random.default_rng(seed)
    order = rng.permutation(len(rows))
    middle = len(rows) // 2
    discovery = [rows[i] for i in order[:middle]]
    estimation = [rows[i] for i in order[middle:]]
    pooled = effect(discovery)[0]
    root_value = max(0.0, pooled or 0.0)
    choices = []
    for index, feature in ((1, "X"), (2, "Z")):
        leaves = [[row for row in discovery if row[index] == value] for value in (0, 1)]
        if any(min(sum(row[0] == a for row in leaf) for a in (0, 1)) < minimum_arm for leaf in leaves):
            continue
        split_value = sum(len(leaf) / len(discovery) * max(0.0, effect(leaf)[0] or 0.0)
                          for leaf in leaves)
        choices.append((split_value - root_value, feature, index))
    choices.sort(key=lambda item: (-item[0], item[1]))
    if not choices or choices[0][0] <= split_margin:
        edit = plain_action(estimation)
        return [edit] * 4, "root"
    _, feature, index = choices[0]
    by_value = {value: plain_action([row for row in estimation if row[index] == value])
                for value in (0, 1)}
    return [by_value[x if feature == "X" else z] for x in (0, 1) for z in (0, 1)], feature


def score(base, tau, actions, px=0.5, pz=0.5):
    """Exact population expectation; action order is (X,Z)=(0,0),(0,1),(1,0),(1,1)."""
    mass = [(1-px)*(1-pz), (1-px)*pz, px*(1-pz), px*pz]
    truths = [tau[0], tau[0], tau[1], tau[1]]
    gain = sum(m * a * t for m, a, t in zip(mass, actions, truths))
    optimum = sum(m * max(t, 0) for m, t in zip(mass, truths))
    return dict(gain=gain, regret=optimum-gain,
                harmful_mass=sum(m*a for m, a, t in zip(mass, actions, truths) if t < 0),
                null_mass=sum(m*a for m, a, t in zip(mass, actions, truths) if t == 0),
                edit_mass=sum(m*a for m, a in zip(mass, actions)))


def analyze_old(input_dir: Path, output_dir: Path):
    """Retrospective calibration only; results cannot be held-out evidence."""
    old_design = json.loads((input_dir / "frozen/design.json").read_text(encoding="utf-8"))
    groups = defaultdict(list)
    with (input_dir / "input.csv").open(newline="", encoding="utf-8") as stream:
        for row in csv.DictReader(stream):
            key = (row["scenario"], int(row["n_total"]), int(row["seed"]))
            groups[key].append(tuple(int(row[name]) for name in ("C", "X", "Z", "Y")))
    assert len(groups) == 1050
    graphs = {}
    for graph in json.loads((input_dir / "tetrad/graphs.json").read_text(encoding="utf-8")):
        key = (graph["scenario"], graph["n_total"], graph["seed"], graph["method"])
        graphs[key] = graph["adjacent"] and not graph["error"] and not graph["warnings"]
    with (input_dir / "jci.csv").open(newline="", encoding="utf-8") as stream:
        for graph in csv.DictReader(stream):
            key = (graph["scenario"], int(graph["n_total"]), int(graph["seed"]), graph["method"])
            graphs[key] = graph["adjacent"] == "TRUE" and not graph["error"] and not graph["warnings"]
    rows_out = []
    for key, rows in groups.items():
        name, n, seed = key
        base, tau = old_design["scenarios"][name]
        pooled = plain_action(rows)
        strata = [plain_action([row for row in rows if row[1] == x]) for x in (0, 1)]
        strategies = {"no-edit": [0]*4, "pooled-RD": [pooled]*4,
                      "strata-RD": [strata[0]]*2 + [strata[1]]*2}
        for c in CS:
            p = lower_bound_action(rows, c)
            s = [lower_bound_action([row for row in rows if row[1] == x], c) for x in (0, 1)]
            strategies[f"pooled-LB-{c}"] = [p]*4
            strategies[f"strata-LB-{c}"] = [s[0]]*2 + [s[1]]*2
        for method in GRAPH_METHODS:
            admitted = graphs[key+(method,)]
            strategies[method+"+strata-RD"] = ([strata[0]]*2 + [strata[1]]*2) if admitted else [0]*4
        tree, chosen_feature = tree_action(rows, seed + 9000000)
        strategies["honest-depth1"] = tree
        for method, actions in strategies.items():
            rows_out.append(dict(scenario=name, n_total=n, seed=seed, method=method,
                                 action=actions, tree_feature=chosen_feature if method == "honest-depth1" else None,
                                 **score(base, tau, actions)))
    output_dir.mkdir(parents=True, exist_ok=False)
    (output_dir / "decisions.json").write_text(json.dumps(rows_out, separators=(",", ":")), encoding="utf-8")
    summary = []
    by_group = defaultdict(list)
    for row in rows_out:
        by_group[(row["scenario"], row["n_total"], row["method"])].append(row)
    for key, group in by_group.items():
        summary.append(dict(zip(("scenario", "n_total", "method"), key)) |
                       {field: float(np.mean([r[field] for r in group]))
                        for field in ("gain", "regret", "harmful_mass", "null_mass", "edit_mass")})
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    (output_dir / "identity.json").write_text(json.dumps(dict(status="RETROSPECTIVE_DEVELOPMENT_ONLY",
        source=str(input_dir), matrices=len(groups), graph_results=len(graphs), decisions=len(rows_out),
        c_grid=CS, delta=DELTA, tree_minimum_arm=8, tree_split_margin=0.02), indent=2), encoding="utf-8")
    print(json.dumps(dict(matrices=len(groups), methods=len(strategies), decisions=len(rows_out))))


NEW_SCENARIOS = {
    "homogeneous": dict(base=(.3, .3), tau=(.2, .2), px=.5),
    "null": dict(base=(.5, .5), tau=(0., 0.), px=.5),
    "harmful": dict(base=(.5, .5), tau=(-.2, -.2), px=.5),
    "localized": dict(base=(.3, .3), tau=(.4, 0.), px=.5),
    "near_cancellation": dict(base=(.5, .5), tau=(.4, -.3), px=.5),
    "prognostic": dict(base=(.2, .6), tau=(.2, .2), px=.5),
    # X is a noisy observation of latent M; C remains randomized. The best
    # observable policy is evaluated using E[tau(M)|X], not latent M itself.
    "source_proxy_failure": dict(base=(.5, .5), tau=(.4, -.3), px=.5,
                                 latent_modifier=True, proxy_error=.3,
                                 observed_tau=(.19, -.09)),
    # A genuine but rare source attribute has little within-leaf support.
    "sparse_modifier": dict(base=(.3, .3), tau=(0., .4), px=.1),
}
NEW_SIZES = (64, 256, 1024)
NEW_SEEDS = tuple(range(9001, 9051))
NEW_LABELS = ("C", "X", "Z", "Y")


def make_new_data(name, n, seed):
    spec = NEW_SCENARIOS[name]
    rng = np.random.default_rng(seed)
    c = rng.binomial(1, .5, n)
    z = rng.binomial(1, .5, n)
    if spec.get("latent_modifier"):
        modifier = rng.binomial(1, .5, n)
        x = modifier ^ rng.binomial(1, spec["proxy_error"], n)
    else:
        x = rng.binomial(1, spec["px"], n)
        modifier = x
    base = np.asarray(spec["base"])
    tau = np.asarray(spec["tau"])
    probability = base[modifier] + tau[modifier] * c + .1 * (z - .5)
    assert np.all((probability >= 0) & (probability <= 1))
    y = rng.binomial(1, probability)
    return pd.DataFrame(dict(C=c, X=x, Z=z, Y=y, scenario=name,
                             n_total=n, seed=seed))


def new_input(root: Path):
    frames = [make_new_data(name, n, seed)
              for name in NEW_SCENARIOS for n in NEW_SIZES for seed in NEW_SEEDS]
    assert len(frames) == 1200
    root.mkdir(parents=True, exist_ok=True)
    target = root / "input.csv"
    if target.exists():
        raise FileExistsError(target)
    pd.concat(frames, ignore_index=True).to_csv(target, index=False)
    print(json.dumps(dict(matrices=len(frames), rows=sum(map(len, frames)), input=str(target))))


def new_tetrad(root: Path):
    from pytetrad.tools.TetradSearch import TetradSearch

    data = pd.read_csv(root / "input.csv", keep_default_na=False)
    results = []
    for index, (key, frame) in enumerate(data.groupby(["scenario", "n_total", "seed"], sort=False), 1):
        name, n, seed = key
        matrix = frame[list(NEW_LABELS)]
        for method in ("FCI", "GFCI"):
            item = dict(scenario=name, n_total=int(n), seed=int(seed), method=method,
                        edges=[], adjacent=False, error="", warnings=[])
            try:
                search = TetradSearch(matrix)
                search.set_verbose(False)
                search.use_g_square(alpha=.05)
                search.use_bdeu(sample_prior=10, structure_prior=0)
                if method == "FCI":
                    search.run_fci(depth=-1, max_disc_path_length=-1)
                else:
                    search.run_gfci(depth=-1, max_degree=-1, max_disc_path_length=-1)
                for edge in search.get_java().getEdges():
                    a, b = str(edge.getNode1().getName()), str(edge.getNode2().getName())
                    item["edges"].append([a, str(edge.getEndpoint1()), str(edge.getEndpoint2()), b])
                    if {a, b} == {"C", "Y"}:
                        item["adjacent"] = True
            except Exception as error:
                item["error"] = f"{type(error).__name__}: {error}"
            results.append(item)
        if index % 100 == 0:
            print(f"Tetrad matrices {index}/1200", flush=True)
    target = root / "tetrad-graphs.json"
    if target.exists():
        raise FileExistsError(target)
    target.write_text(json.dumps(results, separators=(",", ":")), encoding="utf-8")
    print(json.dumps(dict(searches=len(results), errors=sum(bool(r["error"]) for r in results))))


def new_summary(root: Path):
    data = pd.read_csv(root / "input.csv", keep_default_na=False)
    graphs = json.loads((root / "tetrad-graphs.json").read_text(encoding="utf-8"))
    with (root / "jci12.csv").open(newline="", encoding="utf-8") as stream:
        graphs.extend(csv.DictReader(stream))
    graph_index = {}
    for graph in graphs:
        key = (graph["scenario"], int(graph["n_total"]), int(graph["seed"]), graph["method"])
        assert key not in graph_index
        graph_index[key] = graph
    assert len(graph_index) == 3600
    results = []
    for key, frame in data.groupby(["scenario", "n_total", "seed"], sort=False):
        name, n, seed = key
        rows = [tuple(map(int, row)) for row in frame[list(NEW_LABELS)].itertuples(index=False, name=None)]
        spec = NEW_SCENARIOS[name]
        truth = spec.get("observed_tau", spec["tau"])
        pooled = plain_action(rows)
        strata = [plain_action([row for row in rows if row[1] == x]) for x in (0, 1)]
        strategies = {"no-edit": [0]*4, "pooled-RD": [pooled]*4,
                      "strata-RD": [strata[0]]*2+[strata[1]]*2}
        for c in CS:
            p = lower_bound_action(rows, c)
            s = [lower_bound_action([row for row in rows if row[1] == x], c) for x in (0, 1)]
            strategies[f"pooled-LB-{c}"] = [p]*4
            strategies[f"strata-LB-{c}"] = [s[0]]*2+[s[1]]*2
        for method in GRAPH_METHODS:
            graph = graph_index[(name, int(n), int(seed), method)]
            adjacent = graph["adjacent"] if isinstance(graph["adjacent"], bool) else graph["adjacent"] == "TRUE"
            admitted = bool(adjacent and not graph["error"] and not graph["warnings"])
            strategies[method+"+strata-RD"] = [strata[0]]*2+[strata[1]]*2 if admitted else [0]*4
        tree, tree_feature = tree_action(rows, int(seed)+9000000)
        strategies["honest-depth1"] = tree
        for method, actions in strategies.items():
            results.append(dict(scenario=name, n_total=int(n), seed=int(seed), method=method,
                                action=actions, tree_feature=tree_feature if method == "honest-depth1" else None,
                                **score(spec["base"], truth, actions, px=spec["px"])))
    target = root / "decisions.json"
    if target.exists():
        raise FileExistsError(target)
    target.write_text(json.dumps(results, separators=(",", ":")), encoding="utf-8")
    summary = []
    grouped = defaultdict(list)
    for row in results:
        grouped[(row["scenario"], row["n_total"], row["method"])].append(row)
    for key, group in grouped.items():
        summary.append(dict(zip(("scenario", "n_total", "method"), key)) |
                       {field: float(np.mean([r[field] for r in group]))
                        for field in ("gain", "regret", "harmful_mass", "null_mass", "edit_mass")})
    (root / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(dict(matrices=1200, searches=len(graphs), decisions=len(results))))


if __name__ == "__main__":
    if sys.argv[1] == "analyze-old":
        analyze_old(Path(sys.argv[2]), Path(sys.argv[3]))
    elif sys.argv[1] == "new-input":
        new_input(Path(sys.argv[2]))
    elif sys.argv[1] == "new-tetrad":
        new_tetrad(Path(sys.argv[2]))
    elif sys.argv[1] == "new-summary":
        new_summary(Path(sys.argv[2]))
