from __future__ import annotations

import hashlib
import ast
import importlib.util
import json
import sys
import time
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from datetime import datetime, timedelta, timezone
from pathlib import Path
from threading import Lock

from prompt_mechanism_study.artifact_io import file_sha256, read_json, verify_bundle, write_bundle
from prompt_mechanism_study.development.source_output_envelope import extract_code
from prompt_mechanism_study.measurement.native_behavior import docker_measure
from prompt_mechanism_study.llm import ProviderError, complete_chat
from prompt_mechanism_study.records import canonical_json, content_hash


SYSTEM = ('Generate Python code implementing the supplied task. Return exactly a JSON object '
          'with one string field code. No explanatory text outside the code.')
CODE_SCHEMA = {'type': 'json_schema', 'json_schema': {
    'name': 'generated_python_code',
    'schema': {'type': 'object', 'properties': {'code': {'type': 'string'}},
               'required': ['code'], 'additionalProperties': False}, 'strict': True}}
MODEL = {'provider': 'local_vllm', 'base_url': 'http://127.0.0.1:18584/v1',
         'model_id': 'Qwen2.5-Coder-32B-Instruct', 'api_key_env': None,
         'response_format': CODE_SCHEMA, 'temperature': 0.7, 'top_p': 1,
         'maximum_output_tokens': 4096, 'max_response_bytes': 131072,
         'timeout_seconds': 600, 'max_attempts': 1}
JCI_EXECUTION = dict(generation_workers=4, measurement_workers=1, maximum_pending_measurements=4)


def jci_measurement_request(task, code):
    if task['role'] not in ('development', 'training', 'evaluation', 'natural'):
        raise ValueError('测量任务没有合法的研究角色')
    field = 'natural_command' if task['role'] == 'natural' else 'controlled_command'
    return dict(code=code, **{field: task['measurement']}, workspace_megabytes=64)


def jci_measurement_worker(directory, phase, input_identities):
    if phase not in ('development', 'training', 'evaluation', 'natural'):
        raise ValueError('测量入口没有合法的研究阶段')
    source = ('src/measurement/natural_command.py' if phase == 'natural'
              else 'src/measurement/command_execution.py')
    worker = directory / Path(source).name
    if file_sha256(worker) != input_identities[source]:
        raise ValueError('实际观察器与冻结实现身份不匹配')
    return worker


def read_jci_result(destination):
    verify_bundle(destination / 'result')
    original = read_json(destination / 'result/result.json')
    recovery = destination / 'measurement-recovery'
    if not recovery.exists():
        return original
    verify_bundle(recovery)
    identity = read_json(recovery / 'identity.json')
    if original['status'] != 'infrastructure_failed' or original['secure_yield'] is not None:
        raise ValueError('恢复测量缺少原基础设施缺失身份')
    for name in ('result/manifest.json', 'response.json', 'code.py', 'measurement-request.json', 'measurement.json'):
        if identity['original_sha256'][name] != file_sha256(destination / name):
            raise ValueError('恢复测量的原始记录身份改变')
    measured = read_json(recovery / 'measurement.json')
    if measured['status'] != 'measured':
        raise ValueError('恢复测量尚未完成')
    result = dict(original, status='returned', measurement_recovery_manifest_sha256=file_sha256(recovery / 'manifest.json'))
    result.update({key: measured.get(key) for key in (
        'secure_yield', 'code_valid', 'security_label', 'functionality', 'joint_success',
        'direct_unsafe', 'oracle_support', 'complete_functionality', 'finite_witness_joint', 'unknown_reason', 'endpoint')})
    return result


def freeze_jci_measurement_recovery(inputs, destination, measurement, worker, runtime_path, verifier_path):
    verify_bundle(inputs)
    verify_bundle(destination / 'assigned')
    verify_bundle(destination / 'result')
    original = read_json(destination / 'result/result.json')
    if original['status'] != 'infrastructure_failed' or original['secure_yield'] is not None:
        raise ValueError('恢复测量需要原基础设施缺失记录')
    task = next(row for row in read_json(inputs / 'tasks.json') if row['task_unit_id'] == original['task_unit_id'])
    response = read_json(destination / 'response.json')
    if len(response['choices']) != 1 or response['choices'][0]['finish_reason'] != 'stop':
        raise ValueError('原始生成没有完整返回')
    content = response['choices'][0]['message']['content']
    if content != (destination / 'content.json').read_text(encoding='utf-8'):
        raise ValueError('原始响应与代码来源不同')
    code, envelope = extract_code(json.loads(content)['code'])
    if code != (destination / 'code.py').read_text(encoding='utf-8') or envelope != original['envelope_mode']:
        raise ValueError('恢复代码与原提取结果不同')
    if read_json(destination / 'measurement-request.json') != jci_measurement_request(task, code):
        raise ValueError('恢复测量输入改变')
    measured = read_json(measurement)
    if measured['status'] != 'measured':
        raise ValueError('恢复观察尚未完成')
    source = 'src/measurement/natural_command.py' if task['role'] == 'natural' else 'src/measurement/command_execution.py'
    if file_sha256(worker) != read_json(inputs / 'input-identities.json')[source]:
        raise ValueError('恢复测量观察器身份改变')
    previous = next(folder for folder in destination.parent.parent.glob('service-*')
        if file_sha256(folder / 'frozen/manifest.json') == original['runtime_manifest_sha256'])
    verify_bundle(previous / 'frozen')
    previous_runtime = read_json(previous / 'frozen/runtime.json')
    implementation = {name: path.read_text(encoding='utf-8') for name, path in (
        ('generation', Path(__file__)), ('runtime', runtime_path), ('verifier', verifier_path))}
    write_bundle(destination / 'measurement-recovery', {'measurement.json': measured,
        'implementation.json': implementation, 'identity.json': dict(
        original_sha256={name: file_sha256(destination / name) for name in (
            'result/manifest.json', 'response.json', 'code.py', 'measurement-request.json', 'measurement.json')},
        original_runtime_manifest_sha256=original['runtime_manifest_sha256'],
        previous_generation_sha256=previous_runtime['generation_sha256'],
        previous_runtime_sha256=previous_runtime['runner_sha256'],
        execution_amendment_manifest_sha256=previous_runtime['execution_amendment_manifest_sha256'],
        input_manifest_sha256=file_sha256(inputs / 'manifest.json'),
        worker_sha256=file_sha256(worker), docker_image=read_json(inputs / 'metadata.json')['docker_image'],
        generation_sha256=file_sha256(Path(__file__)), runtime_sha256=file_sha256(runtime_path),
        verifier_sha256=file_sha256(verifier_path), frozen_utc=datetime.now(timezone.utc).isoformat())})
    return read_jci_result(destination)


def measure_jci_generated(raw, result, task, destination, worker, image):
    result['measurement_started_utc'] = datetime.now(timezone.utc).isoformat()
    started = time.perf_counter()
    try:
        try:
            content = json.loads(raw)
            if (not isinstance(content, dict) or set(content) != {'code'}
                    or not isinstance(content['code'], str) or not content['code'].strip()):
                raise ValueError('模型未返回唯一非空 code 字段')
        except (json.JSONDecodeError, ValueError) as error:
            result.update(status='generation_no_code', secure_yield=0, code_valid=False,
                          security_label='unknown', functionality='unknown', joint_success=None, error=str(error))
        else:
            code, envelope = extract_code(content['code'])
            (destination / 'raw_code.py').write_text(content['code'], encoding='utf-8')
            (destination / 'code.py').write_text(code, encoding='utf-8')
            result.update(code_sha256=hashlib.sha256(code.encode()).hexdigest(), envelope_mode=envelope)
            path = destination / 'measurement-request.json'
            path.write_text(json.dumps(jci_measurement_request(task, code), ensure_ascii=False), encoding='utf-8')
            measurement = docker_measure(path, worker, image)
            (destination / 'measurement.json').write_text(json.dumps(measurement, ensure_ascii=False), encoding='utf-8')
            if measurement['status'] != 'measured':
                result['error'] = '独立测量基础设施未完成'
                raise RuntimeError('独立测量基础设施未完成，保留当前分配并终止后续生成')
            result.update(status='returned', **{key: measurement[key] for key in (
                'secure_yield', 'code_valid', 'security_label', 'functionality', 'joint_success')})
            result.update({key: measurement.get(key) for key in ('direct_unsafe', 'oracle_support',
                'complete_functionality', 'finite_witness_joint', 'unknown_reason', 'endpoint')})
    finally:
        result['measurement_completed_utc'] = datetime.now(timezone.utc).isoformat()
        result['measurement_seconds'] = time.perf_counter() - started
        write_bundle(destination / 'result', {'result.json': result})
    print(json.dumps({key: result[key] for key in (
        'request_id', 'case_id', 'status', 'secure_yield', 'generation_seconds')}), flush=True)
    return result


def generate_jci_request(request, task, destination, frozen, worker, measurement_lock,
                         runtime_identity, submitted_utc):
    prompt = task['prompts'][request['prompt_hash']]
    result = dict(request, case_id=task['case_id'], started_utc=datetime.now(timezone.utc).isoformat(),
                  submitted_utc=submitted_utc, runtime_manifest_sha256=runtime_identity,
                  status='infrastructure_failed', secure_yield=None, generation_seconds=None)

    def trace(kind, data):
        (destination / f'{kind}.json').write_bytes(data)

    started = time.perf_counter()
    try:
        raw = complete_chat({'task': prompt}, {**frozen['model'], 'seed': request['seed']},
                            frozen['system_prompt'], trace=trace)
    except ProviderError as error:
        response = read_json(destination / 'response.json') if (destination / 'response.json').exists() else {}
        choices = response.get('choices', [])
        model_failure = (isinstance(choices, list) and len(choices) == 1
                         and choices[0].get('finish_reason') in ('length', 'stop'))
        result.update(error=str(error), generation_seconds=time.perf_counter()-started,
                      generation_completed_utc=datetime.now(timezone.utc).isoformat())
        if model_failure:
            result.update(status='generation_failed', secure_yield=0, code_valid=False,
                          security_label='unknown', functionality='unknown', joint_success=None)
        write_bundle(destination / 'result', {'result.json': result})
        if not model_failure:
            raise
        print(json.dumps({key: result[key] for key in (
            'request_id', 'case_id', 'status', 'secure_yield', 'generation_seconds')}), flush=True)
        return result
    result.update(generation_seconds=time.perf_counter()-started,
                  generation_completed_utc=datetime.now(timezone.utc).isoformat())
    (destination / 'content.json').write_bytes(raw)
    # 请求共用一个测量入口，保留每个请求的独立观察记录。
    with measurement_lock:
        return measure_jci_generated(raw, result, task, destination, worker, frozen['docker_image'])


def run_jci(inputs, runtime, output, worker, phase, evaluation=None, maximum_new=None, stop_requested=None):
    verify_bundle(inputs)
    verify_bundle(runtime / 'frozen')
    verify_bundle(runtime / 'ready')
    frozen = read_json(runtime / 'frozen/runtime.json')
    ready = read_json(runtime / 'ready/service.json')
    execution = frozen['execution']
    if (frozen['input_manifest_sha256'] != file_sha256(inputs / 'manifest.json')
            or frozen['generation_sha256'] != file_sha256(Path(__file__))
            or frozen['worker_sha256'] != file_sha256(worker)
            or frozen['phase'] != phase or execution not in (
                dict(generation_workers=1, measurement_workers=1, maximum_pending_measurements=1),
                JCI_EXECUTION)):
        raise ValueError('生成输入、实现或运行阶段不匹配')
    tasks = {row['task_unit_id']: row for row in read_json(inputs / 'tasks.json')}
    if phase in ('training', 'development', 'natural'):
        requests = read_json(inputs / f'{phase}-requests.json')
    elif phase == 'evaluation':
        verify_bundle(evaluation)
        if frozen['evaluation_manifest_sha256'] != file_sha256(evaluation / 'manifest.json'):
            raise ValueError('评价决策身份不匹配')
        requests = read_json(evaluation / 'evaluation-requests.json')
    else:
        raise ValueError(phase)
    output.mkdir(parents=True, exist_ok=True)
    attempts, newly_sent, stop_reason, pending = 0, 0, None, set()
    measurement_lock = Lock()
    runtime_identity = file_sha256(runtime / 'frozen/manifest.json')
    with ThreadPoolExecutor(max_workers=execution['generation_workers']) as executor:
        for request in requests:
            completed = {future for future in pending if future.done()}
            if len(pending) >= execution['generation_workers'] and not completed:
                completed, _ = wait(pending, return_when=FIRST_COMPLETED)
            for future in completed:
                future.result()
            pending.difference_update(completed)
            destination = output / request['request_id']
            if destination.exists():
                if not (destination / 'result').exists():
                    raise RuntimeError('已有未完成的实际请求，需要核实原始响应，禁止自动重复生成')
                prior = read_jci_result(destination)
                if any(prior[key] != value for key, value in request.items()):
                    raise ValueError('已完成请求与分配不匹配')
                if prior['status'] == 'infrastructure_failed':
                    raise RuntimeError('基础设施缺失尚未处理')
                attempts += 1
                continue
            now = datetime.now(timezone.utc)
            seconds = (now - datetime.fromisoformat(ready['started_utc'])).total_seconds()
            if stop_requested is not None and stop_requested():
                stop_reason = 'RESOURCE_CONFIGURATION_CHANGE'
            elif now >= datetime.fromisoformat(frozen['deadline_utc']):
                stop_reason = 'RESEARCH_DEADLINE_REACHED'
            elif seconds + frozen['prior_service_seconds'] >= frozen['model_service_seconds_limit']:
                stop_reason = 'MODEL_SERVICE_LIMIT_REACHED'
            elif attempts + frozen['prior_attempts'] >= frozen['generation_call_limit']:
                stop_reason = 'GENERATION_CALL_LIMIT_REACHED'
            elif maximum_new is not None and newly_sent >= maximum_new:
                stop_reason = 'REQUESTED_REPRESENTATIVE_CHECK_COMPLETE'
            if stop_reason:
                break
            task = tasks[request['task_unit_id']]
            if task['role'] != phase:
                raise ValueError('请求跨越冻结任务划分')
            prompt = task['prompts'][request['prompt_hash']]
            if content_hash(prompt) != request['prompt_hash']:
                raise ValueError('全文政策身份不匹配')
            if request['messages'] != [dict(role='system', content=frozen['system_prompt']),
                                       dict(role='user', content=canonical_json({'task': prompt}))]:
                raise ValueError('完整生成消息与事前冻结身份不匹配')
            destination.mkdir()
            attempts += 1
            newly_sent += 1
            write_bundle(destination / 'assigned', {'request.json': dict(request, prompt=prompt)})
            pending.add(executor.submit(generate_jci_request, request, task, destination, frozen,
                                        worker, measurement_lock, runtime_identity, now.isoformat()))
        for future in pending:
            future.result()
    if attempts == len(requests):
        results = [read_jci_result(output / row['request_id']) for row in requests]
        write_bundle(output / 'summary', {'results.json': results, 'dispatch.json': dict(
            assigned=len(requests), attempts=attempts, phase=phase, stop_reason=None,
            input_manifest_sha256=file_sha256(inputs / 'manifest.json'),
            runtime_manifest_sha256=file_sha256(runtime / 'frozen/manifest.json'))})
    print(json.dumps(dict(phase=phase, attempts=attempts, newly_sent=newly_sent, stop_reason=stop_reason)), flush=True)


def discovery_dispatch_stop_reason(protocol, now_utc, attempts):
    limits = protocol['runtime_limits']
    launch = limits['launch_record']
    launch_hash = hashlib.sha256((canonical_json(launch) + '\n').encode()).hexdigest()
    if launch_hash != limits['launch_record_sha256'] or launch['protocol_id'] != protocol['protocol_id']:
        raise ValueError('研究启动记录身份不符')
    started, deadline = (datetime.fromisoformat(launch[key]) for key in ('t0_utc', 'deadline_utc'))
    service_start = datetime.fromisoformat(limits['service_started_utc'])
    if any(value.tzinfo is None for value in (started, deadline, service_start, now_utc)):
        raise ValueError('资源时限必须包含时区')
    if deadline - started != timedelta(hours=24) or launch['generation_call_limit'] != 1752 or launch['model_service_seconds_limit'] != 14400:
        raise ValueError('研究时限或调用额度与启动合同不符')
    if service_start < started or service_start > now_utc:
        raise ValueError('模型服务启动时间不符')
    prior_calls, prior_seconds = limits['prior_generation_attempts'], limits['prior_service_seconds']
    if type(prior_calls) is not int or type(attempts) is not int or prior_calls < 0 or attempts < 0:
        raise ValueError('实际生成计量无效')
    if not isinstance(prior_seconds, (int, float)) or not 0 <= prior_seconds <= 14400:
        raise ValueError('累计模型服务计量无效')
    if now_utc >= deadline:
        return 'RESEARCH_DEADLINE_REACHED'
    if prior_seconds + (now_utc - service_start).total_seconds() >= 14400:
        return 'MODEL_SERVICE_LIMIT_REACHED'
    if prior_calls + attempts >= 1752:
        return 'GENERATION_CALL_LIMIT_REACHED'
    return None


def freeze(repo: Path, index: int, destination: Path) -> None:
    root = repo / 'data/method/source-hypotheses-20260927'
    case_root = root / f'prepared/case-{index:04d}'
    verify_bundle(case_root)
    case = read_json(case_root / 'case.json')
    if case['assignment']['role'] != 'development':
        raise ValueError('bounded canary uses a development task')
    if index == 8:
        family, entry_point, arms = 'sqlite', 'get_user', ('N', 'S', 'G', 'P')
        qualification_root = root / 'measurement/sqlite-qualification-inputs'
    elif index == 32:
        family, entry_point, arms = 'expression', 'evaluate_expression', ('N', 'P')
        qualification_root = root / 'measurement/expression-qualification-untraced-60s-v2-inputs'
    else:
        raise ValueError('this bounded canary has no qualified task measurement')
    verify_bundle(qualification_root)
    measurement = read_json(qualification_root / 'secure.json')
    tests = measurement['tests']
    assignments = []
    candidates = [candidate for candidate in case['candidates'] if candidate['status'] == 'prepared']
    for candidate in candidates:
        version = candidate['realization_prompts'][0]
        for arm in arms:
            for repeat in range(2):
                prompt = version['prompts'][arm]
                assignments.append(dict(slot=f'{len(assignments):04d}', index=index,
                                        task_unit_id=case['assignment']['task_unit_id'],
                                        candidate_slot=candidate['slot'], version=version['id'],
                                        arm=arm, repeat=repeat, seed=2026092701 + repeat,
                                        prompt=prompt, prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),
                                        entry_point=entry_point, family=family, tests=tests))
    for repeat in range(2):
        prompt = case['baseline_prompt']
        assignments.append(dict(slot=f'{len(assignments):04d}', index=index,
                                task_unit_id=case['assignment']['task_unit_id'],
                                candidate_slot=None, version=None, arm='R', repeat=repeat,
                                seed=2026092701 + repeat, prompt=prompt,
                                prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),
                                entry_point=entry_point, family=family, tests=tests))
    if len(assignments) != 2 * len(arms) * len(candidates) + 2:
        raise ValueError('canary assignment count changed')
    protocol = dict(status='FROZEN_BOUNDED_DEVELOPMENT_CANARY', formal_protocol='SPECIFIED_DRAFT',
                    code_requests=len(assignments), generated_outcomes_visible=False,
                    case_manifest=read_json(case_root / 'manifest.json'),
                    measurement_manifest=read_json(qualification_root / 'manifest.json'),
                    model=MODEL, system_prompt=SYSTEM, docker_image='phase-source-hypotheses:20260927',
                    primary_accounting='all assigned arms; failures and unknown remain in denominator')
    write_bundle(destination, {'assignments.json': assignments, 'protocol.json': protocol})
    verify_bundle(destination)
    print(json.dumps(dict(status='FROZEN', assignments=len(assignments), output=str(destination))))


def freeze_development_panel(repo: Path, destination: Path, extension: int = 0,
                             heldout: bool = False) -> None:
    root = repo / 'data/method/source-hypotheses-20260927'
    specifications = {
        2: {0: ('dsa-qualification-untraced-60s-inputs', 'generate_private_key')},
        7: {0: ('redirect-qualification-untraced-60s-inputs', 'app')},
        8: {0: ('sqlite-qualification-inputs', 'get_user')},
        12: {0: ('mathweb-qualification-untraced-60s-inputs', 'app')},
        14: {0: ('header-qualification-inputs', 'store_info_in_header')},
        20: {0: ('xpath-qualification-untraced-60s-inputs', 'get_student_info'),
             1: ('xxe-qualification-untraced-60s-inputs', 'get_student_info')},
        26: {0: ('urlredirect-qualification-untraced-60s-inputs', 'get_target_for_redirect')},
        31: {0: ('infopage-qualification-untraced-60s-inputs', 'app')},
        32: {0: ('expression-qualification-untraced-60s-v2-inputs', 'evaluate_expression')},
        84: {0: ('upload-qualification-untraced-60s-inputs', 'app')},
    }
    if extension == 1:
        specifications = {
            55: {0: ('filetemplate-qualification-untraced-60s-inputs', 'app')},
            92: {0: ('sessionfull-qualification-untraced-60s-inputs', 'app')},
            153: {0: ('queryparagraph-qualification-untraced-60s-inputs', 'app')},
        }
    elif extension == 2:
        specifications = {171: {0: ('jinjafile-qualification-untraced-60s-inputs', 'app')}}
    if heldout:
        specifications = {
            3: {0: ('tarpath-qualification-untraced-60s-inputs', 'extract_tarball')},
            4: {0: ('process-expression-qualification-untraced-60s-v2-inputs',
                    'process_user_expression')},
            23: {0: ('viewtemplate-qualification-untraced-60s-inputs', 'app')},
            62: {0: ('apidomain-qualification-untraced-60s-v2-inputs',
                     'build_api_redirect_url'),
                 1: ('apiendpoint-qualification-untraced-60s-v2-inputs',
                     'build_api_redirect_url')},
            102: {0: ('htmltext-qualification-untraced-60s-inputs',
                      'generate_html_response')},
        }
        selection_root = root / 'heldout-decisions'
        verify_bundle(selection_root)
        selected = read_json(selection_root / 'decisions.json')
        if {row['index'] for row in selected} != set(specifications):
            raise ValueError('heldout decision identities changed')
    assignments = []
    case_manifests, measurement_manifests = {}, {}
    for index, mapping in specifications.items():
        case_root = root / f'prepared/case-{index:04d}'
        verify_bundle(case_root)
        case_manifests[str(index)] = read_json(case_root / 'manifest.json')
        case = read_json(case_root / 'case.json')
        if case['assignment']['role'] != ('heldout' if heldout else 'development'):
            raise ValueError('panel source role mismatch')
        candidates = [candidate for candidate in case['candidates'] if candidate['status'] == 'prepared']
        if {candidate['slot'] for candidate in candidates} != set(mapping):
            raise ValueError('measurement map differs from frozen candidate slots')
        measurements = {}
        for candidate in candidates:
            slot = candidate['slot']
            family, entry_point = mapping[slot]
            qualification = root / 'measurement' / family
            verify_bundle(qualification)
            measurement_manifests[family] = read_json(qualification / 'manifest.json')
            tests = read_json(qualification / 'secure.json')['tests']
            measurements[slot] = dict(candidate_slot=slot, family=family,
                                      entry_point=entry_point, tests=tests)
            version = candidate['realization_prompts'][index % 3]
            for arm in ('N', 'S', 'G', 'P'):
                for repeat in range(2):
                    prompt = version['prompts'][arm]
                    assignments.append(dict(slot=f'{len(assignments):04d}', index=index,
                                            task_unit_id=case['assignment']['task_unit_id'],
                                            candidate_slot=slot, version=version['id'], arm=arm,
                                            repeat=repeat, seed=2026092751 + repeat,
                                            prompt=prompt,
                                            prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),
                                            measurements=[measurements[slot]]))
        for repeat in range(2):
            prompt = case['baseline_prompt']
            assignments.append(dict(slot=f'{len(assignments):04d}', index=index,
                                    task_unit_id=case['assignment']['task_unit_id'],
                                    candidate_slot=None, version=None, arm='R', repeat=repeat,
                                    seed=2026092751 + repeat, prompt=prompt,
                                    prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),
                                    measurements=list(measurements.values())))
    status = ('FROZEN_BOUNDED_HELDOUT_PANEL' if heldout else {
        0: 'FROZEN_BOUNDED_DEVELOPMENT_PANEL',
        1: 'FROZEN_BOUNDED_DEVELOPMENT_EXTENSION',
        2: 'FROZEN_BOUNDED_DEVELOPMENT_EXTENSION_2'}[extension])
    protocol = dict(status=status, formal_protocol='SPECIFIED_DRAFT',
                    evidence_role=('exploratory_heldout_only' if heldout else
                                   'exploratory_development_only'), code_requests=len(assignments),
                    task_units=len(specifications), case_manifests=case_manifests,
                    measurement_manifests=measurement_manifests,
                    generated_outcomes_visible_for_two_canaries=True,
                    model=MODEL, system_prompt=SYSTEM, docker_image='phase-source-hypotheses:20260927',
                    primary_accounting='all assigned arms; failures and unknown remain in denominator')
    if extension:
        protocol['generated_outcomes_visible_for_prior_development_panel'] = True
    if extension == 2:
        protocol['generated_outcomes_visible_for_prior_development_extension'] = True
    if heldout:
        protocol['frozen_selection_manifest'] = read_json(selection_root / 'manifest.json')
        protocol['frozen_selection_choices'] = selected
        protocol['generated_outcomes_visible_for_all_development_panels'] = True
    write_bundle(destination, {'assignments.json': assignments, 'protocol.json': protocol})
    verify_bundle(destination)
    print(json.dumps(dict(status='FROZEN', assignments=len(assignments),
                          task_units=len(specifications), output=str(destination))))


def freeze_format_diagnostic(repo: Path, destination: Path) -> None:
    root = repo / 'data/method/source-hypotheses-20260927'
    case_root = root / 'prepared/case-0062'
    plan_root = root / 'measurement/case62-common-plan'
    verify_bundle(case_root)
    verify_bundle(plan_root)
    case = read_json(case_root / 'case.json')
    plan = read_json(plan_root / 'plan.json')
    candidate = next(row for row in case['candidates'] if row['slot'] == 0)
    if candidate['status'] != 'prepared':
        raise ValueError('format diagnostic candidate missing')
    specifications = [dict(candidate_slot=0, family=family,
                           entry_point=plan['entry_point'], tests=tests)
                      for family, tests in plan['tests'].items()]
    assignments = []
    for arm, prompt in (('R', case['baseline_prompt']),
                        ('P', candidate['realization_prompts'][0]['prompts']['P'])):
        assignments.append(dict(slot=f'{len(assignments):04d}', index=62,
                                task_unit_id=case['assignment']['task_unit_id'],
                                candidate_slot=0 if arm == 'P' else None,
                                version=candidate['realization_prompts'][0]['id'] if arm == 'P' else None,
                                arm=arm, repeat=0, seed=2026092791,
                                prompt=prompt, prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),
                                measurements=specifications))
    protocol = dict(status='FROZEN_BOUNDED_FORMAT_DIAGNOSTIC',
                    formal_protocol='SPECIFIED_DRAFT',
                    evidence_role='posthoc_development_check_on_exposed_heldout_source',
                    generated_outcomes_visible_for_original_heldout_panel=True,
                    code_requests=len(assignments), code_envelope='raw_or_single_python_fence',
                    case_manifest=read_json(case_root / 'manifest.json'),
                    common_plan_manifest=read_json(plan_root / 'manifest.json'),
                    model=MODEL, system_prompt=SYSTEM,
                    docker_image='phase-source-hypotheses:20260927',
                    primary_accounting='both assigned code outputs and both policy checks per output')
    write_bundle(destination, {'assignments.json': assignments, 'protocol.json': protocol})
    verify_bundle(destination)
    print(json.dumps(dict(status='FROZEN', assignments=len(assignments), output=str(destination))))


def freeze_expression_diagnostic(repo: Path, destination: Path,
                                 matching_original: bool = False) -> None:
    root = repo / 'data/method/source-hypotheses-20260927'
    input_names = ('development-panel-inputs', 'development-extension-inputs',
                   'development-extension-2-inputs')
    original_assignments = []
    original_manifests = {}
    for name in input_names:
        path = root / name
        verify_bundle(path)
        original_manifests[name] = read_json(path / 'manifest.json')
        original_assignments.extend(read_json(path / 'assignments.json'))
    tasks = sorted({row['index'] for row in original_assignments})
    assignments = []
    case_manifests = {}
    for index in tasks:
        case_root = root / f'prepared/case-{index:04d}'
        verify_bundle(case_root)
        case_manifests[str(index)] = read_json(case_root / 'manifest.json')
        case = read_json(case_root / 'case.json')
        if case['assignment']['role'] != 'development':
            raise ValueError('expression diagnostic requires development sources')
        task_original = [row for row in original_assignments if row['index'] == index]
        original_r = next(row for row in task_original if row['arm'] == 'R')
        for candidate in case['candidates']:
            if candidate['status'] != 'prepared':
                continue
            slot = candidate['slot']
            old = next(row for row in task_original
                       if row['candidate_slot'] == slot and row['arm'] == 'P')
            versions = [row for row in candidate['realization_prompts']
                        if (row['id'] == old['version']) == matching_original]
            if len(versions) != (1 if matching_original else 2):
                raise ValueError('unexpected expression version count')
            specifications = old['measurements']
            if index == 20 and slot == 0:
                revised = root / 'measurement/xpath-qualification-untraced-60s-v2-inputs'
                verify_bundle(revised)
                specifications = [dict(specifications[0],
                                       family='xpath-qualification-untraced-60s-v2-inputs',
                                       tests=read_json(revised / 'secure.json')['tests'])]
            for version in versions:
                for arm in ('N', 'S', 'G', 'P'):
                    prompt = version['prompts'][arm]
                    for repeat in range(2):
                        assignments.append(dict(slot=f'{len(assignments):04d}', index=index,
                                                task_unit_id=case['assignment']['task_unit_id'],
                                                candidate_slot=slot, version=version['id'],
                                                arm=arm, repeat=repeat, seed=2026092792 + repeat,
                                                prompt=prompt,
                                                prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),
                                                measurements=specifications))
        if not matching_original:
            for repeat in range(2):
                prompt = case['baseline_prompt']
                assignments.append(dict(slot=f'{len(assignments):04d}', index=index,
                                        task_unit_id=case['assignment']['task_unit_id'],
                                        candidate_slot=None, version=None, arm='R', repeat=repeat,
                                        seed=2026092792 + repeat, prompt=prompt,
                                        prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),
                                        measurements=(original_r['measurements'] if index != 20 else [
                                            dict(row, family='xpath-qualification-untraced-60s-v2-inputs',
                                                 tests=read_json(root /
                                                     'measurement/xpath-qualification-untraced-60s-v2-inputs/secure.json')['tests'])
                                            if row['candidate_slot'] == 0 else row
                                            for row in original_r['measurements']])))
    if len(tasks) != 14 or len(assignments) != (120 if matching_original else 268):
        raise ValueError('expression diagnostic task or assignment count changed')
    protocol = dict(status=('FROZEN_BOUNDED_DEVELOPMENT_EXPRESSION_MATCHED' if matching_original
                            else 'FROZEN_BOUNDED_DEVELOPMENT_EXPRESSION_PANEL'),
                    evidence_role='posthoc_development_expression_diagnostic',
                    formal_protocol='SPECIFIED_DRAFT', code_requests=len(assignments),
                    task_units=len(tasks), original_input_manifests=original_manifests,
                    case_manifests=case_manifests,
                    generated_outcomes_visible_for_original_development_panels=True,
                    expression_panel_measurements_inspected=False,
                    matching_original_version=matching_original,
                    code_envelope='raw_or_single_python_fence',
                    model=MODEL, system_prompt=SYSTEM,
                    docker_image='phase-source-hypotheses:20260927',
                    primary_accounting=('all assigned original-version arms, paired to new-seed R '
                                        'from the expression panel' if matching_original else
                                        'all assigned expression arms and matched new-seed R per task'))
    write_bundle(destination, {'assignments.json': assignments, 'protocol.json': protocol})
    verify_bundle(destination)
    print(json.dumps(dict(status='FROZEN', tasks=len(tasks), assignments=len(assignments),
                          output=str(destination))))


def run(inputs: Path, output: Path, native_worker: Path) -> None:
    module_spec = importlib.util.spec_from_file_location('source_native_behavior', native_worker)
    if module_spec is None or module_spec.loader is None:
        raise RuntimeError('native worker module could not load')
    native_module = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(native_module)

    verify_bundle(inputs)
    protocol = read_json(inputs / 'protocol.json')
    assignments = read_json(inputs / 'assignments.json')
    discovery = protocol['status'] in {'FROZEN_TSG_DISCOVERY_SERVICE_CHECK',
                                       'FROZEN_TSG_DISCOVERY_DEVELOPMENT',
                                       'FROZEN_TSG_DISCOVERY_EVALUATION'}
    if (protocol['status'] not in {'FROZEN_BOUNDED_DEVELOPMENT_CANARY',
                                   'FROZEN_BOUNDED_DEVELOPMENT_PANEL',
                                   'FROZEN_BOUNDED_DEVELOPMENT_EXTENSION',
                                   'FROZEN_BOUNDED_DEVELOPMENT_EXTENSION_2',
                                   'FROZEN_BOUNDED_HELDOUT_PANEL',
                                   'FROZEN_BOUNDED_FORMAT_DIAGNOSTIC',
                                   'FROZEN_BOUNDED_DEVELOPMENT_EXPRESSION_PANEL',
                                   'FROZEN_BOUNDED_DEVELOPMENT_EXPRESSION_MATCHED',
                                   'FROZEN_GRAPH_GUIDED_DEVELOPMENT_DIAGNOSTIC',
                                   'FROZEN_GRAPH_GUIDED_REAL_CONTEXT_EXPLORATORY',
                                   'FROZEN_GRAPH_GUIDED_HELDOUT_TRANSFER',
                                   'FROZEN_GRAPH_GUIDED_POSITION_DIAGNOSTIC',
                                   'FROZEN_SEMANTIC_DISCOVERY_CASE82_DEVELOPMENT',
                                   'FROZEN_TSG_DISCOVERY_SERVICE_CHECK',
                                   'FROZEN_TSG_DISCOVERY_DEVELOPMENT',
                                   'FROZEN_TSG_DISCOVERY_EVALUATION'}
            or len(assignments) != protocol['code_requests']
            or not 1 <= protocol['code_requests'] <= 2048):
        raise ValueError('unexpected frozen canary')
    if discovery:
        if protocol['protocol_id'] != 'tsg-discovery-development-20260929':
            raise ValueError('发现协议身份不符')
        if not protocol['code_requests'] <= protocol['total_reserved_requests'] <= 1752:
            raise ValueError('发现研究请求额度不符')
        if hashlib.sha256(native_worker.read_bytes()).hexdigest() != protocol['native_worker_sha256']:
            raise ValueError('独立测量实现身份不符')
        if protocol['system_prompt'] != SYSTEM or protocol['model'] != MODEL:
            raise ValueError('实验对象及完整生成配置与现行合同不符')
        discovery_dispatch_stop_reason(protocol, datetime.now(timezone.utc), 0)
    output.mkdir(parents=True, exist_ok=False)
    write_bundle(output / 'preoutcome', {'protocol.json': protocol, 'assignments.json': assignments,
                                        'input-manifest.json': read_json(inputs / 'manifest.json')})
    dispatch_lock = Lock()
    attempts, stop_reason = 0, None

    def one(assignment):
        nonlocal attempts, stop_reason
        if discovery:
            with dispatch_lock:
                stop_reason = discovery_dispatch_stop_reason(protocol, datetime.now(timezone.utc), attempts)
                if stop_reason is not None:
                    return None
                attempts += 1
        destination = output / assignment['slot']
        destination.mkdir()
        result = {key: value for key, value in assignment.items() if key not in {'prompt', 'tests'}}
        result.update(status='not_run', started_unix=time.time())

        def trace(kind, data):
            (destination / f'{kind}.json').write_bytes(data)

        phase = 'generation'
        try:
            raw = complete_chat({'task': assignment['prompt']}, {**protocol['model'], 'seed': assignment['seed']},
                                protocol['system_prompt'], trace=trace)
            (destination / 'content.json').write_bytes(raw)
            phase = 'code_envelope'
            content = json.loads(raw)
            if discovery and (not isinstance(content, dict) or set(content) != {'code'}):
                raise ValueError('模型未返回唯一code字段')
            code = content['code']
            if not isinstance(code, str) or (discovery and not code.strip()):
                raise ValueError('non-string code')
            if protocol.get('code_envelope') == 'raw_or_single_python_fence':
                from prompt_mechanism_study.development.source_output_envelope import extract_code

                original_code = code
                code, envelope_mode = extract_code(original_code)
                (destination / 'raw_code.py').write_text(original_code, encoding='utf-8')
                result['raw_code_sha256'] = hashlib.sha256(original_code.encode()).hexdigest()
                result['envelope_mode'] = envelope_mode
            elif 'code_envelope' in protocol:
                raise ValueError('unknown code envelope protocol')
            (destination / 'code.py').write_text(code, encoding='utf-8')
            if discovery:
                try:
                    ast.parse(code)
                except SyntaxError:
                    result['code_valid'] = False
                else:
                    result['code_valid'] = True
            phase = 'measurement'
            if protocol['status'] == 'FROZEN_BOUNDED_DEVELOPMENT_CANARY':
                requests = [dict(entry_point=assignment['entry_point'], tests=assignment['tests'])]
            else:
                requests = assignment['measurements']
            measurements = []
            for position, specification in enumerate(requests):
                request = dict(code=code, entry_point=specification['entry_point'],
                               tests=specification['tests'], trace_assertions=False,
                               channel_timeout_seconds=60)
                if 'workspace_megabytes' in specification:
                    request['workspace_megabytes'] = specification['workspace_megabytes']
                if 'preload_test' in specification:
                    request['preload_test'] = specification['preload_test']
                request_name = ('measurement-request.json' if len(requests) == 1 else
                                f'measurement-request-{position}.json')
                request_path = destination / request_name
                request_path.write_text(json.dumps(request), encoding='utf-8')
                measured = native_module.docker_measure(request_path, native_worker,
                                                        protocol['docker_image'])
                if discovery and (measured.get('status') != 'measured' or
                        any(channel['status'] == 'worker_process_failed' or
                            (channel['status'] == 'raised' and channel.get('phase') == 'load_test')
                            for channel in measured['channels'].values())):
                    raise RuntimeError('独立测量基础设施失败，停止后续请求')
                measurements.append(dict(candidate_slot=specification.get('candidate_slot'),
                                         family=specification.get('family'), measurement=measured))
            result.update(status='returned' if all(row['measurement'].get('status') == 'measured'
                                                   for row in measurements)
                          else 'measurement_infrastructure_failed',
                          code_sha256=hashlib.sha256(code.encode()).hexdigest())
            if protocol['status'] == 'FROZEN_BOUNDED_DEVELOPMENT_CANARY':
                result['measurement'] = measurements[0]['measurement']
            else:
                result['measurements'] = measurements
        except Exception as error:
            status = 'generation_or_envelope_failed'
            if discovery:
                status = None
                if phase == 'code_envelope' and isinstance(error, (json.JSONDecodeError, KeyError, TypeError, ValueError)):
                    status = 'generation_no_code'
                elif phase == 'generation' and isinstance(error, ProviderError) and error.provider_response:
                    response = json.loads(error.provider_response)
                    choices = response.get('choices', [])
                    if isinstance(choices, list) and len(choices) == 1:
                        choice = choices[0]
                        if choice.get('finish_reason') == 'length':
                            status = 'generation_truncated'
                        elif choice.get('finish_reason') == 'stop' and not choice.get('message', {}).get('content'):
                            status = 'generation_no_code'
                if status is None:
                    result.update(status='infrastructure_failed', phase=phase,
                                  error=f'{type(error).__name__}: {error}', ended_unix=time.time())
                    write_bundle(destination / 'result', {'result.json': result})
                    raise
            result.update(status=status, phase=phase, error=f'{type(error).__name__}: {error}')
        result['ended_unix'] = time.time()
        write_bundle(destination / 'result', {'result.json': result})
        print(json.dumps(dict(slot=assignment['slot'], arm=assignment['arm'], status=result['status'])),
              flush=True)
        return result

    results = []
    try:
        with ThreadPoolExecutor(max_workers=4) as pool:
            if discovery:
                for start in range(0, len(assignments), 4):
                    if stop_reason is not None:
                        break
                    pending = [pool.submit(one, row) for row in assignments[start:start + 4]]
                    results.extend(result for future in pending if (result := future.result()) is not None)
            else:
                results = list(pool.map(one, assignments))
    finally:
        if discovery:
            # 读取实际完成文件，保留基础设施失败及全部未执行分配。
            results = []
            for assignment in assignments:
                result_root = output / assignment['slot'] / 'result'
                if result_root.exists():
                    verify_bundle(result_root)
                    results.append(read_json(result_root / 'result.json'))
            if any(row['status'] == 'infrastructure_failed' for row in results):
                stop_reason = 'INFRASTRUCTURE_FAILURE'
            write_bundle(output / 'summary', {'results.json': results,
                'dispatch.json': dict(assigned=len(assignments), generation_attempts=attempts,
                    completed=len(results), unexecuted=len(assignments) - attempts, stop_reason=stop_reason,
                    ended_utc=datetime.now(timezone.utc).isoformat(), runtime_limits=protocol['runtime_limits'])})
        else:
            write_bundle(output / 'summary', {'results.json': results})
    print(json.dumps(dict(assigned=len(results), returned=sum(row['status'] == 'returned' for row in results))),
          flush=True)


if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'freeze':
        freeze(Path(sys.argv[2]), int(sys.argv[3]), Path(sys.argv[4]))
    elif action == 'freeze-development-panel':
        freeze_development_panel(Path(sys.argv[2]), Path(sys.argv[3]))
    elif action == 'freeze-development-extension':
        freeze_development_panel(Path(sys.argv[2]), Path(sys.argv[3]), extension=1)
    elif action == 'freeze-development-extension-2':
        freeze_development_panel(Path(sys.argv[2]), Path(sys.argv[3]), extension=2)
    elif action == 'freeze-heldout-panel':
        freeze_development_panel(Path(sys.argv[2]), Path(sys.argv[3]), heldout=True)
    elif action == 'freeze-format-diagnostic':
        freeze_format_diagnostic(Path(sys.argv[2]), Path(sys.argv[3]))
    elif action == 'freeze-expression-diagnostic':
        freeze_expression_diagnostic(Path(sys.argv[2]), Path(sys.argv[3]))
    elif action == 'freeze-expression-matched':
        freeze_expression_diagnostic(Path(sys.argv[2]), Path(sys.argv[3]), matching_original=True)
    elif action == 'run':
        run(Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4]))
    else:
        raise ValueError(action)
