"""Seven-stage reviewer smoke and bounded non-claim development execution.

The formal provider runner remains deliberately unavailable while the
prospective protocol is ``SPECIFIED_DRAFT``.  This module executes the exact
scientific stage functions on a deterministic, zero-network fixture and emits
an independently replayable ``NON_CLAIM_TEST_ARTIFACT``.  It is the smallest
representative proof that the target path closes without treating a test run as
study evidence. Authorized development uses the same operation-bound renderer,
measurement and outcome functions, with its separate frozen descriptive analysis.
"""

from __future__ import annotations
from pathlib import Path
from dataclasses import asdict
from collections import Counter
from contextlib import redirect_stdout
from concurrent.futures import ThreadPoolExecutor
from io import StringIO
import json
import random
import sys
from prompt_mechanism_study.artifact_io import bundle_digest, read_json, write_bundle
from prompt_mechanism_study.development.reviewer_fixture import (
    ReviewerSmokeFixture,
    load_reviewer_smoke_fixture,
)
from prompt_mechanism_study.measurement.evaluate import (
    close_target_measurements,
    measure_generated_code,
)
from prompt_mechanism_study.experiment.inference import EvidenceLevel, build_target_selector_yields, estimate_target_itt, freeze_assigned_arm_evidence
from prompt_mechanism_study.experiment.randomization import TargetRandomizationPlan, randomize_target_confirmation
from prompt_mechanism_study.experiment.outcomes import derive_outcomes
from prompt_mechanism_study.discovery.prioritization import FixedSlotSource, PolicyTrack, atomic_preoutcome_observations, freeze_atomic_candidate_folds, freeze_confirmation_dispatch, freeze_fixed_slot_ledger, freeze_shared_confirmation_union, run_atomic_shadow_qualification, run_atomic_fci_bootstrap
from prompt_mechanism_study.records import content_hash, content_id
from prompt_mechanism_study.tsg.representation import DataRole, validate_data_role_firewall
from prompt_mechanism_study.experiment.reporting import build_target_rq_tables
from prompt_mechanism_study.verification import verify_confirmation_inputs
from prompt_mechanism_study.experiment.study_design import StudyConfig, ConfirmationInputs
from prompt_mechanism_study.measurement.security_profiles import security_profile_producer_sha256
from prompt_mechanism_study.tsg.task_input import prepare_task_input, generation_input_for_prompt

PROTOCOL_ID = "phase-context-policy-v3"
SCHEMA_VERSION = "3.0"
SMOKE_MODEL_ID = "reviewer-smoke-model"
DEVELOPMENT_CODE_RESPONSE_FORMAT = {
    "type": "json_schema",
    "json_schema": {
        "name": "generated_python_code",
        "strict": True,
        "schema": {
            "type": "object",
            "additionalProperties": False,
            "properties": {"code": {"type": "string"}},
            "required": ["code"],
        },
    },
}
SMOKE_STAGES = (
    "representation",
    "prioritization",
    "hypothesis_freeze",
    "intervention_randomization",
    "measurement",
    "outcome_assembly",
    "inference_reporting",
)


def prepare_development_assignments(plan: dict) -> list[dict]:
    """Replay source-reviewed operation bindings before any development generation.

    This tests measurement and intervention behavior; it does not execute Discovery,
    select hypotheses from outcomes, assign formal roles, or activate the protocol.
    """
    from prompt_mechanism_study.tsg.prompt_tsg import prompt_tsg_from_record, validate_prompt_tsg
    from prompt_mechanism_study.measurement.security_profiles import (
        security_profile_producer_sha256,
    )

    if (
        plan.get("status") != "FROZEN_NON_CLAIM_DEVELOPMENT"
        or plan.get("scientific_claim_allowed") is not False
        or plan.get("qualification_accept_consumed") is not False
        or plan.get("formal_execution_authorized") is not False
    ):
        raise ValueError("only an explicitly bounded non-claim development plan is executable")
    if plan["security_producer_sha256"] != security_profile_producer_sha256():
        raise ValueError("development security producer differs from its prospective freeze")
    if any(
        contrast.get("kind") == "pair_interaction" for contrast in plan["analysis"]["contrasts"]
    ):
        raise ValueError("main supports Atomic contrasts only")
    tasks = plan["tasks"]
    # Validate the selection contract before any provider call. Old saved plans
    # retain their original significance rule when explicitly replayed.
    if plan["analysis"]["method"] == "paired_task_effect_screen_v1":
        from prompt_mechanism_study.experiment.inference import summarize_development_itt
        summarize_development_itt([], plan["analysis"])
        if plan["analysis"]["screening_task_units"] < len({t["task_unit_id"] for t in tasks}):
            raise ValueError("development tasks exceed the frozen screening frame")
    if len({task["task_unit_id"] for task in tasks}) != len(tasks):
        raise ValueError("development inputs must be deduplicated task units")
    if sorted(task["task_id"] for task in tasks) != sorted(plan["development_exposed_task_ids"]):
        raise ValueError("every task needs recorded development exposure before generation")
    seeds = plan["generation_seeds"]
    arms = plan["arms"]
    if (
        not seeds
        or len(set(seeds)) != len(seeds)
        or any(type(seed) is not int for seed in seeds)
        or arms
        not in (
            ["BASELINE", "NOOP", "STYLE", "GENERIC", "TARGET"],
            ["NOOP", "STYLE", "GENERIC", "TARGET"],
        )
    ):
        raise ValueError(
            "development requires a complete Atomic arm family and unique generation seeds"
        )
    if plan["maximum_provider_calls"] != 2 * len(tasks) * len(seeds) * len(arms):
        raise ValueError(
            "development call ceiling must cover every generation and functional review"
        )
    if any(
        evaluator.get("max_attempts") != 1
        for evaluator in (plan["generator"], plan["functional_evaluator"])
    ):
        raise ValueError(
            "development has one prospective attempt and no outcome-driven replacements"
        )
    if plan["generator"].get("response_format") != DEVELOPMENT_CODE_RESPONSE_FORMAT:
        raise ValueError(
            "development code generation requires the strict code-only JSON response contract"
        )
    policies = {row["policy_id"]: row for row in plan["policies"]}
    assignments = []
    for task in tasks:
        if "generation_input" not in task:
            raise ValueError(
                "prepare task input and re-extract its TSG before development generation"
            )
        task = prepare_task_input(task, generation_system_prompt=plan["generation_system_prompt"])
        if task["language"] != "python" or task["prompt_sha256"] != content_hash(task["prompt"]):
            raise ValueError("development source identity or language changed")
        graph = prompt_tsg_from_record(task["graph"])
        validate_prompt_tsg(graph, prompt=task["prompt"], catalog=plan["catalog"])
        if task["functional_contract"].get("source_prompt_sha256") != task["prompt_sha256"]:
            raise ValueError("functional contract must bind the same prepared baseline input")
        policy = policies[task["policy_id"]]
        subject_id = task.get("target_subject_node_id")
        binding, prompts = _development_prompts(task, policy, graph, plan["catalog"], arms)
        if binding.binding_id != task["binding_id"]:
            raise ValueError("development task-hypothesis binding changed")
        for seed in seeds:
            for arm in arms:
                generation_input_for_prompt(task, prompts[arm])
                row = {
                    "task_id": task["task_id"],
                    "task_unit_id": task["task_unit_id"],
                    "policy_id": policy["policy_id"],
                    "binding_id": binding.binding_id,
                    "target_operation_node_id": binding.target_operation_node_id,
                    "arm": arm,
                    "seed": seed,
                    "prompt": prompts[arm],
                    "prompt_sha256": content_hash(prompts[arm]),
                    "security_profile_id": policy["security_profile_id"],
                }
                if binding.factor_scopes:
                    row["factor_scopes"] = task["factor_scopes"]
                if subject_id is not None:
                    row["target_subject_node_id"] = subject_id
                row["assignment_id"] = content_id("development_assignment_", row)
                assignments.append(row)
    random.Random(plan["randomization_seed"]).shuffle(assignments)
    return assignments


def _development_prompts(task, policy, graph, catalog, arms):
    """Use the same exact factor binding for every assigned treatment and control."""
    from prompt_mechanism_study.discovery.mechanisms import (
        bind_task_hypothesis,
        render_task_hypothesis,
    )
    from prompt_mechanism_study.tsg.prompt_tsg import feature_scope_from_record, FeatureScope

    factors = policy["factors"] if "factors" in policy else [{**policy, "operation": "add"}]
    if len(factors) != 1:
        raise ValueError("development factors and arm family differ")
    for factor in factors:
        definition = factor.get("factor_definition", {})
        if not task.get("factor_scopes"):
            if arms != ["BASELINE", "NOOP", "STYLE", "GENERIC", "TARGET"]:
                raise ValueError("new development arms require exact factor scopes")
            if task.get("target_subject_node_id") is None:
                continue
            if not definition.get("subject_role"):
                raise ValueError(
                    "subject-bound development requires a single-requirement subject role"
                )
        if (
            definition.get("semantic_decisions") != [factor["feature_id"]]
            or definition.get("atomicity_review") != "SOURCE_REVIEWED_SINGLE_REQUIREMENT"
            or (task.get("factor_scopes") and (not definition.get("scope_rule")))
            or (not definition.get("definition"))
        ):
            raise ValueError(
                "scoped development needs a reviewed single-requirement definition and scope rule"
            )
    coordinates = (
        {"factor_scopes": tuple((feature_scope_from_record(row) for row in task["factor_scopes"]))}
        if task.get("factor_scopes")
        else {
            "target_operation_node_id": task["target_operation_node_id"],
            "factor_subject_node_ids": (
                (task["target_subject_node_id"],) if task.get("target_subject_node_id") else ()
            ),
        }
    )
    binding = bind_task_hypothesis(
        graph,
        query=policy["query"],
        policy_id=policy["policy_id"],
        factor_feature_ids=tuple((factor["feature_id"] for factor in factors)),
        factor_operations=tuple((factor["operation"] for factor in factors)),
        **coordinates,
    )
    if task.get("factor_scopes"):
        compatibility = task.get("intervention_compatibility", {})
        if (
            compatibility.get("binding_id") != binding.binding_id
            or compatibility.get("decision") != "compatible"
            or compatibility.get("outcomes_used") is not False
            or (not compatibility.get("rationale"))
        ):
            raise ValueError("scoped development needs source-reviewed intervention compatibility")
    by_node = {node.node_id: node for node in graph.nodes}
    task_start = len(task["prompt"]) - len(task["generation_input"]["request"]["task"])
    scopes = binding.factor_scopes or (FeatureScope(binding.target_operation_node_id),)
    if any((by_node[scope.operation_node_id].evidence_start < task_start for scope in scopes)):
        raise ValueError("development factors must bind operations in the user task")
    controls = (
        task["factor_control_texts"] if "factor_control_texts" in task else [task["control_texts"]]
    )
    if len(controls) != len(factors):
        raise ValueError("development requires frozen controls for each scoped factor")
    flags = {
        "BASELINE": (False,),
        "NOOP": (False,),
        "STYLE": (False,),
        "GENERIC": (False,),
        "TARGET": (True,),
    }
    prompts = {}
    for arm in arms:
        if arm == "BASELINE":
            prompts[arm] = task["prompt"]
            continue
        inactive = {
            factor["feature_id"]: controls[index][arm]
            for index, factor in enumerate(factors)
            if not flags[arm][index]
        }
        rendered = render_task_hypothesis(
            binding,
            graph,
            prompt=task["prompt"],
            catalog=catalog,
            enabled=flags[arm],
            additions={
                factor["feature_id"]: factor["addition"]
                for factor in factors
                if factor["operation"] == "add"
            },
            inactive_texts=inactive,
            reviewed_variant=task.get("reviewed_variants", {}).get(arm),
        )
        prompts[arm] = rendered["prompt"]
    factor = factors[0]
    if factor["operation"] == "add":
        target_words = len(factor["addition"].split())
    else:
        from prompt_mechanism_study.tsg.prompt_tsg import scoped_feature_assessment

        assessment = scoped_feature_assessment(
            graph, factor["feature_id"], binding.factor_scopes[0]
        )
        target_words = sum(
            (
                len(task["prompt"][by_node[key].evidence_start : by_node[key].evidence_end].split())
                for key in assessment.requirement_node_ids
            )
        )
    if len(controls[0]["STYLE"].split()) != target_words:
        raise ValueError("style control must match the frozen requirement whitespace-word length")
    return (binding, prompts)


def run_target_development(plan_path: Path, output: Path, *, complete=None) -> dict:
    """Run one prospectively frozen development comparison through actual measurement.

    Exact source/arm/seed assignments are saved before provider calls. Raw responses
    and failures survive independently of final analysis. No task is replaced.
    """
    from prompt_mechanism_study.llm import complete_chat
    from prompt_mechanism_study.experiment.inference import (
        summarize_development_itt,
        summarize_development_sampling,
    )
    from prompt_mechanism_study.measurement.evaluate import MeasurementLedger

    plan = read_json(plan_path)
    assignments = prepare_development_assignments(plan)
    provider = complete or complete_chat
    if output.exists():
        raise FileExistsError(output)
    output.mkdir(parents=True)
    write_bundle(
        output / "preoutcome",
        {
            "plan.json": plan,
            "assignments.json": assignments,
            "environment.json": {
                "python": sys.version,
                "platform": sys.platform,
                "security_producer_sha256": plan["security_producer_sha256"],
            },
        },
    )
    task_by_id = {task["task_id"]: task for task in plan["tasks"]}

    def measure(row):
        calls = []

        def captured(request, evaluator, prompt):
            attempt = {"request": request, "evaluator": dict(evaluator), "system_prompt": prompt}
            calls.append(attempt)
            try:
                raw = provider(request, evaluator, prompt)
                attempt["response"] = raw.decode("utf-8")
                return raw
            except Exception as error:
                attempt["error"] = f"{type(error).__name__}: {error}"
                raise

        task = task_by_id[row["task_id"]]
        result = dict(
            row,
            code=None,
            code_valid=None,
            security_status=None,
            functionality_status=None,
            secure_code_yield=None,
            oracle_evaluable=None,
            functionality=None,
            joint=None,
            measurement_evidence=None,
            error=None,
        )
        try:
            generation_input = generation_input_for_prompt(task, row["prompt"])
            measurement, evidence = measure_generated_code(
                assignment_id=row["assignment_id"],
                generation_request=generation_input["request"],
                generation_evaluator={**plan["generator"], "seed": row["seed"]},
                generation_prompt=generation_input["system_prompt"],
                source_task_prompt=task["prompt"],
                functional_contract=task["functional_contract"],
                functional_evaluator=plan["functional_evaluator"],
                functional_prompt=plan["functional_system_prompt"],
                security_profile_id=row["security_profile_id"],
                complete=captured,
            )
            outcome = derive_outcomes(
                MeasurementLedger(
                    plan["run_id"],
                    content_hash(assignments),
                    "non_claim_development",
                    (measurement,),
                )
            )[0]
            result.update(
                code=evidence["code"],
                code_valid=outcome.code_valid,
                security_status=measurement.oracle_status.value,
                functionality_status=measurement.functional_status.value,
                secure_code_yield=outcome.secure_yield,
                oracle_evaluable=outcome.oracle_evaluable,
                functionality=outcome.functionality,
                joint=outcome.joint,
                measurement_evidence=evidence,
                measurement=asdict(measurement),
                outcome=asdict(outcome),
            )
        except Exception as error:
            result["error"] = f"{type(error).__name__}: {error}"
            if calls and "response" in calls[0]:
                try:
                    result["code"] = json.loads(calls[0]["response"]).get("code")
                except (ValueError, AttributeError):
                    pass
        result["provider_calls"] = len(calls)
        result["provider_calls_by_kind"] = dict(
            Counter((call["evaluator"].get("provider", "unspecified") for call in calls))
        )
        write_bundle(
            output / "cases" / row["assignment_id"], {"calls.json": calls, "result.json": result}
        )
        print(
            json.dumps(
                {
                    "assignment_id": row["assignment_id"],
                    "status": "FAILED" if result["error"] else "MEASURED",
                }
            ),
            flush=True,
        )
        return result

    with ThreadPoolExecutor(max_workers=plan["workers"]) as pool:
        rows = list(pool.map(measure, assignments))
    effects = summarize_development_itt(rows, plan["analysis"])
    provider_kinds = Counter()
    for row in rows:
        provider_kinds.update(row["provider_calls_by_kind"])
    report = {
        "status": (
            "NON_CLAIM_DEVELOPMENT_COMPLETE"
            if complete is None
            else "OFFLINE_REPLAY_NON_CLAIM_DEVELOPMENT_COMPLETE"
        ),
        "scientific_claim_allowed": False,
        "evidence_level": "executed_development" if complete is None else "replayed_development",
        "run_id": plan["run_id"],
        "plan_sha256": content_hash(plan),
        "preoutcome_bundle_sha256": bundle_digest(output / "preoutcome"),
        "task_units": len(task_by_id),
        "assigned_rows": len(assignments),
        "measured_rows": sum((row["error"] is None for row in rows)),
        "failed_rows": sum((row["error"] is not None for row in rows)),
        "provider_calls": sum((row["provider_calls"] for row in rows)),
        "external_provider_calls": (
            sum((row["provider_calls"] for row in rows)) if complete is None else 0
        ),
        "live_provider_calls_by_kind": dict(provider_kinds) if complete is None else {},
        "response_source": "live_provider" if complete is None else "offline_supplied_responses",
        "functional_evaluator_failures": sum(
            (bool((row["measurement_evidence"] or {}).get("functional_failure")) for row in rows)
        ),
        "denominator": "all assigned deduplicated task units; seeds averaged within each task",
        "uncertainty": "Development paired sign-flip tests and task bootstrap intervals; no confirmatory claim or selector validation.",
        "security_counts": dict(
            Counter((row["security_status"] or "infrastructure_failure" for row in rows))
        ),
        "functional_counts": dict(
            Counter((row["functionality_status"] or "infrastructure_failure" for row in rows))
        ),
        "context_modifier_status": "BLOCKED_NO_FROZEN_CONTEXT_RULE",
    }
    write_bundle(
        output / "summary",
        {
            "report.json": report,
            "effects.json": effects,
            "assignments.json": rows,
            "sampling.json": summarize_development_sampling(rows, plan["analysis"]),
        },
    )
    return report


def run_target_reviewer_smoke(
    output: Path, *, inputs: ReviewerSmokeFixture | None = None
) -> dict[str, object]:
    """Traverse seven stages without network calls or claims.

    Bounded development may supply an authored fixture with rendered variants;
    the default reviewer fixture and the non-claim boundary are unchanged.
    """
    if not isinstance(output, Path):
        raise TypeError("target reviewer smoke output must be a Path")
    inputs = load_reviewer_smoke_fixture() if inputs is None else inputs
    if not isinstance(inputs, ReviewerSmokeFixture):
        raise TypeError("offline smoke inputs must be a ReviewerSmokeFixture")
    manifest = inputs.manifest
    firewall = validate_data_role_firewall(
        manifest,
        {"DISCOVERY-SMOKE": DataRole.DISCOVERY, "CONFIRMATION-SMOKE": DataRole.CONFIRMATION},
    )
    population_lineage = inputs.population_lineage
    atomic_folds = freeze_atomic_candidate_folds(
        inputs.atomic_universe,
        atomic_preoutcome_observations(inputs.atomic_observations),
        inputs.atomic_plan,
    )
    fci_parameters = dict(bootstrap_draws=10, bootstrap_seed=2026091801,
                          alpha=0.05, depth=-1, max_path_length=-1,
                          categorical_covariates=inputs.atomic_plan.covariate_names)
    study = StudyConfig(
        manifest, population_lineage, inputs.inference_plan, (inputs.atomic_plan.model_id,),
        ("atomic_full", "atomic_rd_only"), inputs.atomic_universe.top_k,
        inputs.atomic_total_block_slots, inputs.generation_call_limit,
        dict(universe=asdict(inputs.atomic_universe), selection_plan=asdict(inputs.atomic_plan),
             folds=asdict(atomic_folds), fci_parameters=fci_parameters),
    )
    # The backend writes informational text even with verbose=False; keep CLI JSON valid.
    with redirect_stdout(StringIO()):
        atomic_fci_evidence, fci_trace = run_atomic_fci_bootstrap(
            inputs.atomic_universe, inputs.atomic_observations, inputs.atomic_plan,
            fold_freeze=atomic_folds, **fci_parameters,
        )
    atomic = run_atomic_shadow_qualification(
        inputs.atomic_universe,
        inputs.atomic_observations,
        inputs.atomic_plan,
        atomic_fci_evidence,
        fold_freeze=atomic_folds,
    )
    sources = (
        FixedSlotSource(
            PolicyTrack.ATOMIC,
            "atomic_full",
            inputs.atomic_plan.model_id,
            inputs.atomic_universe.universe_id,
            atomic.full.slots,
            inputs.atomic_universe.model_bound_records,
        ),
        FixedSlotSource(
            PolicyTrack.ATOMIC,
            "atomic_rd_only",
            inputs.atomic_plan.model_id,
            inputs.atomic_universe.universe_id,
            atomic.rd_only.slots,
            inputs.atomic_universe.model_bound_records,
        ),
    )
    ledger = freeze_fixed_slot_ledger(PROTOCOL_ID, SCHEMA_VERSION, sources)
    union = freeze_shared_confirmation_union(ledger)
    protocol_records = {
        entry.candidate_record_id: content_id(
            "reviewer_smoke_protocol_record_", entry.candidate.policy_key
        )
        for entry in union.entries
    }
    dispatch = freeze_confirmation_dispatch(union, protocol_records)
    randomization_plan = TargetRandomizationPlan(
        PROTOCOL_ID,
        SCHEMA_VERSION,
        2026083107,
        2026083108,
        inputs.atomic_total_block_slots,
        tuple(
            sorted(
                (
                    (entry.candidate.policy_key, "reviewer-smoke-realization-1", 1.0)
                    for entry in union.entries
                )
            )
        ),
        tuple(
            sorted(
                (
                    (
                        entry.candidate.policy_key,
                        f"{entry.track.value}-smoke-task-{index:02d}",
                        "reviewer-smoke-stratum",
                    )
                    for entry in union.entries
                    for index in range(10)
                )
            )
        ),
    )
    task_bundles = inputs.task_bundles(dispatch, randomization_plan)
    assignments = randomize_target_confirmation(dispatch, randomization_plan, task_bundles)
    evaluator = {"model_id": inputs.atomic_plan.model_id}
    task_contract = dict(
        source_task_prompt=inputs.source_task_prompt,
        functional_contract={"requirements": [{"requirement_id": "fetch", "criterion": inputs.functional_requirement}],
                             "environment_dependencies": [], "language": "python"},
        functional_evaluator=evaluator, security_profile_id=inputs.security_profile_id,
        security_producer_sha256=security_profile_producer_sha256(),
    )
    confirmation = ConfirmationInputs(study.study_id, dispatch, randomization_plan, tuple(task_bundles),
        {"task_contracts": {b.task_instance_id: task_contract for b in task_bundles}})
    verify_confirmation_inputs(study, confirmation, assignments)
    measurements, measurement_records = [], []
    for assignment in assignments:
        prompt = inputs.variant_prompt(
            assignment.policy_key, assignment.task_unit_id, assignment.arm.value
        )
        if content_hash(prompt) != assignment.variant_sha256:
            raise ValueError("smoke generation prompt drifted from its assignment")
        request = {
            "model_id": assignment.model_id,
            "arm": assignment.arm.value,
            "task_unit_id": assignment.task_unit_id,
            "task_instance_id": assignment.task_instance_id,
            "provider_seed": assignment.provider_seed,
            "prompt": prompt,
        }
        measured, raw = measure_generated_code(
            assignment_id=assignment.assignment_id,
            generation_request=request,
            generation_evaluator=evaluator,
            generation_prompt=prompt,
            source_task_prompt=inputs.source_task_prompt,
            functional_contract=task_contract["functional_contract"],
            functional_evaluator=evaluator,
            functional_prompt="Blinded functional review.",
            security_profile_id=inputs.security_profile_id,
            complete=inputs.complete,
        )
        measurements.append(measured)
        raw.update(assignment_id=assignment.assignment_id, measurement=asdict(measured), functional_evaluator=evaluator)
        measurement_records.append(raw)
    measurement_ledger = close_target_measurements(
        assignments,
        measurements,
        study_id=study.study_id,
        randomization_id=randomization_plan.target_randomization_plan_id,
        adapter_bundle_id=content_id("target_reviewer_smoke_adapters_", "local"),
    )
    outcomes = derive_outcomes(measurement_ledger)
    evidence_ledger = freeze_assigned_arm_evidence(dispatch, assignments, outcomes)
    evidence = estimate_target_itt(
        evidence_ledger,
        inputs.inference_plan,
        evidence_level=EvidenceLevel.TESTED,
    )
    yields = build_target_selector_yields(evidence)
    written = write_target_result_bundle(output, study=study, confirmation=confirmation,
        evidence=evidence, yields=yields, measurement_records=measurement_records)
    return {
        "status": "TARGET_REVIEWER_SMOKE_VERIFIED",
        "protocol_status": "SPECIFIED_DRAFT",
        "schema_version": SCHEMA_VERSION,
        "protocol_id": PROTOCOL_ID,
        "stages": list(SMOKE_STAGES),
        "stage_count": len(SMOKE_STAGES),
        "fci_execution": fci_trace,
        "fci_evidence": asdict(atomic_fci_evidence),
        "fci_gates": [asdict(gate) for gate in atomic.fci_gates],
        "data_role_firewall_validation_id": firewall["firewall_validation_id"],
        "study_id": study.study_id,
        "assignment_count": len(assignments),
        "measurement_count": len(measurement_ledger.measurements),
        "outcome_count": len(outcomes),
        "provider_calls_made": 0,
        "evidence_level": evidence.evidence_level.value,
        "package_status": written["package_status"],
        "scientific_claim_allowed": written["scientific_claim_allowed"],
        "result_bundle_sha256": bundle_digest(output),
    }


def write_target_result_bundle(output: Path, *, study, confirmation, evidence, yields, measurement_records):
    """Store direct inputs and results; byte/semantic verification is performed once on readback."""
    from prompt_mechanism_study.verification import verify_target_shared_evidence, load_and_verify_target_result_bundle
    verification = verify_target_shared_evidence(evidence, yields)
    report = build_target_rq_tables(evidence, yields, verification=verification)
    write_bundle(output, {
        "study_config.json": study,
        "confirmation_inputs.json": confirmation,
        "measurement_records.json": {"records": measurement_records},
        "shared_evidence_record.json": evidence,
        "target_selector_yield_result.json": yields,
        "rq_tables.json": report,
    })
    return load_and_verify_target_result_bundle(output)
