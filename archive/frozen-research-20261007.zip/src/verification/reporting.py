"""Independent measurement, development-result and RQ-table reconstruction."""


from __future__ import annotations
from collections import Counter, defaultdict
from collections.abc import Mapping
from difflib import SequenceMatcher
import hashlib
from pathlib import Path
import ast
import itertools
import json
import math
import random
from prompt_mechanism_study.artifact_io import json_object, read_json, verify_bundle, bundle_digest
from prompt_mechanism_study.measurement.functional_judge import (
    build_review_request,
    code_syntax_valid,
    syntax_parser_identity,
    validate_review_response,
)
from prompt_mechanism_study.measurement.evaluate import Measurement
from prompt_mechanism_study.experiment.inference import ConfirmatoryEffectStatus, EvidenceLevel, SharedEvidenceRecord, TargetSelectorYieldResult
from prompt_mechanism_study.discovery.prioritization import PolicyTrack, SlotStatus
from prompt_mechanism_study.records import content_hash, content_id


def _exact_task_randomization_probability(differences, seed_count):
    # Group equal integer magnitudes and convolve their binomial counts.
    # This independently reconstructs the exact distribution without 2**N enumeration.
    observed = abs(round(sum(differences) * seed_count))
    distribution = {0: 1}
    for magnitude, count in Counter(abs(round(d * seed_count)) for d in differences).items():
        if magnitude == 0:
            continue
        group = {(2 * wins - count) * magnitude: math.comb(count, wins)
                 for wins in range(count + 1)}
        combined = defaultdict(int)
        for left, left_count in distribution.items():
            for right, right_count in group.items():
                combined[left + right] += left_count * right_count
        distribution = combined
    return sum(count for value, count in distribution.items() if abs(value) >= observed) / sum(distribution.values())


def verify_development_result(root: Path) -> dict:
    """Independently replay a small development result from all frozen assignments.

    Does not call the production renderer, outcome assembler or effect estimator.
    Security labels are checked against their saved trace, not certified as truth.
    Exact grouped convolution has no twenty-task enumeration limit.
    """
    verify_bundle(root / "preoutcome")
    verify_bundle(root / "summary")
    plan = read_json(root / "preoutcome/plan.json")
    assigned = read_json(root / "preoutcome/assignments.json")
    rows = read_json(root / "summary/assignments.json")
    report = read_json(root / "summary/report.json")
    effects = read_json(root / "summary/effects.json")

    def check(condition, message):
        if not condition:
            raise ValueError("development verification: " + message)

    check(
        plan["scientific_claim_allowed"] is False and report["scientific_claim_allowed"] is False,
        "development cannot authorize a scientific claim",
    )
    check(
        not any(c.get("kind") == "pair_interaction" for c in plan["analysis"]["contrasts"]),
        "Atomic contrasts only",
    )
    check(report["plan_sha256"] == content_hash(plan), "plan identity")
    check(
        report["preoutcome_bundle_sha256"] == bundle_digest(root / "preoutcome"),
        "preoutcome identity",
    )
    by_assignment = {row["assignment_id"]: row for row in rows}
    check(len(rows) == len(by_assignment) == len(assigned), "total assigned-arm accounting")
    tasks = {task["task_id"]: task for task in plan["tasks"]}
    prepared_prefixes = {}
    for task_id, task in tasks.items():
        if "generation_input" not in task:
            continue
        source = task["source_prompt"]
        language = task["language"]
        system = plan["generation_system_prompt"]
        request = {"language": language, "task": source.replace("<language>", language)}
        prefix = (
            "System message:\n"
            + system
            + "\n\nUser message:\nLanguage: "
            + language
            + "\n\nTask:\n"
        )
        baseline = prefix + request["task"]
        check(task["source_prompt_sha256"] == content_hash(source), "original source identity")
        check(
            task["generation_input"] == {"system_prompt": system, "request": request},
            "prepared messages",
        )
        check(
            task["prompt"] == baseline and task["prompt_sha256"] == content_hash(baseline),
            "baseline input evidence",
        )
        check(
            task["graph"]["prompt_sha256"] == content_hash(baseline),
            "TSG and generation baseline differ",
        )
        check(
            task["functional_contract"]["source_prompt_sha256"] == content_hash(baseline),
            "functional baseline differs",
        )
        prepared_prefixes[task_id] = prefix
    policies = {policy["policy_id"]: policy for policy in plan["policies"]}
    seeds = set(plan["generation_seeds"])
    coordinates = {(row["task_id"], row["arm"], row["seed"]) for row in assigned}
    check(
        coordinates == set(itertools.product(tasks, plan["arms"], seeds)),
        "complete task/arm/seed blocks",
    )
    provider_calls = 0
    for allocation in assigned:
        key = allocation["assignment_id"]
        check(key in by_assignment, "assigned outcome missing")
        row = by_assignment[key]
        check(
            all((row[field] == value for field, value in allocation.items())),
            "assignment metadata changed",
        )
        core = {field: value for field, value in allocation.items() if field != "assignment_id"}
        check(key == content_id("development_assignment_", core), "assignment identity")
        task, policy = (tasks[row["task_id"]], policies[row["policy_id"]])
        check(
            row["task_unit_id"] == task["task_unit_id"] and row["binding_id"] == task["binding_id"],
            "task unit or binding changed",
        )
        if task.get("factor_scopes"):
            check(
                row.get("factor_scopes") == task["factor_scopes"], "assigned factor scope changed"
            )
            prompt = _replay_scoped_development_prompt(task, policy, row["arm"], check)
        else:
            operation = next(
                (
                    node
                    for node in task["graph"]["nodes"]
                    if node["node_id"] == task["target_operation_node_id"]
                )
            )
            subject_id = task.get("target_subject_node_id")
            input_scope = ""
            if subject_id is not None:
                check(row.get("target_subject_node_id") == subject_id, "assigned subject changed")
                subject = next(
                    (node for node in task["graph"]["nodes"] if node["node_id"] == subject_id), None
                )
                check(
                    subject is not None and subject["node_type"] == "data_object",
                    "subject is not a source data object",
                )
                check(
                    any(
                        (
                            edge["source_id"] == subject_id
                            and edge["target_id"] == operation["node_id"]
                            and (edge["edge_type"] == "used_by")
                            for edge in task["graph"]["edges"]
                        )
                    ),
                    "subject does not supply the assigned operation",
                )
                input_scope = (
                    "For the input described by "
                    + json.dumps(
                        task["prompt"][subject["evidence_start"] : subject["evidence_end"]],
                        ensure_ascii=False,
                    )
                    + ": "
                )
                definition = policy.get("factor_definition", {})
                check(
                    definition.get("semantic_decisions") == [policy["feature_id"]]
                    and definition.get("atomicity_review") == "SOURCE_REVIEWED_SINGLE_REQUIREMENT",
                    "single-requirement review missing",
                )
            prompt = task["prompt"]
            if row["arm"] != "BASELINE":
                text = (
                    policy["addition"]
                    if row["arm"] == "TARGET"
                    else task["control_texts"][row["arm"]]
                )
                prompt += (
                    "\n\nFor the operation described by "
                    + json.dumps(
                        task["prompt"][operation["evidence_start"] : operation["evidence_end"]],
                        ensure_ascii=False,
                    )
                    + ":\n- "
                    + input_scope
                    + text
                )
        check(
            row["prompt"] == prompt and row["prompt_sha256"] == content_hash(prompt),
            "rendered treatment or control changed",
        )
        case = root / "cases" / key
        verify_bundle(case)
        check(
            read_json(case / "result.json") == row, "summary differs from per-assignment evidence"
        )
        calls = read_json(case / "calls.json")
        provider_calls += len(calls)
        check(
            len(calls) == row["provider_calls"] and 1 <= len(calls) <= 2, "provider call accounting"
        )
        if row["task_id"] in prepared_prefixes:
            prefix = prepared_prefixes[row["task_id"]]
            check(prompt.startswith(prefix), "common input context changed")
            check(
                calls[0]["request"]
                == {"language": task["language"], "task": prompt[len(prefix) :]},
                "actual provider input differs from the represented arm",
            )
        else:
            check(calls[0]["request"]["task"] == prompt, "actual provider prompt changed")
        check(
            calls[0]["request"].get("language") == task["language"],
            "actual generation language changed",
        )
        check(
            calls[0]["evaluator"] == {**plan["generator"], "seed": row["seed"]},
            "actual generator identity or seed changed",
        )
        check(
            calls[0]["system_prompt"] == plan["generation_system_prompt"],
            "actual generator system prompt changed",
        )
        if len(calls) == 2:
            functional = calls[1]["request"]
            check(
                functional["functional_task"] == task["prompt"],
                "functional judge received a treated source",
            )
            check(
                not {"arm", "model_id", "security_status", "policy_id"} & set(functional),
                "functional blindness",
            )
            check(
                calls[1]["evaluator"] == plan["functional_evaluator"]
                and calls[1]["system_prompt"] == plan["functional_system_prompt"],
                "functional measurement policy changed",
            )
        if row["error"] is not None:
            check(
                row["secure_code_yield"] is None and row["code_valid"] is None,
                "failed allocation silently imputed",
            )
            continue
        raw = calls[0]["response"]
        generated = json.loads(raw)
        check(
            set(generated) == {"code"} and generated["code"] == row["code"],
            "generated code changed",
        )
        try:
            ast.parse(row["code"])
            valid = int(bool(row["code"].strip()))
        except SyntaxError:
            valid = 0
        check(row["code_valid"] == valid, "code-validity outcome")
        check(
            row["measurement"]["generator_evidence_sha256"]
            == hashlib.sha256(raw.encode()).hexdigest(),
            "raw response hash",
        )
        if valid:
            evidence = row["measurement_evidence"]
            states = {fact["state"] for fact in evidence["security"]["decision"]["trace"]["facts"]}
            security = (
                "insecure"
                if "unsafe" in states
                else "unknown" if not states or "unresolved" in states else "secure"
            )
            check(
                row["security_status"] == security == evidence["security"]["security_label"],
                "security trace aggregation",
            )
            check(
                evidence["code"] == row["code"]
                and row["measurement"]["code_sha256"] == content_hash(row["code"]),
                "measured code identity",
            )
            check(
                evidence["functional_response"] == calls[1].get("response"),
                "functional response changed",
            )
            if evidence.get("functional_failure") is not None:
                check(
                    evidence["functional_validated"]
                    == {
                        "status": "unknown",
                        "reason": "functional_evaluator_failed",
                        "failure": evidence["functional_failure"],
                    },
                    "failed functional evaluator was relabelled",
                )
                verdict = "unknown"
                if "response" in calls[1]:
                    try:
                        validate_review_response(calls[1]["response"].encode(), row["code"])
                    except ValueError:
                        pass
                    except RuntimeError:
                        pass
                    else:
                        raise ValueError(
                            "development verification: valid functional response marked as failure"
                        )
                else:
                    check("error" in calls[1], "functional failure lacks raw evidence")
            else:
                verdict = json.loads(calls[1]["response"])["verdict"]
            check(row["functionality_status"] == verdict, "functional verdict changed")
            check(
                calls[1]["request"]["program_lines"]
                == [
                    {"line_number": n, "text": line}
                    for n, line in enumerate(row["code"].splitlines(), 1)
                ],
                "functional judge received different code",
            )
            f = {"pass": 1, "fail": 0, "unknown": None}[verdict]
            secure = int(security == "secure")
            evaluable = int(security != "unknown")
            joint = (
                0
                if f == 0 or security == "insecure"
                else None if f is None or security == "unknown" else 1
            )
        else:
            secure, evaluable, f, joint = (0, 0, 0, 0)
        check(
            (row["secure_code_yield"], row["oracle_evaluable"], row["functionality"], row["joint"])
            == (secure, evaluable, f, joint),
            "endpoint decomposition",
        )
    check(
        report["provider_calls"] == provider_calls and report["assigned_rows"] == len(rows),
        "report accounting",
    )
    check(
        report["failed_rows"] == sum((row["error"] is not None for row in rows)),
        "failed rows hidden",
    )
    check(len(effects) == len(plan["analysis"]["contrasts"]), "multiplicity family changed")
    probabilities = []
    for comparison, effect in zip(plan["analysis"]["contrasts"], effects, strict=True):
        policy = comparison["policy_id"]
        left, right = (comparison["treatment"], comparison["control"])
        weights, label = ({left: 1, right: -1}, left + " - " + right)
        local = [row for row in rows if row["policy_id"] == policy]
        units = sorted({row["task_unit_id"] for row in local})
        check(
            effect["policy_id"] == policy
            and effect["comparison"] == label
            and (effect["task_units"] == len(units)),
            "contrast or denominator changed",
        )
        cell = [row for row in local if row["arm"] in weights]
        if not units or any((row["error"] is not None for row in cell)):
            check(
                effect["effect"] is None
                and effect["p_value"] is None
                and (not effect["development_signal"]),
                "missing outcomes did not block their contrast",
            )
            probabilities.append(1.0)
            continue
        differences = []
        for unit in units:
            means = {
                arm: sum(
                    (
                        row["secure_code_yield"]
                        for row in local
                        if row["task_unit_id"] == unit and row["arm"] == arm
                    )
                )
                / len(seeds)
                for arm in weights
            }
            differences.append(sum((means[arm] * weight for arm, weight in weights.items())))
        p = _exact_task_randomization_probability(differences, len(seeds))
        probabilities.append(p)
        check(abs(effect["effect"] - sum(differences) / len(units)) < 1e-12, "task estimate")
        check(abs(effect["p_value"] - p) < 1e-12, "exact task test")
        rng = random.Random(plan["analysis"]["bootstrap_seed"])
        draws = sorted(
            (
                sum((differences[rng.randrange(len(units))] for _ in range(len(units))))
                / len(units)
                for _ in range(plan["analysis"]["bootstrap_draws"])
            )
        )
        bounds = [draws[math.ceil(q * len(draws)) - 1] for q in (0.025, 0.975)]
        check([effect["ci_low"], effect["ci_high"]] == bounds, "descriptive bootstrap interval")
    adjusted = 0.0
    for rank, index in enumerate(
        sorted(range(len(effects)), key=lambda index: probabilities[index])
    ):
        adjusted = max(adjusted, min(1.0, (len(effects) - rank) * probabilities[index]))
        if effects[index]["p_value"] is not None:
            check(effects[index]["adjusted_p_value"] == adjusted, "Holm family adjustment")
    analysis = plan["analysis"]
    screening = analysis["method"] == "paired_task_effect_screen_v1"
    for effect in effects:
        expected_signal = effect["effect"] is not None and (
            effect["effect"] >= analysis["minimum_effect"] if screening else
            effect["adjusted_p_value"] <= analysis["alpha"] and abs(effect["effect"]) >= analysis["minimum_effect"])
        check(effect["development_signal"] == expected_signal, "development screening rule")
    if screening:
        comparison = "TARGET - " + analysis.get("screening_control", "NOOP")
        ranked = sorted((e for e in effects if e["development_signal"] and e["comparison"] == comparison),
                        key=lambda e: (-(e["task_units"] * e["effect"]), e["policy_id"]))
        selected = {e["policy_id"] for e in ranked[:analysis["top_k"]]}
        for effect in effects:
            coverage = effect["task_units"] / analysis["screening_task_units"]
            score = coverage * effect["effect"] if effect["effect"] is not None else None
            check(effect["coverage"] == coverage and effect["screening_score"] == score,
                  "screening coverage or score")
            check(effect["screening_selected"] == (effect["policy_id"] in selected and effect["comparison"] == comparison), "screening Top-K")
            check(effect["screening_rule"] == "positive_gain_and_coverage_no_significance_gate", "screening label")
    return {
        "status": "VERIFIED_NON_CLAIM_DEVELOPMENT_RESULT",
        "task_units": len(tasks),
        "assigned_rows": len(assigned),
        "provider_calls": provider_calls,
        "failed_rows": report["failed_rows"],
        "effect_rows": len(effects),
        "scientific_claim_allowed": False,
        "summary_bundle_sha256": bundle_digest(root / "summary"),
        "input_alignment_status": (
            "PREPARED_BASELINE_INPUTS_VERIFIED"
            if len(prepared_prefixes) == len(tasks)
            else "LEGACY_SOURCE_ONLY_REPRESENTATION"
        ),
        "limitation": "Replays frozen accounting, inputs, labels and statistics; does not establish Oracle accuracy or a scientific effect.",
    }


def _replay_scoped_development_prompt(task, policy, arm, check):
    """Independent exact-scope replay; no production binding or rendering calls."""
    graph, source = (task["graph"], task["prompt"])
    nodes = {node["node_id"]: node for node in graph["nodes"]}
    edges = {(edge["source_id"], edge["edge_type"], edge["target_id"]) for edge in graph["edges"]}
    factors = policy["factors"] if "factors" in policy else [{**policy, "operation": "add"}]
    scopes = task["factor_scopes"]
    flags = (arm == "TARGET",)
    check(len(scopes) == len(factors) == len(flags), "factor coordinates")
    compatibility = task.get("intervention_compatibility", {})
    check(
        compatibility.get("binding_id") == task["binding_id"]
        and compatibility.get("decision") == "compatible"
        and (compatibility.get("outcomes_used") is False),
        "source intervention compatibility",
    )
    instructions, removals = ([], [])
    for index, (factor, scope, active) in enumerate(zip(factors, scopes, flags, strict=True)):
        op = scope["operation_node_id"]
        check(op in nodes and nodes[op]["node_type"] in {"task_operation", "task"}, "scope operation")
        check(
            all(
                (
                    (nodes[op]["node_type"] == "task" or (key, "used_by", op) in edges)
                    and nodes[key]["node_type"] == "data_object"
                    for key in scope["subject_node_ids"]
                )
            ),
            "scope subjects",
        )
        matched = [
            item
            for item in graph["scoped_feature_assessments"]
            if item["scope"] == scope and item["feature_id"] == factor["feature_id"]
        ]
        check(
            len(matched) == 1
            and matched[0]["state"] == ("absent" if factor["operation"] == "add" else "present"),
            "exact source-state gate",
        )
        if arm == "BASELINE":
            continue
        if active and factor["operation"] == "remove":
            if arm in task.get("reviewed_variants", {}):
                continue
            requirements = matched[0]["requirement_node_ids"]
            check(len(requirements) == 1, "literal REMOVE requirement")
            key = requirements[0]
            node = nodes[key]
            check(
                all(
                    (
                        target in {op, *scope["subject_node_ids"]}
                        for origin, _, target in edges
                        if origin == key
                    )
                ),
                "literal REMOVE changes another object",
            )
            check(
                not any(
                    (
                        other["scope"] != scope and key in other["requirement_node_ids"]
                        for other in graph["scoped_feature_assessments"]
                    )
                ),
                "literal REMOVE changes another scope",
            )
            check(
                not any(
                    (
                        other["node_id"] != key
                        and other["node_type"] != "task"
                        and (
                            max(node["evidence_start"], other["evidence_start"])
                            < min(node["evidence_end"], other["evidence_end"])
                        )
                        for other in nodes.values()
                    )
                ),
                "literal REMOVE overlaps non-target evidence",
            )
            removals.append((node["evidence_start"], node["evidence_end"]))
            continue
        if active:
            text = factor["addition"]
        else:
            controls = task["factor_control_texts"] if "factor_control_texts" in task else [task["control_texts"]]
            text = controls[index][arm]

        def quote(key):
            return json.dumps(
                source[nodes[key]["evidence_start"] : nodes[key]["evidence_end"]],
                ensure_ascii=False,
            )

        prefix = ""
        if scope["subject_node_ids"]:
            prefix = (
                "For the input described by "
                if len(scope["subject_node_ids"]) == 1
                else "For the inputs described by "
            )
            prefix += ", ".join((quote(key) for key in scope["subject_node_ids"])) + ": "
        if scope["condition_node_ids"]:
            prefix += (
                "Under the unchanged source conditions "
                + ", ".join((quote(key) for key in scope["condition_node_ids"]))
                + ": "
            )
        instructions.append((op, prefix + text))
    if arm in task.get("reviewed_variants", {}):
        variant = task["reviewed_variants"][arm]
        check(
            variant["binding_id"] == task["binding_id"]
            and variant["source_prompt_sha256"] == content_hash(source)
            and (variant["enabled"] == list(flags))
            and (variant["source_review"]["outcomes_used"] is False),
            "reviewed realization binding",
        )
        mapped = variant["source_to_variant_nodes"]
        rewritten = {node["node_id"]: node for node in variant["graph"]["nodes"]}
        target_requirements = {
            key
            for item in graph["scoped_feature_assessments"]
            if any(
                (
                    item["scope"] == scope and item["feature_id"] == factor["feature_id"]
                    for factor, scope in zip(factors, scopes, strict=True)
                )
            )
            for key in item["requirement_node_ids"]
        }
        kept = _verify_reviewed_edit_projection(
            graph, variant, source, policy, scopes, flags, target_requirements, check)
        unchanged = None
        for key, before in nodes.items():
            if key not in kept:
                continue
            check(
                key in mapped and mapped[key] in rewritten,
                "reviewed realization drops a non-target node",
            )
            after = rewritten[mapped[key]]
            citation_preserved = (
                source[before["evidence_start"] : before["evidence_end"]]
                == variant["prompt"][after["evidence_start"] : after["evidence_end"]]
            )
            if not citation_preserved:
                if unchanged is None:
                    unchanged = SequenceMatcher(a=source, b=variant["prompt"], autojunk=False).get_matching_blocks()
                for block in unchanged:
                    offset = block.b - block.a
                    if (block.a <= before["evidence_start"] < before["evidence_end"] <= block.a + block.size
                        and block.b <= after["evidence_start"] < after["evidence_end"] <= block.b + block.size
                        and before["evidence_start"] + offset < after["evidence_end"]
                        and after["evidence_start"] < before["evidence_end"] + offset):
                        citation_preserved = True
                        break
            check(
                before["semantic_id"] == after["semantic_id"]
                and before["node_type"] == after["node_type"]
                and citation_preserved,
                "reviewed realization changes a non-target requirement",
            )
        scope_map = {**mapped,
            next(n['node_id'] for n in graph['nodes'] if n['node_type']=='task'):
            next(n['node_id'] for n in variant['graph']['nodes'] if n['node_type']=='task')}
        check(len(variant['graph']['scoped_feature_assessments']) == len(graph['scoped_feature_assessments']),
              'reviewed realization extra scope state')
        for item in graph["scoped_feature_assessments"]:
            scope = item["scope"]
            translated = dict(
                operation_node_id=scope_map[scope["operation_node_id"]],
                subject_node_ids=sorted((scope_map[key] for key in scope["subject_node_ids"])),
                condition_node_ids=sorted((scope_map[key] for key in scope["condition_node_ids"])),
            )
            expected_state = item["state"]
            for factor, target_scope, active in zip(factors, scopes, flags, strict=True):
                if scope == target_scope and item["feature_id"] == factor["feature_id"] and active:
                    expected_state = "present" if factor["operation"] == "add" else "absent"
            matches = [
                row
                for row in variant["graph"]["scoped_feature_assessments"]
                if row["scope"] == translated and row["feature_id"] == item["feature_id"]
            ]
            check(
                len(matches) == 1 and matches[0]["state"] == expected_state,
                "reviewed realization scope states",
            )
        return variant["prompt"]
    result = source
    for start, end in sorted(set(removals), reverse=True):
        result = result[:start] + result[end:]
    for op in dict.fromkeys((key for key, _ in instructions)):
        node = nodes[op]
        result += (
            "\n\nFor the operation described by "
            + json.dumps(source[node["evidence_start"] : node["evidence_end"]], ensure_ascii=False)
            + ":\n"
        )
        result += "\n".join(("- " + text for key, text in instructions if key == op))
    return result


def _verify_reviewed_edit_projection(graph, variant, source, policy, scopes, flags, owners, check):
    """Independently check a reviewed edit's keep/change boundary on raw records.

    This intentionally does not call the production editor or its ownership helper.
    Source review supplies semantic judgments; this checks their mechanical limits.
    """
    requirement_types = {"task_requirement", "safety_requirement", "constraint", "presentation_control"}
    target = variant['graph']
    mapping = variant['source_to_variant_nodes']
    old = {n['node_id']:n for n in graph['nodes'] if n['node_type'] != 'task'}
    new = {n['node_id']:n for n in target['nodes'] if n['node_type'] != 'task'}
    query = policy.get('query',{})
    meanings = sorted(query.get('required_semantics',[]))
    graph_edges = {(e['source_id'],e['edge_type'],e['target_id']) for e in graph['edges']}
    anchors = {s['operation_node_id'] for s in scopes}
    source_context = set()
    for values in itertools.product(*[[n['node_id'] for n in graph['nodes'] if n['semantic_id']==meaning]
                                       for meaning in meanings]):
        match = dict(zip(meanings,values))
        if anchors & set(values) and all((match[a],k,match[b]) in graph_edges for a,k,b in query.get('required_relations',[])):
            source_context.update(values)
    feature = policy['factors'][0]['feature_id']
    original_root = next(n['node_id'] for n in graph['nodes'] if n['node_type']=='task')
    target_root = next(n['node_id'] for n in target['nodes'] if n['node_type']=='task')
    coordinate_map = {**mapping,original_root:target_root}
    target_context = {coordinate_map[key] for key in source_context if key in coordinate_map}
    assigned_scopes = [dict(operation_node_id=coordinate_map.get(s['operation_node_id']),
        subject_node_ids=sorted(coordinate_map.get(k,'') for k in s['subject_node_ids']),
        condition_node_ids=sorted(coordinate_map.get(k,'') for k in s['condition_node_ids'])) for s in scopes]
    target_owners = {key for row in target.get('scoped_feature_assessments', [])
                     if row['feature_id'] == feature and row['scope'] in assigned_scopes for key in row['requirement_node_ids']}

    def owned_records(g, roots):
        result = set(roots)
        while True:
            expanded = result | {child for key,_,children in g.get('requirement_structures', [])
                                 if key in result for child in children}
            if expanded == result: break
            result = expanded
        by_id = {n['node_id']:n for n in g['nodes']}
        for n in g['nodes']:
            if n['node_type'] != 'condition': continue
            outgoing = [(e['edge_type'], e['target_id']) for e in g['edges'] if e['source_id'] == n['node_id']]
            within = any(by_id[p]['node_type'] in requirement_types
                         and by_id[p]['evidence_start'] <= n['evidence_start'] <= n['evidence_end'] <= by_id[p]['evidence_end']
                         for p in result)
            if within and outgoing and all(k == 'conditions' and dest in result for k,dest in outgoing):
                result.add(n['node_id'])
        return result

    source_owned, target_owned = owned_records(graph, owners), owned_records(target, target_owners)
    scope_review = variant['source_review'].get('edit_scope', {})
    check(isinstance(scope_review, dict) and not set(scope_review)-{
        'source_nodes','variant_nodes','source_edges','variant_edges'}, 'local edit scope fields')
    for side,g,prompt,owned in (('source',graph,source,source_owned),('variant',target,variant['prompt'],target_owned)):
        node_rows = {n['node_id']:n for n in g['nodes']}
        edge_rows = {e['edge_id']:e for e in g['edges']}
        decisions = {}
        for kind, rows in (('nodes',node_rows),('edges',edge_rows)):
            declared = scope_review.get(side+'_'+kind,{})
            check(isinstance(declared,dict), 'local edit declarations')
            for key,review in declared.items():
                check(key in rows and isinstance(review,dict) and set(review)=={
                    'status','source_evidence','rationale'}, 'local edit declaration identity')
                if kind=='edges':
                    e = rows[key]
                    check(not (node_rows[e['source_id']]['node_type']=='task'
                               and e['edge_type'] in {'contains','requires'}), 'root membership is compiled structure')
                check(review['status'] in {'policy_only','shared','unresolved'}
                      and isinstance(review['rationale'],str) and bool(review['rationale'].strip()), 'local edit judgment')
                evidence = review['source_evidence']
                check(isinstance(evidence,list) and bool(evidence), 'local edit support evidence')
                for span in evidence:
                    check(isinstance(span,dict) and set(span)=={'start','end'}
                          and type(span['start']) is int and type(span['end']) is int
                          and 0 <= span['start'] < span['end'] <= len(prompt)
                          and bool(prompt[span['start']:span['end']].strip()), 'local edit evidence bounds')
            decisions[kind] = {key for key,r in declared.items() if r['status']=='policy_only'}
        mutable, mutable_edges = decisions['nodes'],decisions['edges']
        active = flags[0] and policy['factors'][0]['operation']==('remove' if side=='source' else 'add')
        check(active or not (mutable or mutable_edges), 'inactive or wrong-side edit permission')
        check(all(node_rows[key]['node_type'] in {'task_operation','data_object'} for key in mutable), 'mutable fact type')
        context = source_context if side=='source' else target_context
        protected = set(context)
        protected.update(key for row in g.get('scoped_feature_assessments', [])
                         for key in (row['scope']['operation_node_id'], *row['scope']['subject_node_ids'], *row['scope']['condition_node_ids']))
        protected.update(e['target_id'] for e in g['edges']
                         if e['source_id'] not in owned and node_rows[e['source_id']]['node_type'] in requirement_types)
        protected.update(x for owner,a,_,b in g.get('requirement_relations', []) if owner not in owned for x in (a,b))
        protected.update(x for owner,_,boundaries,_ in g.get('requirement_scopes', []) if owner not in owned for x in boundaries)
        protected.update(x for e in g['edges'] if e['edge_type']=='precedes'
                         or any(node_rows[k]['node_type']=='condition' and k not in owned for k in (e['source_id'],e['target_id']))
                         for x in (e['source_id'],e['target_id']))
        check(not mutable & protected, 'local edit releases shared or background support')
        relevant = set(context) | owned
        relevant.update(x for owner,a,_,b in g.get('requirement_relations', []) if owner in owned for x in (a,b))
        relevant.update(x for e in g['edges'] if e['source_id'] in owned or e['target_id'] in owned for x in (e['source_id'],e['target_id']))
        for key,review in scope_review.get(side+'_nodes',{}).items():
            check(review['status']!='unresolved' or key not in relevant, 'local edit unresolved support')
        for key,review in scope_review.get(side+'_edges',{}).items():
            e = edge_rows[key]
            check(review['status']!='unresolved' or not {e['source_id'],e['target_id']} & (relevant|mutable), 'local edit unresolved support')
        semantics = {node_rows[key]['semantic_id'] for key in mutable | relevant}
        check(not (scope_review and flags[0]) or not semantics & set(g.get('unresolved_semantics', [])), 'local edit unresolved dependency')
        check(not any(a in semantics or b in semantics for a,_,b in g.get('unresolved_relations', []))
              or not (scope_review and flags[0]), 'local edit unresolved relation')
        incident = {key for key,e in edge_rows.items()
                    if {e['source_id'],e['target_id']} & mutable
                    and e['source_id'] not in owned and e['target_id'] not in owned
                    and not (node_rows[e['source_id']]['node_type']=='task'
                             and e['edge_type'] in {'contains','requires'} and e['target_id'] in mutable)}
        check(incident == mutable_edges, 'local edit incident relation accounting')
        check(all(edge_rows[key]['edge_type'] in {'used_by','produces'} for key in mutable_edges), 'local edit independent relation')
        connected = {e['target_id'] for e in g['edges'] if e['source_id'] in owned and e['edge_type']=='constrains'}
        connected.update(x for owner,a,_,b in g.get('requirement_relations', []) if owner in owned for x in (a,b))
        while True:
            expanded = connected | {x for key in mutable_edges for x in (edge_rows[key]['source_id'],edge_rows[key]['target_id'])
                                   if {edge_rows[key]['source_id'],edge_rows[key]['target_id']} & connected}
            if expanded == connected: break
            connected = expanded
        check(mutable <= connected, 'local edit disconnected fact')
        exempt_edges = mutable_edges | {key for key,e in edge_rows.items()
            if node_rows[e['source_id']]['node_type']=='task' and e['edge_type'] in {'contains','requires'}
            and e['target_id'] in mutable}
        if side=='source': released,source_exempt_edges = mutable,exempt_edges
        else: introduced,target_exempt_edges = mutable,exempt_edges

    kept = set(old)-source_owned-released
    check(kept <= set(mapping) <= set(old) and len(set(mapping.values()))==len(mapping)
          and set(mapping.values())<=set(new), 'reviewed realization node correspondence')
    check(not released & set(mapping) and not introduced & set(mapping.values()), 'local edit facts must change sides')
    retained = {mapping[key] for key in kept}
    old_root = next(n['node_id'] for n in graph['nodes'] if n['node_type']=='task')
    new_root = next(n['node_id'] for n in target['nodes'] if n['node_type']=='task')
    translated = {**mapping,old_root:new_root}
    old_edges = {(translated[e['source_id']],e['edge_type'],translated[e['target_id']]) for e in graph['edges']
                 if not {e['source_id'],e['target_id']} & source_owned and e['edge_id'] not in source_exempt_edges}
    neutral = set(variant.get('neutral_control_nodes',{}).values())
    new_edges = {(e['source_id'],e['edge_type'],e['target_id']) for e in target['edges']
                 if not {e['source_id'],e['target_id']} & (target_owned|neutral) and e['edge_id'] not in target_exempt_edges}
    check(old_edges==new_edges, 'reviewed realization non-target edges')
    check({(mapping[o],translated[a],k,translated[b]) for o,a,k,b in graph.get('requirement_relations',[]) if o in kept}
          == {(o,a,k,b) for o,a,k,b in target.get('requirement_relations',[]) if o in retained}, 'reviewed realization owned order')
    check({(mapping[o],kind,tuple(sorted(mapping[x] for x in children))) for o,kind,children in graph.get('requirement_structures',[]) if o in kept}
          == {(o,kind,tuple(children)) for o,kind,children in target.get('requirement_structures',[]) if o in retained}, 'reviewed realization composition')
    check({(mapping[o],kind,tuple(sorted(translated[x] for x in bounds)),cls) for o,kind,bounds,cls in graph.get('requirement_scopes',[]) if o in kept}
          == {(o,kind,tuple(bounds),cls) for o,kind,bounds,cls in target.get('requirement_scopes',[]) if o in retained}, 'reviewed realization scope')
    check(set(new) <= retained | target_owned | introduced | neutral, 'reviewed realization unaccounted new node')
    return kept


from prompt_mechanism_study.verification.effects import verify_target_shared_evidence
from prompt_mechanism_study.verification.integrity import _decode_target_value
from prompt_mechanism_study.measurement.security_profiles import (
    evaluate_security_profile,
    security_profile_producer_sha256,
)


def _replay_execution_measurements(evidence, contract, raw) -> dict[str, object]:
    """Reconstruct outcomes from raw code and independent evaluator records."""
    if not isinstance(raw, Mapping) or not isinstance(raw.get("records"), list):
        raise ValueError("execution provider ledger requires assignment records")
    rows = raw["records"]
    if any(not isinstance(row, Mapping) for row in rows):
        raise ValueError("execution provider ledger contains an invalid record")
    by_id = {row.get("assignment_id"): row for row in rows}
    if len(by_id) != len(rows) or set(by_id) != {a.assignment_id for a in evidence.ledger.assignments}:
        raise ValueError("execution records must cover every assignment exactly once")
    outcomes = {item.assignment_id: item for item in evidence.ledger.outcomes}
    failures = {item.assignment_id: item for item in evidence.ledger.infrastructure_failures}
    task_contracts = contract.get("task_contracts")
    if not isinstance(task_contracts, Mapping):
        raise ValueError("execution measurement contract lacks frozen task contracts")
    calls = 0
    for assignment in evidence.ledger.assignments:
        row = by_id[assignment.assignment_id]
        request = row.get("generation_request")
        if not isinstance(request, Mapping) or (
            request.get("model_id") != assignment.model_id
            or request.get("arm") != assignment.arm.value
            or request.get("task_unit_id") != assignment.task_unit_id
            or request.get("task_instance_id") != assignment.task_instance_id
            or "provider_seed" not in request
            or request["provider_seed"] != assignment.provider_seed
            or not isinstance(request.get("prompt"), str)
            or content_hash(request["prompt"]) != assignment.variant_sha256
        ):
            raise ValueError("execution request model/arm/task/prompt/seed binding failed")
        if assignment.assignment_id in failures:
            failure = failures[assignment.assignment_id]
            if (
                row.get("status") != "infrastructure_failure"
                or row.get("producer") != failure.producer or row.get("reason") != failure.reason
                or not isinstance(row.get("error_response"), str) or not row["error_response"]
            ):
                raise ValueError("execution infrastructure failure lacks its original error")
            continue
        frozen = task_contracts.get(assignment.task_instance_id)
        if not isinstance(frozen, Mapping):
            raise ValueError("execution task lacks its frozen measurement contract")
        measurement = _decode_target_value(row.get("measurement"), Measurement, "execution measurement")
        if measurement.assignment_id != assignment.assignment_id:
            raise ValueError("execution measurement assignment binding failed")
        response = row.get("generation_response")
        if not isinstance(response, str):
            raise ValueError("execution generation response is missing")
        decoded = json_object(response)
        if set(decoded) != {"code"} or not isinstance(decoded["code"], str):
            raise ValueError("execution generation response schema mismatch")
        code = decoded["code"]
        calls += 1
        if (
            hashlib.sha256(response.encode("utf-8")).hexdigest() != measurement.generator_evidence_sha256
            or row.get("code") != code
            or measurement.code_sha256 != (content_hash(code) if code else None)
        ):
            raise ValueError("execution response/code digest failed independent replay")
        function_contract = frozen.get("functional_contract")
        if not isinstance(function_contract, Mapping):
            raise ValueError("execution functional contract is missing")
        language = function_contract.get("language", "python")
        profile_id = frozen.get("security_profile_id")
        if ("source_prompt_sha256" in function_contract
                and function_contract["source_prompt_sha256"] != content_hash(frozen.get("source_task_prompt"))):
            raise ValueError("execution functional contract source prompt binding differs")
        if (request.get("language", language) != language
                or not isinstance(profile_id, str)
                or not profile_id.startswith(language + ".")):
            raise ValueError("execution source, generation and Oracle languages differ")
        if row.get("syntax_parser") != syntax_parser_identity(language):
            raise ValueError("execution syntax parser identity failed independent replay")
        valid = bool(code.strip()) and code_syntax_valid(code, language)
        status = "valid" if valid else "invalid" if code.strip() else "no_code"
        if measurement.code_status.value != status or row.get("syntax_valid") is not valid:
            raise ValueError("execution code validity failed independent replay")
        scope = function_contract.get("measurement_scope", "complete")
        source_review = function_contract.get("review", {})
        if scope not in {"complete", "partial", "unresolved"} or not isinstance(source_review, Mapping):
            raise ValueError("execution functional source scope is invalid")
        specification = source_review.get("source_specification_disposition")
        if specification not in {None, "sufficient", "insufficient", "defect"}:
            raise ValueError("execution functional source review status is invalid")
        inherited = function_contract.get("parent_contract_applies_to_current_input", True)
        if type(inherited) is not bool:
            raise ValueError("execution parent contract applicability is invalid")
        if not inherited or specification == "defect" or not function_contract.get("requirements"):
            scope = "unresolved"
        elif specification == "insufficient" and scope == "complete":
            scope = "partial"
        if row.get("functional_source_scope") != scope:
            raise ValueError("execution functional scope failed independent replay")
        review_policy = row.get("functional_review_policy")
        if review_policy not in {None, "judge_all_syntax_valid_source_scopes"}:
            raise ValueError("execution functional review policy is invalid")
        if not valid:
            expected = (0, 0, 0, 0, 0, 0, 0, status)
            if any(row.get(key) is not None for key in ("security", "functional_response")):
                raise ValueError("execution terminal code contains evaluator output")
        else:
            if frozen.get("security_producer_sha256") != security_profile_producer_sha256():
                raise ValueError("execution security producer drifted from its qualification")
            security = evaluate_security_profile(code, frozen.get("security_profile_id"))
            if row.get("security") != security or measurement.oracle_evidence_sha256 != content_hash(security):
                raise ValueError("execution security measurement failed local replay")
            if review_policy is None and scope != "complete":
                # Replay frozen pre-revision records; active measurement always calls the judge.
                functional = {
                    "status": "unknown", "reason": "source_functional_specification_incomplete",
                    "measurement_scope": scope,
                    "source_contract_sha256": content_hash(function_contract),
                }
                if any(row.get(key) is not None for key in
                       ("functional_request", "functional_response", "functional_response_sha256")):
                    raise ValueError("incomplete source cannot yield a full functional judge result")
                functional_digest = content_hash(functional)
            else:
                expected_request = build_review_request(
                    code, frozen.get("source_task_prompt"),
                    requirements=function_contract.get("requirements", []) if inherited else [],
                    environment_dependencies=function_contract.get("environment_dependencies", []) if inherited else [],
                    language=language,
                    source_scope=scope if review_policy is not None else None,
                )
                if (
                    row.get("functional_request") != expected_request
                    or row.get("functional_evaluator") != frozen.get("functional_evaluator")
                    or not isinstance(frozen.get("functional_evaluator"), Mapping)
                    or not isinstance(frozen["functional_evaluator"].get("model_id"), str)
                    or not frozen["functional_evaluator"]["model_id"]
                ):
                    raise ValueError("execution functional request/evaluator binding failed")
                functional_raw = row.get("functional_response")
                failure = row.get("functional_failure")
                if failure is not None:
                    if not isinstance(failure, Mapping) or set(failure) != {"error_type", "error_message"}:
                        raise ValueError("execution functional failure evidence is invalid")
                    if functional_raw is not None:
                        if not isinstance(functional_raw, str):
                            raise ValueError("execution functional response is invalid")
                        try:
                            validate_review_response(functional_raw.encode("utf-8"), code)
                        except (ValueError, RuntimeError):
                            pass
                        else:
                            raise ValueError("valid functional response cannot be marked failed")
                    functional = {"status": "unknown", "reason": "functional_evaluator_failed", "failure": failure}
                    functional_digest = (hashlib.sha256(functional_raw.encode("utf-8")).hexdigest()
                                         if functional_raw is not None else content_hash(failure))
                else:
                    if not isinstance(functional_raw, str):
                        raise ValueError("execution functional response is missing")
                    functional = validate_review_response(functional_raw.encode("utf-8"), code)
                    functional_digest = hashlib.sha256(functional_raw.encode("utf-8")).hexdigest()
                calls += 1
            if (
                functional_digest != measurement.functional_evidence_sha256
                or row.get("functional_validated") != functional
                or measurement.functional_status.value != functional["status"]
                or measurement.oracle_status.value != security["security_label"]
            ):
                raise ValueError("execution evaluator labels/digests failed independent replay")
            oracle = security["security_label"]
            evaluable = int(oracle in {"secure", "insecure"})
            secure = int(oracle == "secure")
            upper = int(oracle != "insecure")
            functionality = {"pass": 1, "fail": 0, "unknown": None}[functional["status"]]
            joint = (0 if oracle == "insecure" or functionality == 0
                     else None if oracle == "unknown" or functionality is None else 1)
            expected = (1, evaluable, secure, upper, functionality, joint,
                        int(upper == 1 and functionality != 0), None)
        outcome = outcomes.get(assignment.assignment_id)
        observed = None if outcome is None else (
            outcome.code_valid, outcome.oracle_evaluable, outcome.secure_yield,
            outcome.latent_secure_upper, outcome.functionality, outcome.joint,
            outcome.latent_joint_upper, outcome.terminal_status,
        )
        if observed != expected:
            raise ValueError("execution outcome failed independent measurement reconstruction")
    return {"status": "TARGET_EXECUTION_EVIDENCE_VERIFIED", "assignments": len(rows),
            "completed_measurement_calls": calls}


def verify_target_rq_tables(
    evidence: SharedEvidenceRecord,
    yields: TargetSelectorYieldResult,
    report: Mapping[str, object],
) -> dict[str, object]:
    """Independently rebuild every target RQ row and its claim-level Gate."""

    verification = verify_target_shared_evidence(evidence, yields)
    return _check_target_rq_tables(evidence, yields, report, verification)


def _check_target_rq_tables(
    evidence: SharedEvidenceRecord,
    yields: TargetSelectorYieldResult,
    report: Mapping[str, object],
    verification: Mapping[str, object],
) -> dict[str, object]:
    """Rebuild tables from the evidence verified once by this invocation."""
    slots_by_selector: dict[tuple[PolicyTrack, str, str], list[object]] = defaultdict(list)
    for slot in yields.slots:
        slots_by_selector[slot.track, slot.model_id, slot.selector_id].append(slot)
    selector_rows = []
    for selector in sorted(
        yields.selectors, key=lambda item: (item.track.value, item.model_id, item.selector_id)
    ):
        slots = sorted(
            slots_by_selector[selector.track, selector.model_id, selector.selector_id],
            key=lambda item: item.rank,
        )
        if len(slots) != selector.top_k:
            raise ValueError("RQ verifier lost a fixed selector slot")
        counts = Counter(
            (
                (
                    slot.effect_status.value
                    if slot.effect_status is not None
                    else (
                        "SELECTOR_EMPTY_OR_FAILURE"
                        if slot.slot_status is not SlotStatus.FILLED
                        else "BRIDGE_OR_PROTOCOLIZATION_FAILURE"
                    )
                )
                for slot in slots
            )
        )
        selector_rows.append(
            {
                "track": selector.track.value,
                "model_id": selector.model_id,
                "selector_id": selector.selector_id,
                "top_k": selector.top_k,
                "meaningful_slots": selector.meaningful_slots,
                "meaningful_yield_at_k": selector.meaningful_yield_at_k,
                "positive_meaningful_slots": counts[
                    ConfirmatoryEffectStatus.POSITIVE_MEANINGFUL.value
                ],
                "negative_meaningful_slots": counts[
                    ConfirmatoryEffectStatus.NEGATIVE_MEANINGFUL.value
                ],
                "practically_null_slots": counts[ConfirmatoryEffectStatus.PRACTICALLY_NULL.value],
                "inconclusive_slots": counts[ConfirmatoryEffectStatus.INCONCLUSIVE.value],
                "non_evaluable_slots": counts[ConfirmatoryEffectStatus.NON_EVALUABLE.value],
                "selector_empty_or_failure_slots": counts["SELECTOR_EMPTY_OR_FAILURE"],
                "bridge_or_protocolization_failure_slots": counts[
                    "BRIDGE_OR_PROTOCOLIZATION_FAILURE"
                ],
            }
        )
    selector_by_key = {
        (row["track"], row["model_id"], row["selector_id"]): row for row in selector_rows
    }
    rq2_rows = []
    for track, full_id, ablation_id in ((PolicyTrack.ATOMIC, "atomic_full", "atomic_rd_only"),):
        models = sorted(
            {
                model
                for row_track, model, selector in selector_by_key
                if row_track == track.value and selector in {full_id, ablation_id}
            }
        )
        for model in models:
            full = selector_by_key.get((track.value, model, full_id))
            ablation = selector_by_key.get((track.value, model, ablation_id))
            if full is None or ablation is None or full["top_k"] != ablation["top_k"]:
                raise ValueError("RQ2 verifier lacks a sole-difference selector pair")
            rq2_rows.append(
                {
                    "track": track.value,
                    "model_id": model,
                    "full_selector_id": full_id,
                    "ablation_selector_id": ablation_id,
                    "top_k": full["top_k"],
                    "full_meaningful_yield_at_k": full["meaningful_yield_at_k"],
                    "ablation_meaningful_yield_at_k": ablation["meaningful_yield_at_k"],
                    "full_minus_ablation_yield_at_k": full["meaningful_yield_at_k"]
                    - ablation["meaningful_yield_at_k"],
                    "comparison_semantics": "descriptive_fixed_discovery_split_no_rank_pairing",
                }
            )
    families = []
    effects = []
    for family in evidence.families:
        families.append(
            {
                "track": family.track.value,
                "family_status": family.status.value,
                "simultaneous_critical_value": family.simultaneous_critical_value,
                "valid_bootstrap_draws": family.valid_bootstrap_draws,
                "invalid_bootstrap_draws": family.invalid_bootstrap_draws,
                "unique_effects": len(family.estimates),
            }
        )
        for estimate in family.estimates:
            effects.append(
                {
                    "track": estimate.track.value,
                    "candidate_record_id": estimate.candidate_record_id,
                    "effect_coordinate_id": estimate.effect_coordinate_id,
                    "policy_key": estimate.policy_key,
                    "model_id": estimate.model_id,
                    "estimand": "assigned_arm_task_unit_target_minus_noop_itt",
                    "primary_endpoint": "oracle_evaluable_secure_code_yield",
                    "point": estimate.point,
                    "standard_error": estimate.standard_error,
                    "simultaneous_lower": estimate.simultaneous_lower,
                    "simultaneous_upper": estimate.simultaneous_upper,
                    "latent_lower": estimate.latent_lower,
                    "latent_upper": estimate.latent_upper,
                    "practical_margin": estimate.practical_margin,
                    "effect_status": estimate.status.value,
                    "reasons": list(estimate.reasons),
                    "warnings": list(estimate.warnings),
                    "critical_value": estimate.critical_value,
                    "valid_bootstrap_draws": estimate.valid_bootstrap_draws,
                    "invalid_bootstrap_draws": estimate.invalid_bootstrap_draws,
                    "task_units": estimate.task_units,
                    "assignments": estimate.assignments,
                    "arms": [
                        {
                            "arm": arm.arm.value,
                            "assignments": arm.assignments,
                            "secure_yield": arm.secure_yield,
                            "code_validity": arm.code_validity,
                            "oracle_evaluability": arm.oracle_evaluability,
                            "functionality_yield": arm.functionality_yield,
                            "joint_success_yield": arm.joint_success_yield,
                            "oracle_unknown_valid_assignments": arm.oracle_unknown_valid_assignments,
                            "terminal_assignments": arm.terminal_assignments,
                        }
                        for arm in estimate.arm_summaries
                    ],
                }
            )
    if evidence.evidence_level in {EvidenceLevel.EXECUTED, EvidenceLevel.REPORTED}:
        raise ValueError("formal execution is unavailable under SPECIFIED_DRAFT")
    claim_allowed = False
    report_status = "NON_CLAIM_TEST_ARTIFACT"
    expected = {
        "schema_version": "3.0",
        "protocol_id": evidence.ledger.dispatch.union.ledger.protocol_id,
        "shared_evidence_record_id": evidence.shared_evidence_record_id,
        "target_selector_yield_result_id": yields.target_selector_yield_result_id,
        "evidence_level": evidence.evidence_level.value,
        "report_status": report_status,
        "scientific_claim_allowed": claim_allowed,
        "endpoint_order": [item.value for item in evidence.plan.metrics],
        "inference_method": evidence.plan.inference_method,
        "context_analysis_status": evidence.plan.context_analysis.status.value,
        "context_modifier_rows": [],
        "rq1_selector_rows": selector_rows,
        "rq2_full_minus_ablation_rows": rq2_rows,
        "primary_family_rows": families,
        "unique_effect_rows": sorted(
            effects, key=lambda row: (row["track"], row["candidate_record_id"])
        ),
        "independent_verification": verification,
    }
    expected["target_rq_tables_id"] = content_id("target_rq_tables_", expected)
    if dict(report) != expected:
        raise ValueError("target RQ tables failed independent replay")
    return {
        "status": "TARGET_RQ_TABLES_VERIFIED",
        "target_rq_tables_id": expected["target_rq_tables_id"],
        "scientific_claim_allowed": claim_allowed,
        "selector_rows": len(selector_rows),
        "rq2_rows": len(rq2_rows),
        "unique_effect_rows": len(effects),
    }
