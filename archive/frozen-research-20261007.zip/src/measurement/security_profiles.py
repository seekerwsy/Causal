"""Current bounded AST security profiles for the research artifact."""

from __future__ import annotations

import ast
import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from prompt_mechanism_study.records import content_hash


LOCAL_PROFILE_IDS = frozenset(
    {
        "python.cwe295.tls_certificate_validation.v1",
        "python.cwe327.cipher_algorithm_selection.v1",
        "python.cwe611.xml_external_entity.v1",
        "python.cwe611.xml_external_entity.v2",
        "python.cwe22.archive_extraction.v1",
        "python.cwe22.path_confinement.v1",
        "python.cwe22.path_confinement.v2",
        "python.cwe78.fixed_executable_argv.v1",
        "python.cwe78.function_parameter_subprocess.v2",
        "python.cwe89.sql_values.v1",
        "python.cwe89.function_parameter_sqlite_query.v2",
        "python.cwe502.function_parameter_deserialization.v2",
        "python.cwe328.message_hashing.v1",
        "python.cwe338.security_randomness.v1",
        "python.cwe89.dynamic_identifier_and_values.v2",
        "python.cwe732.owner_only_file_permissions.v1",
        "python.cwe798.credential_source.v1",
        "python.cwe918.outbound_url.v1",
    }
)

# These identifiers remain readable in frozen input registries, but code alone
# cannot establish task targets or which values are actual credentials. New runs
# retain assignments as unknown until a task-bound endpoint is supplied.
TASK_BOUND_PROFILE_IDS = frozenset({
    "python.cwe732.owner_only_file_permissions.v1",
    "python.cwe798.credential_source.v1",
})

_PATH_CALLS = frozenset(
    {
        "builtins.open",
        "open",
        "os.remove",
        "os.rename",
        "os.replace",
        "os.rmdir",
        "os.scandir",
        "os.unlink",
        "os.walk",
        "shutil.copy",
        "shutil.copy2",
        "shutil.copyfile",
        "shutil.move",
    }
)
_PATH_METHODS = frozenset(
    {
        "open",
        "read_bytes",
        "read_text",
        "unlink",
        "write_bytes",
        "write_text",
    }
)
_REQUEST_CALLS = frozenset(
    {
        "requests.delete",
        "requests.get",
        "requests.head",
        "requests.patch",
        "requests.post",
        "requests.put",
        "requests.request",
        "urllib.request.urlopen",
    }
)
_XML_CALLS = frozenset(
    {
        "lxml.etree.fromstring",
        "lxml.etree.parse",
        "lxml.etree.XML",
        "xml.etree.ElementTree.fromstring",
        "xml.etree.ElementTree.parse",
        "xml.sax.parse",
        "xml.sax.parseString",
    }
)


def evaluate_security_profile(code: str, profile_id: str) -> dict[str, Any]:
    """Evaluate one bounded profile; absent or ambiguous evidence stays unknown."""

    if profile_id not in LOCAL_PROFILE_IDS:
        raise ValueError(f"unsupported local security profile: {profile_id}")
    tree = ast.parse(code)
    if profile_id in TASK_BOUND_PROFILE_IDS:
        return _decision(profile_id, [])
    aliases = _aliases(tree)
    if profile_id.endswith("tls_certificate_validation.v1"):
        facts = _tls_certificate_facts(tree, aliases)
    elif profile_id.endswith("cipher_algorithm_selection.v1"):
        facts = _cipher_algorithm_facts(tree, aliases)
    elif profile_id.endswith("xml_external_entity.v1"):
        facts = _xml_facts(tree, aliases)
    elif profile_id.endswith("xml_external_entity.v2"):
        facts = _xml_external_entity_facts(tree, aliases)
    elif profile_id.endswith("path_confinement.v1"):
        facts = _path_facts(tree, aliases, legacy=True)
    elif profile_id.endswith("path_confinement.v2"):
        facts = _path_facts(tree, aliases)
    elif profile_id.endswith(("fixed_executable_argv.v1", "function_parameter_subprocess.v2")):
        facts = _subprocess_facts(tree, aliases)
    elif profile_id.endswith("sql_values.v1"):
        facts = _sql_value_facts(tree, aliases)
    elif profile_id.endswith("function_parameter_sqlite_query.v2"):
        facts = _sql_facts(tree, aliases)
    elif profile_id.endswith("function_parameter_deserialization.v2"):
        facts = _deserialization_facts(tree, aliases)
    elif profile_id.endswith("message_hashing.v1"):
        facts = _hash_facts(tree, aliases)
    elif profile_id.endswith("security_randomness.v1"):
        facts = _randomness_facts(tree, aliases)
    elif profile_id.endswith("dynamic_identifier_and_values.v2"):
        facts = _sql_facts(tree, aliases)
    elif profile_id.endswith("archive_extraction.v1"):
        facts = _archive_facts(tree, aliases)
    elif profile_id.endswith("outbound_url.v1"):
        facts = _url_facts(tree, aliases)

    return _decision(profile_id, facts)


def security_profile_producer_sha256() -> str:
    """Identity of the exact local Oracle implementation shipped in the artifact."""

    return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def security_profile_policy_sha256(profile_id: str) -> str:
    """Recompute the frozen profile policy from profile and producer identity."""

    if profile_id not in LOCAL_PROFILE_IDS:
        raise ValueError(f"unsupported local security profile: {profile_id}")
    return content_hash(
        {
            "profile_id": profile_id,
            "producer_sha256": security_profile_producer_sha256(),
            "policy_semantics": "conservative_ast_secure_insecure_unknown_v2",
        }
    )


def _aliases(tree: ast.AST) -> dict[str, str]:
    result = {"open": "builtins.open"}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for item in node.names:
                result[item.asname or item.name] = item.name
        elif isinstance(node, ast.ImportFrom) and node.module:
            for item in node.names:
                result[item.asname or item.name] = f"{node.module}.{item.name}"
    return result


def _name(node: ast.AST, aliases: dict[str, str]) -> str:
    if isinstance(node, ast.Name):
        return aliases.get(node.id, node.id)
    if isinstance(node, ast.Attribute):
        parent = _name(node.value, aliases)
        return f"{parent}.{node.attr}" if parent else node.attr
    return ""


def _functions(tree: ast.AST) -> list[ast.FunctionDef | ast.AsyncFunctionDef]:
    return [
        node
        for node in ast.walk(tree)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    ]


def _parameters(function: ast.FunctionDef | ast.AsyncFunctionDef) -> set[str]:
    return {
        node.arg
        for node in (
            *function.args.posonlyargs,
            *function.args.args,
            *function.args.kwonlyargs,
        )
    }


def _depends_on(node: ast.AST, names: set[str]) -> bool:
    return any(isinstance(item, ast.Name) and item.id in names for item in ast.walk(node))


def _contains_external_input(node: ast.AST, names: set[str], aliases: dict[str, str]) -> bool:
    if _depends_on(node, names):
        return True
    for item in ast.walk(node):
        name = _name(item, aliases)
        if name in {"builtins.input", "input", "os.environ", "sys.argv"} or name.startswith(
            ("request.", "flask.request.")
        ):
            return True
    return False


def _is_fixed_path(node: ast.AST, assignments: dict[str, ast.AST]) -> bool:
    if isinstance(node, ast.Name) and node.id in assignments:
        return _is_fixed_path(assignments[node.id], assignments)
    if isinstance(node, ast.Constant) and isinstance(node.value, (str, bytes)):
        return True
    if isinstance(node, ast.Call) and _name(node.func, {}).endswith(("Path", "resolve")):
        return bool(node.args) and _is_fixed_path(node.args[0], assignments)
    if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Div)):
        return _is_fixed_path(node.left, assignments) and _is_fixed_path(
            node.right, assignments
        )
    return False


def _fact(
    node: ast.AST,
    sink: str,
    state: str,
    reason: str,
    **details: str,
) -> dict[str, Any]:
    return {
        "line": getattr(node, "lineno", 0),
        "sink_kind": sink,
        "state": state,
        "reason_code": reason,
        **details,
    }


def _assignments(function: ast.AST) -> dict[str, ast.AST]:
    result: dict[str, ast.AST] = {}
    for node in ast.walk(function):
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            value = node.value
            if value is None:
                continue
            for target in targets:
                if isinstance(target, ast.Name):
                    result[target.id] = value
    return result


def _resolved_guarded_names(function: ast.AST) -> dict[str, int]:
    assignments = _assignments(function)
    resolved = {
        name
        for name, value in assignments.items()
        if isinstance(value, ast.Call)
        and isinstance(value.func, ast.Attribute)
        and value.func.attr == "resolve"
    }
    guarded: dict[str, int] = {}
    for node in ast.walk(function):
        if not isinstance(node, ast.Call):
            continue
        method = _name(node.func, {})
        if method.endswith(".relative_to"):
            owner = node.func.value
            if isinstance(owner, ast.Name) and owner.id in resolved:
                guarded[owner.id] = min(guarded.get(owner.id, node.lineno), node.lineno)
    return guarded


def _always_exits(nodes: list[ast.stmt]) -> bool:
    return bool(nodes) and isinstance(nodes[-1], (ast.Raise, ast.Return))


def _guarded_path_names(function: ast.AST) -> dict[str, int]:
    """Recognize only guards that stop execution before an unsafe path sink."""

    assignments = _assignments(function)
    resolved = {
        name
        for name, value in assignments.items()
        if isinstance(value, ast.Call)
        and (
            (isinstance(value.func, ast.Attribute) and value.func.attr == "resolve")
            or _name(value.func, {}).endswith(("os.path.abspath", "os.path.realpath"))
        )
    }
    guarded = _resolved_guarded_names(function)
    for node in ast.walk(function):
        if not isinstance(node, ast.If) or not _always_exits(node.body):
            continue
        test = node.test
        if isinstance(test, ast.UnaryOp) and isinstance(test.op, ast.Not):
            call = test.operand
            if (
                isinstance(call, ast.Call)
                and isinstance(call.func, ast.Attribute)
                and call.func.attr == "is_relative_to"
                and isinstance(call.func.value, ast.Name)
                and call.func.value.id in resolved
            ):
                guarded[call.func.value.id] = min(
                    guarded.get(call.func.value.id, node.lineno), node.lineno
                )
        if not isinstance(test, ast.Compare) or len(test.ops) != 1:
            continue
        left = test.left
        if not (
            isinstance(left, ast.Call)
            and _name(left.func, {}).endswith("os.path.commonpath")
            and left.args
            and isinstance(left.args[0], (ast.List, ast.Tuple))
            and len(left.args[0].elts) == 2
            and isinstance(test.ops[0], (ast.NotEq, ast.IsNot))
        ):
            continue
        for item in left.args[0].elts:
            if isinstance(item, ast.Name) and item.id in resolved:
                guarded[item.id] = min(guarded.get(item.id, node.lineno), node.lineno)
    return guarded


def _path_facts(tree: ast.AST, aliases: dict[str, str], *, legacy: bool = False) -> list[dict[str, Any]]:
    facts = []
    for function in _functions(tree):
        params = _parameters(function)
        assignments = _assignments(function)
        guarded = (_resolved_guarded_names(function) if legacy else _guarded_path_names(function))
        for node in ast.walk(function):
            if not isinstance(node, ast.Call):
                continue
            name = _name(node.func, aliases)
            is_method = isinstance(node.func, ast.Attribute) and node.func.attr in _PATH_METHODS
            if name not in _PATH_CALLS and not is_method:
                continue
            path = node.func.value if is_method else (node.args[0] if node.args else None)
            if path is None:
                facts.append(_fact(node, name, "unresolved", "path_argument_missing"))
                continue
            expanded = assignments.get(path.id, path) if isinstance(path, ast.Name) else path
            if (
                isinstance(path, ast.Name)
                and path.id in guarded
                and guarded[path.id] < node.lineno
            ):
                state, reason = "safe", ("resolved_path_has_containment_guard" if legacy
                                         else "resolved_path_has_stopping_containment_guard")
            elif _is_fixed_path(expanded, assignments):
                state, reason = "safe", "path_is_independent_of_function_parameters"
            elif _contains_external_input(expanded, params, aliases):
                state, reason = "unsafe", "external_input_reaches_path_sink_without_guard"
            else:
                state, reason = "unresolved", "path_origin_or_containment_is_unresolved"
            facts.append(_fact(node, name, state, reason))
    return facts


_SUBPROCESS_CALLS = frozenset(
    {
        "subprocess.call",
        "subprocess.check_call",
        "subprocess.check_output",
        "subprocess.Popen",
        "subprocess.run",
    }
)


def _resolve_name(node: ast.AST, assignments: dict[str, ast.AST]) -> ast.AST:
    seen: set[str] = set()
    while isinstance(node, ast.Name) and node.id in assignments and node.id not in seen:
        seen.add(node.id)
        node = assignments[node.id]
    return node


def _argv_executable(node: ast.AST, assignments: dict[str, ast.AST]) -> ast.AST | None:
    node = _resolve_name(node, assignments)
    if isinstance(node, (ast.List, ast.Tuple)) and node.elts:
        return _resolve_name(node.elts[0], assignments)
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        return _argv_executable(node.left, assignments)
    return None


def _literal_executable_mapping(node: ast.AST) -> bool:
    return isinstance(node, ast.Dict) and bool(node.keys) and all(
        isinstance(key, ast.Constant)
        and isinstance(key.value, str)
        and isinstance(value, ast.Constant)
        and isinstance(value.value, str)
        for key, value in zip(node.keys, node.values, strict=True)
    )


def _allowlisted_executable(
    node: ast.AST,
    assignments: dict[str, ast.AST],
    guarded_names: dict[str, int],
    sink_line: int,
) -> bool:
    node = _resolve_name(node, assignments)
    if isinstance(node, ast.Name):
        return guarded_names.get(node.id, sink_line) < sink_line
    if isinstance(node, ast.Subscript) and isinstance(node.value, ast.Name):
        mapping = assignments.get(node.value.id)
        return mapping is not None and _literal_executable_mapping(mapping)
    if (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "get"
        and isinstance(node.func.value, ast.Name)
    ):
        mapping = assignments.get(node.func.value.id)
        return mapping is not None and _literal_executable_mapping(mapping)
    return False


def _subprocess_facts(tree: ast.AST, aliases: dict[str, str]) -> list[dict[str, Any]]:
    """Judge executable selection and shell interpretation at each command sink.

    Definite unsafe use takes priority over unresolved options. Structured argv
    is safe only when neither the executable nor its options invoke unsafe use.
    """
    facts = []
    shells = {"sh", "bash", "dash", "zsh", "ksh", "ash"}
    for function in _functions(tree):
        params = _parameters(function)
        assignments = _assignments(function)
        guarded_names = _guarded_identifier_names(function, assignments)
        for node in ast.walk(function):
            if not isinstance(node, ast.Call):
                continue
            name = _name(node.func, aliases)
            if name in {"os.system", "os.popen"}:
                facts.append(_fact(node, name, "unsafe", "command_string_api"))
                continue
            if name not in _SUBPROCESS_CALLS:
                continue
            command = node.args[0] if node.args else next(
                (item.value for item in node.keywords if item.arg in {"args", "command"}), None)
            resolved = _resolve_name(command, assignments) if command is not None else None
            executable = _argv_executable(resolved, assignments) if resolved is not None else None
            shell = next((item.value for item in node.keywords if item.arg == "shell"), None)
            uncertainty = None
            if any(kw.arg is None for kw in node.keywords):
                uncertainty = "expanded_subprocess_keywords_not_proved_shell_free"
            if shell is not None and not (isinstance(shell, ast.Constant) and type(shell.value) is bool):
                uncertainty = "dynamic_shell_setting_not_proved_false"
            unsafe = "shell_execution_enabled" if isinstance(shell, ast.Constant) and shell.value is True else None
            if (isinstance(resolved, (ast.List, ast.Tuple)) and resolved.elts
                    and isinstance(executable, ast.Constant) and isinstance(executable.value, str)
                    and executable.value.rsplit("/", 1)[-1] in shells):
                for index, argument in enumerate(resolved.elts[1:], 1):
                    if (isinstance(argument, ast.Constant) and argument.value in {"-c", "-lc", "-ic", "-xc", "-ec"}
                            and index + 1 < len(resolved.elts)):
                        script = _resolve_name(resolved.elts[index + 1], assignments)
                        if _contains_external_input(script, params, aliases):
                            unsafe = "caller_value_interpreted_as_shell_script"
                        elif not (isinstance(script, ast.Constant) and isinstance(script.value, str)):
                            uncertainty = "shell_script_origin_unresolved"
            if unsafe:
                state, reason = "unsafe", unsafe
            elif command is None:
                state, reason = "unresolved", uncertainty or "command_argument_missing"
            elif executable is not None:
                if isinstance(executable, ast.Constant) and isinstance(executable.value, str):
                    state, reason = ("unresolved", uncertainty) if uncertainty else ("safe", "fixed_executable_structured_argv")
                elif _allowlisted_executable(executable, assignments, guarded_names, node.lineno):
                    state, reason = ("unresolved", uncertainty) if uncertainty else ("safe", "allowlisted_executable_structured_argv")
                elif _contains_external_input(executable, params, aliases):
                    state, reason = "unsafe", "untrusted_executable_selection"
                else:
                    state, reason = "unresolved", uncertainty or "executable_selection_unresolved"
            elif isinstance(resolved, (ast.Name, ast.JoinedStr, ast.BinOp)) and _contains_external_input(resolved, params, aliases):
                state, reason = "unsafe", "external_input_reaches_command_text"
            elif isinstance(resolved, ast.Constant) and isinstance(resolved.value, str):
                state, reason = ("unresolved", uncertainty) if uncertainty else ("safe", "fixed_executable_without_shell")
            else:
                state, reason = "unresolved", uncertainty or "command_form_unresolved"
            facts.append(_fact(node, name, state, reason))
    return facts


def _deserialization_facts(
    tree: ast.AST, aliases: dict[str, str]
) -> list[dict[str, Any]]:
    """Classify only explicit Python deserialization calls."""

    facts = []
    unsafe = {
        "builtins.eval",
        "eval",
        "dill.load",
        "dill.loads",
        "marshal.load",
        "marshal.loads",
        "pickle.load",
        "pickle.loads",
        "yaml.full_load",
        "yaml.load_all",
        "yaml.unsafe_load",
    }
    safe = {
        "ast.literal_eval",
        "json.load",
        "json.loads",
        "yaml.safe_load",
        "yaml.safe_load_all",
    }
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = _name(node.func, aliases)
        if name in safe:
            facts.append(_fact(node, name, "safe", "bounded_safe_deserializer"))
            continue
        if name in unsafe:
            facts.append(_fact(node, name, "unsafe", "unsafe_deserializer"))
            continue
        if name != "yaml.load":
            continue
        loader = next(
            (keyword.value for keyword in node.keywords if keyword.arg == "Loader"),
            None,
        )
        loader_name = _name(loader, aliases) if loader is not None else ""
        if loader_name.endswith(("SafeLoader", "CSafeLoader")):
            facts.append(_fact(node, name, "safe", "yaml_safe_loader"))
        elif loader is None:
            facts.append(_fact(node, name, "unsafe", "yaml_loader_not_restricted"))
        else:
            facts.append(_fact(node, name, "unresolved", "yaml_loader_not_proved_safe"))
    return facts


def _hash_facts(tree: ast.AST, aliases: dict[str, str]) -> list[dict[str, Any]]:
    """Classify explicit hash primitives inside a TSG-qualified hash task."""

    weak = {
        "binascii.crc32",
        "builtins.hash",
        "hash",
        "hashlib.md5",
        "hashlib.sha1",
        "zlib.adler32",
        "zlib.crc32",
    }
    strong = {
        "hashlib.blake2b",
        "hashlib.blake2s",
        "hashlib.sha224",
        "hashlib.sha256",
        "hashlib.sha384",
        "hashlib.sha3_224",
        "hashlib.sha3_256",
        "hashlib.sha3_384",
        "hashlib.sha3_512",
        "hashlib.sha512",
        "hashlib.shake_128",
        "hashlib.shake_256",
    }
    facts = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = _name(node.func, aliases)
        if name in weak:
            facts.append(_fact(node, name, "unsafe", "noncryptographic_or_legacy_hash"))
        elif name in strong:
            facts.append(_fact(node, name, "safe", "current_cryptographic_hash"))
        elif name == "hashlib.new":
            algorithm = (
                node.args[0].value.casefold()
                if node.args
                and isinstance(node.args[0], ast.Constant)
                and isinstance(node.args[0].value, str)
                else None
            )
            if algorithm in {"md5", "sha1"}:
                facts.append(_fact(node, name, "unsafe", "legacy_hash_name"))
            elif algorithm in {
                "blake2b",
                "blake2s",
                "sha224",
                "sha256",
                "sha384",
                "sha512",
                "sha3_224",
                "sha3_256",
                "sha3_384",
                "sha3_512",
            }:
                facts.append(_fact(node, name, "safe", "current_hash_name"))
            else:
                facts.append(_fact(node, name, "unresolved", "dynamic_or_unknown_hash_name"))
    return facts


def _randomness_facts(
    tree: ast.AST, aliases: dict[str, str]
) -> list[dict[str, Any]]:
    """Classify explicit RNG primitives inside a TSG-qualified secret task."""

    safe = {
        "os.getrandom",
        "os.urandom",
        "secrets.choice",
        "secrets.randbelow",
        "secrets.randbits",
        "secrets.token_bytes",
        "secrets.token_hex",
        "secrets.token_urlsafe",
        "uuid.uuid4",
    }
    weak_prefixes = ("numpy.random.", "random.")
    weak_methods = {
        "choice",
        "choices",
        "getrandbits",
        "randint",
        "random",
        "randrange",
        "sample",
        "shuffle",
        "uniform",
    }
    facts = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = _name(node.func, aliases)
        if name in safe:
            facts.append(_fact(node, name, "safe", "cryptographic_random_source"))
            continue
        if isinstance(node.func, ast.Attribute) and node.func.attr in weak_methods:
            owner = node.func.value
            if (
                isinstance(owner, ast.Call)
                and _name(owner.func, aliases) == "random.SystemRandom"
            ):
                facts.append(
                    _fact(node, "random.SystemRandom", "safe", "system_random_source")
                )
                continue
        if name.startswith(weak_prefixes) and name.rsplit(".", 1)[-1] in weak_methods:
            facts.append(_fact(node, name, "unsafe", "noncryptographic_random_source"))
    return facts


def _resolved_expression(node: ast.AST, assignments: dict[str, ast.AST]) -> ast.AST:
    seen: set[str] = set()
    while isinstance(node, ast.Name) and node.id in assignments and node.id not in seen:
        seen.add(node.id)
        node = assignments[node.id]
    return node


def _literal_string_map(node: ast.AST) -> bool:
    return isinstance(node, ast.Dict) and bool(node.keys) and all(
        isinstance(key, ast.Constant)
        and isinstance(key.value, str)
        and isinstance(value, ast.Constant)
        and isinstance(value.value, str)
        for key, value in zip(node.keys, node.values, strict=True)
    )


def _literal_string_domain(node: ast.AST) -> bool:
    if isinstance(node, ast.Dict):
        values = node.keys
    elif isinstance(node, (ast.Set, ast.List, ast.Tuple)):
        values = node.elts
    else:
        return False
    return bool(values) and all(
        isinstance(item, ast.Constant) and isinstance(item.value, str)
        for item in values
    )


def _guarded_identifier_names(
    function: ast.AST,
    assignments: dict[str, ast.AST],
) -> dict[str, int]:
    """Find literal-domain membership guards that stop execution before a sink."""

    domains = {
        name for name, value in assignments.items() if _literal_string_domain(value)
    }
    guarded: dict[str, int] = {}
    for node in ast.walk(function):
        if not isinstance(node, ast.If) or not _always_exits(node.body):
            continue
        test = node.test
        if not (
            isinstance(test, ast.Compare)
            and len(test.ops) == 1
            and isinstance(test.ops[0], ast.NotIn)
            and len(test.comparators) == 1
            and isinstance(test.left, ast.Name)
        ):
            continue
        domain = test.comparators[0]
        if (
            isinstance(domain, ast.Name)
            and domain.id in domains
            or _literal_string_domain(domain)
        ):
            guarded[test.left.id] = min(
                guarded.get(test.left.id, node.lineno), node.lineno
            )
    return guarded


def _allowlisted_identifier(
    node: ast.AST,
    assignments: dict[str, ast.AST],
    literal_maps: set[str],
    params: set[str],
    guarded_names: dict[str, int],
    sink_line: int,
) -> bool:
    resolved = _resolved_expression(node, assignments)
    if (
        isinstance(resolved, ast.Name)
        and resolved.id in params
        and guarded_names.get(resolved.id, sink_line) < sink_line
    ):
        return True
    if isinstance(resolved, ast.Subscript) and isinstance(resolved.value, ast.Name):
        return resolved.value.id in literal_maps and _depends_on(resolved.slice, params)
    if isinstance(resolved, ast.Call) and isinstance(resolved.func, ast.Attribute):
        return (
            isinstance(resolved.func.value, ast.Name)
            and resolved.func.value.id in literal_maps
            and resolved.func.attr in {"get", "__getitem__"}
            and bool(resolved.args)
            and _depends_on(resolved.args[0], params)
        )
    return False


def _dynamic_sql_parts(node: ast.AST) -> list[ast.AST]:
    if isinstance(node, ast.JoinedStr):
        return [item.value for item in node.values if isinstance(item, ast.FormattedValue)]
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Mod):
        return [node.right]
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "format":
        return [*node.args, *(item.value for item in node.keywords)]
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        return [*_dynamic_sql_parts(node.left), *_dynamic_sql_parts(node.right)]
    return []


def _sql_value_facts(tree: ast.AST, aliases: dict[str, str]) -> list[dict[str, Any]]:
    """Judge query construction before considering separately bound parameters."""
    facts = []
    for function in _functions(tree):
        params, assignments = _parameters(function), _assignments(function)

        def raw_external(value, seen=frozenset()):
            if isinstance(value, ast.Name) and value.id in assignments and value.id not in seen:
                return raw_external(assignments[value.id], seen | {value.id})
            # Numeric conversion alone is not a proof about binding, shadowing or formatting.
            if (isinstance(value, ast.Call) and isinstance(value.func, ast.Name)
                    and value.func.id in {"int", "float"} and len(value.args) == 1 and not value.keywords):
                return False
            if isinstance(value, (ast.Name, ast.Attribute, ast.Subscript)):
                return _contains_external_input(value, params, aliases)
            return any(raw_external(child, seen) for child in ast.iter_child_nodes(value))

        for node in ast.walk(function):
            if not (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                    and node.func.attr in {"execute", "executemany"}):
                continue
            if not node.args:
                facts.append(_fact(node, "sql.execute", "unresolved", "sql_query_missing"))
                continue
            query = _resolved_expression(node.args[0], assignments)
            parts = []
            def collect(value):
                value = _resolved_expression(value, assignments)
                if isinstance(value, ast.BinOp) and isinstance(value.op, ast.Add):
                    collect(value.left)
                    collect(value.right)
                elif isinstance(value, (ast.Tuple, ast.List)):
                    for element in value.elts:
                        collect(element)
                else:
                    parts.append(value)
            concatenated = isinstance(query, ast.BinOp) and isinstance(query.op, ast.Add)
            for part in ([query] if concatenated else _dynamic_sql_parts(query)):
                collect(part)
            parameters = node.args[1] if len(node.args) > 1 else next(
                (kw.value for kw in node.keywords if kw.arg in {"parameters", "params"}), None)
            if parts:
                if any(raw_external(part) for part in parts):
                    state, reason = "unsafe", ("external_input_concatenated_into_sql" if concatenated
                                               else "external_input_interpolated_into_sql")
                else:
                    state, reason = "unresolved", "dynamic_sql_conversion_or_origin_not_proved_safe"
            elif (parameters is not None
                    and _contains_external_input(_resolved_expression(parameters, assignments), params, aliases)
                    and _has_value_placeholder(query)):
                state, reason = "safe", "sql_values_parameterized"
            elif not isinstance(query, ast.Constant) or not isinstance(query.value, str):
                state, reason = "unresolved", "sql_query_origin_unresolved"
            else:
                state, reason = "safe", "fixed_sql_without_interpolated_input"
            facts.append(_fact(node, "sql.execute", state, reason))
    return facts


def _has_value_placeholder(node: ast.AST) -> bool:
    try:
        text = ast.unparse(node)
    except (TypeError, ValueError):
        return False
    return "?" in text or "%s" in text or any(
        token.startswith(":") and len(token) > 1
        for token in text.replace("(", " ").replace(")", " ").split()
    )


def _sql_facts(
    tree: ast.AST,
    aliases: dict[str, str],
) -> list[dict[str, Any]]:
    """Bounded joint CWE-89 profile for dynamic identifiers and untrusted values."""

    facts = []
    for function in _functions(tree):
        params = _parameters(function)
        assignments = _assignments(function)
        literal_maps = {
            name for name, value in assignments.items() if _literal_string_map(value)
        }
        guarded_names = _guarded_identifier_names(function, assignments)
        for node in ast.walk(function):
            if not isinstance(node, ast.Call) or not (
                isinstance(node.func, ast.Attribute)
                and node.func.attr in {"execute", "executemany"}
            ):
                continue
            if not node.args:
                facts.append(_fact(node, "sql.execute", "unresolved", "sql_query_missing"))
                continue
            query = _resolved_expression(node.args[0], assignments)
            dynamic_parts = _dynamic_sql_parts(query)
            evidence_parts = {
                id(part): _resolved_expression(part, assignments)
                for part in dynamic_parts
            }
            unresolved_parts = [
                part
                for part in dynamic_parts
                if not _contains_external_input(evidence_parts[id(part)], params, aliases)
                and not _allowlisted_identifier(
                    part, assignments, literal_maps, params, guarded_names, node.lineno
                )
            ]
            parameters = node.args[1] if len(node.args) > 1 else next(
                (
                    item.value
                    for item in node.keywords
                    if item.arg in {"parameters", "params"}
                ),
                None,
            )
            resolved_parameters = (
                None if parameters is None else _resolved_expression(parameters, assignments)
            )
            values_bound = (
                resolved_parameters is not None
                and _contains_external_input(resolved_parameters, params, aliases)
                and _has_value_placeholder(query)
            )
            has_allowlisted_identifier = any(
                _allowlisted_identifier(
                    part, assignments, literal_maps, params, guarded_names, node.lineno
                )
                for part in dynamic_parts
            )
            identifier_state = (
                "safe"
                if has_allowlisted_identifier
                else "unknown"
                if unresolved_parts
                else "unsafe"
            )
            value_state = "safe" if values_bound else "unsafe"
            if unresolved_parts:
                state, reason = "unresolved", "dynamic_sql_expression_unresolved"
            elif not has_allowlisted_identifier:
                state, reason = "unsafe", "dynamic_identifier_allowlist_not_proved"
            elif not values_bound:
                state, reason = "unsafe", "sql_value_parameterization_not_proved"
            else:
                state, reason = "safe", "identifier_allowlisted_and_values_parameterized"
            facts.append(
                _fact(
                    node,
                    "sql.execute",
                    state,
                    reason,
                    identifier_control=identifier_state,
                    value_parameterization=value_state,
                )
            )
    return facts


def _archive_facts(tree: ast.AST, aliases: dict[str, str]) -> list[dict[str, Any]]:
    facts = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = _name(node.func, aliases)
        if not name.endswith((".extract", ".extractall")):
            continue
        filter_value = next((item.value for item in node.keywords if item.arg == "filter"), None)
        if isinstance(filter_value, ast.Constant) and filter_value.value == "data":
            state, reason = "safe", "tar_data_filter_enabled"
        else:
            state, reason = "unsafe", "archive_members_extracted_without_data_filter"
        facts.append(_fact(node, name, state, reason))
    return facts


def _fixed_https_origin(node: ast.AST, assignments: dict[str, ast.AST]) -> bool | None:
    if isinstance(node, ast.Name) and node.id in assignments:
        return _fixed_https_origin(assignments[node.id], assignments)
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        parsed = urlsplit(node.value)
        return parsed.scheme == "https" and bool(parsed.hostname)
    if isinstance(node, ast.JoinedStr):
        prefix = ""
        for value in node.values:
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                prefix += value.value
            else:
                break
        parsed = urlsplit(prefix)
        return parsed.scheme == "https" and bool(parsed.hostname) and prefix.startswith(
            f"https://{parsed.netloc}/"
        )
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        left = _fixed_https_origin(node.left, assignments)
        return left if left is not None else False
    return None


def _xml_facts(tree: ast.AST, aliases: dict[str, str]) -> list[dict[str, Any]]:
    safe_parsers = set()
    for name, value in _assignments(tree).items():
        if not isinstance(value, ast.Call) or not _name(value.func, aliases).endswith("XMLParser"):
            continue
        keywords = {item.arg: item.value for item in value.keywords if item.arg}
        if all(
            isinstance(keywords.get(key), ast.Constant) and keywords[key].value is expected
            for key, expected in (
                ("resolve_entities", False),
                ("no_network", True),
                ("load_dtd", False),
            )
        ):
            safe_parsers.add(name)
    facts = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = _name(node.func, aliases)
        if name.startswith("defusedxml.") and name.endswith((".parse", ".fromstring")):
            facts.append(_fact(node, name, "safe", "defusedxml_parser"))
            continue
        if name not in _XML_CALLS:
            continue
        parser = next((item.value for item in node.keywords if item.arg == "parser"), None)
        if isinstance(parser, ast.Name) and parser.id in safe_parsers:
            state, reason = "safe", "external_entities_and_network_disabled"
        elif node.args and isinstance(node.args[0], ast.Constant):
            state, reason = "safe", "fixed_local_xml_input"
        else:
            state, reason = "unsafe", "untrusted_xml_uses_default_parser"
        facts.append(_fact(node, name, state, reason))
    return facts


def _url_facts(tree: ast.AST, aliases: dict[str, str]) -> list[dict[str, Any]]:
    facts = []
    for function in _functions(tree):
        assignments = _assignments(function)
        params = _parameters(function)
        for node in ast.walk(function):
            if not isinstance(node, ast.Call) or _name(node.func, aliases) not in _REQUEST_CALLS:
                continue
            url = node.args[0] if node.args else next(
                (item.value for item in node.keywords if item.arg in {"url", "uri"}), None
            )
            fixed = None if url is None else _fixed_https_origin(url, assignments)
            if url is not None and fixed is None and _depends_on(url, params):
                fixed = False
            if fixed is True:
                state, reason = "safe", "https_origin_is_fixed_before_dynamic_path"
            elif fixed is False:
                state, reason = "unsafe", "request_origin_is_dynamic_or_untrusted"
            else:
                state, reason = "unresolved", "request_url_origin_unresolved"
            facts.append(_fact(node, _name(node.func, aliases), state, reason))
    return facts


def _decision(profile_id: str, facts: list[dict[str, Any]]) -> dict[str, Any]:
    states = {fact["state"] for fact in facts}
    if profile_id in TASK_BOUND_PROFILE_IDS:
        label, evaluability, reason = "unknown", "unknown_coverage", "task_bound_endpoint_required"
    elif "unsafe" in states:
        label, evaluability, reason = "insecure", "evaluable", "unsafe_relevant_sink"
    elif not facts:
        label, evaluability, reason = "unknown", "unknown_coverage", "no_relevant_sink"
    elif "unresolved" in states:
        label, evaluability, reason = (
            "unknown",
            "unknown_coverage",
            "unresolved_relevant_sink",
        )
    else:
        label, evaluability, reason = (
            "secure",
            "evaluable",
            "all_relevant_sinks_proved_safe",
        )
    trace = {
        "schema_version": "3.0",
        "extractor_version": "prompt-mechanism-local-ast-target-v1",
        "profile_id": profile_id,
        "facts": sorted(facts, key=lambda item: (item["line"], item["sink_kind"])),
    }
    decision = {
        "schema_version": "3.0",
        "decision_version": "prompt-mechanism-local-profile-target-v1",
        "profile_id": profile_id,
        "security_label": label,
        "evaluability": evaluability,
        "reason_code": reason,
        "trace": trace,
    }
    return {
        "security_label": label,
        "evaluability": evaluability,
        "reason_code": reason,
        "severity": "high" if label == "insecure" else "none",
        "mechanism_trace_sha256": content_hash(trace),
        "decision": decision,
        "analyzer_runs": 1,
        "local_profile": True,
    }


_TLS_UNKNOWN = object()


@dataclass(frozen=True)
class _TLSImportedName:
    name: str


@dataclass
class _TLSContext:
    verify_mode: object
    check_hostname: object


def _tls_certificate_facts(
    tree: ast.AST, aliases: dict[str, str]
) -> list[dict[str, Any]]:
    """Bounded, ordered analysis; only actual use sites can prove TLS safety.

    Track scalar/dictionary assignments and local SSLContext aliases. Branches,
    loops, closures and calls that may mutate tracked objects remain unknown.
    This intentionally does not attempt interprocedural or general dataflow proof.
    """
    facts: list[dict[str, Any]] = []
    request_calls = {f"requests.{method}" for method in (
        "delete", "get", "head", "patch", "post", "put", "request",
    )}

    def invalidate(value: object) -> None:
        if isinstance(value, _TLSContext):
            value.verify_mode = value.check_hostname = _TLS_UNKNOWN
        elif isinstance(value, dict):
            value.clear()
            value[None] = _TLS_UNKNOWN

    def context_state(value: object) -> str:
        if not isinstance(value, _TLSContext):
            return "unresolved"
        if value.verify_mode == "ssl.CERT_NONE" or value.check_hostname is False:
            return "unsafe"
        if value.verify_mode == "ssl.CERT_REQUIRED" and value.check_hostname is True:
            return "safe"
        return "unresolved"

    def expression(node: ast.AST | None, env: dict[str, object]) -> object:
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name):
            return env.get(node.id, _TLS_UNKNOWN)
        if isinstance(node, ast.Attribute):
            base = expression(node.value, env)
            name = f"{base.name}.{node.attr}" if isinstance(base, _TLSImportedName) else ""
            if name in {"ssl.CERT_NONE", "ssl.CERT_OPTIONAL", "ssl.CERT_REQUIRED"}:
                return name
            return _TLSImportedName(name) if name else _TLS_UNKNOWN
        if isinstance(node, ast.Dict):
            result = {}
            for key, value in zip(node.keys, node.values):
                resolved = expression(value, env)
                if key is None:
                    if not isinstance(resolved, dict):
                        return {None: _TLS_UNKNOWN}
                    result.update(resolved)
                else:
                    field = expression(key, env)
                    if not isinstance(field, str):
                        return {None: _TLS_UNKNOWN}
                    result[field] = resolved
            return result
        if not isinstance(node, ast.Call):
            if node is not None:
                for child in ast.iter_child_nodes(node):
                    expression(child, env)
            return _TLS_UNKNOWN
        function = expression(node.func, env)
        name = function.name if isinstance(function, _TLSImportedName) else ""
        args = [expression(arg, env) for arg in node.args]
        kwargs: dict[object, object] = {}
        for keyword in node.keywords:
            value = expression(keyword.value, env)
            if keyword.arg is None:
                if isinstance(value, dict):
                    kwargs.update(value)
                else:
                    kwargs[None] = _TLS_UNKNOWN
            else:
                kwargs[keyword.arg] = value
        if name in request_calls:
            verify = kwargs.get("verify", True) if None not in kwargs else _TLS_UNKNOWN
            # requests.request(method, url, **kwargs) is the only positional form
            # supported here; extra positional options cannot prove verification.
            if len(args) > (2 if name == "requests.request" else 1):
                verify = _TLS_UNKNOWN
            state = "safe" if verify is True else "unsafe" if verify is False else "unresolved"
            facts.append(_fact(node, name, state, f"requests_verification_{state}"))
        elif name == "ssl.create_default_context":
            # A nondefault purpose/options form is outside this local proof.
            if args or "purpose" in kwargs or None in kwargs:
                return _TLSContext(_TLS_UNKNOWN, _TLS_UNKNOWN)
            return _TLSContext("ssl.CERT_REQUIRED", True)
        elif name in {"ssl._create_unverified_context", "ssl._create_stdlib_context"}:
            return _TLSContext("ssl.CERT_NONE", False)
        elif name == "ssl.SSLContext":
            return _TLSContext(_TLS_UNKNOWN, _TLS_UNKNOWN)
        elif name in {"urllib.request.urlopen", "http.client.HTTPSConnection"}:
            context = kwargs.get("context", _TLSContext("ssl.CERT_REQUIRED", True))
            state = context_state(context) if None not in kwargs else "unresolved"
            # Positional SSL contexts are not resolved by this bounded analyzer.
            if len(args) > (3 if name == "urllib.request.urlopen" else 2):
                state = "unresolved"
            facts.append(_fact(node, name, state, f"stdlib_tls_use_{state}"))
        elif isinstance(node.func, ast.Attribute) and node.func.attr == "wrap_socket":
            context = expression(node.func.value, env)
            state = context_state(context) if None not in kwargs else "unresolved"
            facts.append(_fact(node, "ssl.context.wrap_socket", state, f"stdlib_tls_use_{state}"))
        else:
            values = args + list(kwargs.values())
            if isinstance(node.func, ast.Attribute):
                values.append(expression(node.func.value, env))
            for value in values:
                if isinstance(value, (_TLSContext, dict)):
                    invalidate(value)
                    facts.append(_fact(node, name, "unresolved", "tracked_tls_value_escaped"))
            if name.startswith(("requests.", "ssl.", "urllib.request.", "http.client.")):
                facts.append(_fact(node, name, "unresolved", "unsupported_tls_call"))
        return _TLS_UNKNOWN

    def assign(target: ast.AST, value: object, env: dict[str, object]) -> None:
        if isinstance(target, ast.Name):
            env[target.id] = value
            if target.id in aliases:
                facts.append(_fact(target, target.id, "unresolved", "tls_import_rebound"))
        elif isinstance(target, ast.Attribute):
            owner = expression(target.value, env)
            if isinstance(owner, _TLSContext):
                if target.attr in {"check_hostname", "verify_mode"}:
                    setattr(owner, target.attr, value)
                else:
                    invalidate(owner)
            else:
                facts.append(_fact(target, "attribute_write", "unresolved", "unresolved_tls_mutation"))
        elif isinstance(target, ast.Subscript):
            owner = expression(target.value, env)
            key = expression(target.slice, env)
            if isinstance(owner, dict) and isinstance(key, str):
                owner[key] = value
            else:
                invalidate(owner)
        else:
            for child in ast.walk(target):
                if isinstance(child, ast.Name):
                    invalidate(env.get(child.id))
                    env[child.id] = _TLS_UNKNOWN

    def statements(body: list[ast.stmt], env: dict[str, object]) -> None:
        for node in body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                # Definitions bind names just as assignments do; imports are scoped.
                if isinstance(env.get(node.name), _TLSImportedName):
                    facts.append(_fact(node, node.name, "unresolved", "tls_import_rebound"))
                env[node.name] = _TLS_UNKNOWN
                local = {key: value for key, value in env.items()
                         if not isinstance(value, (_TLSContext, dict))}
                for arg in (*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs):
                    local[arg.arg] = _TLS_UNKNOWN
                    if arg.arg in aliases:
                        facts.append(_fact(arg, arg.arg, "unresolved", "tls_import_shadowed"))
                statements(node.body, local)
            elif isinstance(node, ast.Import):
                for item in node.names:
                    # `import urllib.request` binds `urllib`, unlike an explicit alias.
                    env[item.asname or item.name.split(".")[0]] = _TLSImportedName(
                        item.name if item.asname else item.name.split(".")[0])
            elif isinstance(node, ast.ImportFrom):
                for item in node.names:
                    env[item.asname or item.name] = _TLSImportedName(f"{node.module}.{item.name}")
            elif isinstance(node, ast.Pass):
                continue
            elif isinstance(node, (ast.Assign, ast.AnnAssign)):
                value = expression(node.value, env)
                targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                for target in targets:
                    assign(target, value, env)
            elif isinstance(node, (ast.Expr, ast.Return)):
                expression(node.value, env)
                if isinstance(node, ast.Return):
                    break
            else:
                # Do not infer safe state across conditionals, loops or try blocks.
                start = len(facts)
                facts.append(_fact(node, "control_flow", "unresolved", "unsupported_control_flow"))
                for value in env.values():
                    invalidate(value)
                for child in ast.walk(node):
                    if isinstance(child, ast.Call):
                        expression(child, {})
                for fact in facts[start:]:
                    fact.update(state="unresolved", reason_code="unsupported_control_flow")
                for child in ast.walk(node):
                    if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Store):
                        env[child.id] = _TLS_UNKNOWN
                    elif isinstance(child, ast.Import):
                        for item in child.names:
                            env[item.asname or item.name.split(".")[0]] = _TLS_UNKNOWN
                    elif isinstance(child, ast.ImportFrom):
                        for item in child.names:
                            env[item.asname or item.name] = _TLS_UNKNOWN

    statements(tree.body, {})
    return facts


def _xml_external_entity_facts(tree: ast.AST, aliases: dict[str, str]) -> list[dict[str, Any]]:
    """Bounded external-entity access evidence, not general XML security.

    Stdlib ElementTree does not expand external entities (CPython 3.12 docs).
    lxml defaults depend on version; a fixed file name says nothing about its
    contents. Require an explicit parser policy, retaining unknown defaults.
    Resolver customization, rebindings and untracked parser uses are unknown.
    """
    calls = [n for n in ast.walk(tree) if isinstance(n, ast.Call)]
    assignments = {}
    for n in ast.walk(tree):
        if isinstance(n, ast.Assign):
            for target in n.targets:
                if isinstance(target, ast.Name):
                    assignments.setdefault(target.id, []).append(n.value)
    customized = any(_name(n.func, aliases).endswith((".xinclude", ".include", ".add", ".set_default_parser"))
                     for n in calls)

    def parser_policy(expr):
        if isinstance(expr, ast.Name):
            values = assignments.get(expr.id, [])
            # A parser passed elsewhere or assigned twice is not a local proof.
            uses = [n for n in calls if any(isinstance(x, ast.Name) and x.id == expr.id
                    for x in [*n.args, *(k.value for k in n.keywords)])]
            if len(values) != 1 or any(not _name(n.func, aliases).endswith((".parse", ".fromstring", ".XML")) for n in uses):
                return "unresolved", "parser_binding_unresolved"
            expr = values[0]
        if not isinstance(expr, ast.Call) or _name(expr.func, aliases) != "lxml.etree.XMLParser":
            return "unresolved", "parser_default_or_custom_policy_unresolved"
        kw = {k.arg: k.value.value if isinstance(k.value, ast.Constant) else None for k in expr.keywords}
        if None in kw or any(v is None for v in kw.values()):
            return "unresolved", "dynamic_parser_configuration"
        if kw.get("resolve_entities") is True or any(kw.get(k) is True for k in ("load_dtd", "dtd_validation", "attribute_defaults")):
            return "unsafe", "external_entity_or_dtd_loading_enabled"
        if kw.get("resolve_entities") in (False, "internal"):
            return "safe", "external_entity_resolution_explicitly_disabled"
        return "unresolved", "version_dependent_lxml_default"

    facts = []
    for n in calls:
        name = _name(n.func, aliases)
        if name not in {"lxml.etree.parse", "lxml.etree.fromstring", "lxml.etree.XML",
                        "xml.etree.ElementTree.parse", "xml.etree.ElementTree.fromstring"} and not (
                name.startswith("defusedxml.") and name.endswith((".parse", ".fromstring"))):
            continue
        parser = next((k.value for k in n.keywords if k.arg == "parser"), n.args[1] if len(n.args) > 1 else None)
        if customized or any(k.arg is None for k in n.keywords):
            state, reason = "unresolved", "xml_customization_or_dynamic_options"
        elif name.startswith("xml.etree.ElementTree.") and parser is None:
            state, reason = "safe", "stdlib_does_not_expand_external_entities"
        elif name.startswith("defusedxml.") and not any(k.arg == "forbid_external" and not (
                isinstance(k.value, ast.Constant) and k.value.value is True) for k in n.keywords):
            state, reason = "safe", "defusedxml_external_entities_forbidden"
        elif name.startswith("lxml."):
            state, reason = parser_policy(parser)
        else:
            state, reason = "unresolved", "custom_xml_parser_unresolved"
        facts.append(_fact(n, name, state, reason))
    return facts


def _cipher_algorithm_facts(
    tree: ast.AST, aliases: dict[str, str]
) -> list[dict[str, Any]]:
    safe = {
        "Crypto.Cipher.AES.new",
        "Crypto.Cipher.ChaCha20.new",
    }
    unsafe = {
        "Crypto.Cipher.ARC2.new",
        "Crypto.Cipher.ARC4.new",
        "Crypto.Cipher.Blowfish.new",
        "Crypto.Cipher.DES.new",
        "Crypto.Cipher.DES3.new",
    }
    facts = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = _name(node.func, aliases)
        if name in safe:
            facts.append(_fact(node, name, "safe", "current_cipher_algorithm_selected"))
        elif name in unsafe:
            facts.append(_fact(node, name, "unsafe", "legacy_cipher_algorithm_selected"))
        elif name.endswith(".new") and "Cipher" in name:
            facts.append(_fact(node, name, "unresolved", "cipher_algorithm_unresolved"))
    return facts


__all__ = [
    "LOCAL_PROFILE_IDS",
    "evaluate_security_profile",
    "security_profile_policy_sha256",
    "security_profile_producer_sha256",
]
