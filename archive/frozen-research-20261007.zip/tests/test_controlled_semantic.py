import itertools
from fractions import Fraction
from math import comb, log, prod, sqrt

import numpy as np
import pytest
from pathlib import Path

from prompt_mechanism_study.artifact_io import read_json
from prompt_mechanism_study.records import content_hash

from prompt_mechanism_study.development.jci_ridge import (
    DiscreteCI, PromptFCI, pearson_binary_margin_variance,
)
from prompt_mechanism_study.development.semantic_discovery import fixed_panel_interval
from prompt_mechanism_study.development.source_generation import jci_measurement_request, jci_measurement_worker
from prompt_mechanism_study.development.source_frame_audit_20260930 import (
    controlled_natural_contract_fingerprints, controlled_reference_contract_fingerprints,
    write_controlled_contract_fingerprints,
)
from prompt_mechanism_study.development.controlled_tasks import (
    FAMILIES, blueprint_identity, candidate_catalog, development_catalog, source_versions,
    assemble_main_semantics,
    controlled_preparation_attempts,
    validate_main_model_accounting,
    checked_policy_prompts,
)
from prompt_mechanism_study.development.jci_ridge import (
    mixed_training_requests, controlled_ridge_features, select_policy, controlled_comparisons, state_coverage,
    controlled_policy_coefficients, controlled_natural_comparison, controlled_requests,
    validate_controlled_natural_execution,
    controlled_natural_policy_sets,
    controlled_natural_nomination,
    controlled_natural_condition_summary,
    controlled_causal_design_check,
    validate_controlled_natural_source_qualification,
    _validate_controlled_natural_qualification_review,
)


@pytest.fixture(scope='module')
def controlled_verifier():
    import importlib.util
    repo = Path(__file__).resolve().parents[1]
    module = importlib.util.spec_from_file_location('controlled_independent_verifier',
        repo / 'docs/experiments/2026-09-30-jci-result-verifier.py')
    verifier = importlib.util.module_from_spec(module)
    module.loader.exec_module(verifier)
    return verifier


def exact_margin_distribution(margins, positive):
    total = sum(margins)
    distribution = []
    for counts in itertools.product(*(range(margin + 1) for margin in margins)):
        if sum(counts) != positive:
            continue
        mass = Fraction(prod(comb(margin, count) for margin, count in zip(margins, counts)),
                        comb(total, positive))
        score = Fraction(0)
        for margin, count in zip(margins, counts):
            for observed, size in ((count, positive), (margin - count, total - positive)):
                expected = Fraction(margin * size, total)
                score += (observed - expected)**2 / expected
        distribution.append((score, mass))
    assert sum(mass for _, mass in distribution) == 1
    return distribution


@pytest.mark.parametrize('margins', [(1, 1), (1, 2), (2, 3), (1, 1, 1),
    (1, 2, 3), (2, 2, 2), (1, 1, 1, 1, 1), (1, 2, 1, 2, 3), (3, 3, 3, 3, 3)])
def test_fixed_margin_variance_against_all_feasible_tables(margins, controlled_verifier):
    for positive in range(1, sum(margins)):
        distribution = exact_margin_distribution(margins, positive)
        mean = sum(score * mass for score, mass in distribution)
        variance = sum((score - mean)**2 * mass for score, mass in distribution)
        assert pearson_binary_margin_variance(margins, positive) == variance
        assert controlled_verifier.independent_pearson_variance(margins, positive) == variance


def test_five_context_ci_against_independent_exact_randomization():
    cells = np.array([[4, 0], [3, 1], [2, 2], [1, 3], [0, 4]])
    rows = [[x, y] for x, y in itertools.product(range(5), range(2)) for _ in range(cells[x, y])]
    result = DiscreteCI('controlled-five-context', ('C', 'Y'), rows=rows).query('C', 'Y', [])
    expected_statistic = sum(Fraction((int(value) - 2)**2, 2) for value in cells.flat)
    distribution = exact_margin_distribution([4] * 5, 10)
    exact_p = sum(mass for score, mass in distribution if score >= expected_statistic)
    assert result['statistic'] == float(expected_statistic)
    assert abs(result['p_value'] - float(exact_p)) < .02
    constant = DiscreteCI('controlled-constant', ('C', 'Y'),
                         rows=[[0, 0], [1, 0], [2, 1], [3, 1], [4, 1]])
    assert constant.query('C', 'Y', [])['status'] == 'statistically_undetermined'


def test_twelve_comparison_precision_cancellation_and_missingness():
    count = 400 * 4
    coefficients = [(f'{arm}-{i}', Fraction(sign, count))
                    for arm, sign in [('A', 1), ('B', -1)] for i in range(count)]
    groups = {key: key for key, _ in coefficients}
    result = fixed_panel_interval(coefficients, groups, comparisons=12)
    assert result['halfwidth'] == pytest.approx(sqrt(log(480) / count))
    doubled = fixed_panel_interval(coefficients + [(key, -value) for key, value in coefficients],
                                   {}, comparisons=12)
    assert doubled['halfwidth'] == 0
    outcomes = {key: [0, 0] for key in groups}
    outcomes['A-0'] = [0, 1]
    missing = fixed_panel_interval(coefficients, groups, outcomes, comparisons=12)
    assert missing['halfwidth'] == result['halfwidth']
    assert missing['completion_bounds'] == [0, 1 / count]
    worst = [(f'{arm}-{i}', Fraction(sign, count))
             for arm, sign in [('A', 1), ('D', 1), ('B', -2)] for i in range(count)]
    assert fixed_panel_interval(worst, {key: key for key, _ in worst}, comparisons=12)[
        'halfwidth'] == pytest.approx(sqrt(3 * log(480) / count))


def test_actual_six_node_fci_with_two_independent_contexts(tmp_path, controlled_verifier):
    labels = ('C', 'V', 'X_local', 'X_example', 'X_reference', 'Y')
    joint = []
    for c, v, x1, x2, x3, y in itertools.product(range(5), range(2), range(2),
                                               range(2), range(2), range(2)):
        p1 = Fraction(3 + 2 * c, 20)
        p2, p3 = Fraction(7, 20), Fraction(9, 20)
        py = Fraction(1 + 7*x1 + 3*x2 + 2*v, 20)
        mass = Fraction(1, 10) * prod(p if state else 1-p
            for p, state in ((p1, x1), (p2, x2), (p3, x3), (py, y)))
        joint.append(((c, v, x1, x2, x3, y), mass))
    assert sum(mass for _, mass in joint) == 1
    ci = DiscreteCI('controlled-background-population', labels, joint=joint)
    with (tmp_path / 'r-stderr.log').open('w', encoding='utf-8') as stderr:
        worker = PromptFCI(stderr)
        exhausted = DiscreteCI('controlled-cpu-budget-boundary', labels, joint=joint,
                               cpu_remaining=lambda: 0.)
        stopped = worker.search(exhausted, '12', ('C', 'V'))
        assert stopped['status'] == 'cpu_budget_exhausted'
        assert stopped['edges'] is None
        assert exhausted.cache == {}
        controlled_verifier.verify_controlled_graph(dict(stopped, selector='J'), labels)
        results = [worker.search(ci, mode, ('C', 'V')) for mode in ('1', '12')]
        worker.close()
    for selector, result in zip(('F', 'J'), results, strict=True):
        controlled_verifier.verify_controlled_graph(dict(result, selector=selector), labels)
        assert result['status'] == 'determined'
        assert result['pcalg'] == '2.7.12'
        edges = result['edges']
        assert all({edge[0], edge[3]} != {'C', 'V'} for edge in edges)
        assert all('X_reference' not in (edge[0], edge[3]) for edge in edges)
        assert any(edge[0] == 'V' and edge[3] == 'Y' for edge in edges)
        assert set(result['ancestors_y']) - {'C', 'V'} <= {'X_local', 'X_example'}


def test_functional_identity_template_partition_and_replay():
    records, splits = candidate_catalog()
    assert len(records) == 1200
    assert len({row['base_task_identity'] for row in records}) == 1200
    assert candidate_catalog() == (records, splits)
    for family in FAMILIES:
        assert not (set(splits[family]['D']) & set(splits[family]['E']))
        for role in ('D', 'E'):
            panel = [row for row in records if row['role'] == role and row['family'] == family]
            assert len(panel) >= 100
            assert [row['candidate_position'] for row in panel] == list(range(1, len(panel) + 1))
            assert len({row['template_identity'] for row in panel}) == (7 if role == 'D' else 8)
    row = records[0]
    identity = blueprint_identity(row['blueprint'])
    for states in itertools.product((0, 1), repeat=3):
        versions = source_versions(row['blueprint'], list(states))
        assert blueprint_identity(row['blueprint']) == identity
        assert versions[0]['baseline'] != versions[1]['baseline']
        for version in versions:
            text = version['baseline']
            assert ('Optional, non-exhaustive illustration' in text) == bool(states[1])
            assert ('For the parameter primary,' in text) == bool(states[2])
            paragraphs = text.split('\n\n')
            operation = next(i for i, p in enumerate(paragraphs) if p.startswith('Use find on primary')
                             or p.startswith('Primary operation:'))
            qualifier = next(i for i, p in enumerate(paragraphs)
                             if 'For the parameter primary,' in p or 'For the primary collection,' in p)
            assert (qualifier == operation) if states[0] else (qualifier - operation >= 3)
            assert text != version['style']


def test_planned_initial_state_support_without_outcome_selection():
    records, _ = candidate_catalog()
    for role in ('D', 'E'):
        panel = [row for row in records if row['role'] == role and row['candidate_position'] <= 100]
        assert len(panel) == 400
        for column in range(3):
            for state in (0, 1):
                assert sum(row['initial_states'][column] == state for row in panel) >= 50
                for family in FAMILIES:
                    assert sum(row['family'] == family and row['initial_states'][column] == state
                               for row in panel) >= 10


def test_development_exposure_has_separate_three_input_contracts():
    main, _ = candidate_catalog()
    development = development_catalog()
    assert len(development) == len({row['base_task_identity'] for row in development}) == 6
    assert not ({row['base_task_identity'] for row in main} &
                {row['base_task_identity'] for row in development})
    for row in development:
        blueprint = row['blueprint']
        assert len({blueprint[key] for key in ('primary_query', 'comparison_query', 'tertiary_query')}) == 3
        for version in row['versions']:
            for key in ('baseline', 'style'):
                assert 'solve(primary: str, comparison: str, tertiary: str)' in version[key]
                assert 'three independent collections' in version[key]
                assert 'The final result is the union of the intermediate set and this tertiary set.' in version[key]


def test_real_prepared_sources_allocation_replay_and_independent_mixture(controlled_verifier):
    repo = Path(__file__).resolve().parents[1]
    root = repo / 'data/method/controlled-semantic-20260930'
    tasks, identities = assemble_main_semantics(repo, ['D-find-001', 'D-find-002', 'D-find-003'])
    assert len(tasks) == len(identities) == 3
    assert controlled_verifier.independent_controlled_coverage(tasks) == state_coverage(tasks)[1]
    environment = read_json(root / 'development-qualified-inputs/environment.json')
    used = {row['seed'] for row in read_json(root / 'development-qualified-inputs/development-requests.json')}
    requests = mixed_training_requests(tasks, 'representative-input-check', environment=environment, used_seeds=used)
    assert requests == mixed_training_requests(list(reversed(tasks)), 'representative-input-check',
                                              environment=environment, used_seeds=used)
    mixture = [row for row in requests if row['component'] == 'random_mixture']
    coverage = [row for row in requests if row['component'] == 'coverage']
    assert len(mixture) == len({row['independent_event'] for row in mixture}) == 4000
    assert sum(len(row['members']) for row in coverage) == 30
    assert len({row['request_id'] for row in requests}) == len(requests)
    assert len({row['seed'] for row in requests}) == len(requests)
    assert not (used & {row['seed'] for row in requests})
    observed_contexts = {(row['task_unit_id'], row['context'], row['version']) for row in mixture}
    assert len(observed_contexts) == 3 * 5 * 2
    by_task = {task['task_unit_id']: task for task in tasks}
    for row in requests:
        task = by_task[row['task_unit_id']]
        assert row['prompt_hash'] == content_hash(task['prompts'][row['prompt_hash']])
        assert row['physical_identity'] == row['independent_group']
        for member in row['members']:
            mapping = task['conditions'][member['flow']][str(member['version'])][member['condition']]
            assert row['prompt_hash'] == mapping['prompt_hash']
            assert row['actual_states'] == mapping['states']
    for task in tasks:
        for column, policy in enumerate(('local', 'example', 'reference')):
            features = controlled_ridge_features(task, policy)
            assert features == pytest.approx(controlled_verifier.independent_controlled_features(task, policy), abs=1e-15)
            assert len(features) == 16
            assert features[:3] == task['initial_states']
            assert features[3 + column] == 1 - 2 * task['initial_states'][column]
            assert sum(abs(value) for value in features[3:6]) == 1
            assert sum(features[6:9]) == sum(features[9:13]) == 1
            assert features[13:15] == [2, 2]
            assert 0 < features[-1] <= 1
    evaluation_seeds = used | {row['seed'] for row in requests}
    for task_id in ('E-find-001', 'E-find-027'):
        evaluation, identities = assemble_main_semantics(repo, [task_id])
        assert len(evaluation) == 1 and len(identities) == 3
        assert evaluation[0]['role'] == 'evaluation' and evaluation[0]['source_role'] == 'E'
        evaluated = controlled_requests(evaluation, 'evaluation', environment, evaluation_seeds)
        checked = controlled_verifier.verify_controlled_allocation(
            evaluation, evaluated, environment, 'evaluation', evaluation_seeds)
        assert checked == dict(physical_requests=len(evaluated), logical_coverage_requests=44,
                              independent_mixture_events=0, distinct_generation_seeds=len(evaluated))
        assert not evaluation_seeds & {row['seed'] for row in evaluated}
        for version in ('1', '2'):
            for condition in ('B', 'S'):
                mappings = [evaluation[0]['conditions'][flow][version][condition]
                            for flow in ('Raw', 'Rich-Flat', 'TSG')]
                assert mappings[0] == mappings[1] == mappings[2]
            if task_id == 'E-find-027':
                raw = evaluation[0]['conditions']['Raw'][version]
                assert all(raw[policy] == raw['B'] for policy in ('local', 'example', 'reference'))
            for repeat in (0, 1):
                assigned = [row for row in evaluated if row['version'] == int(version) and row['repeat'] == repeat]
                assert len(assigned) == len({row['prompt_hash'] for row in assigned})
                assert sum(len(row['members']) for row in assigned) == 11
        evaluation_seeds.update(row['seed'] for row in evaluated)


def test_authorized_sol_checks_preserve_failed_positions(controlled_verifier):
    repo = Path(__file__).resolve().parents[1]
    root = repo / 'data/method/controlled-semantic-20260930'
    tasks, identities = assemble_main_semantics(repo, [f'D-find-{index:03d}' for index in range(4, 10)])
    assert len(tasks) == len(identities) == 6
    policy = read_json(root / 'main-model-policy.json')
    assert policy['model'] == 'gpt-6.1-sol' and policy['reasoning_effort'] == 'high'
    environment = read_json(root / 'development-qualified-inputs/environment.json')
    requests = mixed_training_requests(tasks, 'authorized-input-check', environment=environment)
    coverage = [row for row in requests if row['component'] == 'coverage']
    assert sum(len(row['members']) for row in coverage) == 60
    for task in tasks:
        qualified = root / 'main-qualified' / (task['case_id'] + '-TSG')
        accounting = read_json(qualified / 'review-accounting.json')
        validate_main_model_accounting(root, accounting)
        assert accounting['models'] == ['gpt-6.1-sol'] and accounting['efforts'] == ['high']
        for target in task['policies']['TSG']:
            features = controlled_ridge_features(task, target['policy'])
            assert features == pytest.approx(
                controlled_verifier.independent_controlled_features(task, target['policy']), abs=1e-15)
        if task['case_id'] in ('D-find-004', 'D-find-005'):
            assert all(not row['semantic_qualified'] and row['execution_mapping'] == 'baseline'
                       for row in task['policies']['TSG'])
            for version in ('1', '2'):
                conditions = task['conditions']['TSG'][version]
                assert all(conditions[name] == conditions['B'] for name in ('local', 'example', 'reference'))
                shared = [row for row in coverage if row['task_unit_id'] == task['task_unit_id']
                          and row['version'] == int(version) and row['prompt_hash'] == conditions['B']['prompt_hash']]
                assert len(shared) == 1
                assert {member['condition'] for member in shared[0]['members']} == {'B', 'local', 'example', 'reference'}
                assert shared[0]['actual_states'] == task['initial_states']
                assert all(controlled_ridge_features(task, name)[3:6] == [0, 0, 0]
                           for name in ('local', 'example', 'reference'))


def test_frozen_selection_formula_ties_abstention_and_missing_support(controlled_verifier):
    candidates = [dict(policy=name) for name in ('local', 'example', 'reference')]
    effects = [.12, -.10, .04]
    assert select_policy(candidates, effects, frozen_discovery=True)['action'] == 'local'
    selected = select_policy(candidates, effects, dict(local=0., example=.5, reference=1.), frozen_discovery=True)
    assert selected['action'] == 'example'
    assert selected['direction'] == -1
    assert selected['scores'] == pytest.approx(dict(local=.12, example=.15, reference=.08))
    assert select_policy(candidates, [.1, -.1, .1], frozen_discovery=True)['action'] == 'local'
    assert select_policy(candidates, [0., 0., 0.], frozen_discovery=True)['action'] == 'B'
    for values in (effects, [.1, -.1, .1], [0., 0., 0.]):
        for supports in (None, dict(local=0., example=.5, reference=1.)):
            assert select_policy(candidates, values, supports, frozen_discovery=True) == controlled_verifier.independent_controlled_choice(values, supports)
    with pytest.raises(ValueError, match='完整有效'):
        select_policy(candidates, effects, dict(local=.5), frozen_discovery=True)


def test_physical_comparison_weights_on_real_prepared_contracts(controlled_verifier):
    repo = Path(__file__).resolve().parents[1]
    tasks, _ = assemble_main_semantics(repo, ['D-find-001', 'D-find-002', 'D-find-003'])
    environment = read_json(repo / 'data/method/controlled-semantic-20260930/development-qualified-inputs/environment.json')
    allocation = mixed_training_requests(tasks, 'comparison-algebra', environment=environment)
    requests = [row for row in allocation if row['component'] == 'coverage']
    # 使用真实全文分配核验系数；这里没有模型响应或模型结果。
    decisions = [dict(task_unit_id=task['task_unit_id'], selected=dict(
        RD=dict(status='FROZEN', action='B', direction=0),
        J=dict(status='unexecuted'), F=dict(status='unexecuted')),
        permutation_choices=[], ridge=dict(choice=dict(action='B', direction=0))) for task in tasks]
    comparisons, values = controlled_comparisons(tasks, requests, decisions)
    assert set(comparisons) == {f'H{index}' for index in range(1, 13)}
    by_request = {row['request_id']: row for row in requests}
    for index in range(1, 7):
        result = comparisons[f'H{index}']
        policy = ('local', 'example', 'reference')[(index-1) % 3]
        reference = 'B' if index <= 3 else 'S'
        expected = {}
        for request in requests:
            task = next(row for row in tasks if row['task_unit_id'] == request['task_unit_id'])
            direction = 1-2*task['initial_states'][('local', 'example', 'reference').index(policy)]
            weight = sum(direction if member['condition'] == policy else -direction
                         if member['condition'] == reference else 0 for member in request['members'])
            if weight:
                expected[request['request_id']] = Fraction(weight, 6)
        assert {key: Fraction(value) for key, value in result['coefficients'].items()} == expected
        assert result['halfwidth'] == pytest.approx(sqrt(log(480)/6))
        assert result['deterministic_range'] == [-1., 1.]
        assert all(key in by_request for key in expected)
    assert all(comparisons[f'H{index}']['status'] == 'unexecuted' for index in (7, 8, 9, 12))
    assert all(comparisons[f'H{index}']['coefficients'] == {} for index in (10, 11))
    assert values['RD']['halfwidth'] == values['Ridge']['halfwidth'] == 0
    verifier = controlled_verifier
    independently_verified = verifier.verify_controlled_comparisons(tasks, requests, decisions, comparisons, selector_values=values)
    assert independently_verified['H1']['nonzero_requests'] == comparisons['H1']['nonzero_requests']
    allocation_verified = verifier.verify_controlled_allocation(tasks, allocation, environment, 'training')
    assert allocation_verified['logical_coverage_requests'] == 30
    assert allocation_verified['independent_mixture_events'] == 4000
    incomplete_comparisons = {}
    for hypothesis, specification in comparisons.items():
        if 'coefficients' not in specification:
            incomplete_comparisons[hypothesis] = specification
            continue
        incomplete = fixed_panel_interval(specification['coefficients'].items(),
            {request['request_id']: request['independent_group'] for request in requests},
            {request['request_id']: [0, 1] for request in requests}, comparisons=12)
        incomplete_comparisons[hypothesis] = dict(specification, **incomplete)
    verifier.verify_controlled_comparisons(tasks, requests, decisions, incomplete_comparisons,
                                          {request['request_id']: None for request in requests})
    available_decisions = [dict(task_unit_id=task['task_unit_id'], selected=dict(
        RD=dict(status='FROZEN', action='B', direction=0),
        **{selector: dict(status='FROZEN', **select_policy(
            [dict(policy=name) for name in ('local', 'example', 'reference')], [.12, -.10, .04],
            dict(local=0., example=.5, reference=1.), frozen_discovery=True)) for selector in ('J', 'F')}),
        permutation_choices=[dict(support_permutation=list(indices), weight=1/6,
            choice=select_policy([dict(policy=name) for name in ('local', 'example', 'reference')], [.12, -.10, .04],
                {name: (0., .5, 1.)[index] for name, index in zip(('local', 'example', 'reference'), indices, strict=True)}, frozen_discovery=True))
            for indices in itertools.permutations(range(3))], ridge=dict(choice=dict(action='reference', direction=1)))
        for task in tasks]
    available_comparisons, available_values = controlled_comparisons(tasks, requests, available_decisions)
    verifier.verify_controlled_comparisons(tasks, requests, available_decisions, available_comparisons,
                                          selector_values=available_values)
    missing_values = {name: (dict(specification, **fixed_panel_interval(specification['coefficients'].items(),
        {request['request_id']: request['independent_group'] for request in requests},
        {request['request_id']: [0, 1] for request in requests}, comparisons=12))
        if 'coefficients' in specification else specification) for name, specification in available_values.items()}
    missing_comparisons = {name: (dict(specification, **fixed_panel_interval(specification['coefficients'].items(),
        {request['request_id']: request['independent_group'] for request in requests},
        {request['request_id']: [0, 1] for request in requests}, comparisons=12))
        if 'coefficients' in specification else specification) for name, specification in available_comparisons.items()}
    verifier.verify_controlled_comparisons(tasks, requests, available_decisions, missing_comparisons,
        {request['request_id']: None for request in requests}, missing_values)


def test_five_fold_ridge_against_independent_library_on_frozen_observations(controlled_verifier):
    from sklearn.linear_model import Ridge
    from sklearn.preprocessing import StandardScaler
    from prompt_mechanism_study.development.graph_guided_decisions import fit_task_equal_ridge
    repo = Path(__file__).resolve().parents[1]
    rows = read_json(repo / 'results/jci-ridge-20260930/analysis/analysis/training-features.json')
    tasks = sorted({row['task_unit_id'] for row in rows})
    assignments = {identity: index % 5 for index, identity in enumerate(tasks)}
    penalties = (.01, .1, 1., 10., 100.)
    learner, evaluations = fit_task_equal_ridge(rows, ['continuous']*13,
        task_folds=assignments, penalties=penalties, minimum_task_support=1)
    independent = []
    for penalty in penalties:
        errors = {}
        for fold in range(5):
            training = [row for row in rows if assignments[row['task_unit_id']] != fold]
            validation = [row for row in rows if assignments[row['task_unit_id']] == fold]
            train_tasks = {row['task_unit_id'] for row in training}
            weights = [1/(len(train_tasks)*sum(other['task_unit_id'] == row['task_unit_id']
                       for other in training)) for row in training]
            x = np.asarray([row['features'] for row in training])
            nonconstant = np.ptp(x, axis=0) > 0
            x = x[:, nonconstant]
            scaler = StandardScaler().fit(x, sample_weight=weights)
            retained = scaler.var_ > 1e-15
            model = Ridge(alpha=penalty, fit_intercept=True, solver='cholesky').fit(
                scaler.transform(x)[:, retained], [row['delta_pn'] for row in training], sample_weight=weights)
            predicted = np.clip(model.predict(scaler.transform(
                np.asarray([row['features'] for row in validation])[:, nonconstant])[:, retained]), -1., 1.)
            for identity in {row['task_unit_id'] for row in validation}:
                errors[identity] = np.mean([(prediction-row['delta_pn'])**2 for row, prediction
                    in zip(validation, predicted, strict=True) if row['task_unit_id'] == identity])
        independent.append(dict(penalty=penalty, mse=np.mean(list(errors.values()))))
    assert [row['mse'] for row in evaluations] == pytest.approx([row['mse'] for row in independent], abs=1e-12)
    assert learner.penalty == min(independent, key=lambda row: (row['mse'], -row['penalty']))['penalty']
    assert all(len(row['folds']) == 5 for row in evaluations)
    independently_fitted, independent_folds = controlled_verifier.independent_fixed_fold_ridge(rows, assignments, rows)
    assert independently_fitted['penalty'] == learner.penalty
    assert [row['mse'] for row in independent_folds] == pytest.approx([row['mse'] for row in evaluations], abs=1e-12)
    for name in ('means', 'scales', 'coefficients'):
        assert independently_fitted[name] == pytest.approx(learner.record()[name], abs=1e-10)
    assert independently_fitted['retained'] == learner.record()['retained']
    assert independently_fitted['predictions'] == pytest.approx(learner.predict(rows), abs=1e-10)


def test_independent_raw_measurement_on_frozen_development_and_candidate_controls(controlled_verifier):
    repo = Path(__file__).resolve().parents[1]
    verifier = controlled_verifier
    inputs = repo / 'data/method/controlled-semantic-20260930/development-qualified-inputs'
    requests = read_json(inputs / 'development-requests.json')
    records = verifier.verify_controlled_result_records(read_json(inputs / 'tasks.json'), requests,
        repo / 'results/controlled-semantic-20260930/development')
    original = read_json(repo / 'results/controlled-semantic-20260930/development-independent-verification/verification.json')
    assert records['complete_total_tokens'] == original['provider_total_tokens']
    assert sum(records['outcomes'].values()) == 23
    assert len(records['outcomes']) == records['usage_records'] == 30
    control_inputs = repo / 'data/method/controlled-semantic-20260930/candidate-controls'
    qualified = repo / 'results/controlled-semantic-20260930/candidate-qualified'
    identities = read_json(control_inputs / 'manifest.json')['files']
    assert len(identities) == 3200
    for name in identities:
        request = read_json(control_inputs / name)
        task = dict(family=request['controlled_command']['blueprint']['family'],
                    measurement=request['controlled_command'])
        verifier.verify_controlled_observation(task, request['code'], read_json(qualified / name))


def test_independent_natural_measurement_on_real_source_controls(controlled_verifier):
    import hashlib
    import tarfile
    from prompt_mechanism_study.artifact_io import file_sha256, verify_bundle
    repo = Path(__file__).resolve().parents[1]
    root = repo / 'data/method/controlled-semantic-20260930'
    inputs = root / 'natural-observer-inputs'
    results = repo / 'results/controlled-semantic-20260930/natural-observer-qualified'
    manifest = verify_bundle(inputs)
    verify_bundle(results / 'verified')
    identity = read_json(results / 'verified/identity.json')
    assert identity['input_manifest_sha256'] == file_sha256(inputs / 'manifest.json')
    assert identity['worker_sha256'] == file_sha256(repo / 'src/measurement/natural_command.py')
    assert identity['image'] == read_json(root / 'development-qualified-inputs/environment.json')['image']
    assert len(manifest['files']) == 15 and all(row['matched'] for row in read_json(results / 'verified/summary.json'))
    sources = {row['source_id']: row for row in read_json(root / 'natural-source-acquisition/frame/sources.json')}
    with tarfile.open(root / 'frozen-inputs-and-implementation.tar.gz', 'r:gz') as archive:
        frozen_trace = archive.extractfile('inputs/src/prompt_mechanism_study/measurement/controlled_command.py').read()
    frozen_trace_sha256 = hashlib.sha256(frozen_trace).hexdigest()
    for name in manifest['files']:
        request = read_json(inputs / name)
        source = sources[request['source']['source_id']]
        assert request['source']['source_snapshot_sha256'] == source['source_snapshot_sha256']
        assert request['source']['position'] == source['source_position']
        assert request['shared_trace_sha256'] == frozen_trace_sha256
        assert request['observer_sha256'] == identity['worker_sha256']
        measured = read_json(results / name)
        controlled_verifier.verify_natural_observation(request['natural_command'], request['code'], measured)
        assert measured['security_label'] == request['expected_label']
        if request['expected_functionality'] is not None:
            assert measured['functionality'] == request['expected_functionality']


def test_natural_contract_fingerprints_preserve_real_source_scope_and_unknowns():
    import hashlib
    import json
    repo = Path(__file__).resolve().parents[1]
    root = repo / 'data/method/controlled-semantic-20260930'
    payload = controlled_natural_contract_fingerprints(root)
    sources = read_json(root / 'natural-source-acquisition/frame/sources.json')
    reviews = {row['position']: row for row in read_json(root / 'natural-source-review.json')['reviews']}
    records = payload['records']
    assert payload['natural_source_count'] == len(sources) == 419
    assert payload['current_development_count'] == 6
    assert payload['reference_contracts_included'] is False
    assert payload['protected_contract_content_read'] is False
    assert payload['semantic_comparisons_performed'] == 0
    assert len(records) == len({row['identity']['task_unit_id'] for row in records}) == 425
    for name, digest in payload['input_sha256'].items():
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest
    for source, record in zip(sources, records[:419], strict=True):
        identity, fields = record['identity'], record['functional_fields']
        review = reviews[source['source_position']]
        assert identity['task_unit_id'] == source['source_id']
        assert identity['source_position'] == source['source_position']
        assert identity['source_record_sha256'] == source['source_snapshot_sha256']
        assert fields == {key: value for key, value in review.items() if key in {
            'status', 'basis', 'family', 'contract', 'target_input', 'requirements_to_preserve', 'reason'}}
        assert record['unrecorded_fields'][:len(review.get('unresolved', []))] == review.get('unresolved', [])
        for field in ('contract', 'target_input', 'requirements_to_preserve'):
            if review.get(field):
                assert fields[field] == review[field]
            else:
                assert field in record['unrecorded_fields']
    development = read_json(root / 'development-sources/records.json')
    for source, record in zip(development, records[419:], strict=True):
        assert record['functional_fields'] == dict(blueprint=source['blueprint'], source_versions=source['versions'])
        assert record['identity']['excluded_roles'] == ['D', 'E', 'natural']
    for record in records:
        fields_bytes = json.dumps(record['functional_fields'], ensure_ascii=False,
                                 sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')
        core = {key: value for key, value in record.items() if key != 'fingerprint_sha256'}
        core_bytes = json.dumps(core, ensure_ascii=False, sort_keys=True,
                               separators=(',', ':'), allow_nan=False).encode('utf-8')
        assert record['functional_fields_sha256'] == hashlib.sha256(fields_bytes).hexdigest()
        assert record['fingerprint_sha256'] == hashlib.sha256(core_bytes).hexdigest()
        assert record['semantic_near_duplicate_status'] == 'PENDING_CONTRACT_REVIEW'


def test_reference_contract_fingerprints_preserve_complete_real_scope_and_limited_fields():
    import hashlib
    import json
    from collections import Counter

    repo = Path(__file__).resolve().parents[1]
    dataset = repo / 'data/dataset-curation/reviewer-task-unit-dataset-v5'
    output = repo / 'data/method/controlled-semantic-20260930/reference-contract-fingerprints.json'

    def digest(value):
        return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
            separators=(',', ':'), allow_nan=False).encode('utf-8')).hexdigest()

    def check(condition, reason):
        if not condition:
            pytest.fail(reason, pytrace=False)

    manifest = json.loads((dataset / 'manifest.json').read_bytes())
    payload = json.loads(output.read_bytes())
    names = ('functional-contracts.jsonl', 'task-roles.jsonl', 'near-duplicate-groups.jsonl')
    tables = {}
    check(set(payload) == {'status', 'dataset_manifest_sha256', 'input_sha256',
        'implementation_sha256', 'reference_task_count', 'reference_group_count',
        'semantic_comparisons_performed', 'protected_contract_content_read',
        'protected_prompt_file_read', 'result_values_read', 'records'}, '输出顶层字段超出限定范围')
    check(set(payload['input_sha256']) == set(names), '输入文件范围不符')
    for name in names:
        raw = (dataset / name).read_bytes()
        file_hash = hashlib.sha256(raw).hexdigest()
        check(file_hash == manifest['files'][name]['sha256'] == payload['input_sha256'][name],
              f'冻结文件哈希不符：{name}')
        tables[name] = [json.loads(line) for line in raw.splitlines()]
        check(len(tables[name]) == manifest['files'][name]['record_count'], f'记录数量不符：{name}')
    check(payload['dataset_manifest_sha256'] == hashlib.sha256((dataset / 'manifest.json').read_bytes()).hexdigest(),
          '来源清单哈希不符')
    check(payload['implementation_sha256'] == hashlib.sha256(
        (repo / 'src/development/source_frame_audit_20260930.py').read_bytes()).hexdigest(), '提取实现哈希不符')
    roles = {row['task_unit_id']: row for row in tables['task-roles.jsonl']}
    groups = {}
    for row in tables['near-duplicate-groups.jsonl']:
        for identity in row['task_unit_ids']:
            check(identity not in groups, f'近重复组身份重复：{identity}')
            groups[identity] = row['near_duplicate_group_id']
    contracts = tables['functional-contracts.jsonl']
    records = payload['records']
    check(len(roles) == len(tables['task-roles.jsonl']) == len(contracts) == len(records) == 2165,
          '参照合同未完整覆盖原角色记录')
    check([row['identity']['task_unit_id'] for row in records] == [row['task_unit_id'] for row in contracts],
          '合同顺序或身份不符')
    check(set(groups) == set(roles) == {row['task_unit_id'] for row in contracts}, '参照组覆盖不符')
    functional_keys = ('entrypoint', 'requirements', 'inputs', 'outputs', 'side_effects', 'environment_dependencies')
    identity_keys = {'task_unit_id', 'near_duplicate_group_id', 'origin', 'source_record_sha256',
        'source_prompt_sha256', 'contract_id', 'data_role', 'exposure_status', 'resolution_status',
        'contract_status', 'evidence_status', 'terminal_quality_decision'}
    missing_counts = Counter()
    for original, record in zip(contracts, records, strict=True):
        task_id = original['task_unit_id']
        role, identity = roles[task_id], record['identity']
        check(original['schema_version'] == 'functional-contract-reviewer-5.0', f'合同格式不符：{task_id}')
        # 完整原记录仅用于机械哈希核验；比较读取限定于功能字段、身份和原审查状态。
        core = {key: value for key, value in original.items() if key != 'functional_contract_record_sha256'}
        check(digest(core) == original['functional_contract_record_sha256'], f'原合同记录哈希不符：{task_id}')
        check(set(record) == {'identity', 'functional_fields', 'unrecorded_fields',
            'functional_fields_sha256', 'semantic_near_duplicate_status', 'fingerprint_sha256'},
            f'指纹字段超出限定范围：{task_id}')
        check(set(identity) == identity_keys, f'身份字段超出限定范围：{task_id}')
        check(identity['task_unit_id'] == task_id and identity['near_duplicate_group_id'] ==
            role['near_duplicate_group_id'] == groups[task_id], f'身份或近重复组不符：{task_id}')
        check(identity['origin'] == 'existing-functional-contract', f'合同来源身份不符：{task_id}')
        check(identity['source_record_sha256'] == original['functional_contract_record_sha256'],
              f'合同记录身份不符：{task_id}')
        for key in ('source_prompt_sha256', 'contract_id', 'resolution_status'):
            check(identity[key] == original[key], f'合同身份字段不符：{task_id}：{key}')
        for key in ('data_role', 'exposure_status'):
            check(identity[key] == role[key], f'角色字段不符：{task_id}：{key}')
        for key in ('contract_status', 'evidence_status', 'terminal_quality_decision'):
            check(identity[key] == original['review'][key], f'原审查状态不符：{task_id}：{key}')
        fields = record['functional_fields']
        check(set(fields) == set(functional_keys), f'功能字段范围不符：{task_id}')
        for key in functional_keys:
            check(fields[key] == original[key], f'功能字段内容不符：{task_id}：{key}')
        missing = [key for key in functional_keys if original[key] is None or original[key] == []]
        check(record['unrecorded_fields'] == missing, f'缺失字段保存不符：{task_id}')
        missing_counts.update(missing)
        check(record['functional_fields_sha256'] == digest(fields), f'功能字段哈希不符：{task_id}')
        check(record['fingerprint_sha256'] == digest({key: value for key, value in record.items()
            if key != 'fingerprint_sha256'}), f'指纹哈希不符：{task_id}')
        check(record['semantic_near_duplicate_status'] == 'PENDING_CONTRACT_REVIEW', f'审查状态不符：{task_id}')
    check(payload['status'] == 'PREPARED_CONTRACT_COMPARISON_INPUTS' and
        payload['reference_task_count'] == len(records) and
        payload['reference_group_count'] == len(set(groups.values())), '提取状态或覆盖计数不符')
    check(payload['semantic_comparisons_performed'] == 0 and payload['protected_contract_content_read'] is True and
        payload['protected_prompt_file_read'] is False and payload['result_values_read'] is False, '读取或比较范围不符')
    print(json.dumps(dict(reference_tasks=len(records), reference_groups=len(set(groups.values())),
        data_roles=dict(Counter(row['data_role'] for row in roles.values())),
        exposure_states=dict(Counter(row['exposure_status'] for row in roles.values())),
        missing_field_counts=dict(missing_counts), output_sha256=hashlib.sha256(output.read_bytes()).hexdigest()),
        ensure_ascii=False, sort_keys=True))


def test_contract_export_requires_explicit_scope_and_preserves_existing_output(tmp_path):
    root = Path(__file__).resolve().parents[1] / 'data/method/controlled-semantic-20260930'
    with pytest.raises(ValueError, match='明确指定'):
        write_controlled_contract_fingerprints('unspecified', tmp_path / 'unwritten.json')
    assert not (tmp_path / 'unwritten.json').exists()
    with pytest.raises(ValueError, match='当前来源数据格式'):
        controlled_reference_contract_fingerprints(root / 'development-sources')
    output = tmp_path / 'contracts.json'
    write_controlled_contract_fingerprints('natural', output)
    before = output.read_bytes()
    assert read_json(output) == controlled_natural_contract_fingerprints(root)
    with pytest.raises(FileExistsError):
        write_controlled_contract_fingerprints('natural', output)
    assert output.read_bytes() == before


def test_natural_source_qualification_binds_actual_sources_and_references(controlled_verifier):
    root = Path(__file__).resolve().parents[1] / 'data/method/controlled-semantic-20260930'
    summary = validate_controlled_natural_source_qualification(root)
    assert summary == controlled_verifier.verify_controlled_natural_source_qualification(root)
    assert summary['source_count'] == 419 and summary['qualified_source_count'] == 0
    assert summary['reference_universe_count'] == 2165 + 6
    assert summary['source_disposition_counts'] == dict(
        OUTSIDE_TASK_SCOPE=296, UNKNOWN_IDENTITY=123, NOT_ESTABLISHED=0)
    qualification = read_json(root / 'natural-source-qualification.json')
    assert len(qualification['dispositions']) == 419
    assert all(row['witnesses'] for row in qualification['dispositions'] if row['status'] == 'UNKNOWN_IDENTITY')
    review = read_json(root / 'natural-source-qualification-review.json')
    _validate_controlled_natural_qualification_review(root, qualification, review, summary)
    controlled_verifier.verify_controlled_natural_qualification_review(root, qualification, review, summary)
    assert review['status'] == 'PASS' and len(review['reviewed_source_positions']) == 123


@pytest.mark.parametrize('change', ('missing_reviewed_source', 'qualification_hash', 'incomplete_review'))
def test_natural_source_qualification_requires_complete_independent_review(controlled_verifier, change):
    root = Path(__file__).resolve().parents[1] / 'data/method/controlled-semantic-20260930'
    qualification = read_json(root / 'natural-source-qualification.json')
    summary = validate_controlled_natural_source_qualification(root, qualification)
    review = read_json(root / 'natural-source-qualification-review.json')
    if change == 'missing_reviewed_source':
        review['reviewed_source_positions'].pop()
    elif change == 'qualification_hash':
        review['qualification_sha256'] = qualification['input_sha256']['natural-contract-fingerprints.json']
    elif change == 'incomplete_review':
        review['status'] = 'PENDING'
    with pytest.raises(ValueError):
        _validate_controlled_natural_qualification_review(root, qualification, review, summary)
    with pytest.raises(AssertionError):
        controlled_verifier.verify_controlled_natural_qualification_review(root, qualification, review, summary)


@pytest.mark.parametrize('change', (
    'missing_source', 'source_order', 'source_fingerprint', 'input_hash', 'reference_id',
    'reference_fingerprint', 'missing_witness', 'empty_reason', 'incomplete', 'not_established',
))
def test_natural_source_qualification_rejects_invalid_actual_record_binding(controlled_verifier, change):
    root = Path(__file__).resolve().parents[1] / 'data/method/controlled-semantic-20260930'
    # 每个负例仅修改实际资格的内存副本。
    qualification = read_json(root / 'natural-source-qualification.json')
    row = next(row for row in qualification['dispositions'] if row['status'] == 'UNKNOWN_IDENTITY')
    witness = row['witnesses'][0]
    if change == 'missing_source':
        qualification['dispositions'].pop()
    elif change == 'source_order':
        qualification['dispositions'].reverse()
    elif change == 'source_fingerprint':
        row['fingerprint_sha256'] = qualification['dispositions'][0]['fingerprint_sha256']
    elif change == 'input_hash':
        qualification['input_sha256']['natural-source-review.json'] = qualification['input_sha256']['natural-contract-fingerprints.json']
    elif change == 'reference_id':
        reference = read_json(root / 'reference-contract-fingerprints.json')['records']
        witness['reference_task_unit_id'] = next(item['identity']['task_unit_id'] for item in reference
            if item['identity']['task_unit_id'] != witness['reference_task_unit_id'])
    elif change == 'reference_fingerprint':
        witness['reference_fingerprint_sha256'] = row['fingerprint_sha256']
    elif change == 'missing_witness':
        row['witnesses'] = []
    elif change == 'empty_reason':
        witness['why_needed_for_identity'] = ' '
    elif change == 'incomplete':
        qualification['status'] = 'PREPARATION_PENDING'
    elif change == 'not_established':
        row['status'] = 'NOT_ESTABLISHED'
    with pytest.raises(ValueError):
        validate_controlled_natural_source_qualification(root, qualification)
    with pytest.raises(AssertionError):
        controlled_verifier.verify_controlled_natural_source_qualification(root, qualification)


def test_natural_condition_summary_on_real_observer_controls(controlled_verifier):
    from collections import defaultdict
    from prompt_mechanism_study.artifact_io import verify_bundle
    repo = Path(__file__).resolve().parents[1]
    inputs = repo / 'data/method/controlled-semantic-20260930/natural-observer-inputs'
    results = repo / 'results/controlled-semantic-20260930/natural-observer-qualified'
    profiles = defaultdict(list)
    # 作者控制的真实观察只核对组装规则，不提供自然模型效果。
    for name in verify_bundle(inputs)['files']:
        source = read_json(inputs / name)
        measured = read_json(results / name)
        controlled_verifier.verify_natural_observation(source['natural_command'], source['code'], measured)
        profiles[source['source']['source_id']].append(dict(measured, request_id=name))
    assert len(profiles) == 3
    for rows in profiles.values():
        summary = controlled_natural_condition_summary(rows)
        controlled_verifier.verify_controlled_natural_condition_summary(rows, summary)
        assert summary['assigned'] == 5 and summary['missing'] == 0
        assert summary['mean'] == .6 and summary['completion_bounds'] == [.6, .6]
        assert summary['security_labels'] == {'secure': 3, 'insecure': 1, 'unknown': 1, 'invalid': 0, 'None': 0}
        assert summary['partial_functionality_pass'] == summary['finite_witness_joint'] == 2
        assert summary['complete_functionality_unknown'] == summary['joint_success_unknown'] == 5


def test_generation_measurement_routing_uses_qualified_source_interfaces(controlled_verifier):
    from prompt_mechanism_study.artifact_io import file_sha256, verify_bundle
    repo = Path(__file__).resolve().parents[1]
    root = repo / 'data/method/controlled-semantic-20260930'
    inputs = root / 'natural-observer-inputs'
    results = repo / 'results/controlled-semantic-20260930'
    qualified = read_json(results / 'natural-observer-qualified/verified/identity.json')
    identities = read_json(root / 'development-qualified-inputs/input-identities.json')
    identities['src/measurement/natural_command.py'] = qualified['worker_sha256']
    natural_worker = jci_measurement_worker(repo / 'src/measurement', 'natural', identities)
    assert natural_worker == repo / 'src/measurement/natural_command.py'
    for phase in ('development', 'training', 'evaluation'):
        worker = jci_measurement_worker(repo / 'src/measurement', phase, identities)
        assert worker == repo / 'src/measurement/command_execution.py'
        assert file_sha256(worker) == identities['src/measurement/command_execution.py']
    for name in verify_bundle(inputs)['files']:
        source = read_json(inputs / name)
        task = dict(role='natural', measurement=source['natural_command'])
        payload = jci_measurement_request(task, source['code'])
        assert payload == {key: source[key] for key in ('code', 'natural_command', 'workspace_megabytes')}
        measured = read_json(results / 'natural-observer-qualified' / name)
        controlled_verifier.verify_natural_observation(payload['natural_command'], payload['code'], measured)
    tasks = {row['task_unit_id']: row for row in read_json(root / 'development-qualified-inputs/tasks.json')}
    for request in read_json(root / 'development-qualified-inputs/development-requests.json'):
        destination = results / 'development' / request['request_id']
        record = read_json(destination / 'result/result.json')
        if record['status'] == 'returned':
            code = (destination / 'code.py').read_text(encoding='utf-8')
            assert jci_measurement_request(tasks[request['task_unit_id']], code) == read_json(
                destination / 'measurement-request.json')


def test_actual_preparation_accounting_includes_all_instances_once(controlled_verifier):
    root = Path(__file__).resolve().parents[1] / 'data/method/controlled-semantic-20260930'
    supplemental = [row for row in read_json(root / 'main-reviewed/accounting.json')
                    if row['agent_path'] in {f'/root/controlled_main_review_{index:04d}' for index in (4, 5, 6)}]
    assert len(supplemental) == 3
    accepted = [read_json(path) for path in sorted((root / 'main-qualified').glob('*/review-accounting.json'))]
    attempts = controlled_preparation_attempts(root, accepted)
    assert attempts == controlled_verifier.independent_controlled_preparation_attempts(root)
    assert len(attempts) == len({row['agent_path'] for row in attempts})
    for row in attempts:
        validate_main_model_accounting(root, row)
    unavailable = next(row for row in attempts if row['agent_path'] ==
        '/root/controlled_main_preparation_continuation/controlled_review_0194')
    assert unavailable['usage'] is None and unavailable['uncached_input_plus_output'] is None
    assert unavailable['completion_status'] == 'interrupted' and unavailable['usage_status'] == 'unavailable'
    assert unavailable['usage_unavailable_reason'] == 'interrupted_session_has_no_token_usage'
    assert unavailable['models'] == ['gpt-6.1-sol'] and unavailable['efforts'] == ['high']
    assert unavailable['top_level_requests'] == 1 and unavailable['observed_seconds'] == pytest.approx(12.32)
    initial = [row for row in attempts if row['agent_path'] in {
        *(f'/root/controlled_main_review_{index:04d}' for index in range(1, 7)),
        *(f'/root/controlled_d_find_{index:03d}_tsg' for index in range(1, 7))}]
    assert len(initial) == sum(row['top_level_requests'] for row in initial) == 12
    assert sum(row['models'] == ['gpt-6-astra'] for row in initial) == 9
    assert sum(row['models'] == ['gpt-6.1-sol'] for row in initial) == 3
    assert sum(row['usage']['input_tokens'] for row in supplemental) == 464659
    assert sum(row['usage']['output_tokens'] for row in supplemental) == 4256
    assert sum(row['usage']['total_tokens'] for row in supplemental) == 468915
    assert sum(row['observed_seconds'] for row in supplemental) == pytest.approx(250.615)
    assert controlled_preparation_attempts(root, attempts) == attempts


def test_independent_preparation_trace_on_actual_frozen_positions(controlled_verifier):
    root = Path(__file__).resolve().parents[1] / 'data/method/controlled-semantic-20260930'
    task_ids = [f'D-find-{index:03d}' for index in (*range(1, 19), 39)]
    positions = [f'{task_id}-TSG.json' for task_id in task_ids]
    task_ids.extend(('E-find-001', 'E-find-027'))
    positions.extend(f'{task_id}-{flow}.json'
                     for task_id in ('E-find-001', 'E-find-027') for flow in ('Raw', 'Rich-Flat', 'TSG'))
    verified = controlled_verifier.independent_controlled_preparations(root, positions)
    assert len(verified['semantic_identities']) == 25 and len(verified['costs']) == 50
    actual = [policy for policies in verified['policies'].values() for policy in policies]
    assert len(actual) == 75 and sum(policy['semantic_qualified'] for policy in actual) == 59
    assert sum(policy['execution_mapping'] == 'baseline' for policy in actual) == 16
    tasks, identities = assemble_main_semantics(root.parents[2], task_ids)
    assert identities == verified['semantic_identities']
    assert controlled_verifier.verify_controlled_prepared_tasks(tasks, verified) == dict(tasks=21, preparation_positions=25)
    failed_positions = [(f'D-find-{index:03d}', 'TSG') for index in (4, 5, 13, 39)]
    failed_positions.append(('E-find-027', 'Raw'))
    for task_id, flow in failed_positions:
        name = f'{task_id}-{flow}'
        original = verified['sources'][task_id]
        for policy in verified['policies'][name]:
            assert policy['actual_states'] == original['initial_states']
            assert policy['prompts'] == {str(row['version']): row['baseline'] for row in original['versions']}
    unknown = next(policy for policy in verified['policies']['D-find-018-TSG'] if policy['policy'] == 'local')
    source = verified['sources']['D-find-018']
    assert unknown['review']['status'] == 'unknown' and unknown['execution_mapping'] == 'baseline'
    assert unknown['semantic_qualified'] is False and unknown['actual_states'] == source['initial_states']
    assert unknown['prompts'] == {str(row['version']): row['baseline'] for row in source['versions']}
    index = {row['public_file']: row for row in read_json(root / 'main-sources/preparation-index.json')}
    for name in positions:
        position = index[name]
        source = verified['sources'][position['task_id']]
        materialized = read_json(root / 'main-blind-reviews' / Path(position['review_file']).stem / 'input.json')
        review = read_json(root / 'main-qualified' / Path(name).stem / 'review.json')
        assert checked_policy_prompts(source, materialized, review) == verified['policies'][Path(name).stem]


def test_policy_orientation_for_natural_comparison_on_real_prepared_allocation():
    repo = Path(__file__).resolve().parents[1]
    root = repo / 'data/method/controlled-semantic-20260930'
    tasks, _ = assemble_main_semantics(repo, ['D-find-001', 'D-find-002', 'D-find-003'])
    environment = read_json(root / 'development-qualified-inputs/environment.json')
    allocated = mixed_training_requests(tasks, 'policy-orientation-check', environment=environment)
    requests = [row for row in allocated if row['component'] == 'coverage']
    by_request = {row['request_id']: row for row in requests}
    for index, policy in enumerate(('local', 'example', 'reference')):
        for reference in ('B', 'S'):
            coefficients = controlled_policy_coefficients(tasks, requests, policy, reference)
            expected = {}
            for request in requests:
                task = next(row for row in tasks if row['task_unit_id'] == request['task_unit_id'])
                for member in request['members']:
                    if member['condition'] == policy:
                        expected[request['request_id']] = Fraction(1-2*task['initial_states'][index], 6)
                    elif member['condition'] == reference:
                        expected[request['request_id']] = -Fraction(1-2*task['initial_states'][index], 6)
            assert dict(coefficients) == expected
            assert sum(weight for _, weight in coefficients) == 0
            assert all(by_request[identity]['component'] == 'coverage' for identity, _ in coefficients)
        with pytest.raises(ValueError, match='完整分配'):
            controlled_natural_comparison(tasks, requests, policy)


def test_causal_design_distinguishability_on_actual_prepared_states(controlled_verifier):
    repo = Path(__file__).resolve().parents[1]
    tasks, _ = assemble_main_semantics(repo, [f'D-find-{position:03d}' for position in range(1, 19)])
    specification = controlled_causal_design_check(tasks)
    controlled_verifier.verify_controlled_causal_design(tasks, specification)
    assert specification['fixed_task_count'] == 18
    assert specification['status'] == 'CHECKED_ASSUMED_STRUCTURES'
    assert specification['distinguishable'] is True
    assert specification['empirical_model_outcomes_used'] is False
    assert {name: [row['independent'] for row in scenario['ci_signature']]
        for name, scenario in specification['scenarios'].items()} == {
            'null': [True, True, True, True],
            'state_response': [True, False, False, False],
            'context_response': [False, True, True, True]}
    assert sum(Fraction(row['probability']) for row in specification['input_cells']) == 1
    failed, _ = assemble_main_semantics(repo, ['D-find-004', 'D-find-005', 'D-find-013'])
    blocked = controlled_causal_design_check(failed)
    controlled_verifier.verify_controlled_causal_design(failed, blocked)
    assert blocked['status'] == 'BLOCKED' and blocked['scenarios'] == {}
    assert {row['variable'] for row in blocked['blocked_variables']} == {'X_local', 'X_reference'}
    assert blocked['distinguishable'] is False


def test_natural_plan_arithmetic_on_frozen_synthetic_sources(controlled_verifier):
    repo = Path(__file__).resolve().parents[1]
    root = repo / 'data/method/controlled-semantic-20260930'
    original, _ = assemble_main_semantics(repo, ['D-find-001', 'D-find-002', 'D-find-003'])
    # 在内存中核对自然分配规格；真实来源身份保持 D，检查仅涉及请求计算。
    tasks = [dict(task, role='natural') for task in original]
    environment = read_json(root / 'development-qualified-inputs/environment.json')
    used = {row['seed'] for row in read_json(root / 'development-qualified-inputs/development-requests.json')}
    assert all(task['role'] == 'training' and task['source_role'] == 'D' for task in original)
    for index, policy in enumerate(('local', 'example', 'reference')):
        requests = controlled_requests(tasks, 'natural', environment, used, selected_policy=policy)
        assert requests == controlled_requests(list(reversed(tasks)), 'natural', environment, used, selected_policy=policy)
        assert len(requests) == sum(len(row['members']) for row in requests) == 144
        assert len({row['request_id'] for row in requests}) == len({row['seed'] for row in requests}) == 144
        assert not used & {row['seed'] for row in requests}
        verified_allocation = controlled_verifier.verify_controlled_allocation(
            tasks, requests, environment, 'natural', used, selected_policy=policy)
        assert verified_allocation == dict(physical_requests=144, logical_coverage_requests=144,
                                           independent_mixture_events=0, distinct_generation_seeds=144)
        for task in tasks:
            assigned = [row for row in requests if row['task_unit_id'] == task['task_unit_id']]
            for condition in ('B', policy, 'S'):
                for version in (1, 2):
                    rows = [row for row in assigned if any(member['condition'] == condition
                            and member['version'] == version for member in row['members'])]
                    assert len(rows) == 8 and {row['repeat'] for row in rows} == set(range(8))
                    expected = list(task['initial_states'])
                    if condition == policy:
                        expected[index] = 1-expected[index]
                    assert all(row['actual_states'] == expected for row in rows)
        comparison = controlled_natural_comparison(tasks, requests, policy)
        assert comparison['halfwidth'] == pytest.approx(sqrt(log(480)/(3*16)))
        assert comparison['precision_qualified'] is False
        with pytest.raises(ValueError, match='半宽超过 0.15'):
            validate_controlled_natural_execution(tasks, requests)
        assert comparison['selected_policy'] == policy and comparison['estimand'] == 'STATE_ONE_MINUS_STATE_ZERO'
        assert comparison['fixed_task_count'] == 3 and comparison['alpha'] == .05/12
        assert comparison['nonzero_requests'] == 96
        assert sum(Fraction(value) for value in comparison['coefficients'].values()) == 0
        verified = controlled_verifier.verify_controlled_natural_comparison(tasks, requests, policy, comparison)
        assert verified['fixed_task_count'] == 3 and verified['logical_assignments'] == 144
        assert verified['nonzero_requests'] == 96 and verified['precision_qualified'] is False
        assert verified['halfwidth'] == pytest.approx(comparison['halfwidth'], abs=1e-14)
        # 这些计划请求没有生成结果，按真实缺失状态核对完成范围与原分母。
        assert all(not (repo / 'results/controlled-semantic-20260930/natural'
                        / row['request_id'] / 'result/result.json').exists() for row in requests)
        outcomes = {row['request_id']: None for row in requests}
        incomplete = dict(comparison, **fixed_panel_interval(comparison['coefficients'].items(),
            {row['request_id']: row['independent_group'] for row in requests},
            {identity: [0, 1] for identity in outcomes}, comparisons=12))
        checked = controlled_verifier.verify_controlled_natural_comparison(
            tasks, requests, policy, incomplete, outcomes)
        assert checked == verified
        assert incomplete['status'] == 'INCOMPLETE' and incomplete['estimate'] is None
        assert incomplete['completion_bounds'] == incomplete['interval'] == [-1., 1.]
        assert len(incomplete['missing_nonzero_requests']) == 96
    unknown, _ = assemble_main_semantics(repo, ['D-find-018'])
    with pytest.raises(ValueError, match='事前通过检查'):
        controlled_requests([dict(unknown[0], role='natural')], 'natural', environment, selected_policy='local')


def test_natural_execution_precision_on_actual_prepared_prompts(controlled_verifier):
    repo = Path(__file__).resolve().parents[1]
    root = repo / 'data/method/controlled-semantic-20260930'
    sources, _ = assemble_main_semantics(repo, [f'D-find-{index:03d}' for index in range(1, 23)])
    environment = read_json(root / 'development-qualified-inputs/environment.json')
    # 仅检查实际全文的分配与执行条件，来源 D 身份及冻结研究角色保持原记录。
    for policy in ('local', 'example', 'reference'):
        eligible = [task for task in sources if next(row for row in task['policies']['TSG']
                    if row['policy'] == policy)['semantic_qualified'] is True]
        tasks = [dict(task, role='natural') for task in eligible[:18]]
        assert len(tasks) == 18 and all(task['source_role'] == 'D' for task in tasks)
        requests = controlled_requests(tasks, 'natural', environment, selected_policy=policy)
        plan = validate_controlled_natural_execution(tasks, requests)
        assert plan['precision_qualified'] is True and plan['halfwidth'] == pytest.approx(sqrt(log(480)/(18*16)))
        assert plan['nonzero_requests'] == 18*32
        verified = controlled_verifier.verify_controlled_natural_comparison(tasks, requests, policy, plan)
        allocation = controlled_verifier.verify_controlled_allocation(
            tasks, requests, environment, 'natural', selected_policy=policy)
        assert verified['precision_qualified'] is True and allocation['logical_coverage_requests'] == 18*48
        assert len(requests) == allocation['physical_requests'] == 18*48
    assert all(task['role'] == 'training' for task in sources)


def test_natural_policy_membership_on_actual_semantic_checks(controlled_verifier):
    repo = Path(__file__).resolve().parents[1]
    sources, _ = assemble_main_semantics(repo, [f'D-find-{index:03d}' for index in range(1, 19)])
    # 仅验证事前语义资格到适用集合的计算，真实来源继续保持 D 身份。
    tasks = [dict(task, role='natural') for task in sources]
    sets = controlled_natural_policy_sets(tasks)
    assert sets == controlled_verifier.independent_controlled_natural_policy_sets(tasks)
    assert {policy: len(identities) for policy, identities in sets.items()} == dict(local=14, example=15, reference=15)
    unknown = next(task for task in tasks if task['case_id'] == 'D-find-018')
    assert unknown['task_unit_id'] not in sets['local']
    assert all(unknown['task_unit_id'] in sets[policy] for policy in ('example', 'reference'))
    failed = {task['task_unit_id'] for task in tasks if task['case_id'] in ('D-find-004', 'D-find-005', 'D-find-013')}
    assert all(not failed & set(identities) for identities in sets.values())
    assert sum(map(len, sets.values())) == 44
    assert all(task['role'] == 'training' and task['source_role'] == 'D' for task in sources)


def test_natural_nomination_specification_on_actual_prepared_prompts(controlled_verifier):
    repo = Path(__file__).resolve().parents[1]
    root = repo / 'data/method/controlled-semantic-20260930'
    sources, _ = assemble_main_semantics(repo, [f'D-find-{index:03d}' for index in range(1, 23)])
    tasks = [dict(task, role='natural') for task in sources]
    environment = read_json(root / 'development-qualified-inputs/environment.json')
    sets = controlled_natural_policy_sets(tasks)
    # 提名输入为前瞻性规则的数学检查配置；不产生或保存发现结果。
    for policy in ('local', 'example', 'reference'):
        negative = controlled_natural_nomination(tasks, sets,
            dict(status='FROZEN', action=policy, direction=-1), environment)
        positive = controlled_natural_nomination(tasks, sets,
            dict(status='FROZEN', action=policy, direction=1), environment)
        assert negative['status'] == positive['status'] == 'READY'
        assert negative['fixed_task_ids'] == positive['fixed_task_ids'] == sets[policy]
        assert negative['comparison'] == positive['comparison']
        assert negative['requests'] == positive['requests']
        assert sum(len(row['members']) for row in negative['requests']) == len(sets[policy])*48
        for plan in (negative, positive):
            verified = controlled_verifier.verify_controlled_natural_plan(
                tasks, sets, plan['nomination'], environment, plan)
            assert verified['status'] == 'READY' and verified['fixed_task_count'] == len(sets[policy])
    insufficient_tasks = tasks[:3]
    insufficient_sets = controlled_natural_policy_sets(insufficient_tasks)
    insufficient = controlled_natural_nomination(insufficient_tasks, insufficient_sets,
        dict(status='FROZEN', action='local', direction=1), environment)
    assert insufficient['status'] == 'unexecuted'
    assert insufficient['reason'] == 'NATURAL_FIXED_PANEL_PRECISION_INSUFFICIENT'
    assert insufficient['fixed_task_ids'] == insufficient_sets['local'] and len(insufficient['requests']) == 144
    assert controlled_verifier.verify_controlled_natural_plan(insufficient_tasks, insufficient_sets,
        insufficient['nomination'], environment, insufficient)['reason'] == insufficient['reason']
    unavailable = controlled_natural_nomination(tasks, sets, dict(status='unexecuted'), environment)
    abstained = controlled_natural_nomination(tasks, sets, dict(status='FROZEN', action='B', direction=0), environment)
    assert unavailable['reason'] == 'JCI_NOMINATION_UNAVAILABLE' and unavailable['requests'] == []
    assert abstained['reason'] == 'JCI_ABSTENTION' and abstained['comparison']['alpha'] == .05/12
    for plan in (unavailable, abstained):
        assert controlled_verifier.verify_controlled_natural_plan(tasks, sets,
            plan['nomination'], environment, plan)['reason'] == plan['reason']
    failed = [task for task in tasks if task['case_id'] == 'D-find-004']
    failed_sets = controlled_natural_policy_sets(failed)
    empty = controlled_natural_nomination(failed, failed_sets,
        dict(status='FROZEN', action='local', direction=1), environment)
    assert empty['reason'] == 'NATURAL_POLICY_SET_EMPTY' and empty['fixed_task_ids'] == []
    assert empty['policy_sets'] == failed_sets
    assert controlled_verifier.verify_controlled_natural_plan(failed, failed_sets,
        empty['nomination'], environment, empty)['reason'] == 'NATURAL_POLICY_SET_EMPTY'
