from fractions import Fraction
from math import log, sqrt

import numpy as np
import pytest

from prompt_mechanism_study.development.semantic_discovery import (
    SemanticTextFeatures, class_statistics, fixed_panel_interval,
    materialize_versions, nomination_positions, policy_coefficients, request_plan,
    signed_pick, source_span,
)


def test_fixed_panel_precision_and_shared_cancellation():
    coefficients = [(str(i), Fraction(1 if i % 2 else -1, 48)) for i in range(96)]
    groups = {str(i): str(i) for i in range(96)}
    result = fixed_panel_interval(coefficients, groups)
    assert result['halfwidth'] == pytest.approx(.33790527899)
    assert result['halfwidth'] == pytest.approx(sqrt(log(240) / 48))
    zero = fixed_panel_interval([('same', Fraction(1, 12)), ('same', Fraction(-1, 12))], {})
    assert zero['halfwidth'] == 0
    assert zero['deterministic_range'] == [0, 0]
    coupled = fixed_panel_interval(coefficients, {str(i): 'one' for i in range(96)})
    assert coupled['halfwidth'] > result['halfwidth']


def test_missing_request_completion_and_negative_weight():
    result = fixed_panel_interval([('p', 1), ('n', -1)], {'p': 'p', 'n': 'n'},
                                  {'p': [1, 1], 'n': [0, 1]})
    assert result['estimate'] is None
    assert result['completion_bounds'] == [0, 1]
    assert result['status'] == 'INCOMPLETE'
    with pytest.raises(ValueError):
        fixed_panel_interval([('p', 1)], {'p': 'p'}, {})


def test_true_single_version_reference_sharing_and_independent_seeds():
    tasks = [dict(task_unit_id='task', index=74, reference_prompt='original prompt',
                  measurement={'endpoint': 'finite_html'})]
    candidates = [dict(task_unit_id='task', candidate_id='policy',
                       p_versions=['original prompt'], n_versions=['change one', 'change two'])]
    requests, bindings = request_plan(tasks, candidates, 'V', 'frozen_environment')
    assert len(requests) == 8
    assert len({row['seed'] for row in requests}) == 8
    p = next(row for row in bindings if row['name'] == 'policy:P')
    reference = next(row for row in bindings if row['name'] == 'R')
    assert p['request_weights'] == reference['request_weights']
    coefficients = policy_coefficients(bindings, 'task', 'policy')
    assert sum(value for _, value in coefficients) == 0
    assert request_plan(tasks, candidates, 'V', 'frozen_environment') == (requests, bindings)
    candidates[0]['n_versions'] = ['same', 'same']
    with pytest.raises(ValueError, match='相同文本'):
        request_plan(tasks, candidates, 'V', 'frozen_environment')


def test_task_equal_class_mean_and_no_nomination_support_gate():
    rows = [dict(task_unit_id='a', semantic_class_id='class', delta_pn=1)] * 5
    rows += [dict(task_unit_id=key, semantic_class_id='class', delta_pn=-1)
             for key in ('b', 'c', 'd')]
    result = class_statistics(rows)
    assert result['global_mean'] == -.5
    assert result['categories']['class']['prediction'] == -.5
    rows.append(dict(task_unit_id='e', semantic_class_id='new', delta_pn=0))
    result = class_statistics(rows)
    assert result['categories']['new']['prediction'] == result['global_mean']
    assert signed_pick([dict(candidate_id='new')], [.1])['direction'] == 1
    assert signed_pick([dict(candidate_id='new')], [0]) is None


def test_random_nomination_samples_targets_before_changes():
    rows = [dict(opportunity_id='priority', target_id='first', qualified=True,
                 ordinary_content=True, distinguishable_explanations=True,
                 transferable_definition=True)]
    rows += [dict(opportunity_id=f'a{i}', target_id='many', qualified=True,
                  ordinary_content=True, distinguishable_explanations=False,
                  transferable_definition=True) for i in range(20)]
    rows += [dict(opportunity_id='b', target_id='one', qualified=True,
                  ordinary_content=True, distinguishable_explanations=False,
                  transferable_definition=True)]
    choices = [nomination_positions(rows, seed)[1] for seed in range(1000)]
    assert 430 < choices.count('b') < 570
    assert nomination_positions([], 1) == [None, None]


def test_real_version_mixtures_and_direction_antisymmetry():
    row = dict(canonical_text='task original source', orientation=1,
               p_versions=['one real prompt'], n_versions=['a genuine edit', 'another genuine edit'])
    reverse = dict(row, orientation=-1, p_versions=row['n_versions'], n_versions=row['p_versions'])
    features = SemanticTextFeatures().fit([row])
    assert np.allclose(features.transform([row]), -features.transform([reverse]))


def test_source_positions_and_single_original_realization():
    source = dict(source_prompt='A & B; A & B.', shared_execution_interface='fixed interface')
    assert source_span(source['source_prompt'], 'A & B', 1) == (7, 12)
    assert materialize_versions(source, [[]]) == [
        'A & B; A & B.\n\nShared execution interface:\nfixed interface']
    changed = materialize_versions(source, [[dict(quote='A & B', occurrence=1, replacement='B & A')]])
    assert changed == ['A & B; B & A.\n\nShared execution interface:\nfixed interface']
    with pytest.raises(ValueError, match='重叠'):
        materialize_versions(source, [[dict(quote='A & B', occurrence=0, replacement='B'),
                                       dict(quote='A', occurrence=0, replacement='C')]])
    with pytest.raises(ValueError, match='同一文本'):
        materialize_versions(source, [[], []])
