from pathlib import Path

import pytest

from prompt_mechanism_study.artifact_io import file_sha256, read_json, verify_bundle, write_bundle
from prompt_mechanism_study.development import source_generation


@pytest.mark.parametrize('field', ['generation_workers', 'measurement_workers', 'maximum_pending_measurements'])
def test_jci_rejects_unfrozen_execution_concurrency(tmp_path, field):
    repo = Path(__file__).resolve().parents[1]
    inputs = repo / 'data/method/controlled-semantic-20260930/development-qualified-inputs'
    worker = repo / 'src/measurement/command_execution.py'
    execution = dict(source_generation.JCI_EXECUTION)
    execution[field] = 2
    runtime = tmp_path / 'runtime'
    write_bundle(runtime / 'frozen', {'runtime.json': dict(
        input_manifest_sha256=file_sha256(inputs / 'manifest.json'),
        generation_sha256=file_sha256(Path(source_generation.__file__)),
        worker_sha256=file_sha256(worker), phase='development', execution=execution)})
    write_bundle(runtime / 'ready', {'service.json': {}})
    output = tmp_path / 'results'
    with pytest.raises(ValueError, match='生成输入、实现或运行阶段不匹配'):
        source_generation.run_jci(inputs, runtime, output, worker, 'development')
    assert not output.exists()


def test_jci_actual_response_measurements_preserve_unknown_and_failure():
    repo = Path(__file__).resolve().parents[1]
    results = repo / 'results/controlled-semantic-20260930'
    checked = results / 'pipeline-measurement-check-20261002'
    verify_bundle(checked / 'verified')
    summary = read_json(checked / 'verified/summary.json')
    assert summary['generation_calls'] == 0 and not summary['main_pipeline_generation_executed']
    assert {row['security_label'] for row in summary['checked']} == {'secure', 'unknown', 'invalid'}
    for row in summary['checked']:
        source = results / 'development' / row['request_id']
        actual = checked / row['request_id']
        assert row['source_response_sha256'] == file_sha256(source / 'response.json')
        assert row['source_content_sha256'] == file_sha256(source / 'content.json')
        verify_bundle(actual / 'result')
        previous = read_json(source / 'result/result.json')
        observed = read_json(actual / 'result/result.json')
        for field in ('secure_yield', 'code_valid', 'security_label', 'functionality', 'joint_success',
                      'oracle_support', 'direct_unsafe', 'complete_functionality', 'finite_witness_joint',
                      'unknown_reason', 'endpoint', 'code_sha256', 'envelope_mode'):
            assert observed.get(field) == previous.get(field)
        assert (source / 'code.py').read_bytes() == (actual / 'code.py').read_bytes()
        assert read_json(source / 'measurement-request.json') == read_json(actual / 'measurement-request.json')
    failed = read_json(checked / 'missing-worker/result/result.json')
    assert failed['status'] == 'infrastructure_failed' and failed['secure_yield'] is None
    assert read_json(checked / 'missing-worker/measurement.json')['status'] == 'infrastructure_failure'


def test_jci_actual_measurement_recovery_preserves_original_request():
    repo = Path(__file__).resolve().parents[1]
    request = repo / 'results/controlled-semantic-20260930/evaluation/controlled-evaluation-0fecdc3ca7039ffcb691'
    original = read_json(request / 'result/result.json')
    recovered = source_generation.read_jci_result(request)
    assert original['status'] == 'infrastructure_failed' and original['secure_yield'] is None
    assert recovered['status'] == 'returned'
    measured = read_json(request / 'measurement-recovery/measurement.json')
    assert recovered['secure_yield'] == measured['secure_yield']
    for field in ('request_id', 'seed', 'messages', 'members', 'submitted_utc', 'runtime_manifest_sha256'):
        assert recovered[field] == original[field]
    identity = read_json(request / 'measurement-recovery/identity.json')
    assert identity['original_sha256']['result/manifest.json'] == file_sha256(request / 'result/manifest.json')


def test_jci_measurement_recovery_rejects_changed_original_response(tmp_path):
    import json
    import shutil
    repo = Path(__file__).resolve().parents[1]
    source = repo / 'results/controlled-semantic-20260930/evaluation/controlled-evaluation-0fecdc3ca7039ffcb691'
    destination = tmp_path / 'request'
    shutil.copytree(source, destination)
    response = read_json(destination / 'response.json')
    response['choices'][0]['finish_reason'] = 'length'
    (destination / 'response.json').write_text(json.dumps(response), encoding='utf-8')
    with pytest.raises(ValueError, match='原始记录身份改变'):
        source_generation.read_jci_result(destination)
