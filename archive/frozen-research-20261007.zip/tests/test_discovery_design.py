from copy import deepcopy
import importlib.util
from pathlib import Path
from shutil import copy2, copytree
from tempfile import mkdtemp

import numpy as np
import pytest

from prompt_mechanism_study.development.graph_guided_decisions import (
    DiscoveryFeatures,
    discovery_contract_statistics,
    discovery_pick,
    discovery_weights,
    fit_discovery_ridge,
)
from prompt_mechanism_study.development.graph_guided_report import (
    discovery_mean_interval,
    discovery_missing_interval,
    discovery_shared_bounds,
    discovery_task_vectors,
    discovery_primary_tables,
    discovery_measurement_outcome,
)
from prompt_mechanism_study.artifact_io import file_sha256, read_json, verify_bundle
from prompt_mechanism_study.development.graph_guided_study import (
    discovery_assignments, discovery_bind_preparation, discovery_bound_prompt,
    discovery_model_record,
    discovery_preparation_resource_contract,
    discovery_preparation_diagnostics,
    discovery_materialize_preparation,
    discovery_bind_reviewed,
    _discovery_review_reason_present,
)
from prompt_mechanism_study.development.source_generation import discovery_dispatch_stop_reason
from prompt_mechanism_study.records import canonical_json
from datetime import datetime, timedelta
import hashlib


# 本文件的数值与关系仅为数学例子，没有模型观测或自然任务证据。
def mathematical_row(task, candidate='candidate-a'):
    return dict(
        task_unit_id=task, candidate_id=candidate, contract_id='before-versus-after',
        citation_start=0, orientation=1, delta_pn=0.25,
        canonical_text='Render input using a handler and display the result.',
        p_versions=['Describe the input before the task.', 'Place the input description first.'],
        n_versions=['Describe the input after the task.', 'Place the input description last.'],
        marginals={'input': 1, 'handler': 1, 'view': 1, 'flows_to': 1},
        relations=[('input', 'flows_to', 'handler', 'submit', 'positive')],
    )


def test_mathematical_endpoints_scope_polarity_and_signed_policy():
    original = mathematical_row('task-a')
    rewired, scope, polarity = [deepcopy(original) for _ in range(3)]
    rewired['relations'][0] = ('input', 'flows_to', 'view', 'submit', 'positive')
    scope['relations'][0] = ('input', 'flows_to', 'handler', 'preview', 'positive')
    polarity['relations'][0] = ('input', 'flows_to', 'handler', 'submit', 'negative')
    encoder = DiscoveryFeatures().fit([original, rewired, scope, polarity])
    full, _ = encoder.transform([original, rewired, scope, polarity], 'relations')
    assert all(np.linalg.norm(full[0] - row) > 0 for row in full[1:])
    no_endpoints, _ = encoder.transform([original, rewired], 'endpointless')
    np.testing.assert_array_equal(no_endpoints[0], no_endpoints[1])
    common, _ = encoder.transform([original], 'common')
    np.testing.assert_array_equal(full[0, :common.shape[1]], common[0])
    reverse = deepcopy(original)
    reverse['orientation'] = -1
    reverse['p_versions'], reverse['n_versions'] = reverse['n_versions'], reverse['p_versions']
    opposite, _ = encoder.transform([reverse], 'relations')
    np.testing.assert_array_equal(opposite[0], -full[0])


def test_mathematical_unseen_and_empty_relation_blocks():
    original = mathematical_row('task-a')
    unseen = deepcopy(original)
    unseen['relations'][0] = ('unknown', 'flows_to', 'handler', 'submit', 'positive')
    encoder = DiscoveryFeatures().fit([original])
    _, missing = encoder.transform([unseen], 'relations')
    assert len(missing[0]) == 1
    original['relations'] = []
    empty = DiscoveryFeatures().fit([original])
    complete, _ = empty.transform([original], 'relations')
    ablated, _ = empty.transform([original], 'endpointless')
    np.testing.assert_array_equal(complete, ablated)
    with pytest.raises(ValueError):
        empty.transform([{**original, 'p_versions': ['one version']}], 'common')


def test_task_weights_grouped_learning_and_fixed_selection():
    rows = [mathematical_row(f'task-{i}') for i in range(8)]
    extra = mathematical_row('task-0', 'candidate-b')
    rows.append(extra)
    weights = discovery_weights(rows)
    for task in {row['task_unit_id'] for row in rows}:
        assert sum(w for row, w in zip(rows, weights) if row['task_unit_id'] == task) == 1
    features, model, validation = fit_discovery_ridge(rows)
    assert len(validation) == 4
    assert all(len(entry['folds']) == 8 for entry in validation)
    saved = discovery_model_record(features, model, validation)
    assert canonical_json(saved)
    repeated = fit_discovery_ridge(rows)
    assert saved == discovery_model_record(*repeated)
    verifier_path = Path('docs/experiments/2026-09-29-discovery-verify.py')
    specification = importlib.util.spec_from_file_location('independent_discovery_verifier', verifier_path)
    verifier = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(verifier)
    independent = verifier.independent_definition(rows)
    for field in ('common', 'policy', 'marginals', 'relations'):
        assert independent[field] == saved[field]
    coefficients = verifier.independent_ridge(rows, independent, 'common', model.alpha)
    np.testing.assert_allclose(coefficients, saved['coefficients'], rtol=1e-8, atol=1e-10)
    np.testing.assert_allclose(verifier.independent_feature_matrix(rows, independent, 'common'),
                               features.transform(rows, 'common')[0], rtol=1e-12, atol=1e-12)
    scores = model.predict(features.transform(rows, 'common')[0])
    assert np.all(np.isfinite(scores))
    assert discovery_pick(rows[:2], [-0.4, 0.1])['direction'] == -1
    assert discovery_pick([], []) is None


def test_contract_representative_and_support():
    rows = [mathematical_row(f'task-{i}') for i in range(4)]
    later = mathematical_row('task-0', 'later')
    later.update(citation_start=10, delta_pn=-1)
    stats, global_mean, nominee = discovery_contract_statistics(rows + [later])
    assert stats[0]['tasks'] == 4
    assert stats[0]['mean'] == 0.25
    assert nominee['direction'] == 1
    assert global_mean == pytest.approx(((-0.375) + 3 * 0.25) / 4)
    assert discovery_contract_statistics([]) == ([], None, None)


def test_interval_constant_rare_and_unassessed_states():
    positive = discovery_mean_interval([1] * 26, (-1, 1), 0.01)
    assert positive['lower'] == pytest.approx(0.5065374896513102)
    zero = discovery_mean_interval([0] * 26, (-1, 1), 0.01)
    assert zero['lower'] < -0.1 < 0.1 < zero['upper']
    rare = discovery_mean_interval([1] + [0] * 25, (-1, 1), 0.01)
    assert rare['lower'] < 0 < rare['upper']
    empty = discovery_mean_interval([], (-1, 1), 0.01)
    assert empty == dict(lower=-1.0, upper=1.0, n=0, status='UNASSESSED')
    with pytest.raises(ValueError):
        discovery_mean_interval([float('nan')], (-1, 1), 0.01)


def test_missing_envelope_and_shared_record_cancellation():
    assert discovery_shared_bounds([('shared', 1), ('shared', -1)], {'shared': (0, 1)}) == (0, 0)
    assert discovery_shared_bounds([('P', -1), ('N', 1)], {'P': (0.5, 1), 'N': (0, 0.25)}) == (-1, -0.25)
    missing = discovery_missing_interval([-1] * 26, [1] * 26, (-1, 1), 0.01)
    assert missing['n'] == 26 and missing['missing_tasks'] == 26
    assert missing['lower'] == -1 and missing['upper'] == 1
    observed = discovery_mean_interval([0.5] * 26, (-1, 1), 0.01)
    partial = discovery_missing_interval([-1] + [0.5] * 25, [1] + [0.5] * 25, (-1, 1), 0.01)
    assert partial['lower'] <= observed['lower'] <= observed['upper'] <= partial['upper']


def test_randomization_replay_binding_shared_policies_and_role_cursor():
    task = dict(task_unit_id='mathematical-task', index=1, execution_interface='same interface',
                measurement={'entry_point': 'mathematical-entry'}, reference_prompt='mathematical reference')
    candidate = dict(task_unit_id=task['task_unit_id'], candidate_id='mathematical-candidate',
                     use='open', p_versions=['P-a', 'P-b'], n_versions=['N-a', 'N-b'])
    duplicated = dict(candidate, candidate_id='mathematical-equivalent')
    first, bindings, state = discovery_assignments([task], [candidate, duplicated], 'development')
    replay, replay_bindings, replay_state = discovery_assignments([task], [duplicated, candidate], 'development')
    assert first == replay and bindings == replay_bindings and state == replay_state
    assert len(first) == 12 and len(bindings) == 2
    assert len({row['seed'] for row in first if row['arm'] == 'R'}) == 4
    for version in (0, 1):
        p = {row['seed'] for row in first if row['arm'] == 'P' and row['version'] == version}
        n = {row['seed'] for row in first if row['arm'] == 'N' and row['version'] == version}
        assert p == n and len(p) == 2
    evaluation, _, next_state = discovery_assignments([task], [candidate], 'evaluation', state)
    independent, _, _ = discovery_assignments([task], [candidate], 'evaluation')
    assert {row['request_id'] for row in first}.isdisjoint(row['request_id'] for row in evaluation)
    assert evaluation != independent and state != next_state
    assert all(len(row['candidate_memberships']) == 2 for row in first if row['arm'] != 'R')
    with pytest.raises(ValueError):
        discovery_assignments([task, task], [candidate], 'development')


def test_mathematical_task_vectors_fixed_actions_missing_and_low_expectation():
    task = dict(task_unit_id='mathematical-task', index=1, execution_interface='mathematical interface',
                measurement={'entry_point': 'mathematical-entry'}, reference_prompt='mathematical reference')
    candidate = dict(task_unit_id=task['task_unit_id'], candidate_id='mathematical-candidate',
                     use='open', p_versions=['P-a', 'P-b'], n_versions=['N-a', 'N-b'])
    replication = dict(candidate, candidate_id='mathematical-replication', use='replication')
    assignments, bindings, _ = discovery_assignments([task], [candidate, replication], 'evaluation')
    outcomes = {row['request_id']: dict(primary=[0., 1.], sensitivity=[0., 1.]) for row in assignments}
    action = dict(candidate_id=candidate['candidate_id'], direction=-1)
    decisions = [dict(task_unit_id=task['task_unit_id'], actions=dict(
        tsg=action, raw=action, ridge=action, contract_mean=None,
        replication=dict(candidate_id=replication['candidate_id'], direction=-1)))]
    vectors = discovery_task_vectors(assignments, bindings, decisions, outcomes, [task['task_unit_id']])
    assert vectors['T1'][0]['primary'] == [0., 0.]
    assert vectors['T2'][0]['primary'] == [-1., 1.]
    assert vectors['T3'][0]['primary'] == [-1., 1.]
    for row in assignments:
        value = float(row['arm'] == 'P')
        outcomes[row['request_id']] = dict(primary=[value, value], sensitivity=[value, value])
    vectors = discovery_task_vectors(assignments, bindings, decisions, outcomes, [])
    assert vectors['T2'][0]['primary'] == [-1., -1.]
    tables = discovery_primary_tables(vectors)
    assert tables[1]['primary']['mean_lower'] == -1.
    assert tables[2]['task_units'] == 0
    assert tables[2]['primary']['interval']['status'] == 'UNASSESSED'
    with pytest.raises(ValueError):
        discovery_task_vectors(assignments, bindings, decisions, {}, [])
    with pytest.raises(ValueError):
        discovery_task_vectors(assignments, bindings, decisions, outcomes, ['outside-task'])


def test_actual_program_control_outcomes_security_functionality_and_unknown():
    root = Path(__file__).resolve().parents[1] / 'results/graph-guided-20260929'
    examples = [('static_download', 'secure', 'secure', 'pass', 1),
                ('json_name_count', 'unknown', 'unknown', 'unknown', None),
                ('xml_content', 'overrestrictive', 'secure', 'fail', 0),
                ('product_fields', 'vulnerable', 'insecure', 'pass', 0)]
    for family, control, security, functionality, joint in examples:
        measured = read_json(root / f'{family}-qualification' / f'{control}.json')
        outcome = discovery_measurement_outcome(measured, True)
        assert outcome['security'] == security
        assert outcome['functionality'] == functionality
        assert outcome['joint_success'] == joint
        assert outcome['primary'] == [float(security == 'secure')] * 2


def test_actual_source_preparation_binding_full_prompts_coordinates_and_features():
    root = Path(__file__).resolve().parents[1] / 'data/method/graph-guided-20260929'
    source = read_json(root / 'preparation-inputs/qualified/case-0124/input.json')
    prepared = read_json(root / 'preparation/cli55/case-0124/tsg.json')
    inputs = root / 'binding-review-inputs/case-0124'
    verify_bundle(inputs)
    reviews = {row['blind_id']: row for row in read_json(inputs.parent / 'binding124-final.json')['reviews']}
    annotations = read_json(inputs.parent / 'binding124-source-coordinates.json')
    scoped = {}
    for row in read_json(inputs / 'mapping.json'):
        if row['flow'] != 'TSG':
            continue
        review = dict(reviews[row['blind_id']])
        annotation = annotations[row['blind_id']]
        review.update(semantic_nodes=annotation['semantic_nodes'], relations=annotation['relations'])
        review['contract'] = dict(review['contract'], operation=annotation['operation'])
        scoped[row['candidate_id']] = review
    actual = discovery_bind_preparation(prepared, source, scoped)
    bound_root = root / 'binding/case-0124'
    verify_bundle(bound_root)
    assert actual['candidates'] == read_json(bound_root / 'candidates.json')
    assert len(read_json(bound_root / 'slots.json')) == 4
    assert {row['contract']['operation'] for row in actual['candidates']} == {'REMOVE'}
    for original, bound in zip(prepared['candidates'], actual['candidates'], strict=True):
        for side in ('p_versions', 'n_versions'):
            assert bound[side] == [discovery_bound_prompt(value, source['shared_execution_interface'])
                                   for value in original[side]]
        assert all(text.count(source['shared_execution_interface']) == 1
                   for text in bound['p_versions'] + bound['n_versions'])
    features = DiscoveryFeatures().fit(actual['candidates'])
    forward, _ = features.transform(actual['candidates'], 'relations')
    reverse = [dict(row, orientation=-1, p_versions=row['n_versions'], n_versions=row['p_versions'])
               for row in actual['candidates']]
    backward, _ = features.transform(reverse, 'relations')
    np.testing.assert_allclose(forward, -backward, atol=0, rtol=0)
    assert all(node['source_quote'] in source['source_prompt']
               for row in actual['candidates'] for node in row['semantic_nodes'])


def test_actual_resource_selected_frame_hash_prefix_and_immutable_population():
    root = Path(__file__).resolve().parents[1] / 'data/method/graph-guided-20260929/task-frame'
    verify_bundle(root)
    identity, tasks = read_json(root / 'identity.json'), read_json(root / 'tasks.json')
    assert identity['selected'] == {'development': 16, 'evaluation': 18}
    assert identity['maximum_total_requests'] == 1400
    assert identity['projected_service_seconds'] <= 14400
    assert not identity['generation_effects_used'] and not identity['hypothesis_support_used']
    assert len({row['task_unit_id'] for rows in tasks.values() for row in rows}) == 34
    for role, rows in tasks.items():
        digests = [hashlib.sha256(
            f"tsg-discovery-development-20260929|{role}|{row['task_unit_id']}|2026092901".encode()).hexdigest()
                   for row in rows]
        assert digests == sorted(digests)
    assert all(row['inventory']['exposure_status'] == 'NO_RECORD_IN_INSPECTED_FILES'
               and not row['inventory']['prior_method_mention'] for row in tasks['evaluation'])


def test_actual_launch_limits_with_mathematical_dispatch_times():
    root = Path(__file__).resolve().parents[1]
    launch_path = root / 'data/method/graph-guided-20260929/launch/launch.json'
    launch = read_json(launch_path)
    start = datetime.fromisoformat(launch['t0_utc'])
    protocol = dict(protocol_id=launch['protocol_id'], runtime_limits=dict(
        launch_record=launch, launch_record_sha256=hashlib.sha256(launch_path.read_bytes()).hexdigest(),
        service_started_utc=(start + timedelta(hours=1)).isoformat(),
        prior_generation_attempts=0, prior_service_seconds=0))
    now = start + timedelta(hours=2)
    assert discovery_dispatch_stop_reason(protocol, now, 0) is None
    assert discovery_dispatch_stop_reason(protocol, now, 1752) == 'GENERATION_CALL_LIMIT_REACHED'
    assert discovery_dispatch_stop_reason(protocol, start + timedelta(hours=5), 0) == 'MODEL_SERVICE_LIMIT_REACHED'
    assert discovery_dispatch_stop_reason(protocol, start + timedelta(hours=24), 0) == 'RESEARCH_DEADLINE_REACHED'
    prior = deepcopy(protocol)
    prior['runtime_limits'].update(prior_generation_attempts=1751, prior_service_seconds=10800)
    assert discovery_dispatch_stop_reason(prior, now - timedelta(seconds=1), 0) is None
    assert discovery_dispatch_stop_reason(prior, now, 0) == 'MODEL_SERVICE_LIMIT_REACHED'
    assert discovery_dispatch_stop_reason(prior, now - timedelta(seconds=1), 1) == 'GENERATION_CALL_LIMIT_REACHED'
    changed = deepcopy(protocol)
    changed['runtime_limits']['launch_record']['deadline_utc'] = (start + timedelta(hours=25)).isoformat()
    changed['runtime_limits']['launch_record_sha256'] = hashlib.sha256(
        (canonical_json(changed['runtime_limits']['launch_record']) + '\n').encode()).hexdigest()
    with pytest.raises(ValueError):
        discovery_dispatch_stop_reason(changed, now, 0)


def test_authorized_evaluation_resources_preserve_frozen_development_and_case214():
    root = Path(__file__).resolve().parents[1]
    base = root / 'data/method/graph-guided-20260929'
    frame = read_json(base / 'task-frame/tasks.json')
    for role, tasks in frame.items():
        for task in tasks:
            source = read_json(base / f"preparation-inputs/qualified/case-{task['index']:04d}/input.json")
            resources = discovery_preparation_resource_contract(root, source)
            expected = 64000 if role == 'evaluation' and task['index'] != 214 else 32000
            assert resources['total_token_limit'] == expected
            assert bool(resources['amendment_sha256']) == (expected == 64000)
    authorization = read_json(base / 'evaluation-resource-authorization.json')
    assert len(authorization['evaluation_indices']) == 17
    assert authorization['case214_refreeze_or_retry'] is False


def test_actual_case142_delivered_flow_and_preserved_outputs():
    root = Path(__file__).resolve().parents[1]
    base = root / 'data/method/graph-guided-20260929/preparation/cli55'
    accounting = read_json(base / 'case-0142/accounting.json')
    assert all(row['input_task_identity_verified'] for row in accounting)
    assert all(row['input_flow_instruction_verified'] is False for row in accounting)
    prepared = [read_json(base / f'dev142-{flow}-initial.json') for flow in ('tsg', 'raw')]
    assert all(row['index'] == 142 and row['representation']['flow'] == 'TSG' for row in prepared)
    audited = read_json(base / 'case-0142/accounting.json')
    assert all(row['resource_qualified'] and not row['preparation_flow_qualified'] for row in audited)
    slots = read_json(root / 'data/method/graph-guided-20260929/binding/case-0142/slots.json')
    assert len(slots) == 4
    assert all(row['status'] == 'preparation_flow_not_qualified' for row in slots)


def test_actual_evaluation_full_prompt_and_interface_provenance():
    root = Path(__file__).resolve().parents[1] / 'data/method/graph-guided-20260929'
    source = read_json(root / 'preparation-inputs/qualified/case-0009/input.json')
    prepared = read_json(root / 'preparation/cli55/dev9-raw-initial.json')
    for candidate in prepared['candidates']:
        for side in ('p_versions', 'n_versions'):
            for version in candidate[side]:
                assert discovery_bound_prompt(version, source['shared_execution_interface']) == version['user_prompt']
    interface_source = read_json(root / 'preparation-inputs/qualified/case-0182/input.json')
    original = read_json(root / 'preparation/cli55/dev182-tsg-initial.json')
    unit = next(row for row in original['source_coverage'] if row['id'] == 'u10')
    assert unit['start'] is None and unit['end'] is None
    diagnostics = read_json(root / 'binding/case-0182/diagnostics.json')
    document = next(row for row in diagnostics if row.get('source_unit_id') == 'u10')
    assert document['source_document'] == 'shared_execution_interface'
    start, end = document['actual']
    assert interface_source['shared_execution_interface'][start:end] == unit['quote']


def actual_preparation_diagnostic(index):
    root = Path(__file__).resolve().parents[1] / 'data/method/graph-guided-20260929'
    source = read_json(root / f'preparation-inputs/qualified/case-{index:04d}/input.json')
    prepared = read_json(root / f'preparation/cli55/dev{index}-tsg-initial.json')
    return source, prepared, discovery_preparation_diagnostics(source, prepared)


@pytest.mark.parametrize('index', [232, 90])
def test_actual_empty_tsg_requests_repair(index):
    source, prepared, result = actual_preparation_diagnostic(index)
    assert 'TSG图缺失或节点为空' in result['errors']
    assert '来源覆盖缺失或为空' in result['errors']
    assert prepared == result['normalized_preparation']
    with pytest.raises(ValueError, match='非空图'):
        reviews = {candidate['candidate_id']: dict(status='unknown', reason='原始图缺失')
                   for candidate in prepared['candidates']}
        discovery_bind_preparation(prepared, source, reviews)


def test_actual_case241_local_target_and_global_source_errors_are_separate():
    source, prepared, result = actual_preparation_diagnostic(241)
    assert result['candidate_diagnostics'][1]['errors'] == []
    assert result['candidate_diagnostics'][1]['connected'] is True
    assert result['candidate_diagnostics'][0]['errors']
    assert any(row.get('id') == 'e_shared_export_refines_name' for row in result['graph_diagnostics'])
    assert any('system_prompt' in error for error in result['errors'])
    assert any('shared_execution_interface' in error for error in result['errors'])
    for unit in result['normalized_preparation']['source_coverage']:
        assert source[unit['source_document']][unit['start']:unit['end']] == unit['quote']
    assert 'occurrence' not in prepared['source_coverage'][0]
    assert result['normalized_preparation']['source_coverage'][0]['occurrence'] == 0


def test_actual_case182_supported_forest_and_interface_citations():
    source, prepared, result = actual_preparation_diagnostic(182)
    assert result['graph_diagnostics'] == []
    assert all(row['errors'] == [] and row['connected'] is False for row in result['candidate_diagnostics'])
    assert all(error.startswith('来源单元需要显式source_document:') or
               error == '来源覆盖不完整:system_prompt:未覆盖非空白字符125:首位置0'
               for error in result['errors'])
    unit = next(row for row in result['normalized_preparation']['source_coverage'] if row['id'] == 'u10')
    assert unit['source_document'] == 'shared_execution_interface' and unit['editable'] is False
    assert source[unit['source_document']][unit['start']:unit['end']] == unit['quote']
    assert next(row for row in prepared['source_coverage'] if row['id'] == 'u10')['start'] is None
    complete = discovery_preparation_diagnostics(source, prepared, complete=True)
    assert all(any('完整提示字符串' in error for error in row['errors'])
               for row in complete['candidate_diagnostics'])
    assert all(any('13个完整字段' in error for error in row['errors'])
               for row in complete['candidate_diagnostics'])


@pytest.mark.parametrize(('index', 'qualified_tsg'), [(241, 1), (182, 2)])
def test_actual_reviewed_binding_preserves_selected_support_without_path_completion(index, qualified_tsg):
    repository = Path(__file__).resolve().parents[1]
    relative = Path('data/method/graph-guided-20260929')
    original = repository / relative
    runtime = repository / '.codex-runtime'
    runtime.mkdir(exist_ok=True)
    scratch = Path(mkdtemp(prefix=f'discovery-reviewed-{index}-', dir=runtime))
    frozen_manifest = original / f'binding/case-{index:04d}/manifest.json'
    frozen_sha = file_sha256(frozen_manifest)
    inputs = Path(f'binding-review-inputs/case-{index:04d}')
    copytree(original / inputs, scratch / relative / inputs)
    review_names = [f'binding{index}-final.json', f'binding{index}-source-coordinates.json']
    for name in review_names:
        source_path = original / 'binding-review-inputs' / name
        if source_path.is_file():
            copy2(source_path, scratch / relative / 'binding-review-inputs' / name)
    mapping = read_json(original / inputs / 'mapping.json')
    for row in mapping:
        destination = scratch / row['preparation_path']
        destination.parent.mkdir(parents=True, exist_ok=True)
        copy2(repository / row['preparation_path'], destination)
    discovery_bind_reviewed(scratch, index)
    result = scratch / relative / f'binding/case-{index:04d}'
    verify_bundle(result)
    candidates = read_json(result / 'candidates.json')
    assert sum(candidate['flow'] == 'TSG' for candidate in candidates) == qualified_tsg
    assert len(read_json(result / 'slots.json')) == 4
    diagnostics = next(row for row in read_json(result / 'diagnostics.json')
                       if row['flow'] == 'TSG' and 'candidate_diagnostics' in row)
    assert diagnostics['graph_edges_added'] is False
    prepared_path = next(row['preparation_path'] for row in mapping if row['flow'] == 'TSG')
    original_preparation = read_json(repository / prepared_path)
    selected = {row['candidate_id']: row['subgraph'] for row in original_preparation['candidates']}
    for row in diagnostics['candidate_diagnostics']:
        assert row['selected_node_ids'] == selected[row['candidate_id']]['node_ids']
        assert row['selected_edge_ids'] == selected[row['candidate_id']]['edge_ids']
    if index == 241:
        assert diagnostics['graph_diagnostics']
    else:
        assert all(row['connected'] is False for row in diagnostics['candidate_diagnostics'])
    assert file_sha256(frozen_manifest) == frozen_sha


def test_actual_repaired_case90_structured_review_reason_and_complete_preparation():
    repository = Path(__file__).resolve().parents[1]
    root = repository / 'data/method/graph-guided-20260929/preparation-repair/pilot-tokenized/case-0090/TSG'
    prepared, source = read_json(root / 'final.json'), read_json(root / 'source.json')
    reason = prepared['review']['reason']
    assert isinstance(reason, dict) and len(reason) == 8
    assert _discovery_review_reason_present(reason)
    assert all(_discovery_review_reason_present(value) for value in reason.values())
    for invalid in (None, '', '  ', [], {}, {'source': ''}, {'source': []}, {'source': {'nested': 'value'}}):
        assert not _discovery_review_reason_present(invalid)
    actual = discovery_preparation_diagnostics(source, prepared, complete=True)
    assert actual['errors'] == []
    assert actual['graph_diagnostics'] == []
    assert len(actual['candidate_diagnostics']) == 2
    assert all(row['errors'] == [] for row in actual['candidate_diagnostics'])
    original = read_json(root / 'diagnostics.json')
    assert len(original['errors']) == 2
    assert all('候选缺少语义审查理由' in error for error in original['errors'])


def actual_case241_exact_edits():
    root = (Path(__file__).resolve().parents[1] /
            'data/method/graph-guided-20260929/preparation-repair/main/case-0241/TSG')
    source, prepared = read_json(root / 'source.json'), read_json(root / 'final.json')
    edited = deepcopy(prepared)
    suffix = '\n\nShared execution interface: ' + source['shared_execution_interface']
    for candidate in edited['candidates']:
        for arm in ('p', 'n'):
            versions = candidate.pop(f'{arm}_versions')
            assert all(version.endswith(suffix) for version in versions)
            candidate[f'{arm}_edits'] = [
                [] if version.removesuffix(suffix) == source['source_prompt'] else
                [dict(quote=source['source_prompt'], occurrence=0,
                      replacement=version.removesuffix(suffix))]
                for version in versions]
    return source, prepared, edited


def test_actual_prompt_edits_reproduce_frozen_versions_and_repeat_diagnostics():
    source, prepared, edited = actual_case241_exact_edits()
    untouched = deepcopy(edited)
    rendered = discovery_materialize_preparation(source, edited)
    assert edited == untouched
    suffix = '\n\nShared execution interface: ' + source['shared_execution_interface']
    rendered_suffix = '\n\nShared execution interface:\n' + source['shared_execution_interface']
    for original, candidate in zip(prepared['candidates'], rendered['candidates'], strict=True):
        for key in ('p_versions', 'n_versions'):
            assert candidate[key] == [value.removesuffix(suffix) + rendered_suffix for value in original[key]]
        assert 'p_edits' in candidate and 'n_edits' in candidate
    diagnostics = discovery_preparation_diagnostics(source, rendered, complete=True)
    assert diagnostics['errors'] == []
    repeated = discovery_preparation_diagnostics(source, diagnostics['normalized_preparation'], complete=True)
    assert repeated == diagnostics
    assert discovery_preparation_diagnostics(source, edited, complete=True) == diagnostics
    assert discovery_materialize_preparation(source, prepared) == prepared
    with pytest.raises(ValueError, match='禁止同时提交全文'):
        discovery_materialize_preparation(source, rendered)
    changed = deepcopy(rendered)
    changed['candidates'][0]['p_versions'][0] = prepared['candidates'][0]['n_versions'][0]
    with pytest.raises(ValueError, match='渲染不一致'):
        discovery_preparation_diagnostics(source, changed, complete=True)


def test_actual_prompt_edits_use_original_positions_for_multiple_replacements():
    source, prepared, edited = actual_case241_exact_edits()
    prompt = source['source_prompt']
    split = prompt.index('Security Policy:')
    replacement = edited['candidates'][0]['p_edits'][0][0]['replacement']
    assert replacement[:split] == prompt[:split]
    edited['candidates'][0]['p_edits'][0] = [
        dict(quote=prompt[split:], occurrence=0, replacement=replacement[split:]),
        dict(quote=prompt[:split], occurrence=0, replacement=prompt[:split]),
    ]
    rendered = discovery_materialize_preparation(source, edited)
    suffix = '\n\nShared execution interface: ' + source['shared_execution_interface']
    rendered_suffix = '\n\nShared execution interface:\n' + source['shared_execution_interface']
    assert rendered['candidates'][0]['p_versions'][0] == (
        prepared['candidates'][0]['p_versions'][0].removesuffix(suffix) + rendered_suffix)
    assert edited['candidates'][0]['n_edits'][0] == []
    assert rendered['candidates'][0]['n_versions'][0] == (
        prepared['candidates'][0]['n_versions'][0].removesuffix(suffix) + rendered_suffix)


@pytest.mark.parametrize('failure', ['absent_quote', 'outside_source', 'overlap', 'bad_occurrence',
                                     'boolean_occurrence', 'empty_quote', 'bad_replacement',
                                     'extra_coordinate', 'duplicate_interface', 'missing_arm'])
def test_actual_prompt_edits_reject_invalid_source_transformations(failure):
    source, _, edited = actual_case241_exact_edits()
    candidate = edited['candidates'][0]
    edit = candidate['p_edits'][0][0]
    if failure == 'absent_quote':
        edit['occurrence'] = 1
    elif failure == 'outside_source':
        assert source['system_prompt'] not in source['source_prompt']
        edit['quote'] = source['system_prompt']
    elif failure == 'overlap':
        quote = 'Security Policy:'
        assert quote in source['source_prompt']
        candidate['p_edits'][0].append(dict(quote=quote, occurrence=0, replacement=quote))
    elif failure == 'bad_occurrence':
        edit['occurrence'] = -1
    elif failure == 'boolean_occurrence':
        edit['occurrence'] = False
    elif failure == 'empty_quote':
        edit['quote'] = ''
    elif failure == 'bad_replacement':
        edit['replacement'] = None
    elif failure == 'extra_coordinate':
        edit['source_document'] = 'source_prompt'
    elif failure == 'duplicate_interface':
        edit['replacement'] += '\n' + source['shared_execution_interface']
    elif failure == 'missing_arm':
        del candidate['n_edits']
    with pytest.raises(ValueError):
        discovery_materialize_preparation(source, edited)
    with pytest.raises(ValueError):
        discovery_preparation_diagnostics(source, edited, complete=True)


def test_actual_targeted_repair_contract_operations_and_complete_diagnostics():
    root = (Path(__file__).resolve().parents[1] /
            'data/method/graph-guided-20260929/preparation-repair/targeted-20260929/main')
    paths = sorted(root.glob('case-*/*/final.json'))
    assert len(paths) == 15
    failures, qualified = [], []
    for path in paths:
        source, prepared = read_json(path.parent / 'source.json'), read_json(path)
        result = discovery_preparation_diagnostics(source, prepared, complete=True)
        if result['errors']:
            for row in result['candidate_diagnostics']:
                assert row['errors'] == ['合同operation必须与候选operation逐字相同']
                failures.append((source['index'], path.parent.name, row['candidate_id']))
            assert result['graph_diagnostics'] == []
        else:
            assert result['graph_diagnostics'] == []
            qualified.append((source['index'], path.parent.name))
    assert len(qualified) == 13
    assert len(failures) == 4
    assert [(index, flow) for index, flow, _ in failures] == [(9, 'TSG')] * 2 + [(182, 'Raw')] * 2


def test_actual_targeted_selector_task_isolation_and_effect_accounting():
    directory = Path('results/graph-guided-20260929/targeted-causal-selectors')
    verify_bundle(directory)
    features = {row['candidate_id']: row for row in read_json(directory / 'features.json')}
    targets = read_json(directory / 'targets.json')
    folds = read_json(directory / 'folds.json')
    summary = read_json(directory / 'summary.json')
    aliases = read_json(directory / 'aliases.json')
    assert len(features) == len(targets) == 18
    assert len(folds) == 10 and sum(map(len, aliases.values())) == 19
    assert all(row['orientation'] == 1 and row['marginals'] == {} and row['relations'] == []
               for row in features.values())
    for fold in folds:
        assert len(fold['training_task_ids']) == 9
        assert fold['task_unit_id'] not in fold['training_task_ids']
        assert set(fold['candidate_ids']).isdisjoint(fold['training_candidate_ids'])
        assert set(fold['candidate_ids']) | set(fold['training_candidate_ids']) == set(features)
        assert set(fold['unseen_contracts']) == set(fold['candidate_ids'])
        for method, record in fold['alphas'].items():
            chosen = min(record['inner_evaluations'], key=lambda row: (row['mse'], -row['alpha']))
            assert record['selected'] == chosen['alpha']
            for entry in record['inner_evaluations']:
                assert {row['task_unit_id'] for row in entry['folds']} == set(fold['training_task_ids'])
            scores = dict(zip(fold['candidate_ids'], fold['predictions'][method], strict=True))
            ordered = sorted(scores, key=lambda identity: (
                -abs(scores[identity]) if method == 'effect-ridge' else -scores[identity], identity))
            assert fold['choices'][method]['candidate_id'] == ordered[0]
        for method, distribution in fold['distributions'].items():
            assert sum(row['probability'] for row in distribution) == pytest.approx(1.)
            utility, lower, upper = 0., 0., 0.
            for selection in distribution:
                target = targets[selection['candidate_id']]
                probability, direction = selection['probability'], selection['direction']
                assert features[selection['candidate_id']]['task_unit_id'] == fold['task_unit_id']
                utility += probability * direction * target['delta_pn']
                endpoints = [direction * value for value in target['unknown_bounds']]
                lower += probability * min(endpoints)
                upper += probability * max(endpoints)
            assert fold['evaluation'][method]['signed_pn_utility'] == pytest.approx(utility)
            assert fold['evaluation'][method]['unknown_bounds'] == pytest.approx([lower, upper])
    for method, result in summary.items():
        values = [row['evaluation'][method] for row in folds]
        assert result['task_equal_utility'] == pytest.approx(
            sum(row['signed_pn_utility'] for row in values) / 10)
        assert result['task_equal_unknown_bounds'] == pytest.approx([
            sum(row['unknown_bounds'][i] for row in values) / 10 for i in (0, 1)])
