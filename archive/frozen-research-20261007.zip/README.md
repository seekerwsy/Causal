# CausalGuide

Research prototype for finding and testing prompt-side security requirements in
LLM code generation. Each Atomic policy changes one complete requirement while
preserving the task's non-target behavior.

The normative [protocol](docs/protocol.md) is `phase-context-policy-v3`,
**SPECIFIED_DRAFT**. Formal execution is inactive. Implemented components, offline
smoke checks and bounded development results do not establish whole-method efficacy.

The completed [controlled research design](docs/experiments/2026-09-30-controlled-semantic-interventions.md)
is **DESIGN_FINALIZED** and has completed execution and independent verification
under the owner's authorization.
It specifies controlled semantic interventions with
400 synthetic discovery tasks and 400 independent synthetic validation tasks,
JCI/FCI/RD comparisons, isolated Raw/Rich-Flat/TSG preparation, and separately
defined natural-task transfer evaluation. The complete design caps Qwen attempts
at 28,510, including representation controls and development checks. Its inputs
and implementation passed qualification before model generation. The
[execution record](docs/experiments/2026-09-30-controlled-semantic-execution.md)
tracks preparation, frozen inputs, actual execution and independent verification.
The [controlled research report](docs/experiments/2026-09-30-controlled-semantic-results.md)
records verified source qualification, representation preparation, discovery,
all 9,216 evaluation requests, eleven executed primary comparisons and complete
costs. The twelfth comparison remains unexecuted because its prospectively frozen
natural-task eligibility sets are empty. The
[independent verification](results/controlled-semantic-20260930/verification/verification.json)
passed the complete report. All nonconstant primary intervals include zero;
JCI, FCI and RD select the same action, so their contrasts cancel exactly.
The evidence supports no positive TSG or JCI increment in this fixed panel.

The current bounded [development repair](docs/experiments/2026-10-07-controlled-repair.md)
checks actual native-tool target access, signed safety-gain selection with baseline
abstention, and complete preparation/review submissions on already exposed inputs.
Its real Docker observations and independent decision verification are separate
development evidence. Completed study outputs retain their frozen rules and identities.

The completed bounded-development
[protocol](docs/experiments/2026-09-30-jci-ridge-comparison-plan.md) is
`jci-ridge-development-20260930`, `AUTHORIZED_BOUNDED_RESEARCH`.
TSG binds Atomic ordinary-content policies. A shared task-equal Ridge is compared
with FCI-time and JCI12-FCI ancestor-priority consumers. Actual qualified command
execution tasks determine the training and evaluation sizes. Structure learning
uses fresh requests with independently randomized task and policy-slot assignment.
Limits are 24 hours, 1344 Qwen generation attempts, six hours of model service,
and two hours of structure CPU. Source, policy and measurement qualification
must finish before their first model request. The
[readiness record](docs/experiments/2026-09-30-jci-readiness.md) separates completed
checks, frozen qualified inputs, completed training analysis and evaluation execution.
The [result report](docs/experiments/2026-09-30-jci-ridge-results.md) records all
312 generations, 202 graph searches and independent verification. JCI changes
context endpoints, while all three frozen selectors choose identical actions
and signs. The report preserves unknown outcomes and identifies concrete
measurement limitations. The [review guide](docs/experiments/2026-09-30-jci-review-guide.md)
provides the single reproduction path and exact measurement image.
The formal draft above remains inactive.

The following records preserve completed bounded studies and their frozen evidence.
The [previous development protocol](docs/graph-guided-discovery-protocol.md),
[research result](docs/experiments/2026-09-30-goal-result.md) and
[review guide](docs/experiments/2026-09-30-review-guide.md) document the completed
SCM comparison, exposed-task generation, source preparation and verification.
Its prospective precision gate stopped new O/V generation; it produced no O/V
effect or method-superiority claim.
The [design validation](docs/experiments/2026-09-29-discovery-design-validation.md)
checks encoding and interval rules. Its prospective power calculations do not
qualify the day-scale sample for reliable algorithm-superiority conclusions.
The [archived discovery review guide](docs/experiments/2026-09-29-discovery-review-guide.md)
identifies the frozen development inputs, seven scientific stages and independent
verification entry. Its actual frame contains 16 development and 18 evaluation
tasks. The [executed study record](docs/experiments/2026-09-29-discovery-run-status.md)
reports 520 local-model code-generation requests and independent result verification.
The [authorized preparation repair](docs/experiments/2026-09-29-tsg-preparation-repair.md)
completed 72 source-representation, hypothesis-preparation and intervention-editing
requests on those 18 now-exposed tasks. Seventeen final TSGs are nonempty; one
preparation failed. Independent semantic and graph reviews retain disagreements,
missing positions and a documented flow-blinding failure. A subsequent targeted
repair completed 30 preparation requests across 15 registered streams on 12 exposed
tasks, producing nine nonempty TSGs and 27 policies in 30 fixed positions. Independent
mechanical checks pass 13 streams; both semantic reviewers support 22 positions,
with 19 also passing the mechanical checks. The targeted public materials pass the
registered flow-label checks. Both separate graph reviews support all nine graphs'
source fidelity and coverage and all 15 materialized targets' local source support;
missing positions remain unknown. The subsequent Qwen generation completed all
256 assigned requests for 27 prepared policies on 12 tasks: 254 returned code and
two were truncated. Independent verification reproduced all six endpoints and
324 policy-effect bounds. The result report separates concrete unsafe witnesses
from unknown coverage, dependency failures and target-coupled functionality.
These repairs retain their exposed-task method-development identities and the
original frozen results.
The [current causal comparison](docs/experiments/2026-09-29-causal-comparison-results.md)
executes 1792 FCI/JCI/GFCI searches on task-level subsamples of the repaired real
outputs, including exact conditional tests, and a nested leave-one-task-out
comparison of six policy selectors. Sparse-test sensitivity, known-context
orientation, shared-request uncertainty, and case-level sources of apparent
selection gains are reported separately. These exposed-data analyses do not
establish structural-algorithm superiority or a graph contribution.
The [completed bounded-run record](docs/experiments/2026-09-28-graph-guided-report.md)
tracks the authorized bounded run, completed checks, and outstanding scientific work.
The owner-authorized repair supplement has executed 267 additional local-model
requests and 3536 additional main structure searches. It adds semantic selector
inputs, six ordinary-content edit operations, three measurable source tasks,
revised measurement preparation, and source-only review material for 49 prepared
tasks and 48 authored graphs. Independent semantic review is deferred;
all supplementary evidence retains its exploratory identity.
The [current bounded-run reproduction guide](docs/experiments/2026-09-28-graph-guided-review-guide.md)
identifies its seven stages, core files, real-code measurement checks, and independent result verification.
The [bounded development research report](docs/experiments/2026-09-28-source-hypotheses-report.md)
records the executed source, intervention, model-generation, measurement and policy-selection evidence, together with unmet natural-source and independent-evaluation requirements. Its [original experiment plan](docs/next-experiment-plan.md) retains the executed study's design.
Formal experiments remain inactive. The
[completed day-scale development report](docs/experiments/2026-09-26-day-research-report.md)
records the available evidence from the preceding study.

## Formal draft and reviewer smoke

```text
representation → prioritization → hypothesis freeze
→ intervention/randomization → measurement → outcome assembly → inference/reporting
```

| Stage | Responsibility |
| --- | --- |
| Representation | Preserve requirements, objects, conditions and scope in Prompt TSG; construct Atomic candidates. |
| Prioritization | Check support and compare Full (FCI admission plus RD ranking) with RD-only on the same candidates and folds. |
| Hypothesis freeze | Fix policies, slots, task populations, models, budgets and analysis before evaluation. |
| Intervention/randomization | Assign Target, No-op, Style and Generic-security prompts for one requirement. |
| Measurement | Measure security, code validity and functionality independently of assigned-arm labels. |
| Outcome assembly | Account for every assigned task/arm/seed, including failure and unknown. |
| Inference/reporting | Estimate task-unit ITT effects, retain the frozen comparison family and independently verify saved results. |

The table describes the formal draft and existing smoke. The completed bounded study's
seven stages, scientific rules and implementation status are specified together
in the [development protocol](docs/experiments/2026-09-30-jci-ridge-comparison-plan.md).

TSG edges express source semantics, not causal relationships. An unexpressed
requirement does not imply insecure generated code; unknown does not mean absent.
Post-assignment compliance, generation success and drift never filter the ITT
denominator. Secure-code yield, Oracle coverage, functionality and joint success
remain separate. Current TSG uses source-contract schema 4, graph schema 3 and concept-catalog schema 2;
older formats are replayed with their captured Git implementation.
TSG program validation checks structure, references and source locations, not
semantic entailment. Models judge source meaning and candidate applicability;
independent reference evaluation measures their errors. The compiler does not
complete roles or classify domains using hand-coded concept rules.
`main` is Atomic-only; [Pair research is deferred](https://github.com/seekerwsy/Causal/tree/codex/pair-interaction-research).

## Reproduce the reviewer smoke

Use Python 3.12:

```text
python -m pip install -e ".[dev,selectors,languages]"
python -m pytest -q
```

The default suite includes the complete seven-stage smoke and independent result
verification. To inspect a standalone saved package:

```text
prompt-mechanism-study study smoke NEW_OUTPUT_DIRECTORY
prompt-mechanism-study study verify-result NEW_OUTPUT_DIRECTORY
```

The smoke uses synthetic tasks and offline model responses, makes no provider
calls, and runs real FCI on fixture observations. Its output is
`NON_CLAIM_TEST_ARTIFACT`. Reviewers do not need to rebuild the source dataset or
repeat historical curation to run it. See the [reviewer guide](docs/reviewer-guide.md)
for stage inputs/outputs and a reading order of at most ten core files.

## Artifact scope and evidence

The reviewer command above reproduces a **non-claim** seven-stage result from
bundled synthetic tasks and offline code responses. The result package retains raw code and evaluator responses alongside prospective
inputs, assignments, measured labels, unknowns and independently checked results.
There is not yet a claim-bearing natural-task result table in `main`.

The static file-permission and credential-source profiles currently return
`unknown`: recognizing a permission-setting call or a credential-like name does
not establish the task's complete security boundary. Those endpoints require
task-bound measurement before use; qualification reports each profile separately.
See the [measurement scope amendment](docs/protocol.md) for the prospective
boundary and preservation of earlier frozen results.

The [outcome-blind scope preflight](docs/artifact-scope-preflight.md) recounts the
released v4 task inventory and earlier candidate-screen coverage for four Python
CWE labels. It also records why existing AST examples alone do not qualify an
endpoint on generated code. This preflight does not admit any task or policy to a
formal experiment. Natural-task transfer, automatic TSG's incremental value and
FCI's selection benefit remain unproved.

The complete pre-scope development workspace is retained on local branch
`codex/pre-artifact-scope-20260923` at `f1cd0011`. Historical results keep their
original measurement rules and are outside the default reviewer artifact.

## Work on the prototype

Source is grouped directly under `src/`: `data`, `tsg`, `discovery`, `experiment`,
`measurement` and `verification`. `src/cli.py` is the command entry and
`src/target_workflow.py` the linear workflow. `development` only supplies the
reviewer smoke fixture. The import package remains `prompt_mechanism_study`.
Source import and read-only input verification live in `data/commands.py`.
Contracts and independent source judgments are supplied inputs; the prototype
does not run a separate contract-production and repair campaign. Extraction, generation and functional review share
`llm.py`; each stage retains its own response interpretation. File serialization
is shared in `artifact_io.py`, while result arithmetic is independently replayed
in `verification/`. `experiment/reporting.py` builds tables without calling the
verifier or writing files; `target_workflow.py` coordinates verification and
package writing. `contracts.json` is the authoritative source representation;
candidate analysis and visualization compile graph views from it. Candidate states
stay in `factor-states.json`, so changing an assessment does not rewrite source
semantics. No second graph cache is maintained.

The reviewer package has six business files plus its byte-integrity manifest:
study configuration, confirmation inputs, raw measurement records, statistical
evidence, selector yields and RQ tables. Prospective call limits, role separation,
randomization and independent numerical replay remain checked. The unused
qualification/budget/freeze/report-authorization hierarchy has been retired;
formal provider execution and claim authorization remain unavailable. Numerical
power planning and endpoint-specific qualification remain available separately.
The preceding implementation is preserved on
`codex/pre-framework-contraction-20260925` at `8e9241d2d`; old frozen packages
must use that implementation, not be rewritten into this format.

| Author operation | Entry or guide |
| --- | --- |
| Prepare new source data | `data`; [dataset boundaries](docs/research-dataset-spec.md) and [source preparation](docs/contract-content-cleaning.md) |
| Extract and assess TSG | `representation` / `qualification`; [TSG workflow](docs/tsg-workflow-stability.md) and [candidate semantics](docs/tsg-candidate-construction.md) |
| Run authorized bounded development | `study development OUTPUT --development-plan FROZEN_PLAN` |
| Verify its saved results | `study verify-development SAVED_RUN` |

Use `GROUP --help` for available commands. Source preparation is an author task,
not an extra scientific stage. Frozen historical inputs use their corresponding
implementations on the preserved branch. Current tests are described in the
[test guide](tests/README.md). The [paper draft](paper/fse2027/main.tex) is separate
from the development archive.
