# Active protocol: context-conditioned Atomic prompt policies

## 1. Authority and status

This is the single normative method on `main`, protocol `phase-context-policy-v3`,
status **SPECIFIED_DRAFT**. It permits source preparation, offline verification and
explicitly authorized bounded development checks. It does not authorize formal
Discovery, provider Confirmation, protected-task exposure, provider spending or
scientific reporting. Formal use requires a prospectively authorized frozen
package and the qualifications below.

The sole prospective bounded-development specification is the
[TSG discovery and randomized policy evaluation protocol](graph-guided-discovery-protocol.md),
`tsg-discovery-development-20260929`. Within that explicitly scoped study, its
candidate preparation, arms, selectors, randomization and three-comparison inference
rules govern; the formal Discovery roster and FCI admission rules below do not
define that development experiment. This is a specified protocol, with no new
execution authorized by its publication. Earlier development packages replay their
own frozen rules. The new study's implementation status is listed in its Section 13.

The 2026-09-16 scope decision defers Pair interaction research to
[`codex/pair-interaction-research`](https://github.com/seekerwsy/Causal/tree/codex/pair-interaction-research),
commit `e6833027`. Main now has one Atomic policy family. The old draft, complete
Pair implementation and original manuscript remain on that branch. Frozen
artifacts are never reinterpreted under this reduction; Pair reproduction uses
the preserved implementation. Protocol IDs in historical artifacts are unchanged;
implementation/configuration digests distinguish the prospective Atomic draft.

## 2. Research objective

CausalGuide investigates how changing one task-bound prompt requirement affects
LLM-generated code outcomes and what scoped explanation that evidence supports.
Engineering exists to make the scientific procedure inspectable and reproducible.

The active path has exactly seven stages:

**representation → prioritization → hypothesis freeze → intervention/randomization
→ measurement → outcome assembly → inference/reporting.**

The manuscript groups these into representation, requirement-level causal analysis,
and evidence-grounded explanations/guidance. This changes presentation, not execution.

## 3. Scientific boundaries

Prompt TSG describes source semantics; its edges are not causal edges. Generated
code supplies independently measured security and functionality outcomes. It is
not a primary-PAG variable or causal mediator. Observational scores and FCI
adjacency prioritize hypotheses; assigned interventions identify policy effects.

The independent unit is a cross-source-deduplicated **task unit**. The legacy
field `semantic_cluster_id` retains its frozen meaning. Repeated seeds, task
instances and overlapping selector slots do not create independent observations.
Assigned-arm ITT is primary. Fidelity, compliance, generation success and
non-target drift are diagnostics, never post-assignment denominator filters.

## 4. Populations and outcome-blind preparation

Development, qualification, Discovery and Confirmation use prospectively bound,
non-overlapping task-unit roles and source lineages. Record development exposure
before inspecting new task-level feedback. Preserve protected inputs, reservations
and all previous reviews. No outcome-driven replacement or retrospective role change.

Optional D0 is source preparation, not another scientific stage. It permits one
bounded round of independently sourced natural tasks before Discovery under a
frozen context-only coverage target. Acquisition cannot depend on feature states,
selector ranks, FCI/RD, candidate support, outcomes, paraphrases, interventions or
synthetic cell filling. Unknown context membership and remaining gaps are retained.
Candidate support and power are separate checks, not acquisition targets. The
post-preparation population digest binds all downstream support and design records.

## 5. Representation

Prepare the actual system message, user task and declared language before
extraction. Original input identity and exact evidence spans bind the graph;
later generation must use the corresponding input. Development may discover
source concepts, but their definitions and producer are fixed before Discovery.
External CWE labels cannot replace source evidence or decide extraction scope.

The [TSG workflow](tsg-workflow-stability.md) defines the current extraction path:
source records with participants/composition/conditions/targets, mechanical checks,
one ordinary source review with at most one complete-record revision, then direct
compilation. The revision uses the extraction schema and original source; it does
not use field-level patches, alias merging or silent removal of invalid facts. The existing bounded mechanical repair limit is unchanged. There is
no additional default readback or detailed binding reviewer. Debug readings remain
available; a positive LLM review is not an independent semantic reference. A revised
record set passing structural checks is not certified semantically correct; before/after
records and the review are saved for independent evaluation.

The owner-approved 2026-09-25 revision limits program checks to structural
validity and faithful compilation: field/type validity, identities, references,
source locations, declared relation signatures and composition/scope consistency.
These checks do not establish source entailment. The compiler preserves declared
bindings and inherited guards; it does not add participants based on concept
names, decide value types, or infer applicability from role-domain tables.
Literal-name gates, character-type classifiers and existing-value-return role
completion are removed. Overlapping evidence is legal. Arbitrary graph-size and
quote-length cutoffs are removed; configured model request/response limits remain.
Citation lookup still locates source text and preserves its exact span; it is
not a semantic support judgment.

Each candidate's complete binding is assessed by the model against the full
source. Independent reference evaluation, not acceptance by the parser, measures
semantic correctness. The single review/revision path remains; no reviewer
or new rule engine is introduced. Frozen inputs using the retired catalog rules
must use their captured implementation, not silently discard those rules.

A requirement preserves content, negation, thresholds, direct objects, operation
instances and conditions together. Conditions providing information are distinct
from targets being constrained. Participation in the same workflow does not
justify spreading a requirement to every operation. Input assumptions are not
editable obligations. Atomic requirements may retain conditions; and/or/not/opaque
composition preserves meanings that cannot safely be treated as independent factors.

Candidate construction selects, normalizes equivalent definitions and binds exact
scope; it cannot split a source node, repair its missing relations or select half
of a compound obligation. Complete semantic bindings, not plausible description
text, determine downstream meaning. Semantic atomicity does not prove independent
editability. The [candidate guide](tsg-candidate-construction.md) specifies the bridge.

Atomic means one complete editable requirement, not a requirement without internal
conditions or quantification. Whole-task and universal requirements may be bound
directly to their original boundary without local expansion. A complete alternative
or prohibition with one common binding can be considered as one policy after
semantic review; its members are not separate asserted factors. Independent
requirements cannot be bundled to bypass the single-requirement restriction.
The frozen factor records scope kind, quantified class and policy-internal guards.
Task matching uses independent operation/subject/execution context; internal guards
need not exist as separate task facts after the policy is removed. Unclear
applicability, expression or editability remains unresolved. These changes do not
activate Pair or context-modifier inference.

Applicability and expression are distinct. Source coverage and impact annotations
are supplied to the candidate assessor, not used by program locality rules to
withhold all candidate judgments. The assessor must retain uncertainty when it
affects the candidate, including shared constraints; unknown is never silently
erased. Structural projections still cannot assert an OR member, discard a guard,
or invent a missing target endpoint. Preserve
`UNRESOLVED != ABSENT`; an unexpressed prompt requirement does not mean generated
software lacks that protection. Evaluation reports critical meanings, extra
assertions, candidate correctness and coverage alongside whole-graph diagnostics.

Model identity, endpoint, credential-environment coordinate, thinking mode and
sampling settings are supplied by the frozen evaluator configuration rather than
a source-code restriction to one vendor/model. Supported transports remain explicit;
input/output limits and one attempt are retained. Configuration and raw responses
are saved, including failed candidate proposals. This does not authorize spending
or changing the model during a frozen comparison.

## 6. Context-conditioned hypotheses

`AnalysisScope` contains exactly `security_pattern_id`, `context_query_id`,
`language_scope`, `api_scope`, and `task_archetype_scope`. Scope collections are
nonempty, unique and sorted. One `AtomicPolicyKey` binds that scope, one feature,
one operation (`ADD` or `REMOVE`) and one outcome. A model effect is
`(policy_key, model_id)`; the protocol-bound candidate record adds protocol identity.

Rank, score, expected direction, model, qualification result and selector are not
semantic policy identity. Different task-local object names do not create new
factors. Context queries and scope selection are independent of the target state;
ambiguous matches remain unresolved rather than choosing a convenient state.

## 7. Discoverability and observational prioritization

Before reading Discovery outcomes, freeze one candidate universe, source/state
support decisions, uncertainty/reliability thresholds and task-unit fold manifests.
Each Atomic candidate needs an applicable context, natural factor-state support,
source-lineage overlap and valid folds. Unknown memberships remain in coverage;
support insufficiency is not a null effect. No task edits manufacture natural support.

For each model and security scope, qualified FCI uses natural prompt states,
approved pre-treatment covariates, independently measured baseline outcomes and
frozen typed background constraints. Atomic Full applies the qualified adjacency
criterion. RD-only omits that criterion. Both use identical candidate rows,
discoverability decisions, folds, cross-fitted standardized first-order risk
differences, absolute-value ranking, deterministic tie-breaks and fixed K.
ADD ranks expressed-minus-unexpressed; REMOVE reverses that orientation. Scores
retain sign without requiring a favorable direction. FCI is not the score and
neither score nor admission establishes a randomized causal effect.

### Bounded development screening (prospective revision, 2026-09-23)

Authorized development checks may use `paired_task_effect_screen_v1` in the
existing development runner. This does not activate formal natural-state Discovery
or remove its FCI comparison. Freeze the common task-frame size, primary selection
contrast, minimum observed gain and Top-K before outcomes. The recommended starting
gain is 0.05 (five percentage points), explicitly written into the plan; it is a
budget decision, not a statistical or security guarantee.

For each policy use one primary selection contrast (default TARGET minus NOOP);
retain other listed contrasts as diagnostics. Average repetitions within tasks,
then rank positive gains meeting the threshold by
`applicable_task_units / frozen_common_task_units * observed_gain`. Keep harmful,
unknown, missing and unselected rows. A missing assigned outcome blocks that policy's
contrast, not other policies, and is never silently dropped. Correctly marked
Oracle unknowns contribute zero observed secure yield, not an insecure label.

The exact task sign-flip p-value and Holm adjustment remain descriptive outputs;
neither controls screening admission. The selected list is a validation queue,
not an adoption recommendation. Functionality, joint success and unknown outcomes
remain in the saved assignment report and must accompany subsequent validation.
No functionality-preservation claim follows merely from entering this queue.

Example fields inside a new frozen development plan's `analysis` object:

```json
{
  "method": "paired_task_effect_screen_v1",
  "minimum_effect": 0.05,
  "screening_task_units": 32,
  "screening_control": "NOOP",
  "top_k": 2
}
```

Retain the existing contrasts, generation seeds, bootstrap parameters, alpha and
`scientific_claim_allowed: false`. Old `paired_task_signflip_holm_bootstrap_v1`
plans replay their original significance-gated signal; old results are not relabelled.
The independent verifier uses exact grouped convolution instead of enumerating
2^N sign allocations, so no twenty-task ceiling remains.

## 8. Selectors and fixed budgets

The approved main RQ1/RQ4 roster is CausalGuide, Prompt Attribution (simple
correlation baseline), Causal Prompt Concepts, Prompt Perturbation, and LLM-Judge
Explanation (direct prompted-LLM baseline). These are study method labels, not
claims that five implementations are qualified. The two research-comparator
source/implementation bindings, every method's allowed information, selection
rules, native-output bridge and costs require a joint prospective freeze.
No working label silently identifies a published algorithm or faithful reproduction.

All methods map outputs outcome-blind into the frozen admissible Atomic universe.
The bridge preserves proposed semantics; it does not invent a missing requirement
or replace a failed proposal. Full versus RD-only is the RQ2 admission-gate
ablation, not an additional main comparator. Blinded Expert, seeded Random and
other reference profiles are supplemental only if separately authorized, qualified
and budgeted; they are not added to the five-method roster.

Mapped counts original slots resolving to a scoped requirement, operation and
comparator. It is distinct from protocolization, assigned execution and an
evaluable effect. Effect-confirmed is a paper-facing alias for formally authorized
POSITIVE_MEANINGFUL or NEGATIVE_MEANINGFUL slots under Section 12; it changes no
stored status, margin, estimator or multiplicity rule. Report signs separately.
Effect-confirmed Yield@K is the existing meaningful Yield@K. Neither development
statuses nor mere exclusion of zero qualifies as scientific effect confirmation.
An opposite-to-prediction effect is effect-bearing but does not validate advice.
Equal K is an output-slot budget, not equal compute; disclose method-specific costs.

Every slot remains in K, including empty, failed and non-evaluable slots. The
selected union is deduplicated by model effect; one shared result fans back to
all referring slots. Protocolization and model dispatch are distinct. No reranking,
replacement or budget reassignment follows Confirmation outcomes.

## 9. Prompt policies and realizations

ADD introduces a source-resolved unexpressed requirement without assuming insecure
baseline code. REMOVE withdraws an identifiable expressed requirement through a
validated neutral counterpart; it never instructs the opposite insecure behavior.
Both preserve declared non-target behavior and remain separate policies.

Each Atomic comparison has four arms: target edit, operation-matched no-op,
placebo/sham, and direction-compatible generic-security instruction. The primary
contrast is **target minus matched no-op**. No-op preserves the source requirement
state while matching the editing operation. Placebo and generic comparisons need
their own prospectively frozen secondary rules before supporting specificity claims.

Freeze finite editing realizations and positive weights summing to one. Assign
exactly one realization to each task-policy coordinate by the existing seeded,
source-stratified balanced allocation before task-specific materialization. Generate
and validate only that complete arm bundle. Retain a failed allocation without
retrying another realization, replacing the task or renormalizing weights.
Different realizations can have different protocolizable populations; the estimand
must retain that limitation. Source tasks need not arrive with experimental controls.

## 10. Randomization

Freeze eligible task pools, realized arm bundles, model/request settings and the
complete assignment table before generation. Within each task-instance, policy,
realization and model block, allocate equally across the four arms using the frozen
seed/block schedule. Preserve task, arm, realization, model and request-randomness
bindings. Failed bundle materialization is a pre-assignment record; every committed
assignment subsequently remains in its assigned arm and has a terminal record.

## 11. Measurement and estimand

Measurement is arm blind. Keep raw requests/responses and separate:

- code production and syntax validity;
- Oracle support/evaluability and secure/insecure/unknown labels;
- functionality pass/fail/unknown against the original task;
- secure-and-functional joint success and its unknown coverage;
- infrastructure failures and post-assignment diagnostics.

The primary endpoint, **oracle-evaluable secure-code yield**, is one only when a
request yields valid code evaluated as secure. A valid Oracle-unknown program has
zero observed secure yield, not an insecure label. No-code/invalid generations
remain recorded. Infrastructure failure is not silently recoded as a measured zero;
it blocks affected inference until the same assignment is resolved under its rules.

Syntax-valid programs receive original-task functional review, allowing reasonable
implementation freedom and unknown for genuinely unassessable requirements. Source
incompleteness alone does not imply functional failure. The prospective functional
judge revision still requires qualification; frozen old labels retain their rules.

Average seeds within each task instance, then apply frozen within-task instance
weights. For task-unit difference D and realization weight q:

    tau = sum_r q_r * mean_(assigned task units in realization r)(D)
    D = within-task mean(Y_target - Y_noop)

Within realization/source-stratum cells, lambda_rs = q_r * n_rs / n_r. Use these
same fixed weights for every arm mean, diagnostic fraction and sensitivity bound.
Missing realization/support never creates a smaller renormalized policy.

For latent secure valid-code yield, L is observed secure yield and
U = L + I(valid and Oracle-unevaluable). Report the contrast bounds
mean(L_target)-mean(U_noop) through mean(U_target)-mean(L_noop).
Differential code production or Oracle coverage must not be called improved
underlying software security. Functionality and joint claims need their own evidence.

### Measurement scope correction (prospective revision, 2026-09-24)

New executions cannot infer complete file-permission protection from recognized
`chmod` calls, or infer actual credentials from variable-name substrings. The
local AST routes for `owner_only_file_permissions.v1` and `credential_source.v1`
now return `unknown` with `task_bound_endpoint_required`. Their identifiers remain
readable in supplied registries; this is not an accepted measurement endpoint.
The removed heuristics are preserved at `7d5a42ad2` on
`codex/pre-semantic-boundary-simplification-20260924` for historical replay.
Implementation hashes change; frozen results and gold references are not relabelled.

A file endpoint must use a source-reviewed target set fixed before generation and
observe the declared final-state property on that set. A credential endpoint needs
an independently specified security boundary; identifier spelling is insufficient.
The existing isolated file-access worker remains available for its declared finite
access witnesses. Access denial and permission-bit requirements are distinct
endpoints and must not be substituted for one another. This revision does not
supply a general credential Oracle or activate a new behavior experiment.

Profile qualification now records each declared profile separately, including
missing gold coverage and unavailable endpoints. A blocked profile cannot qualify;
it also cannot erase another profile's verified result. A partial aggregate report
is not approval of the whole requested scope. Formal inclusion still requires a
prospective, explicit scope choice; no output-dependent reassignment is allowed.
Already assigned Oracle-unknown cases remain in ITT, with independent functional
review and unknown coverage reported as above.

## 12. Multiplicity and simultaneous inference

There is one primary family: all unique Atomic target-minus-no-op secure-yield
model effects in the frozen confirmation union. Empty unions have
`NO_ELIGIBLE_COORDINATES`, not fabricated zero effects. Secondary endpoints and
contrasts require separately frozen and implemented families.

The 2026-09-23 prospective revision uses `per_effect_bonferroni_bootstrap`.
Each policy is estimated on its own frozen support. For effect j, variance is
sum_(r,s) lambda_jrs^2 * sample_variance(D_jrs)/n_jrs. Resample task units within
that policy's original source strata; all descendants move together and original
lambda weights remain fixed. Policies may share tasks. No independence between
policy estimates is required for the Bonferroni allocation.

Allocate alpha/m to each of the m effects in the **original frozen union**, including
untestable effects. For each effect independently, retain the existing studentized
bootstrap and minimum-valid-draw rule; use the higher (1-alpha/m) quantile of
absolute studentized deviations. Report each effect's critical value, valid/invalid
draw counts and interval. Family draw counts are sums of these effect-level counts;
there is no common family critical value. These bootstrap intervals are approximate,
not a finite-sample coverage guarantee. Limited tail resolution is reported as a
warning; adequate draws and coverage calibration must be planned before formal use.

Zero-variance resamples are retained: their absolute studentized deviation is zero
when the resampled point equals the observed point, and unbounded otherwise.
If the required quantile is unbounded, report no finite interval for that policy
(`unbounded_studentized_bootstrap_tail`), while retaining its point estimate and
development-screen eligibility. Dropping these resamples can give spurious precision
for rare events. `bootstrap_zero_variance=retain_unbounded_tail` is part of the
inference-plan identity; older results retain their frozen implementation.

Missing assigned outcomes, missing realization support, too few task units, zero
standard error or insufficient valid draws limit only the affected policy's
inference. Retain its point estimate whenever identifiable, task/assignment counts,
reasons and original slots; never renormalize away missing support. The family is
`PARTIALLY_EVALUABLE` when some effects have intervals and others do not. Shared
measurement or provenance defects still invalidate every affected policy.

Exceeding `maximum_unknown_fraction_among_valid` is a coverage warning, not an
observed secure-yield inference gate. Unknowns remain in the denominator. Always
report latent-yield bounds and arm-specific measurement coverage; an observed
yield increase does not alone establish a latent security improvement.

Existing frozen outputs retain their old rules. The new inference-method field and
power-method identity prevent interpreting an old max-|T| plan as this revision.
Historical target result reproduction requires its saved implementation; no formal
reference result is replaced by this draft revision.

With prospectively frozen practical margin epsilon, the five statuses are:

| Status | Rule |
| --- | --- |
| POSITIVE_MEANINGFUL | interval lower > epsilon |
| NEGATIVE_MEANINGFUL | interval upper < -epsilon |
| PRACTICALLY_NULL | entire interval lies within [-epsilon, epsilon] |
| INCONCLUSIVE | evaluable interval meeting none of the above |
| NON_EVALUABLE | affected policy lacks provenance, support or valid inference |

Margins, alpha, minima, draw count/seed and validity criteria come from the frozen
power-and-margin memo, never from inspected effects. Meaningful Yield@K counts
positive- or negative-meaningful slots divided by original K. Every other slot
contributes zero utility without being called a zero causal effect. RQ2 reports
descriptive Full-minus-RD-only Yield@K on the frozen Discovery split; no nested
utility interval or pooled hypothesis ATE is an active claim.

## 13. Robustness and context modifiers

Retain realization-specific populations, weights and failures, and separate model
effect coordinates. The mixture estimate alone does not prove wording robustness
or cross-model replication. Such labels require frozen populations, contrasts,
margins and simultaneous rules. No one-snapshot run is a replication study.

Context-modifier inference remains `BLOCKED_NO_FROZEN_CONTEXT_RULE` until exact
task assignment, contrasts and joint bootstrap/multiplicity rules are frozen.
Missing rules do not receive guessed defaults or claims. These follow-ups are not
prerequisites for reporting an otherwise evaluable primary Atomic effect.

## 14. Implementation markers

Generated-code markers can only be separately qualified diagnostics. They do not
enter primary-PAG variables, candidate selection, eligibility or effect status.
An assignment effect on a marker cannot identify mediation, causal necessity or
sufficiency, or the generator's internal reasoning.

## 15. Evidence levels

Keep `specified`, `implemented`, `tested`, `executed` and `reported` distinct.
A unit test is not an executed experiment. Smoke, calibration and development
observations cannot become confirmatory evidence. Observational selection,
randomized policy effects, specificity, robustness and replication have different
evidence requirements; one cannot silently promote another.

### 15.1 Evidence-grounded explanations and guidance

This is a specified reporting contract, not a qualified explanation generator.
The product is an English Explanation + Suggested Action record. The Explanation
connects applicable scope, source requirement/target/condition, concrete edit and
comparator, effect evidence, and functionality/uncertainty. The Suggested Action
identifies a modification option, supported adoption, an endpoint-specific warning,
or explicit withholding under the evidence conditions below.
Tie each statement to exact source, policy and verified result records.

Without formal randomized evidence, an edit is an unconfirmed option. A favorable
primary endpoint does not establish preserved functionality, lower underlying
insecurity, specificity or joint success. Adoption advice additionally requires
resolved applicability and prospectively specified security/task-preservation
criteria, secondary margins, coverage and a joint decision predicate. Those exact
rules remain open; missing support blocks advice, not reporting the effect.

Retain negative, practically null, inconclusive and non-evaluable findings.
Harmful REMOVE evidence cannot validate reverse ADD. A negative effect warns about
the tested policy only. Task-local binding is not an individual causal effect,
transportability guarantee or evidence about internal model reasoning.

## 16. Main-paper research questions

The owner authorized manuscript synchronization and Overleaf submission on
2026-09-16. The four manuscript RQ sentences remain unchanged; the Atomic-only
study and five-method decision govern their operationalization. This prose
revision does not activate formal execution or additional experiments.

- RQ1: compare the five methods in Section 8 under a common budget; report K,
  Mapped, Effect-confirmed (+/-), Effect-confirmed Yield@K, overlap and the complete
  candidate-to-confirmation funnel. All original slots remain in K. Shared effects
  are evaluated once and reused; external confirmation is not a native baseline
  capability. Exact comparator procedures still require prospective qualification.
- RQ2: Atomic Full versus RD-only is the sole-difference structural-gate comparison.
  Shared rows, support, folds, scores, tie-breaks, K and confirmation isolate FCI
  admission. This does not measure graph readability or every component's value.
- RQ3: model-specific Atomic ADD/REMOVE policy effects on secure-code yield, with
  distinct functionality, coverage and specificity evidence before hardening claims.
  Use the same held-out effects as RQ1; effect-bearing does not mean advice-validating.
- RQ4: perceived utility of the same five methods' complete Explanation + Suggested
  Action products under common presentation.
  It does not validate causal discovery, objective repair or actual adoption success.

## 17. Secondary analyses and human study

RFCI/JCI are optional exploratory appendix work, not required main-path components
or ways to promote causal evidence. Any supplemental blinded Expert selector is
distinct from RQ4 participants.

RQ4 uses anonymized English products and five 1--5 Likert items: clarity, evidence
sufficiency/justification, credibility, actionability and overall usefulness.
Overall usefulness is the planned primary rating; other items are secondary.
This is not yet a preregistration. Freeze ethics determination, participant/case
manifests, item wording/anchors, balanced assignment and blinded randomized order,
primary/secondary analysis and multiplicity, and repeated expert/case dependence
before recruitment or response inspection. Include unfavorable and unresolved
cases; prospectively define unavailable/empty/unmappable product handling and
report its counts by method.

Freeze each method's evidence access and explanation-construction procedure,
including whether shared confirmation is supplied, before study materials are
produced. A common presentation must not invent evidence, strengthen native
claims or rewrite every product through CausalGuide. RQ4 compares complete products,
not wording alone under identical evidence; it cannot attribute ratings solely
to Prompt TSG or establish objective comprehension, actual adoption or repair.
Exact implementation/material and human-study rules remain open until frozen.

## 18. Artifacts and two freezes

Before Discovery outcomes: bind source/task roles, population identity, catalog
and representation qualification, candidate universe, support/folds, FCI/RD and
baseline profiles, generator policy, selection rules, practical margins and
power/budget assumptions. Freeze knowledge separately from observed scores.

Before Confirmation outcomes: freeze the scored fixed-K ledgers, shared effect
union, bridge decisions, Oracle qualifications, realizations, task allocations,
complete arm assignments and inference plan. Recheck power and budget on the
actual task-effect/realization table under the original assumptions. Preserve
both freezes, excluded/failed records and exact input/configuration/producer hashes.
Every paper claim must map to a frozen field, function and table builder.

## 19. Prospective Sample Size and Data Gate

Source usability depends on an interpretable task, relevant operation/security
boundary and observable non-target behavior. Missing unrelated detail limits
claims rather than automatically excluding the task. Source screening is separate
from exact intervention/control design. Frozen five-axis source reviews remain
historical judgments and cannot be retrospectively relabeled.

Qualify representation against independently frozen source references and declared
language/operation/state profiles, including coverage/uncertainty. Qualify the
Oracle for the endpoint and code forms actually admitted, using representative
positive/negative/unknown cases and differential-error checks. Unused languages
or profiles do not block a narrower study. These checks do not prove universal
semantic or measurement accuracy.

The power-and-margin memo must use the categorical task-unit simulation and exact
Atomic inference rules, including validity, evaluability, secure yield, dependence,
realization mixtures, support and non-evaluable replicates. Actual Confirmation
allocation must meet the frozen design's support and power criteria. Gaussian
planning approximations, convenient historical counts and development success
cannot substitute for this qualification. The formal provider budget must cover
the exact comparator envelope, tasks, arms, models, request slots and qualification
costs before execution. Current paid development balances are not this budget.

## 20. Failure and negative-result semantics

Preserve all assigned outcomes, unknowns, harmful/null results, backend failures
and non-evaluable cases. Distinguish source exclusion, candidate ineligibility,
protocolization failure, missing outcome and inferential insufficiency. Each has
its own stage and cannot erase a fixed selector slot or committed assignment.
Diagnose exact requests, transformations and measurements before attributing a
failure to model quality or randomness. No new reviewer loop follows merely from
an unfavorable result.

## 21. Active artifact and historical boundary

The [reviewer guide](reviewer-guide.md) gives the single entry, stage mappings and
reading order. The offline synthetic smoke and independent verifier must run
without development archives or server history. No formal reference output exists
yet. Mutable smoke fixtures may change with scope; frozen experiment packages may
not. Historical Pair packages, manuscript and tests use the preserved research
branch, not a compatibility framework in main. Credentials and local caches remain
outside released artifacts.

## 22. Acceptance criteria

The maintained suite protects input/source identity, unknown handling, exact
Atomic scope, shared-universe selection, fixed-slot fanout, replayable randomization,
arm-independent outcomes, total assignment accounting, weighted task-unit ITT,
simultaneous inference and independent saved-result verification. One end-to-end
smoke exercises the seven stages. Run focused checks during editing and the
complete reviewer path once before completion; broaden only for a concrete change
or failure. Offline tests do not close empirical qualification or authorize claims.

## 23. Current decisions and open scientific work

Main is Atomic-only following the owner's 2026-09-16 instruction. Pair candidates,
relation selection, factorial arms, interaction effects and their qualification/
budget/test requirements have been removed from this active method. Resuming them
requires work on the preserved branch and a new prospective research decision.

Automatic TSG semantic binding, independent representation/Oracle qualification,
natural support, power/budget activation, secondary guidance rules and RQ4 design
remain open. The immediate representation question is whether source-correct
bindings improve candidate decisions and useful hypothesis discovery. Detailed
review output or more passing offline tests is not evidence of that improvement.
