import json
import math
from itertools import product

import numpy as np
from scipy.optimize import brentq
from scipy.special import rel_entr
from scipy.stats import binom


def kl_interval(successes, count, threshold):
    proportion = successes / count
    if successes == 0:
        return 0.0, -math.expm1(-threshold / count)
    if successes == count:
        return math.exp(-threshold / count), 1.0

    def equation(probability):
        return (
            rel_entr(proportion, probability)
            + rel_entr(1 - proportion, 1 - probability)
            - threshold / count
        )

    lower = brentq(equation, np.nextafter(0.0, 1.0), proportion)
    upper = brentq(equation, proportion, np.nextafter(1.0, 0.0))
    return lower, upper


def main():
    # 计算假设概率情景下的设计能力，不生成或读取实验结果。
    tasks, repetitions = 12, 10
    count = tasks * repetitions
    half_width = math.sqrt(math.log(125) / count)
    bounds = np.array([kl_interval(k, count, math.log(1000)) for k in range(count + 1)])
    differences = (np.arange(count + 1)[:, None] - np.arange(count + 1)[None, :]) / count
    lower = np.maximum(differences - half_width, bounds[:, 0, None] - bounds[None, :, 1])
    upper = np.minimum(differences + half_width, bounds[:, 1, None] - bounds[None, :, 0])
    excludes_zero = (lower > 0) | (upper < 0)
    scenarios = []
    for baseline, edited in [(0.5, 0.5), (0.5, 0.75), (0.5, 0.65), (0.5, 0.6), (0.9, 0.95)]:
        probabilities = np.outer(
            binom.pmf(np.arange(count + 1), count, edited),
            binom.pmf(np.arange(count + 1), count, baseline),
        )
        scenarios.append(
            {
                "baseline_probability": baseline,
                "edited_probability": edited,
                "standard_error": math.sqrt((baseline * (1 - baseline) + edited * (1 - edited)) / count),
                "probability_interval_excludes_zero": float(probabilities[excludes_zero].sum()),
            }
        )

    # 穷举单个双次块的有限结果，核实共享来源时的范围与乘积期望。
    squared_effect_checks = []
    block_values = []
    for baseline, graph, raw in [(0.5, 0.75, 0.65), (0.1, 0.9, 0.4), (0.95, 0.9, 0.95)]:
        expected = 0.0
        for values in product([0, 1], repeat=6):
            b1, g1, r1, b2, g2, r2 = values
            probabilities = [baseline, graph, raw, baseline, graph, raw]
            probability = math.prod(p if value else 1 - p for value, p in zip(values, probabilities))
            contrast = (g1 - b1) * (g2 - b2) - (r1 - b1) * (r2 - b2)
            block_values.append(contrast)
            expected += probability * contrast
        target = (graph - baseline) ** 2 - (raw - baseline) ** 2
        if not math.isclose(expected, target, abs_tol=1e-12):
            raise ValueError("平方效果的乘积期望与目标不一致")
        squared_effect_checks.append({"probabilities_B_G_R": [baseline, graph, raw], "expectation": expected, "target": target})

    result = {
        "status": "PROSPECTIVE_DESIGN_ARITHMETIC_ONLY",
        "conditions": "12 fixed tasks, 10 independent requests per distinct arm, homogeneous probabilities within each scenario",
        "maximum_generation_requests": tasks * 3 * repetitions + 2 * 2 * 8,
        "hoeffding_half_width": half_width,
        "all_success_interval": [float(lower[count, count]), float(upper[count, count])],
        "disagreement_cases": [
            {
                "tasks": d,
                "half_width": math.sqrt(math.log(125) * d / (tasks * tasks * repetitions)),
                "maximum_absolute_contrast": d / tasks,
            }
            for d in [0, 2, 6, 12]
        ],
        "v_nominal_95_hoeffding_half_width": math.sqrt(math.log(40) / 16),
        "squared_effect_block_range": [min(block_values), max(block_values)],
        "squared_effect_contrast_half_width": math.sqrt(2 * math.log(200) / 60),
        "squared_effect_checks": squared_effect_checks,
        "scenarios": scenarios,
    }
    if not np.all(lower <= upper + 1e-12):
        raise ValueError("设计枚举出现空交集，需要单独解释区间规则")
    if result["maximum_generation_requests"] != 392:
        raise ValueError("生成请求数量不一致")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
