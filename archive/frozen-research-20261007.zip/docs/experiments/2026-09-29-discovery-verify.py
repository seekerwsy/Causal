import argparse
import ast
import hashlib
import json
import math
import subprocess
import sys
import tarfile
from collections import Counter
from decimal import Decimal, localcontext
from datetime import datetime, timezone
from pathlib import Path

from markdown_it import MarkdownIt
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer

from prompt_mechanism_study.artifact_io import write_bundle


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def manifest(root):
    record = load(root / 'manifest.json')
    actual = {path.relative_to(root).as_posix() for path in root.rglob('*') if path.is_file()}
    assert actual == set(record['files']) | {'manifest.json'}
    for name, expected in record['files'].items():
        assert digest(root / name) == expected
    return digest(root / 'manifest.json')


def control_outcome(measured, code):
    # 安全与功能独立读取；未知安全结果保留上下界。
    ast.parse(code)
    assert measured['status'] == 'measured'
    assert set(measured['channels']) == {'security', 'functionality'}
    security_channel = measured['channels']['security']
    functionality_channel = measured['channels']['functionality']
    for channel in (security_channel, functionality_channel):
        assert channel['status'] in {'passed', 'raised', 'timeout', 'assertion_failed'}
        assert not (channel['status'] == 'raised' and channel.get('phase') == 'load_test')
    security = security_channel['observation']['security_label'] if security_channel['status'] == 'passed' else 'unknown'
    functionality = functionality_channel['observation']['functionality'] if functionality_channel['status'] == 'passed' else 'unknown'
    assert security in {'secure', 'insecure', 'unknown'} and functionality in {'pass', 'fail', 'unknown'}
    value = int(security == 'secure')
    if security == 'insecure' or functionality == 'fail':
        joint = 0
    elif security == 'secure' and functionality == 'pass':
        joint = 1
    else:
        joint = None
    return dict(primary=[value, value], sensitivity=[value, value + int(security == 'unknown')],
                security=security, functionality=functionality, valid=True,
                reason='measured_' + security, joint_success=joint)


def interval(values, bounds, alpha):
    # 独立复算使用高精度乘积与二分，避免共享生产求根实现。
    if not values:
        return (float(bounds[0]), float(bounds[1]))
    with localcontext() as context:
        context.prec = 60
        a, b = map(Decimal, map(str, bounds))
        observations = [(Decimal(str(value)) - a) / (b - a) for value in values]
        assert all(0 <= value <= 1 for value in observations)
        constants = list(map(Decimal, ('0', '.05', '.10', '.20', '.35', '.50', '.65', '.80', '.95')))
        threshold = Decimal(2) / Decimal(str(alpha))
        def lower_endpoint(sequence):
            if not any(sequence):
                return Decimal(0)
            lo, hi = Decimal(0), Decimal(1)
            for _ in range(160):
                midpoint = (lo + hi) / 2
                mixture = Decimal(0)
                for constant in constants:
                    product = Decimal(1)
                    for observed in sequence:
                        product *= 1 + constant * (observed / midpoint - 1)
                    mixture += product / 9
                if mixture > threshold:
                    lo = midpoint
                else:
                    hi = midpoint
            return max(Decimal(0), (lo + hi) / 2 - Decimal('1e-10'))
        lower = a + (b - a) * lower_endpoint(observations)
        upper = a + (b - a) * (1 - lower_endpoint([1 - value for value in observations]))
        return (float(lower), float(upper))


def verify_qualification(repo, adapter):
    base = repo / 'data/method/graph-guided-20260929'
    plan = load(base / 'source-execution-contracts.json')
    assert not plan['generation_results_used'] and not plan['hypotheses_or_policies_included']
    cards = {row['family']: row for row in plan['contracts']}
    assert len(cards) == len(plan['contracts'])
    for group in plan.get('source_equivalence_groups', []):
        assert set(group['members']).intersection(row['index'] for row in cards.values()) == {group['retained_index']}
    adapter_hash = manifest(adapter)
    observations = load(adapter / 'observations.json')
    assert len(observations) == 5 * len(cards)
    assert len({(row['family'], row['control']) for row in observations}) == len(observations)
    indexed = {(row['family'], row['control']): row for row in observations}
    evidence, counts = [], Counter()
    for family, card in sorted(cards.items()):
        suffix = card.get('qualification_suffix', '')
        inputs = base / f'measurement/{family}-qualification-inputs{suffix}'
        contract = base / f'measurement/{family}-qualification-contract{suffix}'
        results = repo / f'results/graph-guided-20260929/{family}-qualification{suffix}'
        manifest(inputs)
        contract_hash = manifest(contract)
        qualification_hash = manifest(results / 'verified')
        qualification = load(results / 'verified/qualification.json')
        assert qualification['status'] == 'QUALIFIED_FINITE_ENDPOINT'
        assert qualification['endpoint_contract_sha256'] == contract_hash
        expected = load(contract / 'expected.json')
        assert set(expected.values()) == {'secure', 'insecure', 'unknown'}
        qualification_records = {row['control']: row for row in qualification['observations']}
        for control, label in expected.items():
            request_path, result_path = inputs / f'{control}.json', results / f'{control}.json'
            request, measured = load(request_path), load(result_path)
            record = indexed[family, control]
            assert record['request_sha256'] == digest(request_path)
            assert record['result_sha256'] == digest(result_path) == qualification_records[control]['result_sha256']
            outcome = control_outcome(measured, request['code'])
            assert outcome == record['outcome'] and outcome['security'] == label
            counts[label] += 1
        evidence.append(dict(family=family, source_index=card['index'], qualification_manifest_sha256=qualification_hash))
    manifest(base / 'model-identity')
    model = load(base / 'model-identity/identity.json')
    assert model['model_id'] == 'Qwen2.5-Coder-32B-Instruct'
    assert model['weight_dtypes'] == ['BF16'] and model['quantization_config'] is None
    assert model['model_calls'] == 0 and model['model_service_started'] is False
    return dict(status='INDEPENDENT_REAL_CONTROL_ASSEMBLY_VERIFIED', controls=len(observations),
                qualified_endpoints=len(cards), labels=dict(counts), evidence=evidence,
                source_plan_sha256=digest(base / 'source-execution-contracts.json'),
                adapter_manifest_sha256=adapter_hash, generated_prompt_effects_verified=False)


def verify_tables(root):
    manifest(root)
    vectors = load(root / 'vectors.json')
    tables = load(root / 'tables.json')
    assert len(tables) == 3 and set(vectors) == {'T1', 'T2', 'T3'}
    records = []
    for table, (comparison, bounds, alpha) in zip(tables, [('T1', (-2, 2), .02), ('T2', (-2, 2), .02), ('T3', (-1, 1), .01)]):
        assert table['comparison'] == comparison and table['bounds'] == list(bounds) and table['alpha'] == alpha
        rows = vectors[comparison]
        assert table['task_units'] == len(rows) == len({row['task_unit_id'] for row in rows})
        for endpoint in ('primary', 'sensitivity'):
            lower, upper = [row[endpoint][0] for row in rows], [row[endpoint][1] for row in rows]
            assert all(bounds[0] <= lo <= hi <= bounds[1] for lo, hi in zip(lower, upper))
            expected = interval(lower, bounds, alpha)[0], interval(upper, bounds, alpha)[1]
            actual = table[endpoint]['interval']
            assert actual['n'] == len(rows) and actual['missing_tasks'] == sum(lo != hi for lo, hi in zip(lower, upper))
            assert abs(actual['lower'] - expected[0]) < 1e-9 and abs(actual['upper'] - expected[1]) < 1e-9
            for field, values in (('mean_lower', lower), ('mean_upper', upper)):
                assert table[endpoint][field] is None if not rows else abs(table[endpoint][field] - sum(values) / len(values)) < 1e-12
            records.append(dict(comparison=comparison, endpoint=endpoint, interval=expected))
    return records


def verify_service(repo, inputs, results, adapter, role='service-check', preparation_override=None,
                   initial_state=None):
    input_hash = manifest(inputs)
    protocol, assignments = load(inputs / 'protocol.json'), load(inputs / 'assignments.json')
    assert protocol['status'] == {'service-check': 'FROZEN_TSG_DISCOVERY_SERVICE_CHECK',
        'development': 'FROZEN_TSG_DISCOVERY_DEVELOPMENT', 'evaluation': 'FROZEN_TSG_DISCOVERY_EVALUATION'}[role]
    assert protocol['code_requests'] == len(assignments)
    preparation = preparation_override or repo / 'data/method/graph-guided-20260929' / (role + '-preparation')
    manifest(preparation)
    if preparation_override:
        frozen_protocol = load(preparation / 'protocol.json')
        for key in ('model', 'system_prompt', 'generation_implementation_sha256', 'native_worker_sha256'):
            assert protocol[key] == frozen_protocol[key]
        frozen_unix = datetime.fromisoformat(frozen_protocol['frozen_utc']).timestamp()
    assert assignments == load(preparation / 'assignments.json')
    state = initial_state if preparation_override else (load(repo / 'data/method/graph-guided-20260929/development-preparation/randomization-state.json') if role == 'evaluation' else None)
    replayed, replayed_bindings, _ = independent_assignments(load(preparation / 'tasks.json'),
        load(preparation / 'candidates.json'), 'evaluation' if role == 'evaluation' else 'development', state)
    if role == 'service-check':
        assert len(assignments) == 32
        replayed = [dict(row, slot=f'{position:04d}') for position, row in
                    enumerate(row for row in replayed if row['arm'] != 'R')]
    else:
        assert manifest(preparation) == protocol['preparation_manifest_sha256']
    assert replayed == assignments and replayed_bindings == load(preparation / 'bindings.json')
    manifest(results / 'preoutcome')
    assert load(results / 'preoutcome/protocol.json') == protocol
    assert load(results / 'preoutcome/assignments.json') == assignments
    manifest(results / 'summary')
    dispatch = load(results / 'summary/dispatch.json')
    summary = load(results / 'summary/results.json')
    assert dispatch['completed'] == len(summary) <= dispatch['generation_attempts'] <= len(assignments)
    assert dispatch['unexecuted'] == len(assignments) - dispatch['generation_attempts']
    if role == 'service-check':
        assert dispatch['generation_attempts'] == len(summary) == 32
        assert dispatch['unexecuted'] == 0 and dispatch['stop_reason'] is None
    indexed = {row['slot']: row for row in summary}
    assert len(indexed) == len(summary) and len({row['request_id'] for row in assignments}) == len(assignments)
    outcomes, counts, tokens = [], Counter(), Counter()
    assembled_expected = {}
    for assignment in assignments:
        slot = results / assignment['slot']
        if not (slot / 'result').exists():
            assert assignment['slot'] not in indexed
            outcome = dict(primary=[0, 1], sensitivity=[0, 1], security='missing', functionality='unknown',
                           joint_success=None, valid=None, reason='assigned_response_missing')
            assembled_expected[assignment['request_id']] = outcome
            outcomes.append(dict(slot=assignment['slot'], request_id=assignment['request_id'], outcome=outcome))
            counts['assigned_response_missing'] += 1
            continue
        result_hash = manifest(slot / 'result')
        result = load(slot / 'result/result.json')
        if preparation_override:
            assert result['started_unix'] >= frozen_unix
        assert result == indexed[assignment['slot']]
        for key in ('request_id', 'task_unit_id', 'policy_id', 'arm', 'version', 'seed', 'prompt_sha256'):
            assert result[key] == assignment[key]
        assert hashlib.sha256(json.dumps(assignment['prompt'], ensure_ascii=False, separators=(',', ':')).encode()).hexdigest() == assignment['prompt_sha256']
        if result['status'] in {'infrastructure_failed', 'measurement_infrastructure_failed', 'not_run'}:
            outcome = dict(primary=[0, 1], sensitivity=[0, 1], security='missing', functionality='unknown',
                           joint_success=None, valid=result.get('code_valid'), reason=result['status'])
            assembled_expected[assignment['request_id']] = dict(outcome, slot=assignment['slot'], result_sha256=result_hash)
            outcomes.append(dict(slot=assignment['slot'], request_id=assignment['request_id'], outcome=outcome,
                                 result_manifest_sha256=result_hash))
            counts[result['status']] += 1
            continue
        request, response = load(slot / 'request.json'), load(slot / 'response.json')
        model = protocol['model']
        assert request['model'] == model['model_id'] == response['model']
        for name in ('temperature', 'top_p', 'response_format'):
            assert request[name] == model[name]
        assert request['seed'] == assignment['seed'] and request['n'] == 1
        assert request['max_tokens'] == model['maximum_output_tokens'] == 4096
        assert len(request['messages']) == 2
        assert request['messages'][0] == {'role': 'system', 'content': protocol['system_prompt']}
        assert request['messages'][1]['role'] == 'user'
        assert json.loads(request['messages'][1]['content']) == {'task': assignment['prompt']}
        assert len(response['choices']) == 1
        choice = response['choices'][0]
        for key in ('prompt_tokens', 'completion_tokens', 'total_tokens'):
            tokens[key] += response['usage'][key]
        assert result['status'] in {'returned', 'generation_no_code', 'generation_truncated'}
        counts[result['status']] += 1
        if result['status'] == 'returned':
            assert choice['finish_reason'] == 'stop'
            content = load(slot / 'content.json')
            assert content == json.loads(choice['message']['content']) and set(content) == {'code'}
            raw_code = (slot / 'raw_code.py').read_text(encoding='utf-8')
            assert raw_code == content['code'] and digest(slot / 'raw_code.py') == result['raw_code_sha256']
            parsed = MarkdownIt().parse(raw_code)
            code = parsed[0].content if len(parsed) == 1 and parsed[0].type == 'fence' and parsed[0].info.strip().lower() in {'python', 'py'} else raw_code
            assert code == (slot / 'code.py').read_text(encoding='utf-8')
            assert digest(slot / 'code.py') == result['code_sha256']
            try:
                ast.parse(code)
            except SyntaxError:
                valid = False
            else:
                valid = True
            assert valid == result['code_valid'] and len(result['measurements']) == 1
            specification = assignment['measurements'][0]
            measurement_request = load(slot / 'measurement-request.json')
            assert measurement_request['code'] == code and measurement_request['tests'] == specification['tests']
            assert measurement_request['entry_point'] == specification['entry_point']
            measured = result['measurements'][0]
            assert measured['family'] == specification['family']
            if valid:
                outcome = control_outcome(measured['measurement'], code)
            else:
                assert all(row['status'] == 'invalid_code' for row in measured['measurement']['channels'].values())
                outcome = dict(primary=[0, 0], sensitivity=[0, 0], security='unknown', functionality='unknown', valid=False, joint_success=0, reason='invalid_code')
        else:
            assert choice['finish_reason'] == ('length' if result['status'] == 'generation_truncated' else 'stop')
            outcome = dict(primary=[0, 0], sensitivity=[0, 0], security='unknown', functionality='unknown', valid=False, joint_success=0, reason=result['status'])
        outcomes.append(dict(slot=assignment['slot'], request_id=assignment['request_id'],
            outcome=outcome, result_manifest_sha256=result_hash, request_sha256=digest(slot / 'request.json'),
            response_sha256=digest(slot / 'response.json'), seconds=result['ended_unix'] - result['started_unix']))
        assembled_expected[assignment['request_id']] = dict(outcome, slot=assignment['slot'], result_sha256=result_hash)
    launch = protocol['runtime_limits']['launch_record']
    assert datetime.fromisoformat(protocol['runtime_limits']['service_started_utc']) < datetime.fromisoformat(launch['deadline_utc'])
    adapter_hash = manifest(adapter)
    assembled = load(adapter / 'outcomes.json')
    assert set(assembled) == {row['request_id'] for row in outcomes}
    assert assembled == assembled_expected
    return dict(status='INDEPENDENT_REQUESTS_AND_OUTCOMES_VERIFIED', role=role, input_manifest_sha256=input_hash,
        requests=len(assignments), model_calls=dispatch['generation_attempts'], result_counts=dict(counts), token_usage=dict(tokens), records=outcomes,
        production_outcome_assembly_manifest_sha256=adapter_hash, production_labels_independently_verified=True,
        scientific_use='service qualification only; excluded from effects' if role == 'service-check' else 'bounded development policy evidence',
        randomization_replay='INDEPENDENTLY_REPLAYED', cross_task_independence='ASSUMPTION_NOT_PROVEN')


def verify_preparation(repo, roots):
    frame_root = repo / 'data/method/graph-guided-20260929/task-frame'
    frame_hash = manifest(frame_root)
    frame, population = load(frame_root / 'identity.json'), load(frame_root / 'tasks.json')
    assert frame['selected'] == {'development': 16, 'evaluation': 18}
    assert frame['maximum_total_requests'] == 1400 and frame['projected_service_seconds'] <= 14400
    assert not frame['generation_effects_used'] and not frame['hypothesis_support_used']
    for role, tasks in population.items():
        keys = [hashlib.sha256(
            f"tsg-discovery-development-20260929|{role}|{task['task_unit_id']}|2026092901".encode()).hexdigest()
                for task in tasks]
        assert keys == sorted(keys)
    records = []
    for root in roots:
        binding_hash = manifest(root)
        identity = load(root / 'identity.json')
        index = identity['index']
        source_root = repo / f'data/method/graph-guided-20260929/preparation-inputs/qualified/case-{index:04d}'
        manifest(source_root)
        source = load(source_root / 'input.json')
        candidates, slots = load(root / 'candidates.json'), load(root / 'slots.json')
        review_root = repo / f'data/method/graph-guided-20260929/binding-review-inputs/case-{index:04d}'
        assert manifest(review_root) == identity['review_input_manifest_sha256']
        mapping = load(review_root / 'mapping.json')
        reviews = {row['blind_id']: row for row in load(root / 'reviews.json')['reviews']}
        serialization = None
        raw_path = review_root.parent / f'binding{index}-model-output.json'
        final_path = review_root.parent / f'binding{index}-final.json'
        if index == 136:
            raw = raw_path.read_text(encoding='utf-8')
            value, end = json.JSONDecoder().raw_decode(raw)
            assert raw[end:].strip() == ']}'
            assert value == load(final_path) == load(root / 'reviews.json')
            serialization = dict(raw_sha256=digest(raw_path), serialized_sha256=digest(final_path),
                complete_json_value_preserved=True, extra_delimiters=raw[end:].strip())
        assert len(slots) == 4
        assert {(row['flow'], row['position']) for row in slots} == {
            (flow, position) for flow in ('TSG', 'Raw') for position in range(2)}
        assert identity['independent_quality'] == 'PENDING_INDEPENDENT_REVIEW'
        assert not identity['generation_results_used']
        for candidate in candidates:
            assert candidate['task_unit_id'] == source['task_unit_id']
            path = repo / f"data/method/graph-guided-20260929/preparation/cli55/dev{index}-{candidate['flow'].lower()}-initial.json"
            original = load(path)
            policy = next(row for row in original['candidates'] if row['candidate_id'] == candidate['original_candidate_id'])
            coordinates = next(row for row in mapping if row['flow'] == candidate['flow']
                               and row['candidate_id'] == candidate['original_candidate_id'])
            assert digest(path) == coordinates['preparation_sha256']
            orientation = reviews[coordinates['blind_id']]['orientation']
            assert orientation in {-1, 1} and candidate['orientation'] == 1
            for side in ('p_versions', 'n_versions'):
                texts = []
                for value in policy[side]:
                    if isinstance(value, dict):
                        if 'user_prompt' in value:
                            assert set(value).issubset({'version_id', 'user_prompt', 'system_prompt',
                                'source_task', 'source_code', 'source_code_status', 'shared_execution_interface'})
                            if 'system_prompt' in value:
                                assert value['system_prompt'] == source['system_prompt']
                            if 'shared_execution_interface' in value:
                                assert value['shared_execution_interface'] == source['shared_execution_interface']
                            if 'source_task' in value:
                                assert isinstance(value['source_task'], str) and value['source_task']
                                assert value['source_task'] in value['user_prompt']
                            value = value['user_prompt']
                        else:
                            assert {'version_id', 'system_prompt', 'source_task', 'shared_execution_interface'}.issubset(value)
                            assert set(value).issubset({'version_id', 'system_prompt', 'source_task', 'shared_execution_interface',
                                                       'source_code', 'source_code_status'})
                            assert value['system_prompt'] == source['system_prompt']
                            assert value['shared_execution_interface'] == source['shared_execution_interface']
                            if value.get('source_code'):
                                assert value['source_code'] in value['source_task']
                            value = value['source_task'] + '\n\nShared execution interface:\n' + value['shared_execution_interface']
                    assert value.count(source['shared_execution_interface']) == 1
                    texts.append(value)
                expected = candidate[side] if orientation == 1 else candidate['n_versions' if side == 'p_versions' else 'p_versions']
                assert texts == expected
            marginals = Counter()
            roles = set()
            for node in candidate['semantic_nodes']:
                assert node['role'] not in roles and node['source_quote'] in source['source_prompt']
                roles.add(node['role'])
                for field, value in [('node_type', node['type']), ('role', node['role']),
                                     ('scope', node['scope']), ('polarity', node['polarity'])]:
                    marginals[json.dumps([field, value], ensure_ascii=False, separators=(',', ':'))] += 1
            for edge in candidate['relations']:
                assert len(edge) == 5 and edge[0] in roles and edge[2] in roles
                for field, value in [('relation', edge[1]), ('scope', edge[3]), ('polarity', edge[4])]:
                    marginals[json.dumps([field, value], ensure_ascii=False, separators=(',', ':'))] += 1
            assert dict(marginals) == candidate['marginals']
            payload = json.dumps(candidate['contract'], sort_keys=True, ensure_ascii=False, separators=(',', ':'))
            assert hashlib.sha256(payload.encode()).hexdigest() == candidate['contract_id']
        records.append(dict(index=index, candidates=len(candidates), positions=len(slots),
                            binding_manifest_sha256=binding_hash, new_code_calls=0,
                            author_review_serialization=serialization))
    return dict(status='INDEPENDENT_SOURCE_FRAME_AND_BINDING_VERIFIED_NOT_F0',
                task_frame_manifest_sha256=frame_hash, records=records,
                independent_semantic_quality='PENDING_INDEPENDENT_REVIEW',
                source_semantic_entailment='NOT_ESTABLISHED_BY_REFERENCE_AND_HASH_CHECKS')


def verify_evaluation_authorization(repo):
    path = repo / 'data/method/graph-guided-20260929/evaluation-resource-authorization.json'
    authority = load(path)
    assert authority['protocol_id'] == 'tsg-discovery-development-20260929'
    assert authority['status'] == 'OWNER_AUTHORIZED'
    assert authority['evaluation_indices'] == [142,182,236,16,198,241,188,192,82,9,232,202,234,208,90,74,226]
    assert authority['total_token_limit'] == 64000 and authority['wall_seconds_limit'] == 360
    assert authority['permitted_requests'] == 2 and not authority['case214_refreeze_or_retry']
    assert authority['model'] == 'gpt-5.5' and authority['reasoning_effort'] == 'high'
    return authority, digest(path)


def verify_development_freeze(repo, root):
    frozen_hash = manifest(root)
    protocol, tasks = load(root / 'protocol.json'), load(root / 'tasks.json')
    candidates, assignments = load(root / 'candidates.json'), load(root / 'assignments.json')
    bindings, slots = load(root / 'bindings.json'), load(root / 'slots.json')
    assert protocol['status'] == 'F0_FROZEN_DEVELOPMENT_NOT_RUNTIME_FROZEN'
    assert len(tasks) == 16 and len(slots) == 64
    assert len(assignments) == protocol['code_requests'] <= 576
    assert protocol['total_reserved_requests'] == 1400
    assert not protocol['generated_development_outcomes_visible']
    assert not protocol['evaluation_materials_used_for_contracts']
    frame_root = repo / 'data/method/graph-guided-20260929/task-frame'
    assert manifest(frame_root) == protocol['frame_manifest_sha256']
    population = load(frame_root / 'tasks.json')
    assert load(root / 'evaluation-source-frame.json') == population['evaluation']
    assert [task['task_unit_id'] for task in tasks] == [task['task_unit_id'] for task in population['development']]
    archive = repo / 'data/method/graph-guided-20260929/archive/f0-implementation'
    archive_identity = load(archive / 'identity.json')
    assert archive_identity['active'] is False
    assert archive_identity['f0_manifest_sha256'] == frozen_hash
    assert archive_identity['implementation_sha256'] == protocol['implementation_sha256']
    assert digest(archive / 'source.tar.gz') == archive_identity['source_tar_sha256']
    with tarfile.open(archive / 'source.tar.gz', 'r:gz') as snapshot:
        members = snapshot.getmembers()
        assert len(members) == len(protocol['implementation_sha256'])
        assert {member.name for member in members} == set(protocol['implementation_sha256'])
        for member in members:
            assert member.isfile()
            stream = snapshot.extractfile(member)
            assert stream is not None
            assert hashlib.sha256(stream.read()).hexdigest() == protocol['implementation_sha256'][member.name]
    # 原F0实现逐字节归档；批准的评价准备调整不改变原生成、学习或测量。
    for name, expected in protocol['implementation_sha256'].items():
        if name == 'src/development/graph_guided_study.py' and digest(repo / name) != expected:
            verify_evaluation_authorization(repo)
        elif name != 'docs/experiments/2026-09-29-discovery-verify.py':
            assert digest(repo / name) == expected
    assert digest(repo / 'docs/graph-guided-discovery-protocol.md') == protocol['normative_protocol_sha256']
    assert digest(repo / 'data/method/graph-guided-20260929/preparation-inputs/evaluation-settings.json') == protocol['evaluation_preparation_settings_sha256']
    preparation = verify_preparation(repo, [repo / f"data/method/graph-guided-20260929/binding/case-{task['index']:04d}"
                                           for task in tasks])
    expected_candidates = [candidate for task in tasks for candidate in
        load(repo / f"data/method/graph-guided-20260929/binding/case-{task['index']:04d}/candidates.json")]
    assert candidates == expected_candidates
    assert load(root / 'contracts.json') == {row['contract_id']: row['contract'] for row in candidates}
    assert len({row['thread_id'] for row in load(root / 'preparation-accounting.json')}) == 32
    for task in tasks:
        source = load(repo / f"data/method/graph-guided-20260929/preparation-inputs/qualified/case-{task['index']:04d}/input.json")
        assert task['reference_prompt'] == source['source_prompt'] + '\n\nShared execution interface:\n' + source['shared_execution_interface']
    expected, expected_bindings, random_state = independent_assignments(tasks, candidates, 'development')
    assert expected == assignments and expected_bindings == bindings
    assert load(root / 'randomization-state.json') == random_state
    assert len({row['request_id'] for row in assignments}) == len(assignments)
    return dict(status='INDEPENDENT_F0_RANDOMIZATION_AND_INPUTS_VERIFIED', manifest_sha256=frozen_hash,
                tasks=len(tasks), policies=len(candidates), positions=len(slots), requests=len(assignments),
                preparation=preparation, new_code_calls=0,
                frozen_implementation_archive_sha256=archive_identity['source_tar_sha256'],
                current_preparation_implementation_sha256=digest(repo / 'src/development/graph_guided_study.py'),
                current_verifier_sha256=digest(Path(__file__)))


def independent_assignments(tasks, candidates, role, state=None):
    expected, expected_bindings = [], []
    random_seed = np.random.Generator(np.random.PCG64(2026092902))
    random_arm = np.random.Generator(np.random.PCG64(2026092903))
    random_order = np.random.Generator(np.random.PCG64(2026092904))
    if state is not None:
        random_seed.bit_generator.state = state['seed']
        random_arm.bit_generator.state = state['arm']
        random_order.bit_generator.state = state['order']
    for task in sorted(tasks, key=lambda row: row['task_unit_id']):
        grouped = {}
        for candidate in sorted([row for row in candidates if row['task_unit_id'] == task['task_unit_id']],
                                key=lambda row: row['candidate_id']):
            value = dict(p_versions=candidate['p_versions'], n_versions=candidate['n_versions'],
                         version_weights=[.5, .5], execution_interface=task['execution_interface'],
                         measurement=task['measurement'])
            serialized = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'))
            policy_id = hashlib.sha256(json.dumps(serialized, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()
            grouped.setdefault(policy_id, []).append(candidate)
        def append(policy_id, version, seed, position, arm, prompt, members):
            identity = ['tsg-discovery-development-20260929', role, task['task_unit_id'],
                        policy_id, version, int(seed), position]
            serialized = json.dumps(identity, ensure_ascii=False, separators=(',', ':'))
            request_id = hashlib.sha256(json.dumps(serialized, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()
            expected.append(dict(request_id=request_id, index=task['index'], task_unit_id=task['task_unit_id'],
                role=role, policy_id=policy_id, version=version, seed=int(seed), pair_position=position,
                arm=arm, prompt=prompt, prompt_sha256=hashlib.sha256(json.dumps(prompt, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest(),
                candidate_memberships=members, measurements=[task['measurement']]))
        for policy_id, members in sorted(grouped.items()):
            seeds = random_seed.choice(2**31 - 1, size=2, replace=False) + 1
            identities = [row['candidate_id'] for row in members]
            expected_bindings.extend(dict(task_unit_id=task['task_unit_id'], candidate_id=row['candidate_id'],
                use=row['use'], policy_id=policy_id, seeds=[int(seed) for seed in seeds]) for row in members)
            for version in range(2):
                for seed in seeds:
                    arms = ['P', 'N'] if random_arm.integers(2) == 0 else ['N', 'P']
                    for position, arm in enumerate(arms):
                        append(policy_id, version, seed, position, arm,
                               members[0]['p_versions' if arm == 'P' else 'n_versions'][version], identities)
        seeds = random_seed.choice(2**31 - 1, size=4, replace=False) + 1
        for position, seed in enumerate(seeds):
            append('R', 0, seed, position, 'R', task['reference_prompt'], [])
    reordered = [dict(expected[int(index)], slot=f'{position:04d}')
                 for position, index in enumerate(random_order.permutation(len(expected)))]
    return reordered, expected_bindings, {
        'seed': random_seed.bit_generator.state, 'arm': random_arm.bit_generator.state,
        'order': random_order.bit_generator.state}


def verify_targeted_generation_preparation(repo, root):
    frozen_hash = manifest(root)
    base = repo / 'data/method/graph-guided-20260929'
    protocol = load(root / 'protocol.json')
    tasks, candidates = load(root / 'tasks.json'), load(root / 'candidates.json')
    slots, evidence = load(root / 'slots.json'), load(root / 'source-evidence.json')
    registration_path = base / 'preparation-repair/targeted-20260929/registration.json'
    registration = load(registration_path)
    assert protocol['status'] == 'F0_FROZEN_DEVELOPMENT_NOT_RUNTIME_FROZEN'
    assert protocol['formal_protocol'] == 'SPECIFIED_DRAFT'
    assert not protocol['generated_targeted_outcomes_visible']
    assert protocol['measurements_frozen_before_generation']
    assert protocol['repair_registration_sha256'] == digest(registration_path)
    common_root = repo / 'results/graph-guided-20260929/targeted-repair-model-quality-verification'
    graph_root = common_root.parent / (common_root.name + '-graph')
    assert protocol['common_quality_manifest_sha256'] == manifest(common_root)
    assert protocol['graph_quality_manifest_sha256'] == manifest(graph_root)
    common = {row['blind_id']: row for row in load(common_root / 'positions.json')}
    graphs = {row['blind_id']: row for row in load(graph_root / 'positions.json')}
    assert len(common) == len(slots) == 30 and len(graphs) == 18
    assert {row['blind_id'] for row in slots} == set(common)
    assert len(evidence) == len(registration['streams']) == 15
    assert {(row['index'], row['flow']) for row in evidence} == {
        (row['index'], row['flow']) for row in registration['streams']}
    for quality_root in (common_root, graph_root):
        for item in load(quality_root / 'summary.json')['input_identity'].values():
            assert digest(repo / item['path']) == item['sha256']
    assert manifest(base / 'task-frame')
    frame = {row['index']: row for row in load(base / 'task-frame/tasks.json')['evaluation']}
    expected_tasks, expected_candidates, mechanical_errors = {}, [], []
    for item in evidence:
        index, flow = item['index'], item['flow']
        directory = repo / registration['preparation_root'] / f'case-{index:04d}' / flow
        assert repo / item['source_path'] == directory / 'source.json'
        assert repo / item['final_path'] == directory / 'final.json'
        assert digest(directory / 'source.json') == item['source_sha256']
        assert digest(directory / 'final.json') == item['final_sha256']
        source, prepared = load(directory / 'source.json'), load(directory / 'final.json')
        original = frame[index]
        assert source['source_prompt'] == original['source']['prompt']
        assert source['shared_execution_interface'] == original['execution_interface']
        assert source['task_unit_id'] == original['task_unit_id']
        assert source['system_prompt'] == protocol['system_prompt']
        task_id = original['task_unit_id']
        expected_tasks[index] = dict(index=index, task_unit_id=task_id,
            execution_interface=original['execution_interface'], measurement=original['measurement'],
            reference_prompt=source['source_prompt'] + '\n\nShared execution interface:\n' + original['execution_interface'])
        structural = repair_structure(source, prepared, flow)
        stream_errors = structural['errors'] or structural['graph_errors'] or any(
            position['errors'] for position in structural['positions'])
        selected = sorted([row for row in slots if row['index'] == index and row['flow'] == flow],
                          key=lambda row: row['position'])
        assert [row['position'] for row in selected] == [0, 1]
        for slot in selected:
            position = slot['position']
            review = common[slot['blind_id']]
            candidate = prepared['candidates'][position] if position < len(prepared['candidates']) else None
            original_id = candidate['candidate_id'] if candidate else None
            assert review['index'] == index and review['flow'] == flow and review['position'] == position
            assert review['candidate_id'] == original_id == slot['original_candidate_id']
            mechanical = candidate is not None and not stream_errors
            local_support = flow == 'Raw' or graphs[slot['blind_id']]['selected_support_completeness_both']
            semantic = review['conservative_model_quality_support']
            qualified = mechanical and local_support and semantic
            assert slot['task_unit_id'] == task_id and slot['quality_qualified'] == qualified
            assert slot['mechanical_qualified'] == mechanical and slot['semantic_qualified'] == semantic
            assert slot['local_support'] == local_support
            assert slot['status'] == ('qualified' if qualified else 'diagnostic_only' if candidate else 'missing')
            if candidate is None:
                assert slot['candidate_id'] is None
                continue
            identity = ['targeted-generation', index, flow, original_id, position]
            serialized = json.dumps(identity, sort_keys=True, ensure_ascii=False, separators=(',', ':'))
            candidate_id = hashlib.sha256(json.dumps(serialized, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()
            assert slot['candidate_id'] == candidate_id
            expected_candidates.append(dict(candidate, original_candidate_id=original_id,
                candidate_id=candidate_id, index=index, task_unit_id=task_id, flow=flow, use='open',
                quality_qualified=qualified, blind_id=slot['blind_id']))
            for side in ('p', 'n'):
                rendered = repair_edit_versions(source, candidate[side + '_edits'])
                assert rendered == candidate[side + '_versions']
            if structural['positions'][position]['errors']:
                mechanical_errors.append(dict(index=index, flow=flow, candidate_id=original_id,
                    errors=structural['positions'][position]['errors']))
    assert candidates == expected_candidates
    assert tasks == sorted(expected_tasks.values(), key=lambda row: row['index'])
    assert (len(tasks), len(candidates), sum(row['quality_qualified'] for row in candidates)) == (12, 27, 19)
    assert Counter(row['status'] for row in slots) == {'qualified': 19, 'diagnostic_only': 8, 'missing': 3}
    prior = base / 'evaluation-preparation/randomization-state.json'
    assert manifest(prior.parent)
    assert digest(prior) == protocol['prior_randomization_sha256']
    assignments, bindings, state = independent_assignments(tasks, candidates, 'development', load(prior))
    assert assignments == load(root / 'assignments.json') and bindings == load(root / 'bindings.json')
    assert state == load(root / 'randomization-state.json')
    assert len(assignments) == protocol['code_requests']
    unique_policies = len({(row['task_unit_id'], row['policy_id']) for row in bindings})
    assert len(assignments) == unique_policies * 8 + len(tasks) * 4
    assert len({row['request_id'] for row in assignments}) == len(assignments)
    assert len({row['seed'] for row in assignments}) > 0
    return dict(status='INDEPENDENT_TARGETED_GENERATION_INPUTS_VERIFIED', manifest_sha256=frozen_hash,
        tasks=len(tasks), policies=len(candidates), positions=len(slots), requests=len(assignments),
        unique_policies=unique_policies, quality_qualified=19, diagnostic_only=8, missing_positions=3,
        mechanical_errors=mechanical_errors, randomization_replay='INDEPENDENTLY_REPLAYED', model_calls=0)


def verify_targeted_generation_effects(preparation, inputs, results, analysis):
    manifest(analysis)
    assignments, candidates, bindings, slots = (load(preparation / name) for name in
        ('assignments.json', 'candidates.json', 'bindings.json', 'slots.json'))
    outcomes, effects = load(analysis / 'outcomes.json'), load(analysis / 'effects.json')
    assert len(effects) == len(candidates)
    assert load(analysis / 'slots.json') == slots
    endpoints = {}
    for request, outcome in outcomes.items():
        validity = outcome['valid']
        functionality = outcome['functionality']
        endpoints[request] = dict(primary=outcome['primary'], sensitivity=outcome['sensitivity'],
            code_validity=[0, 1] if validity is None else [int(validity)] * 2,
            oracle_coverage=[0, 1] if outcome['security'] == 'missing' else [int(outcome['security'] in {'secure', 'insecure'})] * 2,
            functionality=[0, 0] if validity is False or functionality == 'fail' else [1, 1] if functionality == 'pass' else [0, 1],
            joint_success=[0, 1] if outcome['joint_success'] is None else [outcome['joint_success']] * 2)
    def weighted(requests, endpoint):
        coefficients = Counter()
        for request, coefficient in requests:
            coefficients[request] += coefficient
        result = [0., 0.]
        for request, coefficient in coefficients.items():
            lower, upper = endpoints[request][endpoint]
            result[0] += coefficient * (lower if coefficient > 0 else upper)
            result[1] += coefficient * (upper if coefficient > 0 else lower)
        return result
    for candidate, effect in zip(candidates, effects, strict=True):
        for key in ('index', 'task_unit_id', 'candidate_id', 'original_candidate_id', 'flow',
                    'target', 'operation', 'quality_qualified'):
            assert effect[key] == candidate[key]
        selected = [row for row in bindings if row['candidate_id'] == candidate['candidate_id']
                    and row['task_unit_id'] == candidate['task_unit_id'] and row['use'] == 'open']
        assert len(selected) == 1
        task_rows = [row for row in assignments if row['task_unit_id'] == candidate['task_unit_id']]
        rows = {arm: [row for row in task_rows if row['arm'] == arm and
                     (arm == 'R' or row['policy_id'] == selected[0]['policy_id'])] for arm in ('P', 'N', 'R')}
        assert all(len(value) == 4 for value in rows.values())
        for arm in ('P', 'N'):
            assert Counter(row['version'] for row in rows[arm]) == {0: 2, 1: 2}
        for arm, arm_rows in rows.items():
            actual = effect['arms'][arm]
            assert actual['n'] == 4
            assert actual['security'] == dict(Counter(outcomes[row['request_id']]['security'] for row in arm_rows))
            assert actual['functionality'] == dict(Counter(outcomes[row['request_id']]['functionality'] for row in arm_rows))
            terms = [(row['request_id'], .25) for row in arm_rows]
            assert actual['endpoints'] == {name: weighted(terms, name) for name in next(iter(endpoints.values()))}
        for comparison, negative in (('pn', 'N'), ('pr', 'R')):
            terms = [(row['request_id'], .25) for row in rows['P']] + [(row['request_id'], -.25) for row in rows[negative]]
            assert effect[comparison] == {name: weighted(terms, name) for name in next(iter(endpoints.values()))}
    diagnostics = load(analysis / 'measurement-diagnostics.json')
    assert len(diagnostics) == len(assignments)
    for assignment, diagnostic in zip(assignments, diagnostics, strict=True):
        for key in ('request_id', 'slot', 'index', 'arm', 'policy_id'):
            assert diagnostic[key] == assignment[key]
        assert diagnostic['outcome'] == outcomes[assignment['request_id']]
        path = results / assignment['slot'] / 'result/result.json'
        result = load(path) if path.is_file() else None
        expected_channels = result['measurements'][0]['measurement']['channels'] if result and result['status'] == 'returned' else {}
        assert diagnostic['channels'] == expected_channels
        assert diagnostic['status'] == (result['status'] if result else 'assigned_response_missing')
    summary = load(analysis / 'summary.json')
    assert summary['status'] == 'EXECUTED_TARGETED_GENERATION_DESCRIPTIVE_ANALYSIS'
    assert summary['input_manifest_sha256'] == manifest(inputs)
    assert summary['preparation_manifest_sha256'] == manifest(preparation)
    assert summary['result_manifest_sha256'] == manifest(results / 'summary')
    for key, expected in dict(tasks=12, fixed_positions=30, materialized_policies=27,
        qualified_policies=19, missing_positions=3, assigned_requests=len(assignments),
        unique_policies=len({row['policy_id'] for row in bindings})).items():
        assert summary[key] == expected
    for field in ('security', 'functionality'):
        assert summary[field] == dict(Counter(row[field] for row in outcomes.values()))
    for field, outcome_field in (('code_validity', 'valid'), ('joint_success', 'joint_success')):
        assert summary[field] == dict(Counter(str(row[outcome_field]) for row in outcomes.values()))
    assert summary['generation_status'] == dict(Counter(row['status'] for row in diagnostics))
    for comparison in ('pn', 'pr'):
        counts = Counter()
        for row in effects:
            if not row['quality_qualified']:
                continue
            lower, upper = row[comparison]['primary']
            counts['positive' if lower > 0 else 'negative' if upper < 0 else 'zero' if lower == upper == 0 else 'unresolved'] += 1
        assert summary['qualified_direction_counts'][comparison] == dict(counts)
    return dict(status='INDEPENDENT_TARGETED_SIX_ENDPOINT_EFFECTS_VERIFIED', policies=len(effects),
        qualified_policies=19, diagnostic_policies=8, missing_positions=3, endpoints=6,
        comparisons=['P-N', 'P-R'], all_assigned_requests_retained=True,
        effect_bounds_interpretation='unknown-outcome bounds; no sampling uncertainty or population claim')


def independent_feature_matrix(rows, model, mode):
    def text_block(texts, record):
        encoder = TfidfVectorizer(analyzer='char', ngram_range=(2, 4), norm='l2',
                                  vocabulary=record['vocabulary'], dtype=np.float64)
        encoder.fit(texts)
        encoder.idf_ = np.asarray(record['idf'])
        return encoder.transform(texts).toarray()
    def unit_length(values):
        lengths = np.linalg.norm(values, axis=1, keepdims=True)
        return np.divide(values, lengths, out=np.zeros_like(values), where=lengths != 0)
    orientation = np.asarray([row['orientation'] for row in rows])[:, None]
    common = text_block([row['canonical_text'] for row in rows], model['common'])
    positive = text_block([text for row in rows for text in row['p_versions']], model['policy'])
    negative = text_block([text for row in rows for text in row['n_versions']], model['policy'])
    difference = unit_length(positive.reshape(len(rows), 2, -1).mean(axis=1)
                             - negative.reshape(len(rows), 2, -1).mean(axis=1))
    blocks = [orientation, orientation * common, difference]
    if mode != 'common':
        marginal = np.asarray([[row['marginals'].get(key, 0) for key in model['marginals']] for row in rows], dtype=float)
        counts = [Counter(json.dumps(edge, ensure_ascii=False, separators=(',', ':')) for edge in row['relations']) for row in rows]
        relation = np.asarray([[row.get(key, 0) for key in model['relations']] for row in counts], dtype=float)
        blocks.extend([orientation * unit_length(marginal),
                       orientation * unit_length(relation) if mode == 'relations' else np.zeros_like(relation)])
    return np.concatenate(blocks, axis=1)


def independent_definition(rows):
    definitions = {}
    for name, texts in [('common', [row['canonical_text'] for row in rows]),
                        ('policy', [text for row in rows for text in row['p_versions'] + row['n_versions']])]:
        encoder = TfidfVectorizer(analyzer='char', ngram_range=(2, 4), max_features=256, norm='l2', dtype=np.float64).fit(texts)
        definitions[name] = dict(vocabulary={key: int(value) for key, value in encoder.vocabulary_.items()}, idf=encoder.idf_.tolist())
    definitions['marginals'] = sorted({key for row in rows for key in row['marginals']})
    definitions['relations'] = sorted({json.dumps(edge, ensure_ascii=False, separators=(',', ':')) for row in rows for edge in row['relations']})
    return definitions


def independent_ridge(rows, definition, mode, alpha):
    counts = Counter(row['task_unit_id'] for row in rows)
    weights = np.sqrt([1 / counts[row['task_unit_id']] for row in rows])
    matrix = independent_feature_matrix(rows, definition, mode) * weights[:, None]
    target = np.asarray([row['delta_pn'] for row in rows]) * weights
    # 直接求解任务加权的对偶方程，独立核验生产SVD估计。
    return matrix.T @ np.linalg.solve(matrix @ matrix.T + alpha * np.eye(len(rows)), target)


def verify_development_effects(repo, root):
    f0 = repo / 'data/method/graph-guided-20260929/development-preparation'
    assert manifest(f0) == load(root / 'identity.json')['f0_manifest_sha256']
    assignments, bindings = load(f0 / 'assignments.json'), load(f0 / 'bindings.json')
    candidates, effects, outcomes = load(f0 / 'candidates.json'), load(root / 'effects.json'), load(root / 'outcomes.json')
    assert set(outcomes) == {row['request_id'] for row in assignments}
    assert len(candidates) == len(effects)
    for candidate, effect in zip(candidates, effects, strict=True):
        assert {key: effect[key] for key in candidate} == candidate
        matched = [row for row in bindings if row['task_unit_id'] == candidate['task_unit_id']
                   and row['candidate_id'] == candidate['candidate_id'] and row['use'] == 'open']
        assert len(matched) == 1
        requests = [row for row in assignments if row['task_unit_id'] == candidate['task_unit_id']
                    and row['policy_id'] == matched[0]['policy_id'] and row['arm'] in {'P', 'N'}]
        assert Counter((row['arm'], row['version']) for row in requests) == {('P', 0): 2, ('P', 1): 2, ('N', 0): 2, ('N', 1): 2}
        reference = [row for row in assignments if row['task_unit_id'] == candidate['task_unit_id'] and row['arm'] == 'R']
        assert len(reference) == 4
        pn = [(row['request_id'], .25 if row['arm'] == 'P' else -.25) for row in requests]
        pr = [(row['request_id'], .25) for row in requests if row['arm'] == 'P'] + [(row['request_id'], -.25) for row in reference]
        def bounded(terms, endpoint):
            coefficients = {}
            for request, coefficient in terms:
                coefficients[request] = coefficients.get(request, 0) + coefficient
            lower = sum(coefficient * outcomes[request][endpoint][0 if coefficient > 0 else 1]
                        for request, coefficient in coefficients.items() if coefficient)
            upper = sum(coefficient * outcomes[request][endpoint][1 if coefficient > 0 else 0]
                        for request, coefficient in coefficients.items() if coefficient)
            return [lower, upper]
        expected_pn, expected_pr = bounded(pn, 'primary'), bounded(pr, 'primary')
        assert effect['primary_pn'] == expected_pn and effect['primary_pr'] == expected_pr
        assert effect['sensitivity_pn'] == bounded(pn, 'sensitivity')
        for field, expected in [('delta_pn', expected_pn), ('delta_pr', expected_pr)]:
            if expected[0] == expected[1]:
                assert effect[field] == expected[0]
            else:
                assert field not in effect
    assert load(root / 'training.json') == [row for row in effects if 'delta_pn' in row]
    return dict(status='INDEPENDENT_ASSIGNED_REQUEST_DEVELOPMENT_EFFECTS_VERIFIED',
                policies=len(effects), assignments=len(assignments), task_units=len({row['task_unit_id'] for row in assignments}))


def verify_learning(repo, root):
    manifest(root)
    effect_verification = verify_development_effects(repo, root)
    models, training = load(root / 'models.json'), load(root / 'training.json')
    assert len({row['task_unit_id'] for row in training}) >= 8
    checked = []
    for name, model in models.items():
        rows = load(root / 'reference-training.json') if name == 'adoption' else training
        mode = 'common' if name == 'adoption' else name
        definition = independent_definition(rows)
        for field in ('common', 'policy', 'marginals', 'relations'):
            assert definition[field] == model[field]
        coefficients = independent_ridge(rows, definition, mode, model['alpha'])
        np.testing.assert_allclose(coefficients, model['coefficients'], rtol=1e-8, atol=1e-10)
        assert model['intercept'] is False
        evaluations = []
        for alpha in (.1, 1., 10., 100.):
            folds = []
            for task in sorted({row['task_unit_id'] for row in rows}):
                train = [row for row in rows if row['task_unit_id'] != task]
                test = [row for row in rows if row['task_unit_id'] == task]
                folded_definition = independent_definition(train)
                coefficient = independent_ridge(train, folded_definition, mode, alpha)
                prediction = independent_feature_matrix(test, folded_definition, mode) @ coefficient
                mse = float(np.mean((prediction - [row['delta_pn'] for row in test]) ** 2))
                folds.append(dict(task_unit_id=task, mse=mse))
            evaluations.append(dict(alpha=alpha, mse=float(np.mean([row['mse'] for row in folds])), folds=folds))
        assert len(evaluations) == len(model['validation'])
        for actual, expected in zip(model['validation'], evaluations, strict=True):
            assert actual['alpha'] == expected['alpha']
            assert abs(actual['mse'] - expected['mse']) < 1e-10
            for original, recomputed in zip(actual['folds'], expected['folds'], strict=True):
                assert original['task_unit_id'] == recomputed['task_unit_id'] and abs(original['mse'] - recomputed['mse']) < 1e-10
        chosen = min(evaluations, key=lambda row: (row['mse'], -row['alpha']))
        assert chosen['alpha'] == model['alpha']
        checked.append(dict(model=name, tasks=len({row['task_unit_id'] for row in rows}), policies=len(rows), alpha=model['alpha']))
    outcomes, effects = load(root / 'outcomes.json'), load(root / 'effects.json')
    assert training == [row for row in effects if 'delta_pn' in row]
    for row in effects:
        if 'delta_pn' in row:
            assert row['primary_pn'] == [row['delta_pn']] * 2
        if 'delta_pr' in row:
            assert row['primary_pr'] == [row['delta_pr']] * 2
    return dict(status='INDEPENDENT_TASK_WEIGHTED_RIDGE_AND_FOLD_ENCODING_VERIFIED', records=checked,
                outcome_requests=len(outcomes), effect_verification=effect_verification)


def verify_evaluation_freeze(repo, root):
    frozen_hash = manifest(root)
    protocol, tasks = load(root / 'protocol.json'), load(root / 'tasks.json')
    candidates, bindings = load(root / 'candidates.json'), load(root / 'bindings.json')
    assert protocol['status'] == 'F1_FROZEN_EVALUATION_NOT_RUNTIME_FROZEN'
    assert len(tasks) == 18 and len(load(root / 'slots.json')) == 72
    assert not protocol['generated_evaluation_outcomes_visible']
    assert protocol['independent_model_quality_review'] == 'COMPLETED_OUTCOME_BLIND_ISOLATED_MODEL_REVIEW'
    quality = load(root / 'model-quality.json')
    quality_material = repo / 'data/method/graph-guided-20260929/model-quality-evaluation'
    quality_result = repo / 'results/graph-guided-20260929/evaluation-model-quality-verification'
    assert manifest(quality_material / 'public') == quality['public_manifest_sha256']
    assert manifest(quality_material / 'private') == quality['private_manifest_sha256']
    assert manifest(quality_result) == quality['result_manifest_sha256'] == protocol['model_quality_result_manifest_sha256']
    assert quality['summary'] == load(quality_result / 'summary.json')
    assert not quality['policy_qualification_changed'] and not quality['primary_pool_filtered_by_model_review']
    assert quality['summary']['positions'] == 72 and quality['summary']['tasks'] == 18
    quality_ids = set()
    for record in quality['summary']['input_identity'].values():
        assert digest(repo / record['path']) == record['sha256']
    for reviewer in ('reviewer-a', 'reviewer-b'):
        record = load(quality_material / (reviewer + '.json'))
        assert record['reviewer_kind'] == 'isolated_model_session' and record['independent_from_preparation']
        assert not record['generated_code_or_outcomes_seen'] and len(record['judgments']) == 72
        assert record['reviewer_id'] not in quality_ids
        quality_ids.add(record['reviewer_id'])
        completed = record['available_time']['completed_at']
        completed_at = (datetime.strptime(completed, '%Y-%m-%d %H:%M:%S UTC').replace(tzinfo=timezone.utc)
                        if completed.endswith(' UTC') else datetime.fromisoformat(completed.replace('Z', '+00:00')))
        assert completed_at <= datetime.fromisoformat(protocol['frozen_utc'])
    quality_protocol = load(quality_material / 'public/protocol.json')
    for task in tasks:
        assert manifest(repo / f"data/method/graph-guided-20260929/binding/case-{task['index']:04d}") == quality_protocol['binding_manifest_sha256'][str(task['index'])]
    f0 = repo / 'data/method/graph-guided-20260929/development-preparation'
    analysis = repo / 'data/method/graph-guided-20260929/development-analysis'
    manifest(f0)
    authority, authorization_hash = verify_evaluation_authorization(repo)
    assert protocol['evaluation_resource_authorization'] == authority
    assert protocol['evaluation_resource_authorization_sha256'] == authorization_hash
    assert protocol['evaluation_amendment_sha256'] == digest(repo / authority['normative_amendment'])
    assert protocol['f0_implementation_sha256'] == load(f0 / 'protocol.json')['implementation_sha256']
    archive = repo / 'data/method/graph-guided-20260929/archive/f1-implementation'
    archive_identity_manifest = manifest(archive / 'identity')
    archive_identity = load(archive / 'identity/identity.json')
    assert archive_identity['status'] == 'FROZEN_F1_IMPLEMENTATION_ARCHIVE'
    assert archive_identity['f1_manifest_sha256'] == frozen_hash
    assert archive_identity['files'] == protocol['implementation_sha256']
    assert len(protocol['implementation_sha256']) == 7
    assert digest(archive / 'source.tar.gz') == archive_identity['source_tar_sha256']
    with tarfile.open(archive / 'source.tar.gz', 'r:gz') as snapshot:
        members = snapshot.getmembers()
        assert len(members) == len(protocol['implementation_sha256'])
        assert {member.name for member in members} == set(protocol['implementation_sha256'])
        for member in members:
            assert member.isfile()
            stream = snapshot.extractfile(member)
            assert stream is not None
            assert hashlib.sha256(stream.read()).hexdigest() == protocol['implementation_sha256'][member.name]
    # 原F1七份实现均核实归档身份；生成、测量、学习及报告继续核实当前文件。
    for name, expected in protocol['implementation_sha256'].items():
        if name not in {'src/development/graph_guided_study.py', 'docs/experiments/2026-09-29-discovery-verify.py'}:
            assert digest(repo / name) == expected
    accounting = load(root / 'preparation-accounting.json')
    assert len(accounting) == 36 and len({row['thread_id'] for row in accounting}) == 36
    for row in accounting:
        limit = 32000 if row['index'] == 214 else 64000
        assert row['resource_contract']['total_token_limit'] == limit
        assert row['resource_contract']['amendment_sha256'] == (None if row['index'] == 214 else authorization_hash)
        if row['index'] != 214:
            assert row['input_task_identity_verified']
            session = [json.loads(line) for line in Path(row['session_path']).read_text(encoding='utf-8').splitlines()]
            prompts = [item['text'] for entry in session if entry['type'] == 'response_item'
                       and entry['payload'].get('role') == 'user'
                       for item in entry['payload']['content'] if item.get('text', '').startswith('本实例只执行')]
            assert len(prompts) == 1
            instruction, actual_source = prompts[0].split('\n', 1)
            source = load(repo / f"data/method/graph-guided-20260929/preparation-inputs/qualified/case-{row['index']:04d}/input.json")
            assert json.loads(actual_source) == source
            assert hashlib.sha256(prompts[0].encode()).hexdigest() == row['delivered_prompt_sha256']
            delivered_flow = instruction.startswith('本实例只执行' + row['flow'] + '流程。')
            assert delivered_flow == row['input_flow_instruction_verified']
            prepared_path = repo / f"data/method/graph-guided-20260929/preparation/cli55/dev{row['index']}-{row['flow'].lower()}-initial.json"
            valid_json = row.get('json_output_validated', True)
            if prepared_path.is_file() and not valid_json:
                validated = subprocess.run([sys.executable, '-m', 'json.tool', str(prepared_path)],
                                           capture_output=True, text=True, encoding='utf-8', check=False)
                assert validated.returncode != 0
                audited = load(repo / f"data/method/graph-guided-20260929/preparation/cli55/case-{row['index']:04d}/{row['flow'].lower()}-output-validation.json")
                assert audited['original_sha256'] == digest(prepared_path)
                assert audited['raw_text'] == prepared_path.read_text(encoding='utf-8')
                assert audited['parsed_policy_object_obtained'] is False
            prepared = load(prepared_path) if prepared_path.is_file() and valid_json else None
            identity_valid = (prepared is not None and prepared.get('index') == source['index']
                              and prepared.get('task_unit_id') == source['task_unit_id'])
            representation = prepared.get('representation') if prepared is not None else None
            flow = representation.get('flow') if isinstance(representation, dict) else representation
            flow_valid = identity_valid and isinstance(flow, str) and flow.casefold() == row['flow'].casefold() and delivered_flow
            assert row['preparation_identity_qualified'] == identity_valid
            assert row['preparation_flow_qualified'] == flow_valid
        if row['execution_qualified']:
            assert row['usage']['input_tokens'] + row['usage']['output_tokens'] == row['usage']['total_tokens'] <= limit
            assert 1 <= row['top_level_requests'] <= 2 and not row['tool_item_types']
            assert row['complete_accounting']
            assert row.get('transport_boundary_qualified', True)
            assert row.get('preparation_identity_qualified', True) and row.get('preparation_flow_qualified', True)
    assert manifest(analysis) == protocol['development_analysis_manifest_sha256']
    assert load(root / 'models.json') == load(analysis / 'models.json')
    models = load(root / 'models.json')
    learning = verify_learning(repo, analysis)
    expected, expected_bindings, state = independent_assignments(tasks, candidates, 'evaluation', load(f0 / 'randomization-state.json'))
    assert expected == load(root / 'assignments.json') and expected_bindings == bindings
    assert state == load(root / 'randomization-state.json')
    preparation = verify_preparation(repo, [repo / f"data/method/graph-guided-20260929/binding/case-{task['index']:04d}" for task in tasks])
    training = load(analysis / 'training.json')
    task_values, representatives = {}, {}
    for row in training:
        task_values.setdefault(row['task_unit_id'], []).append(row['delta_pn'])
        key = row['task_unit_id'], row['contract_id']
        if key not in representatives or (row['citation_start'], row['candidate_id']) < (representatives[key]['citation_start'], representatives[key]['candidate_id']):
            representatives[key] = row
    global_mean = sum(sum(values) / len(values) for values in task_values.values()) / len(task_values)
    means = {}
    for (_, contract), row in representatives.items():
        means.setdefault(contract, []).append(row['delta_pn'])
    predictions = {contract: (sum(values) + 2 * global_mean) / (len(values) + 2) for contract, values in means.items()}
    assert abs(load(analysis / 'nomination.json')['global_task_mean'] - global_mean) < 1e-12
    nominated = []
    for contract, values in means.items():
        mean = sum(values) / len(values)
        score = max(abs(mean) - 1.28 * float(np.std(values, ddof=1)) / np.sqrt(len(values)), 0) if len(values) >= 4 else 0
        if score > 0:
            nominated.append(dict(contract_id=contract, tasks=len(values), mean=mean, nomination_score=score,
                prediction=predictions[contract], direction=-1 if mean < 0 else 1))
    nominee = min(nominated, key=lambda row: (-row['nomination_score'], row['contract_id'])) if nominated else None
    assert load(analysis / 'nomination.json')['nominee'] == nominee == protocol['selected_replication_contract']
    random = np.random.Generator(np.random.PCG64(2026092905))
    decisions = load(root / 'decisions.json')
    assert [row['task_unit_id'] for row in decisions] == sorted(task['task_unit_id'] for task in tasks)
    def selected(pool, scores):
        if not pool:
            return None
        row, score = min(zip(pool, scores, strict=True), key=lambda pair: (-abs(float(pair[1])), pair[0]['candidate_id']))
        return dict(candidate_id=row['candidate_id'], direction=-1 if score < 0 else 1, prediction=float(score))
    checked = []
    for decision in decisions:
        task_id = decision['task_unit_id']
        source = load(repo / f"data/method/graph-guided-20260929/preparation-inputs/qualified/case-{decision['index']:04d}/input.json")
        assert source['f0_contrast_contracts'] == load(f0 / 'contracts.json')
        assert not source['development_effects_or_replication_nominee_visible']
        pool = sorted([row for row in candidates if row['task_unit_id'] == task_id and row['use'] == 'open'], key=lambda row: row['candidate_id'])
        assert decision['candidate_ids'] == [row['candidate_id'] for row in pool]
        scores_by_mode = {}
        for mode, selector in [('common', 'ridge'), ('relations', 'relations'), ('endpointless', 'endpointless')]:
            scores = independent_feature_matrix(pool, models[mode], mode) @ np.asarray(models[mode]['coefficients']) if pool else np.array([])
            np.testing.assert_allclose(scores, decision['predictions'][mode], rtol=1e-10, atol=1e-12)
            scores_by_mode[mode] = scores
            expected_action = selected(pool, scores)
            actual = decision['actions'][selector]
            assert (actual is None) == (expected_action is None)
            if actual is not None:
                assert actual['candidate_id'] == expected_action['candidate_id'] and actual['direction'] == expected_action['direction']
        for flow, selector in [('TSG', 'tsg'), ('Raw', 'raw')]:
            entries = [(row, score) for row, score in zip(pool, scores_by_mode['common'], strict=True) if row['flow'] == flow]
            expected_action = selected([row for row, _ in entries], [score for _, score in entries])
            actual = decision['actions'][selector]
            assert (actual is None) == (expected_action is None)
            if actual is not None:
                assert actual['candidate_id'] == expected_action['candidate_id'] and actual['direction'] == expected_action['direction']
        mean_scores = [predictions.get(row['contract_id'], global_mean) for row in pool]
        np.testing.assert_allclose(mean_scores, decision['contract_mean_predictions'], rtol=0, atol=1e-12)
        expected_mean = selected(pool, mean_scores)
        if expected_mean is None:
            assert decision['actions']['contract_mean'] is None
        else:
            assert decision['actions']['contract_mean']['candidate_id'] == expected_mean['candidate_id']
            assert decision['actions']['contract_mean']['direction'] == expected_mean['direction']
        direction = -1 if global_mean < 0 else 1
        assert decision['actions']['first'] == (dict(candidate_id=pool[0]['candidate_id'], direction=direction) if pool else None)
        assert decision['actions']['random'] == (dict(candidate_id=pool[int(random.integers(len(pool)))]['candidate_id'], direction=direction) if pool else None)
        rep = [row for row in candidates if row['task_unit_id'] == task_id and row['use'] == 'replication']
        assert len(rep) <= 1
        assert decision['actions']['replication'] == (dict(candidate_id=rep[0]['candidate_id'], direction=nominee['direction']) if rep else None)
        if pool and 'adoption' in models:
            task = next(row for row in tasks if row['task_unit_id'] == task_id)
            reference_rows = [dict(row, n_versions=[task['reference_prompt']] * 2,
                canonical_text=json.dumps(dict(original_contrast=row['contract'], state_p=row['contract']['state_p'],
                    state_reference=task['reference_prompt'], comparison='P-R'), sort_keys=True, ensure_ascii=False, separators=(',', ':'))) for row in pool]
            scores = independent_feature_matrix(reference_rows, models['adoption'], 'common') @ np.asarray(models['adoption']['coefficients'])
            np.testing.assert_allclose(scores, decision['adoption_predictions'], rtol=1e-10, atol=1e-12)
            selected_row, score = min(zip(pool, scores, strict=True), key=lambda pair: (-pair[1], pair[0]['candidate_id']))
            actual = decision['actions']['adoption']
            assert (actual is None) == (score <= .05)
            if actual is not None:
                assert actual['candidate_id'] == selected_row['candidate_id'] and abs(actual['prediction'] - score) < 1e-12
        else:
            assert decision['actions']['adoption'] is None and decision['adoption_predictions'] == []
        checked.append(dict(task_unit_id=task_id, candidates=len(pool)))
    assert not protocol['low_expected_task_ids'] and protocol['low_expectation_comparison'] == 'PENDING_INDEPENDENT_REVIEW'
    return dict(status='INDEPENDENT_F1_ASSIGNMENTS_PREDICTIONS_AND_ACTIONS_VERIFIED', manifest_sha256=frozen_hash,
                tasks=len(tasks), requests=len(expected), records=checked, preparation=preparation,
                learning=learning,
                frozen_implementation_archive_sha256=archive_identity['source_tar_sha256'],
                frozen_implementation_identity_manifest_sha256=archive_identity_manifest,
                frozen_implementation_sha256=protocol['implementation_sha256'],
                current_preparation_implementation_sha256=digest(repo / 'src/development/graph_guided_study.py'),
                current_verifier_sha256=digest(Path(__file__)),
                human_low_expectation_review='PENDING_INDEPENDENT_REVIEW')


def verify_evaluation_outputs(repo, root):
    manifest(root)
    f1 = repo / 'data/method/graph-guided-20260929/evaluation-preparation'
    assert load(root / 'decisions.json') == load(f1 / 'decisions.json')
    assignments, bindings = load(f1 / 'assignments.json'), load(f1 / 'bindings.json')
    outcomes, actual_vectors = load(root / 'outcomes.json'), load(root / 'vectors.json')
    assert set(outcomes) == {row['request_id'] for row in assignments}
    def coefficients(task, action, use='open'):
        if action is None:
            return []
        matches = [row for row in bindings if row['task_unit_id'] == task and row['candidate_id'] == action['candidate_id'] and row['use'] == use]
        assert len(matches) == 1 and action['direction'] in {-1, 1}
        requests = [row for row in assignments if row['task_unit_id'] == task and row['policy_id'] == matches[0]['policy_id'] and row['arm'] in {'P', 'N'}]
        assert Counter((row['arm'], row['version']) for row in requests) == {('P', 0): 2, ('P', 1): 2, ('N', 0): 2, ('N', 1): 2}
        return [(row['request_id'], action['direction'] / 4 * (1 if row['arm'] == 'P' else -1)) for row in requests]
    def bounded_sum(terms, endpoint):
        combined = {}
        for request, coefficient in terms:
            combined[request] = combined.get(request, 0) + coefficient
        lower = sum(weight * outcomes[request][endpoint][0 if weight > 0 else 1] for request, weight in combined.items() if weight)
        upper = sum(weight * outcomes[request][endpoint][1 if weight > 0 else 0] for request, weight in combined.items() if weight)
        return [lower, upper]
    expected = dict(T1=[], T2=[], T3=[])
    low_expected = set(load(f1 / 'protocol.json')['low_expected_task_ids'])
    for decision in load(f1 / 'decisions.json'):
        task, actions = decision['task_unit_id'], decision['actions']
        for comparison, positive, negative in [('T1', 'tsg', 'raw'), ('T2', 'ridge', 'contract_mean')]:
            terms = coefficients(task, actions[positive]) + [(request, -weight) for request, weight in coefficients(task, actions[negative])]
            expected[comparison].append(dict(task_unit_id=task, primary=bounded_sum(terms, 'primary'),
                sensitivity=bounded_sum(terms, 'sensitivity'), coefficients=[list(term) for term in terms]))
        if task in low_expected:
            terms = coefficients(task, actions['replication'], 'replication')
            expected['T3'].append(dict(task_unit_id=task, primary=bounded_sum(terms, 'primary'),
                sensitivity=bounded_sum(terms, 'sensitivity'), coefficients=[list(term) for term in terms]))
    assert expected == actual_vectors
    for effect in load(root / 'effects.json'):
        task = effect['task_unit_id']
        terms = coefficients(task, dict(candidate_id=effect['candidate_id'], direction=1), effect['use'])
        reference = [(row['request_id'], -.25) for row in assignments if row['task_unit_id'] == task and row['arm'] == 'R']
        assert len(reference) == 4
        positive = [(request, weight) for request, weight in terms if weight > 0]
        for endpoint in ('primary', 'sensitivity'):
            assert bounded_sum(terms, endpoint) == effect['pn'][endpoint]
            assert bounded_sum(positive + reference, endpoint) == effect['pr'][endpoint]
    return dict(status='INDEPENDENT_SHARED_REQUEST_COEFFICIENTS_EFFECTS_AND_INTERVALS_VERIFIED',
                vectors={name: len(rows) for name, rows in expected.items()}, intervals=verify_tables(root))


def verify_human_quality_material(repo, root):
    public, private = root / 'public', root / 'private'
    public_sha, private_sha = manifest(public), manifest(private)
    base = repo / 'data/method/graph-guided-20260929'
    f0 = base / 'development-preparation'
    f0_sha = manifest(f0)
    protocol = load(public / 'protocol.json')
    population = protocol.get('population', 'development')
    assert population in {'development', 'evaluation'}
    assert protocol['status'] in {'SOURCE_ONLY_HUMAN_QUALITY_MATERIAL_NOT_JUDGMENTS',
                                  'SOURCE_ONLY_QUALITY_MATERIAL_NOT_JUDGMENTS'}
    task_count, position_count = (16, 64) if population == 'development' else (18, 72)
    assert protocol['f0_manifest_sha256'] == f0_sha
    assert protocol['independent_reviewers_registered'] == 0
    assert protocol['unfilled_values_are_not_results'] is True
    assert protocol['judgment_values'] == ['support', 'not_support', 'unknown']
    assert protocol['primary_inputs_unchanged'] is True
    assert protocol['new_model_calls'] == 0 and protocol['new_policy_binding'] is False
    for key in ('flow_labels_visible', 'generated_codes_visible', 'outcomes_visible',
                'selector_scores_visible', 'author_legality_visible', 'private_mapping_provided_to_reviewers'):
        assert protocol[key] is False
    identity = load(private / 'identity.json')
    assert identity['public_manifest_sha256'] == public_sha and identity['f0_manifest_sha256'] == f0_sha
    assert identity['generator_sha256'] == protocol['generator_sha256']
    packets = load(public / 'packets.json')
    mapping = load(private / 'mapping.json')
    assert len(packets) == len(mapping) == position_count
    by_id = {row['blind_id']: row for row in packets}
    assert len(by_id) == position_count and set(by_id) == {row['blind_id'] for row in mapping}
    if population == 'development':
        slot_rows, candidate_rows = load(f0 / 'slots.json'), load(f0 / 'candidates.json')
    else:
        manifest(base / 'task-frame')
        tasks = load(base / 'task-frame/tasks.json')['evaluation']
        assert len(tasks) == task_count and len({task['index'] for task in tasks}) == task_count
        slot_rows, candidate_rows, binding_hashes = [], [], {}
        for task in tasks:
            binding = base / f"binding/case-{task['index']:04d}"
            binding_hashes[str(task['index'])] = manifest(binding)
            task_slots = load(binding / 'slots.json')
            assert {(row['flow'], row['position']) for row in task_slots} == {
                (flow, position) for flow in ('TSG', 'Raw') for position in (0, 1)}
            assert len(task_slots) == 4
            slot_rows.extend(dict(row, index=task['index']) for row in task_slots)
            task_candidates = load(binding / 'candidates.json')
            assert all(row['index'] == task['index'] and row['task_unit_id'] == task['task_unit_id']
                       for row in task_candidates)
            candidate_rows.extend(task_candidates)
        assert protocol['binding_manifest_sha256'] == binding_hashes
    slots = {(row['index'], row['flow'], row['position']): row for row in slot_rows}
    candidates = {(row['index'], row['flow'], row['position']): row for row in candidate_rows}
    assert len(slots) == len(slot_rows) == position_count
    assert len(candidates) == len(candidate_rows)
    assert Counter(row['flow'] for row in mapping) == {'TSG': position_count // 2, 'Raw': position_count // 2}
    assert {(row['index'], row['flow'], row['position']) for row in mapping} == set(slots)
    source_keys = ('source_prompt', 'system_prompt', 'language', 'shared_execution_interface',
                   'interface_scope', 'measurement')
    policy_keys = ('target', 'operation', 'scope', 'state_p', 'state_n', 'p_versions', 'n_versions',
                   'source_citations', 'non_target_requirements')

    def user_full_text(value, source):
        # 独立重建实际user全文，保留全部文本并移除对象元数据。
        interface = source['shared_execution_interface']
        if isinstance(value, str):
            text = value
        else:
            assert isinstance(value, dict)
            assert set(value).issubset({'version_id', 'system_prompt', 'user_prompt', 'source_task',
                                        'user_prompt_full', 'source_code', 'source_code_status',
                                        'shared_execution_interface'})
            if 'system_prompt' in value:
                assert value['system_prompt'] == source['system_prompt']
            if 'shared_execution_interface' in value:
                assert value['shared_execution_interface'] == interface
            if 'user_prompt' in value or 'user_prompt_full' in value:
                text = value.get('user_prompt', value.get('user_prompt_full'))
                if 'user_prompt' in value and 'user_prompt_full' in value:
                    assert value['user_prompt'] == value['user_prompt_full']
                if 'source_task' in value:
                    assert isinstance(value['source_task'], str) and value['source_task']
                    assert value['source_task'] in text
            else:
                assert {'version_id', 'system_prompt', 'source_task',
                        'shared_execution_interface'}.issubset(value)
                if value.get('source_code'):
                    assert value['source_code'] in value['source_task']
                text = value['source_task'] + '\n\nShared execution interface:\n' + interface
        assert isinstance(text, str) and text.strip() and text.count(interface) == 1
        return text

    available = 0
    for row in mapping:
        key = row['index'], row['flow'], row['position']
        assert row['flow'] in {'TSG', 'Raw'} and row['position'] in (0, 1)
        prefix = 'human-quality' if population == 'development' else 'model-quality-evaluation'
        assert row['blind_id'] == hashlib.sha256(
            (prefix + '-20260929|' + '|'.join(map(str, key))).encode()).hexdigest()
        assert row['task_id'] == hashlib.sha256((prefix + '-task|' + str(row['index'])).encode()).hexdigest()
        assert row['frozen_status'] == slots[key]['status']
        assert row['candidate_id'] == (candidates[key]['candidate_id'] if key in candidates else None)
        assert (slots[key]['status'] == 'qualified') == (key in candidates)
        original = base / 'binding-review-inputs' / f"case-{row['index']:04d}"
        assert manifest(original) == row['original_review_manifest_sha256']
        source_input = load(original / 'input.json')
        original_mapping = load(original / 'mapping.json')
        prepared = [item for item in original_mapping if (item['flow'], item['position']) == key[1:]]
        assert len(prepared) <= 1
        assert row['original_blind_id'] == (prepared[0]['blind_id'] if prepared else None)
        packet = by_id[row['blind_id']]
        assert set(packet) == {'blind_id', 'task_id', 'source', 'policy'}
        assert packet['task_id'] == row['task_id']
        assert packet['source'] == {key: source_input['source'][key] for key in source_keys}
        matches = [policy for policy in source_input['policies'] if policy['blind_id'] == row['original_blind_id']]
        if row['original_blind_id'] is None:
            assert not matches and packet['policy'] is None
            continue
        assert len(matches) == 1
        expected = {key: matches[0][key] for key in policy_keys}
        if population == 'evaluation':
            for side in ('p_versions', 'n_versions'):
                expected[side] = [user_full_text(value, source_input['source'])
                                  for value in matches[0][side]]
        if key in candidates:
            final = candidates[key]
            contract = final['contract']
            normalized = [[user_full_text(value, source_input['source']) for value in matches[0][side]]
                          for side in ('p_versions', 'n_versions')]
            assert [final['p_versions'], final['n_versions']] in (normalized, normalized[::-1])
            expected.update(target=contract['target_proposition'], operation=contract['operation'],
                            scope=contract['scope'], state_p=contract['state_p'], state_n=contract['state_n'],
                            p_versions=final['p_versions'], n_versions=final['n_versions'],
                            non_target_requirements=contract['non_target_requirements'])
        assert packet['policy'] == expected
        for side in ('p_versions', 'n_versions'):
            assert len(packet['policy'][side]) == 2
            assert all(isinstance(text, str) and text.strip() for text in packet['policy'][side])
        available += 1
    template = load(public / 'judgments-template.json')
    assert all(template[key] is None for key in ('reviewer_id', 'independent_from_preparation',
                                                'generated_code_or_outcomes_seen', 'available_time'))
    assert {row['blind_id'] for row in template['judgments']} == set(by_id)
    assert len(template['judgments']) == position_count
    for judgment in template['judgments']:
        assert set(judgment) == {'blind_id', 'source_support', 'atomic_boundary', 'non_target_preservation',
                                  'state_and_version_consistency', 'distinguishable', 'duplicate_of', 'evidence'}
        assert judgment['duplicate_of'] == []
        assert all(value is None for key, value in judgment.items() if key not in {'blind_id', 'duplicate_of'})
    assert protocol['positions'] == position_count
    assert protocol['tasks'] == len({row['task_id'] for row in mapping}) == task_count
    assert protocol['materialized_policies'] == available
    if population == 'development':
        assert available == 46 and len(candidates) == 25
    return dict(status='INDEPENDENT_SOURCE_ONLY_HUMAN_MATERIAL_VERIFIED',
                population=population, positions=position_count, source_tasks=task_count,
                materialized_policies=available, execution_qualified_policies=len(candidates),
                human_judgments=0, public_manifest_sha256=public_sha, private_manifest_sha256=private_sha,
                scientific_scope='Material qualification only; no human quality or low-expectation conclusion.')


def repair_events(path):
    # 保留终止时不完整尾行的字节身份，仅完整事件参与核查。
    lines = path.read_text(encoding='utf-8-sig').splitlines(keepends=True)
    return [json.loads(line) for line in lines if line.endswith('\n')]


def repair_structure(source, prepared, flow):
    errors, graph_errors, valid_units = [], [], {}
    documents = {name: source[name] for name in ('source_prompt', 'system_prompt', 'shared_execution_interface')}
    covered = {name: set() for name in documents}
    coverage = prepared.get('source_coverage', [])
    if not isinstance(coverage, list):
        errors.append('coverage_not_list')
        coverage = []
    identities = Counter(row.get('id') for row in coverage if isinstance(row, dict))
    for position, row in enumerate(coverage):
        if not isinstance(row, dict):
            errors.append(f'coverage:{position}:not_object')
            continue
        identity, name, quote = row.get('id'), row.get('source_document'), row.get('quote')
        if not isinstance(identity, str) or not identity or identities[identity] != 1:
            errors.append(f'coverage:{position}:identity')
            continue
        if name not in documents or not isinstance(quote, str) or not quote:
            errors.append(f'coverage:{identity}:document_or_quote')
            continue
        starts = [offset for offset in range(len(documents[name])) if documents[name].startswith(quote, offset)]
        occurrence = row.get('occurrence')
        if type(occurrence) is not int or occurrence < 0 or occurrence >= len(starts):
            errors.append(f'coverage:{identity}:occurrence')
            continue
        start, end = starts[occurrence], starts[occurrence] + len(quote)
        if (row.get('start'), row.get('end'), row.get('editable')) != (start, end, name == 'source_prompt'):
            errors.append(f'coverage:{identity}:coordinates_or_editability')
            continue
        if not row.get('meaning') or row.get('status') not in {'represented', 'unresolved', 'out_of_declared_scope'}:
            errors.append(f'coverage:{identity}:meaning_or_status')
        valid_units[identity] = row
        covered[name].update(range(start, end))
    coverage_counts = {}
    for name, document in documents.items():
        required = {offset for offset, char in enumerate(document) if not char.isspace()}
        missing = sorted(required - covered[name])
        coverage_counts[name] = dict(non_whitespace=len(required), covered=len(required & covered[name]),
                                     missing=len(missing), first_missing=missing[0] if missing else None)
        if missing:
            errors.append(f'coverage:{name}:missing:{len(missing)}')
    representation = prepared.get('representation', {})
    if not isinstance(representation, dict):
        errors.append('representation_not_object')
        representation = {}
    if representation.get('flow') != flow or any(prepared.get(key) != source[key] for key in ('index', 'task_unit_id')):
        errors.append('preparation_identity')
    graph = representation.get('tsg', {})
    if not isinstance(graph, dict):
        errors.append('graph_not_object')
        graph = {}
    nodes, edges, invalid_items = {}, {}, set()
    if flow == 'Raw' and (graph or prepared.get('tsg')):
        errors.append('raw_contains_graph')
    for kind, rows, registry in [('node', graph.get('nodes', []), nodes), ('edge', graph.get('edges', []), edges)]:
        if not isinstance(rows, list):
            graph_errors.append(f'{kind}:not_list')
            continue
        for position, row in enumerate(rows):
            if not isinstance(row, dict):
                graph_errors.append(f'{kind}:{position}:not_object')
                continue
            identity = row.get('id')
            if not isinstance(identity, str) or not identity or identity in registry:
                graph_errors.append(f'{kind}:{position}:identity')
                invalid_items.add((kind, identity))
                continue
            registry[identity] = row
            refs = row.get('source_unit_ids', [])
            fields = ('type', 'role', 'scope', 'polarity') if kind == 'node' else ('relation', 'scope', 'polarity')
            if not isinstance(refs, list) or not refs or any(ref not in valid_units for ref in refs) or any(not row.get(key) for key in fields):
                graph_errors.append(f'{kind}:{identity}:source_or_fields')
                invalid_items.add((kind, identity))
    for identity in set(nodes) & set(edges):
        graph_errors.append(f'graph:shared_identity:{identity}')
        invalid_items.update({('node', identity), ('edge', identity)})
    for identity, edge in edges.items():
        if edge.get('source') not in nodes or edge.get('target') not in nodes:
            graph_errors.append(f'edge:{identity}:endpoint')
            invalid_items.add(('edge', identity))
    if flow == 'TSG':
        if not nodes:
            errors.append('empty_tsg')
        represented = {ref for node in nodes.values() for ref in node.get('source_unit_ids', [])}
        graph_errors.extend(f'coverage:{identity}:missing_node' for identity, row in valid_units.items()
                            if row.get('status') == 'represented' and identity not in represented)
    candidates = prepared.get('candidates', [])
    if not isinstance(candidates, list):
        errors.append('candidates_not_list')
        candidates = []
    if len(candidates) > 2:
        errors.append('candidate_count_exceeds_two_positions')
    if not candidates and not prepared.get('empty_candidate_reason'):
        errors.append('empty_candidate_reason_missing')
    required_contract = {'target_proposition', 'source_state', 'object_roles', 'state_p', 'state_n',
                         'operation', 'scope', 'non_target_requirements', 'measurement_endpoint',
                         'version_rules', 'cross_task_role_mapping', 'applicable_conditions', 'unknown_conditions'}
    counts = Counter(candidate.get('candidate_id') for candidate in candidates if isinstance(candidate, dict))
    positions = []
    for position in range(2):
        if position >= len(candidates):
            positions.append(dict(position=position, status='empty', errors=[]))
            continue
        candidate, problems = candidates[position], []
        if not isinstance(candidate, dict):
            positions.append(dict(position=position, status='mechanical_errors', errors=['candidate_not_object']))
            continue
        identity = candidate.get('candidate_id')
        if not identity or counts[identity] != 1 or candidate.get('rank') != position + 1:
            problems.append('candidate_identity_or_rank')
        for key in ('target', 'operation', 'state_p', 'state_n', 'roles', 'scope', 'non_target_requirements', 'endpoint'):
            if not candidate.get(key):
                problems.append(f'missing:{key}')
        refs = candidate.get('source_unit_ids', [])
        if not isinstance(refs, list):
            refs = []
        if not refs or any(ref not in valid_units for ref in refs):
            problems.append('candidate_source_reference')
        if not any(valid_units.get(ref, {}).get('editable') for ref in refs):
            problems.append('no_editable_source')
        selected = candidate.get('subgraph', {})
        if not isinstance(selected, dict):
            problems.append('subgraph_not_object')
            selected = {}
        selected_nodes, selected_edges = selected.get('node_ids', []), selected.get('edge_ids', [])
        if not isinstance(selected_nodes, list) or not isinstance(selected_edges, list):
            problems.append('subgraph_ids_not_lists')
            selected_nodes, selected_edges = [], []
        if flow == 'TSG':
            if not selected_nodes or len(set(selected_nodes)) != len(selected_nodes) or len(set(selected_edges)) != len(selected_edges):
                problems.append('selected_graph_identity')
            selected_sources = set()
            for kind, selected_ids, registry in [('node', selected_nodes, nodes), ('edge', selected_edges, edges)]:
                for selected_id in selected_ids:
                    if selected_id not in registry or (kind, selected_id) in invalid_items:
                        problems.append(f'selected_{kind}:{selected_id}:invalid')
                        continue
                    item = registry[selected_id]
                    selected_sources.update(item.get('source_unit_ids', []))
                    if kind == 'edge' and not {item['source'], item['target']}.issubset(selected_nodes):
                        problems.append(f'selected_edge:{selected_id}:incomplete_endpoints')
            if not set(refs).issubset(selected_sources):
                problems.append('candidate_sources_not_covered_by_selected_graph')
            if not candidate.get('support_reason'):
                problems.append('support_reason_missing')
        elif selected_nodes or selected_edges:
            problems.append('raw_candidate_uses_graph')
        versions = []
        for side in ('p_versions', 'n_versions'):
            values = candidate.get(side, [])
            if not isinstance(values, list) or len(values) != 2:
                problems.append(f'{side}:version_count')
                values = []
            for version, value in enumerate(values):
                if not isinstance(value, str) or not value.strip():
                    problems.append(f'{side}:{version}:empty_or_non_string')
                elif value.count(source['shared_execution_interface']) != 1:
                    problems.append(f'{side}:{version}:interface_count')
            versions.append(values)
        if all(isinstance(value, str) for values in versions for value in values) and set(versions[0]) & set(versions[1]):
            problems.append('identical_opposite_states')
        contract = candidate.get('contract', {})
        if not isinstance(contract, dict):
            contract = {}
        if set(contract) != required_contract or any(not contract.get(key) for key in required_contract - {'unknown_conditions'}):
            problems.append('contract_fields')
        if contract.get('operation') != candidate.get('operation'):
            problems.append('contract_operation')
        review = candidate.get('review', prepared.get('review', {}))
        reason = review.get('reason') if isinstance(review, dict) else None
        if not ((isinstance(reason, str) and reason.strip()) or
                (isinstance(reason, dict) and reason and all(isinstance(key, str) and key.strip()
                 and isinstance(value, str) and value.strip() for key, value in reason.items()))):
            problems.append('review_reason_missing')
        positions.append(dict(position=position, candidate_id=identity, operation=candidate.get('operation'),
                              status='mechanically_checked' if not problems else 'mechanical_errors', errors=problems,
                              selected_nodes=len(selected_nodes), selected_edges=len(selected_edges),
                              semantic_status='REQUIRES_INDEPENDENT_REVIEW'))
    return dict(nodes=len(nodes), edges=len(edges), candidates=len(candidates), source_units=len(coverage),
                coverage=coverage_counts, errors=errors, graph_errors=graph_errors, positions=positions,
                operations=dict(Counter(candidate.get('operation', 'unknown') for candidate in candidates if isinstance(candidate, dict))))


def repair_edit_versions(source, versions):
    # 编辑坐标始终来自原始来源；独立复算不使用准备模块的全文生成函数。
    if not isinstance(versions, list) or len(versions) != 2:
        return None
    original = source['source_prompt']
    rendered = []
    for edits in versions:
        if not isinstance(edits, list):
            return None
        replacements = []
        for edit in edits:
            if not isinstance(edit, dict) or set(edit) != {'quote', 'occurrence', 'replacement'}:
                return None
            quote, occurrence, replacement = edit['quote'], edit['occurrence'], edit['replacement']
            if not isinstance(quote, str) or not quote or type(occurrence) is not int or occurrence < 0 or not isinstance(replacement, str):
                return None
            starts = [offset for offset in range(len(original)) if original.startswith(quote, offset)]
            if occurrence >= len(starts):
                return None
            replacements.append((starts[occurrence], starts[occurrence] + len(quote), replacement))
        ordered = sorted(replacements)
        if any(left[1] > right[0] for left, right in zip(ordered, ordered[1:])):
            return None
        text = original
        for start, end, replacement in reversed(ordered):
            text = text[:start] + replacement + text[end:]
        text += '\n\nShared execution interface:\n' + source['shared_execution_interface']
        if not text.strip() or text.count(source['shared_execution_interface']) != 1:
            return None
        rendered.append(text)
    return rendered


def verify_repair_normalization(source, raw, normalized, diagnostic_errors):
    assert {key: value for key, value in raw.items() if key not in {'source_coverage', 'candidates'}} == {
        key: value for key, value in normalized.items() if key not in {'source_coverage', 'candidates'}}
    assert len(raw.get('candidates', [])) == len(normalized.get('candidates', []))
    for before, after in zip(raw.get('candidates', []), normalized.get('candidates', []), strict=True):
        if not isinstance(before, dict) or not any(key in before for key in ('p_edits', 'n_edits')):
            assert before == after
            continue
        assert {key: value for key, value in before.items() if key not in {'p_versions', 'n_versions'}} == {
            key: value for key, value in after.items() if key not in {'p_versions', 'n_versions'}}
        for side in ('p', 'n'):
            edits_key, versions_key = side + '_edits', side + '_versions'
            if edits_key not in before:
                assert before.get(versions_key) == after.get(versions_key)
                continue
            expected = repair_edit_versions(source, before[edits_key])
            if expected is None or versions_key in before:
                assert diagnostic_errors, '无效编辑或重复全文必须记录诊断错误。'
                assert before.get(versions_key) == after.get(versions_key)
            else:
                assert after.get(versions_key) == expected, '编辑生成的全文与独立来源坐标复算不一致。'
    assert len(raw.get('source_coverage', [])) == len(normalized.get('source_coverage', []))
    for before, after in zip(raw.get('source_coverage', []), normalized.get('source_coverage', []), strict=True):
        assert {key: value for key, value in before.items() if key not in {'start', 'end', 'editable', 'occurrence'}} == {
            key: value for key, value in after.items() if key not in {'start', 'end', 'editable', 'occurrence'}}
        if 'occurrence' in before:
            assert before['occurrence'] == after['occurrence']


def verify_preparation_repair(repo, root, indices=None, repair_registration=None):
    fixed = (214, 142, 182, 236, 16, 198, 241, 188, 192, 82, 9, 232, 202, 234, 208, 90, 74, 226)
    targeted = repair_registration is not None
    representative = indices is not None
    assert not (targeted and representative)
    registered = load(repair_registration) if targeted else None
    if targeted:
        assert all(key in registered for key in ('streams', 'preparation_root', 'material_root', 'common_verification_root'))
        assert (repo / registered['preparation_root']).resolve() == root.resolve()
        streams = registered['streams']
        assert isinstance(streams, list) and streams
        expected = {(row['index'], row['flow']) for row in streams}
        assert len(expected) == len(streams)
        registered_streams = {(row['index'], row['flow']): row for row in streams}
        assert all(type(index) is int and flow in {'TSG', 'Raw'} for index, flow in expected)
        indices = tuple(dict.fromkeys(row['index'] for row in streams))
        assert registered.get('positions', 2 * len(streams)) == 2 * len(streams)
        if 'registered_utc' in registered:
            assert datetime.fromisoformat(registered['registered_utc']).tzinfo is not None
    else:
        indices = tuple(indices) if representative else fixed
    assert len(set(indices)) == len(indices) and set(indices).issubset(fixed)
    assert root.is_dir()
    actual = {(int(case.name.removeprefix('case-')), flow.name) for case in root.glob('case-*')
              for flow in case.iterdir() if flow.is_dir()}
    if not targeted:
        expected = ({pair for pair in actual if pair[0] in indices} if representative else
                    {(index, flow) for index in fixed for flow in ('TSG', 'Raw')})
    assert expected and all(flow in {'TSG', 'Raw'} for _, flow in expected)
    assert {index for index, _ in expected} == set(indices)
    if targeted:
        assert actual == expected, '定向修复必须保留登记的全部任务流程。'
    elif not representative:
        assert actual == expected, '主面板必须保留全部18项任务和两个流程。'
    rows, frozen_implementations = [], []
    for index in indices:
        for flow in ('TSG', 'Raw'):
            if (index, flow) not in expected:
                continue
            directory = root / f'case-{index:04d}' / flow
            registration, source = load(directory / 'registration.json'), load(directory / 'source.json')
            if targeted and 'registered_utc' in registered:
                assert datetime.fromisoformat(registration['registered_utc']) >= datetime.fromisoformat(registered['registered_utc'])
            if targeted:
                stream = registered_streams[index, flow]
                prior_path = (repo / stream['prior_preparation_path']).resolve()
                assert prior_path.is_file() and digest(prior_path) == stream['prior_preparation_sha256']
                assert Path(registration['repair_registration_path']).resolve() == repair_registration.resolve()
                assert registration['repair_registration_sha256'] == digest(repair_registration)
                assert Path(registration['prior_preparation_path']).resolve() == prior_path
                assert registration['prior_preparation_sha256'] == digest(prior_path)
                assert registration['completion_encoding'] == 'source_quote_edits'
                prior = load(prior_path)
                repair_targets = [{key: value for key, value in candidate.items() if key in {
                    'candidate_id', 'rank', 'target', 'operation', 'state_p', 'state_n', 'scope', 'non_target_requirements'}}
                    for candidate in prior['candidates']]
                assert isinstance(stream['repair_notes'], list) and all(isinstance(note, str) for note in stream['repair_notes'])
            accounting, diagnostics = load(directory / 'accounting.json'), load(directory / 'diagnostics.json')
            original_path = repo / f'data/method/graph-guided-20260929/preparation-inputs/qualified/case-{index:04d}/input.json'
            assert Path(registration['source_path']).resolve() == original_path.resolve()
            assert digest(original_path) == registration['source_sha256']
            original = load(original_path)
            for key in ('index', 'task_unit_id', 'source_prompt', 'system_prompt', 'shared_execution_interface', 'operations'):
                assert source[key] == original[key]
            assert source['source_documents'] == {name: dict(field=name, editable=name == 'source_prompt')
                for name in ('source_prompt', 'system_prompt', 'shared_execution_interface')}
            assert set(source) == {'index', 'task_unit_id', 'source_prompt', 'system_prompt', 'shared_execution_interface',
                                   'operations', 'source_documents', 'measurement'}
            for key in ('entry_point', 'family', 'scope', 'unknown'):
                assert source['measurement'][key] == original['measurement'][key]
            endpoints = {}
            for channel, program in original['measurement']['tests'].items():
                endpoints[channel] = [dict(field=node.arg, description=node.value.value) for node in ast.walk(ast.parse(program))
                    if isinstance(node, ast.keyword) and node.arg in {'endpoint', 'scope', 'limitation', 'unresolved'}
                    and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str)]
            assert source['measurement']['endpoint_descriptions'] == endpoints
            assert registration['index'] == accounting['index'] == index
            assert registration['flow'] == accounting['flow'] == flow
            assert registration['task_unit_id'] == accounting['task_unit_id'] == source['task_unit_id']
            assert registration['model'] == 'gpt-5.5' and registration['effort'] == 'high'
            assert registration['permitted_requests'] == 2 and registration['actual_total_token_limit'] == 64000
            if not representative or root.name == 'pilot-complete':
                assert registration['wall_seconds_limit'] == 720
            assert registration['wall_seconds_limit'] in {360, 720}
            assert registration['outcomes_visible'] is False and registration['historical_contracts_visible'] is False
            assert accounting['position_retained'] is True
            assert registration['provider_output_token_limit'] == accounting['provider_output_token_limit'] == 'not_enforced_by_provider'
            frozen_implementations.append((registration['instructions_sha256'], registration.get('implementation_sha256')))
            requests = accounting['requests']
            assert 1 <= len(requests) <= 2 and [row['request_number'] for row in requests] == list(range(1, len(requests) + 1))
            assert {path.name for path in directory.glob('request-*.prompt.txt')} == {f'request-{number}.prompt.txt' for number in range(1, len(requests) + 1)}
            total, complete, request_reports = 0, True, []
            for number, record in enumerate(requests, 1):
                prefix = f'request-{number}'
                assert load(directory / f'{prefix}.accounting.json') == record
                prompt_path = directory / f'{prefix}.prompt.txt'
                prompt = prompt_path.read_text(encoding='utf-8')
                assert digest(prompt_path) == record['prompt_sha256']
                payload = json.loads(prompt.split('\n', 1)[1])
                assert payload['phase'] == ('representation' if number == 1 else 'completion')
                assert payload['flow'] == flow and payload['source'] == source
                payload_keys = ({'phase', 'flow', 'source', 'instruction'} if number == 1 else
                                {'phase', 'flow', 'source', 'instruction', 'draft', 'diagnostics'})
                if targeted:
                    payload_keys.update({'repair_targets', 'repair_notes'})
                    assert payload['repair_targets'] == repair_targets
                    assert payload['repair_notes'] == stream['repair_notes']
                assert set(payload) == payload_keys
                if number == 2:
                    first_diagnostics = load(directory / 'request-1.diagnostics.json')
                    draft = first_diagnostics['normalized_preparation'] or dict(unparsed_response=(directory / 'request-1.response.txt').read_text(encoding='utf-8-sig'))
                    assert payload['draft'] == draft
                    assert payload['diagnostics'] == {key: value for key, value in first_diagnostics.items() if key != 'normalized_preparation'}
                events = repair_events(directory / f'{prefix}.events.jsonl')
                completed = [event['usage'] for event in events if event['type'] == 'turn.completed']
                assert len(completed) <= 1
                tools = [event['item']['type'] for event in events if event['type'] in {'item.started', 'item.completed'}
                         and event['item']['type'] not in {'agent_message', 'reasoning', 'error'}]
                assert not tools and not record['tool_calls'], '准备请求不得调用工具。'
                command = load(directory / f'{prefix}.command.json')
                assert command[command.index('--model') + 1] == 'gpt-5.5' and 'model_reasoning_effort="high"' in command
                assert '--ignore-user-config' in command and 'web_search="disabled"' in command
                assert 'model_instructions_file=' + json.dumps(Path(registration['instructions_path']).as_posix()) in command
                assert all('features.' + feature + '=false' in command for feature in registration['tools_configured_disabled'])
                session = []
                if record['session_path']:
                    session_path = Path(record['session_path'])
                    assert digest(session_path) == record['session_sha256']
                    session = repair_events(session_path)
                contexts = [event['payload'] for event in session if event['type'] == 'turn_context']
                assert not [event for event in session if event['type'] == 'response_item'
                            and event['payload'].get('type') in {'function_call', 'custom_tool_call', 'web_search_call', 'computer_call'}]
                delivered = [item['text'] for event in session if event['type'] == 'response_item'
                             and event['payload'].get('role') == 'user' for item in event['payload'].get('content', [])
                             if item.get('text', '').startswith('本实例只执行')]
                model_verified = bool(contexts) and all(context['model'] == 'gpt-5.5' and context['effort'] == 'high' for context in contexts)
                delivered_verified = len(delivered) == 1 and delivered[0].strip() == prompt.strip()
                assert record['actual_model_and_effort_verified'] == model_verified
                assert record['delivered_prompt_verified'] == delivered_verified
                assert record['top_level_requests'] == (len(contexts) if record['thread_id'] else None)
                assert [event['thread_id'] for event in events if event['type'] == 'thread.started'] == ([record['thread_id']] if record['thread_id'] else [])
                usages = [event['payload']['info']['total_token_usage'] for event in session if event['type'] == 'event_msg'
                          and event['payload'].get('type') == 'token_count' and event['payload'].get('info')]
                assert record['usage'] == (usages[-1] if usages else None)
                observed = record['usage']
                if observed:
                    assert observed['input_tokens'] + observed['output_tokens'] == observed['total_tokens']
                    assert 0 <= observed['cached_input_tokens'] <= observed['input_tokens']
                    assert 0 <= observed['reasoning_output_tokens'] <= observed['output_tokens']
                    total += observed['total_tokens']
                if completed:
                    assert observed is not None
                    assert all(completed[0][key] == observed[key] for key in ('input_tokens', 'cached_input_tokens', 'output_tokens', 'reasoning_output_tokens'))
                assert record['complete_usage'] == bool(completed and observed)
                complete = complete and record['complete_usage']
                response_path = directory / f'{prefix}.response.txt'
                messages = [event['item']['text'] for event in events if event['type'] == 'item.completed' and event['item']['type'] == 'agent_message']
                if response_path.is_file():
                    assert messages and response_path.read_text(encoding='utf-8-sig').strip() == messages[-1].strip()
                request_diagnostics = load(directory / f'{prefix}.diagnostics.json')
                normalized = request_diagnostics['normalized_preparation']
                if normalized is not None:
                    raw = json.loads(response_path.read_text(encoding='utf-8-sig'))
                    if targeted and number == 2:
                        assert all(isinstance(candidate, dict)
                                   and {'p_edits', 'n_edits'}.issubset(candidate)
                                   and not {'p_versions', 'n_versions'}.intersection(candidate)
                                   for candidate in raw['candidates']), '本轮完成请求必须使用来源精确编辑。'
                    verify_repair_normalization(source, raw, normalized, request_diagnostics['errors'])
                duration = (datetime.fromisoformat(record['stopped_utc']) - datetime.fromisoformat(record['started_utc'])).total_seconds()
                assert duration >= 0
                request_reports.append(dict(number=number, complete_usage=record['complete_usage'], usage=observed,
                                            duration_seconds=duration, prompt_sha256=digest(prompt_path),
                                            response_sha256=digest(response_path) if response_path.is_file() else None,
                                            events_sha256=digest(directory / f'{prefix}.events.jsonl'),
                                            normalized_available=normalized is not None,
                                            nodes=len((normalized or {}).get('representation', {}).get('tsg', {}).get('nodes', [])),
                                            edges=len((normalized or {}).get('representation', {}).get('tsg', {}).get('edges', [])),
                                            candidates=len((normalized or {}).get('candidates', [])),
                                            recorded_errors=request_diagnostics['errors'],
                                            termination_reason=record['termination_reason']))
            assert diagnostics == load(directory / f'request-{len(requests)}.diagnostics.json')
            assert accounting['observed_total_tokens'] == total and accounting['complete_usage'] == complete
            assert accounting['actual_total_tokens'] == (total if complete else None)
            admission = accounting['second_request_admission']
            if admission is not None:
                assert admission['is_provider_hard_bound'] is False
                assert admission['first_request_actual_total_tokens'] == requests[0]['usage']['total_tokens']
                assert admission['remaining_tokens'] == 64000 - requests[0]['usage']['total_tokens']
                if 'second_input_estimate' in admission:
                    assert admission['second_input_estimate'] == requests[0]['usage']['input_tokens'] + admission['second_prompt_tokens'] - admission['first_prompt_tokens']
                    assert admission['conservative_input_proxy'] == math.ceil(admission['second_input_estimate'] * 1.1) + 2048
                if len(requests) == 2:
                    assert sum(admission[key] for key in ('first_request_actual_total_tokens', 'conservative_input_proxy', 'output_reserve_tokens')) <= 64000
            elapsed = (datetime.fromisoformat(accounting['completed_utc']) - datetime.fromisoformat(registration['registered_utc'])).total_seconds()
            request_elapsed = (datetime.fromisoformat(requests[-1]['stopped_utc']) - datetime.fromisoformat(registration['registered_utc'])).total_seconds()
            assert accounting['registered_utc'] == registration['registered_utc']
            # 执行器在最终文件写入前结束单调计时，completed_utc 包含这些文件的写入时间。
            assert 0 <= request_elapsed <= elapsed
            assert request_elapsed - 1 <= accounting['duration_seconds'] <= elapsed + 1
            if accounting['resource_qualified']:
                assert request_elapsed <= registration['wall_seconds_limit'] + 1
            resource = (len(requests) == 2 and complete and total <= 64000 and accounting['duration_seconds'] <= registration['wall_seconds_limit']
                        and all(record['exit_code'] == 0 and record['top_level_requests'] == 1
                                and record['actual_model_and_effort_verified'] and record['delivered_prompt_verified'] for record in requests))
            assert accounting['resource_qualified'] == resource
            assert accounting['preparation_qualified'] == (accounting['failure_reason'] is None)
            assert accounting['preparation_qualified'] == (resource and not diagnostics['errors']
                and all(record['termination_reason'] is None for record in requests))
            final_path = directory / 'final.json'
            assert final_path.is_file() == (len(requests) == 2 and diagnostics['normalized_preparation'] is not None)
            if final_path.is_file():
                final = load(final_path)
                assert final == diagnostics['normalized_preparation']
                structure = repair_structure(source, final, flow)
            else:
                structure = dict(nodes=0, edges=0, candidates=0, source_units=0, coverage={}, errors=['NO_FINAL_PREPARATION'],
                                 graph_errors=[], operations={}, positions=[dict(position=position, status='preparation_failed', errors=[]) for position in range(2)])
            rows.append(dict(index=index, flow=flow, task_unit_id=source['task_unit_id'], source_sha256=registration['source_sha256'],
                             registration_sha256=digest(directory / 'registration.json'), final_sha256=digest(final_path) if final_path.is_file() else None,
                             final_available=final_path.is_file(),
                             resource_qualified=resource, recorded_preparation_qualified=accounting['preparation_qualified'],
                             failure_reason=accounting['failure_reason'], recorded_errors=diagnostics['errors'],
                             recorded_graph_diagnostics=diagnostics['graph_diagnostics'], requests=request_reports,
                             actual_total_tokens=total if complete else None, observed_total_tokens=total,
                             duration_seconds=accounting['duration_seconds'],
                             request_finished_elapsed_seconds=request_elapsed,
                             artifact_finalized_elapsed_seconds=elapsed, **structure))
    if not representative:
        assert all(value == frozen_implementations[0] for value in frozen_implementations)
        assert frozen_implementations[0][1], '主面板必须登记准备实现身份。'
    by_flow = {}
    for flow in ('TSG', 'Raw'):
        selected = [row for row in rows if row['flow'] == flow]
        operations = Counter()
        for row in selected:
            operations.update(row['operations'])
        by_flow[flow] = dict(streams=len(selected), positions=2 * len(selected), requests=sum(len(row['requests']) for row in selected),
            nodes=sum(row['nodes'] for row in selected), edges=sum(row['edges'] for row in selected),
            candidates=sum(row['candidates'] for row in selected), zero_candidate_streams=sum(row['final_available'] and not row['candidates'] for row in selected),
            missing_final_streams=sum(not row['final_available'] for row in selected),
            empty_graph_streams=sum(row['final_available'] and not row['nodes'] for row in selected) if flow == 'TSG' else None,
            resource_qualified=sum(row['resource_qualified'] for row in selected),
            recorded_preparation_qualified=sum(row['recorded_preparation_qualified'] for row in selected),
            streams_with_mechanical_errors=sum(bool(row['errors'] or row['graph_errors'] or any(position['errors'] for position in row['positions'])) for row in selected),
            operations=dict(operations), observed_total_tokens=sum(row['observed_total_tokens'] for row in selected),
            incomplete_usage_streams=sum(row['actual_total_tokens'] is None for row in selected),
            duration_seconds=sum(row['duration_seconds'] for row in selected))
    return dict(status='INDEPENDENT_PREPARATION_ARTIFACT_IDENTITIES_AND_ACCOUNTING_VERIFIED',
                scope='REGISTERED_TARGETED_DEVELOPMENT_REPAIR' if targeted else ('REPRESENTATIVE_DEVELOPMENT' if representative else 'FIXED_18_TASK_DEVELOPMENT_PANEL'),
                tasks=len(indices), streams=len(rows), positions=2 * len(rows),
                fixed_main_positions=72 if not targeted else None,
                repair_registration_sha256=digest(repair_registration) if targeted else None,
                registered_positions=2 * len(expected) if targeted else None,
                indices=list(indices), by_flow=by_flow, records=rows, model_calls=0,
                semantic_status='REQUIRES_INDEPENDENT_REVIEW',
                scientific_scope='Mechanical source, structure and resource checks only; no code outcomes or semantic correctness claims.')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, default=Path('.'))
    parser.add_argument('--adapter', type=Path, default=Path('results/graph-guided-20260929/outcome-assembly-qualified-sources'))
    parser.add_argument('--tables', type=Path)
    parser.add_argument('--service-inputs', type=Path)
    parser.add_argument('--service-results', type=Path)
    parser.add_argument('--service-adapter', type=Path)
    parser.add_argument('--panel-role', choices=('development', 'evaluation'))
    parser.add_argument('--panel-inputs', type=Path)
    parser.add_argument('--panel-results', type=Path)
    parser.add_argument('--panel-adapter', type=Path)
    parser.add_argument('--binding', type=Path, action='append', default=[])
    parser.add_argument('--development-freeze', type=Path)
    parser.add_argument('--development-analysis', type=Path)
    parser.add_argument('--evaluation-freeze', type=Path)
    parser.add_argument('--evaluation-output', type=Path)
    parser.add_argument('--human-quality-material', type=Path)
    parser.add_argument('--preparation-repair', type=Path)
    parser.add_argument('--repair-indices', type=int, nargs='+')
    parser.add_argument('--repair-registration', type=Path)
    parser.add_argument('--targeted-generation-preparation', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    arguments = parser.parse_args()
    if arguments.targeted_generation_preparation:
        assert not arguments.preparation_repair and not arguments.repair_registration
        assert bool(arguments.panel_inputs) == bool(arguments.panel_results) == bool(arguments.panel_adapter)
        assert arguments.panel_role in {None, 'development'}
        repo, preparation = arguments.repo.resolve(), arguments.targeted_generation_preparation.resolve()
        report = verify_targeted_generation_preparation(repo, preparation)
        if arguments.panel_inputs:
            initial_state = load(repo / 'data/method/graph-guided-20260929/evaluation-preparation/randomization-state.json')
            report['generation'] = verify_service(repo, arguments.panel_inputs.resolve(),
                arguments.panel_results.resolve(), arguments.panel_adapter.resolve(), 'development', preparation, initial_state)
            report['effects'] = verify_targeted_generation_effects(preparation, arguments.panel_inputs.resolve(),
                arguments.panel_results.resolve(), arguments.panel_adapter.resolve())
            report['model_calls'] = report['generation']['model_calls']
            report['status'] = 'INDEPENDENT_TARGETED_GENERATION_AND_EFFECTS_VERIFIED'
        report['verifier_sha256'] = digest(Path(__file__))
        write_bundle(arguments.output, {'verification.json': report})
        print(json.dumps({key: report[key] for key in ('status', 'tasks', 'policies', 'positions', 'requests', 'model_calls')}))
        return
    assert arguments.preparation_repair or not arguments.repair_indices
    assert not (arguments.repair_registration and arguments.repair_indices)
    if arguments.preparation_repair or arguments.repair_registration:
        repo = arguments.repo.resolve()
        registered_path = arguments.repair_registration.resolve() if arguments.repair_registration else None
        registered_root = (repo / load(registered_path)['preparation_root']).resolve() if registered_path else None
        if arguments.preparation_repair and registered_root:
            assert arguments.preparation_repair.resolve() == registered_root
        root = registered_root or arguments.preparation_repair.resolve()
        report = verify_preparation_repair(repo, root, arguments.repair_indices, registered_path)
        report['verifier_sha256'] = digest(Path(__file__))
        write_bundle(arguments.output, {'verification.json': report})
        print(json.dumps({key: report[key] for key in ('status', 'tasks', 'streams', 'positions', 'by_flow')}, ensure_ascii=False))
        return
    report = verify_qualification(arguments.repo.resolve(), arguments.adapter.resolve())
    if arguments.tables:
        report['table_intervals'] = verify_tables(arguments.tables.resolve())
    else:
        report['table_status'] = 'NOT_EXECUTED_NO_F1_RESULTS'
    assert abs(interval([1] * 26, (-1, 1), .01)[0] - .5065374896513102) < 1e-12
    assert interval([], (-1, 1), .01) == (-1., 1.)
    report.update(verifier_sha256=digest(Path(__file__)), model_calls=0,
                  human_evaluation='PENDING_INDEPENDENT_REVIEW')
    assert bool(arguments.service_inputs) == bool(arguments.service_results) == bool(arguments.service_adapter)
    if arguments.service_inputs:
        report['service'] = verify_service(arguments.repo.resolve(), arguments.service_inputs.resolve(), arguments.service_results.resolve(), arguments.service_adapter.resolve())
        report['model_calls'] = report['service']['model_calls']
    assert bool(arguments.panel_role) == bool(arguments.panel_inputs) == bool(arguments.panel_results) == bool(arguments.panel_adapter)
    if arguments.panel_role:
        report['panel'] = verify_service(arguments.repo.resolve(), arguments.panel_inputs.resolve(),
            arguments.panel_results.resolve(), arguments.panel_adapter.resolve(), arguments.panel_role)
        report['model_calls'] += report['panel']['model_calls']
    if arguments.binding:
        report['preparation'] = verify_preparation(arguments.repo.resolve(), [path.resolve() for path in arguments.binding])
    if arguments.development_freeze:
        report['development_freeze'] = verify_development_freeze(arguments.repo.resolve(), arguments.development_freeze.resolve())
    if arguments.development_analysis:
        report['development_analysis'] = verify_learning(arguments.repo.resolve(), arguments.development_analysis.resolve())
    if arguments.evaluation_freeze:
        report['evaluation_freeze'] = verify_evaluation_freeze(arguments.repo.resolve(), arguments.evaluation_freeze.resolve())
    if arguments.evaluation_output:
        report['evaluation_output'] = verify_evaluation_outputs(arguments.repo.resolve(), arguments.evaluation_output.resolve())
    if arguments.human_quality_material:
        report['human_quality_material'] = verify_human_quality_material(arguments.repo.resolve(), arguments.human_quality_material.resolve())
    write_bundle(arguments.output, {'verification.json': report})
    print(json.dumps({key: report[key] for key in ('status', 'controls', 'qualified_endpoints', 'table_status', 'model_calls') if key in report}))


if __name__ == '__main__':
    main()
