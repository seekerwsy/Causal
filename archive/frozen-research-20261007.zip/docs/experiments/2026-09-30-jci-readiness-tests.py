import itertools
import importlib.util
from pathlib import Path
from fractions import Fraction

import numpy as np
from scipy.stats import chi2_contingency

from prompt_mechanism_study.artifact_io import read_json, verify_bundle
from prompt_mechanism_study.development.graph_guided_decisions import TaskEqualRidge, fit_task_equal_ridge
from prompt_mechanism_study.development.jci_ridge import (
    DiscreteCI, LABELS, PromptFCI, ancestors_y, evaluation_budget, make_scm_tasks,
    mixed_training_requests, population_joint, select_policy, structure_rows,
    state_coverage, comparison_coefficients,
)


def test_ancestor_priority_applies_to_removal_and_addition():
    candidates = [dict(policy_hash='remove', changed_states={'X_ex': -1}),
                  dict(policy_hash='cue', changed_states={'X_cue': 1})]
    assert select_policy(candidates, [.1, .3], {'X_ex': 1.})['action'] == 'remove'
    assert select_policy(candidates, [.1, .3], {'X_cue': 1.})['action'] == 'cue'


def test_actual_review_states_and_nonqualified_slots():
    root = Path('data/method/jci-ridge-20260930/reviewed-twenty-seven')
    verify_bundle(root)
    records = {row['case_id']: row for row in read_json(root / 'records.json')}
    for identity in ('J015', 'J037', 'J055'):
        row = records[identity]
        assert row['source_states'] == [0, 0, 0]
        assert row['policies'][0]['features'][:6] == [0, 0, 0, 0, 1, 0]
    for identity in ('J040', 'J059', 'J024'):
        row = records[identity]
        assert row['semantic_review_status'] == 'UNQUALIFIED'
        assert row['slot_prompt_hashes'] == [row['baseline_hash']] * 3
        assert not any(policy['semantic_qualified'] for policy in row['policies'])
    assert records['J008']['slot_states'] == [[0, 0, 0], [0, 0, 0], [0, 0, 1]]
    assert records['J061']['policies'][0]['changed_states'] == {'X_ex': -1}


def test_source_identity_and_protection():
    root = Path('data/method/jci-ridge-20260930')
    verify_bundle(root/'source-check')
    source = read_json(root/'source-check/source-records.json')
    manual = read_json(root/'manual-source-review.json')
    assert len(source) == len(manual['rows']) == 67
    assert {row['case_id'] for row in source} == {row[0] for row in manual['rows']}
    assert len({row['task_unit_id'] for row in source}) == 67
    assert sum(row[1] == 'POTENTIAL_DATA_BOUNDARY' for row in manual['rows']) == 39
    assert manual['source_state_positive_cases']['X_role'] == []


def test_exact_scm_queries_and_ancestor_truth():
    results = read_json(Path('results/jci-ridge-20260930/population-qualified/population-searches.json'))
    truth = {'direct': {'X1', 'X2'}, 'latent': {'X2'}, 'uncovered': {'X1'}, 'null': set()}
    for result in results:
        assert set(result['ancestors_y'])-{'C'} <= truth[result['mechanism']]
    for mechanism in truth:
        ci = DiscreteCI(mechanism, LABELS, joint=population_joint(mechanism))
        assert ci.query('C', 'X3', [])['independent']
        assert not ci.query('C', 'X1', [])['independent']
        if mechanism == 'direct':
            assert ci.query('C', 'Y', ['X1', 'X2'])['independent']
        if mechanism == 'null':
            assert ci.query('C', 'Y', [])['independent']
    assert ancestors_y([['X1', 'TAIL', 'ARROW', 'X2'], ['X2', 'TAIL', 'ARROW', 'Y'],
                        ['X3', 'CIRCLE', 'ARROW', 'Y']]) == ['X1', 'X2']


def test_three_level_conditional_test_and_degenerate_strata():
    cells = np.array([[18, 2], [10, 10], [2, 18]])
    rows = [[x, y, x] for x, y in itertools.product(range(3), range(2)) for _ in range(cells[x, y])]
    ci = DiscreteCI('three-level-boundary', ('C', 'Y', 'D'), rows=rows)
    result = ci.query('C', 'Y', [])
    assert abs(result['statistic']-chi2_contingency(cells, correction=False).statistic) < 1e-12
    assert result == ci.query('Y', 'C', [])
    assert result == DiscreteCI('three-level-boundary', ('C', 'Y', 'D'), rows=rows).query('Y', 'C', [])
    assert result['p_value'] < .001
    assert ci.query('C', 'Y', ['D'])['status'] == 'statistically_undetermined'
    fixed = DiscreteCI('invariant-pearson', ('C', 'Y'), rows=[[0, 0], [1, 1], [2, 1]])
    assert fixed.query('C', 'Y', [])['status'] == 'statistically_undetermined'


def test_task_potential_states_and_independent_row_assembly():
    for mechanism in ('direct', 'latent', 'uncovered', 'null'):
        states, probabilities, outcomes = make_scm_tasks(mechanism, 512, 0)
        assert states.shape == (512, 3, 3) and outcomes.shape == (512, 3, 4)
        assert np.array_equal(states[:, 0, 2], states[:, 1, 2])
        assert np.array_equal(states[:, 0, 2], states[:, 2, 2])
        assert np.array_equal(states[:, 0, 1], states[:, 1, 1])
        assert np.array_equal(states[:, 0, 0], states[:, 2, 0])
        if mechanism == 'null':
            assert np.all(probabilities == probabilities[:, :1])
        if mechanism == 'latent':
            assert np.all(probabilities[:, 0] == probabilities[:, 1])
        rows = structure_rows(states, outcomes, mechanism, 0)
        assert rows.shape == (512, 5)
        assert np.array_equal(rows, structure_rows(states, outcomes, mechanism, 0))
        assert not np.array_equal(rows, structure_rows(states, outcomes, mechanism, 1))


def policy_rows():
    return [dict(task_unit_id=f't{i}', features=[i % 2, i / 11, None], delta_pn=(i % 2)*.4-.1)
            for i in range(12)]


def test_normalized_objective_and_task_candidate_duplication():
    rows = policy_rows()
    model = TaskEqualRidge(('discrete', 'continuous', 'continuous'), .1).fit(rows)
    design = np.column_stack((np.ones(len(rows)), model.transform(rows)))
    y = np.asarray([row['delta_pn'] for row in rows])
    regularizer = np.diag([0., .1, .1])
    assert np.max(abs(design.T@(design@model.coefficients-y)/12+regularizer@model.coefficients)) < 1e-12
    duplicated = rows + [rows[0]]*3
    other = TaskEqualRidge(('discrete', 'continuous', 'continuous'), .1).fit(duplicated)
    assert np.allclose(model.coefficients, other.coefficients, rtol=0, atol=1e-12)
    assert model.retained == [True, True, False]


def test_fold_only_support_and_intercept():
    rows = policy_rows()
    learner, folds = fit_task_equal_ridge(rows, ('discrete', 'continuous', 'continuous'))
    assert len(folds) == 4 and all(len(row['folds']) == 12 for row in folds)
    assert len(learner.tasks) == 12
    constant = [dict(row, delta_pn=.3, features=[None]) for row in rows]
    intercept = TaskEqualRidge(('continuous',), 10).fit(constant)
    assert np.allclose(intercept.predict(constant), .3)
    rare = [dict(row, features=[int(i < 4)]) for i, row in enumerate(rows)]
    model = TaskEqualRidge(('discrete',), .1).fit(rare[1:])
    assert model.allowed == [[0.]] and model.retained == [False]


def test_shared_time_chain_and_saturated_identification():
    labels = ('C', 'X', 'Y')
    chain, saturated_causal, saturated_latent = [], [], []
    for c, x, y in itertools.product(range(2), repeat=3):
        px = Fraction(1, 5)+Fraction(c, 2)
        py_chain = Fraction(1, 5)+Fraction(x, 2)
        py_direct = Fraction(1, 10)+Fraction(x, 3)+Fraction(c, 4)
        base = Fraction(1, 2)*(px if x else 1-px)
        chain.append(((c, x, y), base*(py_chain if y else 1-py_chain)))
        saturated_causal.append(((c, x, y), base*(py_direct if y else 1-py_direct)))
        mass = Fraction(0)
        for u in range(2):
            pu_x = Fraction(1, 10)+Fraction(c, 3)+Fraction(u, 4)
            pu_y = Fraction(1, 10)+Fraction(c, 4)+Fraction(u, 3)
            mass += Fraction(1, 4)*(pu_x if x else 1-pu_x)*(pu_y if y else 1-pu_y)
        saturated_latent.append(((c, x, y), mass))
    null_ancestor = DiscreteCI('saturated-latent', labels, joint=saturated_latent)
    true_ancestor = DiscreteCI('saturated-causal', labels, joint=saturated_causal)
    for x, y in itertools.combinations(labels, 2):
        third = next(label for label in labels if label not in (x, y))
        for conditions in ([], [third]):
            assert not null_ancestor.query(x, y, conditions)['independent']
            assert not true_ancestor.query(x, y, conditions)['independent']
    output = Path('.codex-runtime/jci-readiness')
    output.mkdir(parents=True, exist_ok=True)
    with (output/'r-query.log').open('w', encoding='utf-8') as stderr:
        worker = PromptFCI(stderr)
        for mode in ('1', '12'):
            assert 'X' in worker.search(DiscreteCI('chain', labels, joint=chain), mode)['ancestors_y']
            assert 'X' not in worker.search(null_ancestor, mode)['ancestors_y']
            assert 'X' not in worker.search(true_ancestor, mode)['ancestors_y']
        worker.close()


def test_mixture_cancellation_keeps_task_effect():
    joint = []
    task_effects = []
    for c, x, y in itertools.product(range(2), repeat=3):
        p = Fraction(1, 5)+Fraction(3*x, 5)
        joint.append(((c, x, y), Fraction(1, 4)*(p if y else 1-p)))
    for source in (0, 1):
        task_effects.append((.2+.6*(1-source))-(.2+.6*source))
    ci = DiscreteCI('cancellation', ('C', 'X', 'Y'), joint=joint)
    assert ci.query('C', 'X', [])['independent']
    assert ci.query('C', 'Y', [])['independent']
    assert np.allclose(task_effects, [.6, -.6])


def test_true_ancestor_priority_can_lose_policy_value():
    candidates = [dict(policy_hash='small', changed_states={'X': 1}),
                  dict(policy_hash='large', changed_states={'X': 0})]
    assert select_policy(candidates, [.02, .30])['action'] == 'large'
    assert select_policy(candidates, [.02, .30], {'X': 1.})['action'] == 'small'
    assert select_policy(candidates, [.02, .30], {})['action'] == 'large'
    assert select_policy(candidates, [0., 0.], {'X': 1.})['action'] == 'B'


def test_real_random_mixture_keeps_slots_and_fresh_generations():
    tasks = [dict(task_unit_id=f't{i}', slot_prompt_hashes=[f'b{i}', f'b{i}', f'e{i}'])
             for i in range(8)]
    requests = mixed_training_requests(tasks, 'readiness-mixed-training')
    assert requests == mixed_training_requests(tasks, 'readiness-mixed-training')
    assert len(requests) == 2*16+6*8
    assert len({row['request_id'] for row in requests}) == len(requests)
    assert len({row['seed'] for row in requests}) == len(requests)
    mixed = [row for row in requests if row['component'] == 'random_mixture']
    assert len(mixed) == 48
    by_task = {task['task_unit_id']: task for task in tasks}
    for row in mixed:
        assert row['context'] in (0, 1, 2)
        assert row['prompt_hash'] == by_task[row['task_unit_id']]['slot_prompt_hashes'][row['context']]
    assert evaluation_budget(24, 12, 72, 36, True) == dict(
        training_calls=288, evaluation_repeats=29, total_calls=1332)
    assert evaluation_budget(24, 12, 72, 36, False)['evaluation_repeats'] == 8


def test_frozen_real_panel_assignment_and_review_binding():
    root = Path('data/method/jci-ridge-20260930/experiment-qualified-inputs')
    verify_bundle(root)
    tasks = read_json(root/'tasks.json')
    training = [row for row in tasks if row['role'] == 'training']
    evaluation = [row for row in tasks if row['role'] == 'evaluation']
    assert (len(training), len(evaluation)) == (16, 8)
    exposure = read_json(root/'exposure.json')
    exposed = {row['task_unit_id'] for row in exposure if row['prior_method_result_exposed']}
    assert exposed <= {row['task_unit_id'] for row in training}
    frozen = read_json(root/'training-requests.json')
    assert frozen == mixed_training_requests(training, 'jci-ridge-20260930-training')
    mixture = {row['request_id'] for row in frozen if row['component'] == 'random_mixture'}
    assert len(frozen) == 176 and len(mixture) == 96
    samples = read_json(root/'structure-subsamples.json')
    assert len(samples) == 100
    assert all(len(sample['request_ids']) == 76 and len(set(sample['request_ids'])) == 76
               and set(sample['request_ids']) <= mixture for sample in samples)
    retained, coverage = state_coverage(training)
    assert retained == ['X_ex', 'X_cue', 'X_local']
    assert all(min(row['distinct_task_support'].values()) >= 4 for row in coverage)
    process = next(row for row in tasks if row['case_id'] == 'J011')
    assert process['slot_states'][0] == process['slot_states'][1]
    assert process['slot_prompt_hashes'][0] != process['slot_prompt_hashes'][1]
    assert not process['policies'][0]['changed_states']


def test_shared_request_coefficients_cancel_and_keep_opposite_directions():
    same = dict(action='edit', direction=1)
    decisions = [dict(case_id='c', task_unit_id='t', baseline_hash='base',
                      selected={'J':same, 'R':same})]
    assert comparison_coefficients(decisions, 'R')[0]['coefficients'] == {}
    decisions[0]['selected']['R'] = dict(action='other', direction=-1)
    coefficients = comparison_coefficients(decisions, 'R')[0]['coefficients']
    assert coefficients == {'edit':1, 'other':1, 'base':-2}
    assert sum(value**2 for value in coefficients.values()) == 6
    decisions[0]['selected']['R'] = dict(action='edit', direction=-1)
    coefficients = comparison_coefficients(decisions, 'R')[0]['coefficients']
    assert coefficients == {'edit':2, 'base':-2}
    assert sum(value**2 for value in coefficients.values()) == 8


def test_independent_ci_replay_on_frozen_finite_checks():
    path = Path('docs/experiments/2026-09-30-jci-result-verifier.py')
    specification = importlib.util.spec_from_file_location('independent_jci_verifier', path)
    verifier = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(verifier)
    root = Path('results/jci-ridge-20260930/finite-qualified')
    for mechanism in ('direct', 'latent', 'uncovered', 'null'):
        rows = read_json(root / f'{mechanism}-rows.json')
        queries = read_json(root / f'{mechanism}-queries.json')
        current = DiscreteCI(f'finite-readiness-{mechanism}', LABELS, rows=rows)
        for query in queries.values():
            result = current.query(query['x'], query['y'], query['conditioned'])
            verifier.verify_ci(f'finite-readiness-{mechanism}', LABELS, rows, result)
            assert result['p_value'] == query['p_value']


def test_independent_actual_request_and_unknown_accounting():
    path = Path('docs/experiments/2026-09-30-jci-result-verifier.py')
    specification = importlib.util.spec_from_file_location('independent_request_verifier', path)
    verifier = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(verifier)
    inputs = Path('data/method/jci-ridge-20260930/experiment-qualified-inputs')
    tasks = {row['task_unit_id']: row for row in read_json(inputs/'tasks.json')}
    requests = read_json(inputs/'training-requests.json')
    selected = {'jci-ridge-20260930-training-'+suffix for suffix in ('00134', '00050', '00064', '00054')}
    rows = [row for row in requests if row['request_id'] in selected]
    outcomes, tokens = verifier.verify_requests(rows, tasks, Path('results/jci-ridge-20260930/training'))
    assert len(outcomes) == 4 and sum(outcomes.values()) == 1 and tokens > 0
