"""Post-outcome support/action replay on the fixed author-contract panel.

The view mapping was specified after outcomes were visible. It is diagnostic,
not a prospective TSG-value test or an independent natural-task holdout.
"""

import json
import sys
from collections import defaultdict
from pathlib import Path


ARMS = ('N', 'P', 'H')
VIEWS = ('surface', 'operation', 'operation_plus_instance_count')


def key(task, view):
    if view == 'surface':
        return ('author_controlled',)
    if view == 'operation':
        return (task['block'],)
    if view == 'operation_plus_instance_count':
        return (task['block'], 2 if task['id'][-2:] in ('A3', 'B3', 'C3', 'D3') else 1)
    raise ValueError(view)


def main(root, verify=False, ceiling=False):
    frozen = root / 'data/method/day-research-20260926/frozen/file-contract'
    output = root / 'results/day-research-20260926/file-contract'
    tasks = json.loads((frozen / 'tasks_json').read_text(encoding='utf-8'))
    rows = json.loads((output / 'summary/results.json').read_text(encoding='utf-8'))
    assert len(tasks) == 12 and len(rows) == 144 and all(r['status'] == 'returned' for r in rows)
    collected = defaultdict(lambda: defaultdict(list))
    for r in rows:
        if r['arm'] not in ARMS:
            continue
        m = r['measurement']
        assert m['status'] == 'measured'
        collected[r['task_unit_id']][r['arm']].append((r['version'], m['secure_yield'], m['contract_joint']))
    yields = {}
    for task in tasks:
        arm_values = {}
        for arm in ARMS:
            draws = sorted(collected[task['id']][arm])
            assert [v for v, _, _ in draws] == [0, 1]
            arm_values[arm] = {'secure_yield': sum(x[1] for x in draws) / 2,
                               'contract_joint': sum(x[2] for x in draws) / 2}
        yields[task['id']] = arm_values
    decisions = []
    for task in tasks:
        for view in VIEWS:
            training = [other for other in tasks if other['id'] != task['id'] and key(other, view) == key(task, view)]
            if len(training) < 2:
                action = 'N'; reason = 'insufficient_support'; means = None
            else:
                means = {arm: sum(yields[other['id']][arm]['secure_yield'] for other in training) / len(training)
                         for arm in ARMS}
                candidate = max(ARMS, key=lambda arm: (means[arm], -ARMS.index(arm)))
                action = candidate if candidate != 'N' and means[candidate] - means['N'] > .05 else 'N'
                reason = 'trained_action'
            decisions.append({'task': task['id'], 'name': task['name'], 'view': view,
                              'attributes': key(task, view), 'support': len(training),
                              'action': action, 'reason': reason,
                              'training_secure_means': means,
                              'observed_secure_yield': yields[task['id']][action]['secure_yield'],
                              'observed_contract_joint': yields[task['id']][action]['contract_joint']})
    summaries = {}
    for view in VIEWS:
        d = [x for x in decisions if x['view'] == view]
        summaries[view] = {'unsupported': sum(x['reason'] == 'insufficient_support' for x in d),
                           'edited': sum(x['action'] != 'N' for x in d),
                           'mean_secure_yield': sum(x['observed_secure_yield'] for x in d) / 12,
                           'mean_contract_joint': sum(x['observed_contract_joint'] for x in d) / 12}
    baselines = {arm: {'mean_secure_yield': sum(yields[t['id']][arm]['secure_yield'] for t in tasks) / 12,
                       'mean_contract_joint': sum(yields[t['id']][arm]['contract_joint'] for t in tasks) / 12}
                 for arm in ARMS}
    report = {'status': 'POST_OUTCOME_TSG_SUPPORT_REPLAY_ONLY',
              'task_count': 12, 'policy_family_count': 1,
              'consumer': 'Old fixed threshold: >=2 matching other tasks; choose best N/P/H secure yield only if gain over N >5pp; otherwise N.',
              'feature_exposure': 'Views and instance-count mapping chosen after the panel outcomes were known; leave-one-task-out does not remove researcher leakage or family dependence.',
              'feature_semantics': 'Instance count is from authored source contracts (A3/B3/C3/D3 have two private instances), not the old ambiguous command target_count.',
              'summaries': summaries, 'always_arm_reference': baselines, 'decisions': decisions,
              'prohibition': 'Do not call this prospective TSG superiority, a Graph-vs-text contrast, context-modifier inference, or natural-task generalization.'}
    if ceiling:
        best = []
        for task in tasks:
            values = yields[task['id']]
            top = max(values[arm]['secure_yield'] for arm in ARMS)
            best.append({'task': task['id'], 'name': task['name'],
                         'secure_yield': top,
                         'tied_best_arms': [arm for arm in ARMS if values[arm]['secure_yield'] == top]})
        hindsight = sum(row['secure_yield'] for row in best) / len(best)
        best_constant = max(baselines[arm]['mean_secure_yield'] for arm in ARMS)
        ceiling_report = {
            'status': 'POST_OUTCOME_FINITE_PANEL_HINDSIGHT_CEILING_ONLY',
            'task_count': len(tasks), 'policy_family_count': 1,
            'endpoint': 'frozen_observer_secure_yield',
            'policy_pool': list(ARMS), 'task_equal_weighting': True,
            'hindsight_best_per_task': hindsight,
            'best_constant_arm': [arm for arm in ARMS if baselines[arm]['mean_secure_yield'] == best_constant],
            'best_constant_yield': best_constant,
            'observed_hindsight_gap': hindsight - best_constant,
            'rows': best,
            'interpretation': 'Optimistic in-sample upper bound among N/P/H on the same two observed versions per task; outcomes choose the arm. Not an estimand for future code, an independent test, or a TSG advantage.'}
        ceiling_path = output / 'tsg-hindsight-ceiling.json'
        if verify:
            assert json.loads(ceiling_path.read_text(encoding='utf-8')) == json.loads(json.dumps(ceiling_report))
        else:
            assert not ceiling_path.exists()
            ceiling_path.write_text(json.dumps(ceiling_report, indent=2), encoding='utf-8')
        print(json.dumps({key: ceiling_report[key] for key in
                          ('hindsight_best_per_task', 'best_constant_arm', 'best_constant_yield',
                           'observed_hindsight_gap')}, indent=2))
        return
    path = output / 'tsg-support-replay.json'
    if verify:
        assert json.loads(path.read_text(encoding='utf-8')) == json.loads(json.dumps(report))
    else:
        assert not path.exists()
        path.write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps({'summaries': summaries, 'always_arm_reference': baselines}, indent=2))


if __name__ == '__main__':
    if sys.argv[1] == 'verify-ceiling': main(Path(sys.argv[2]), verify=True, ceiling=True)
    elif sys.argv[1] == 'ceiling': main(Path(sys.argv[2]), ceiling=True)
    elif sys.argv[1] == 'verify': main(Path(sys.argv[2]), verify=True)
    else: main(Path(sys.argv[1]))
