from collections import Counter
from pathlib import Path

from prompt_mechanism_study.artifact_io import read_json, verify_bundle


def verify(repo):
    root = repo / 'data/method/graph-guided-20260929'
    results = repo / 'results/graph-guided-20260929'
    current = repo / 'results/graph-guided-20260930/training-uniform-measurement'
    remeasurement = repo / 'results/graph-guided-20260930/measurement/verified'
    verify_bundle(current)
    verify_bundle(remeasurement)
    outcomes = read_json(current / 'outcomes.json')
    effects = read_json(current / 'effects.json')
    revised = {(row['batch'], row['slot']): row for row in read_json(remeasurement / 'rows.json')}
    assert len(revised) == 148
    outcome_by_batch = {(row['batch'], row['request_id']): row for row in outcomes}
    effect_by_batch = {(row['batch'], row['candidate_id']): row for row in effects}
    assert len(outcome_by_batch) == len(outcomes) == 744
    assert len(effect_by_batch) == len(effects) == 71
    names = {'development-preparation': ('development-main', 'dev-main'),
             'evaluation-preparation': ('evaluation-main', 'eval-main'),
             'targeted-generation-preparation': ('targeted-generation-main', 'targeted-gen')}
    checked_revised = set()
    for batch, (result_name, revised_name) in names.items():
        inputs = root / batch
        verify_bundle(inputs)
        assignments = read_json(inputs / 'assignments.json')
        bindings = read_json(inputs / 'bindings.json')
        candidates = read_json(inputs / 'candidates.json')
        assert len({row['request_id'] for row in assignments}) == len(assignments)
        for assignment in assignments:
            request_id = assignment['request_id']
            record = outcome_by_batch[batch, request_id]
            assert record['slot'] == assignment['slot']
            assert record['task_unit_id'] == assignment['task_unit_id']
            key = (revised_name, assignment['slot'])
            if key in revised:
                observation = revised[key]
                assert observation['request_id'] == request_id
                assert record['primary'] == observation['secure_yield']
                assert record['security_label'] == observation['security_label']
                assert record['functionality'] == observation['functionality']
                checked_revised.add(key)
            else:
                folder = results / result_name / assignment['slot'] / 'result'
                verify_bundle(folder)
                original = read_json(folder / 'result.json')
                assert original['request_id'] == request_id
                if original['status'] in {'generation_no_code', 'generation_truncated'}:
                    expected = 0
                elif original['status'] == 'returned' and not original['code_valid']:
                    expected = 0
                elif original['status'] == 'returned':
                    measured = original['measurements'][0]['measurement']
                    security = measured['channels']['security'] if measured['status'] == 'measured' else {}
                    expected = (int(security['observation']['security_label'] == 'secure')
                                if security.get('status') == 'passed' else 0)
                else:
                    expected = None
                assert record['primary'] == expected
        by_policy = {(row['task_unit_id'], row['candidate_id']): row['policy_id']
                     for row in bindings if row['use'] == 'open'}
        for candidate in candidates:
            task_id, candidate_id = candidate['task_unit_id'], candidate['candidate_id']
            policy_id = by_policy[task_id, candidate_id]
            selected = [row for row in assignments if row['task_unit_id'] == task_id
                        and row['policy_id'] == policy_id and row['arm'] in {'P', 'N'}]
            assert Counter((row['arm'], row['version']) for row in selected) == {
                ('P', 0): 2, ('P', 1): 2, ('N', 0): 2, ('N', 1): 2}
            values = [outcome_by_batch[batch, row['request_id']]['primary'] for row in selected]
            expected = None if None in values else (
                sum(outcome_by_batch[batch, row['request_id']]['primary'] for row in selected
                    if row['arm'] == 'P') -
                sum(outcome_by_batch[batch, row['request_id']]['primary'] for row in selected
                    if row['arm'] == 'N')) / 4
            assert effect_by_batch[batch, candidate_id]['delta_pn'] == expected
    assert checked_revised == set(revised)
    print(f'已独立核对{len(outcomes)}项原分配、{len(revised)}项重新测量、{len(effects)}项P/N效果')


if __name__ == '__main__':
    verify(Path.cwd())
