.libPaths(c('.codex-runtime/r-lib', .libPaths()))
suppressPackageStartupMessages(library(pcalg))
suppressPackageStartupMessages(library(jsonlite))
input <- file('stdin', open='r')
marks <- c('NONE', 'CIRCLE', 'ARROW', 'TAIL')
repeat {
  line <- readLines(input, n=1L, warn=FALSE)
  if (length(line) == 0L) break
  request <- fromJSON(line)
  rows <- as.matrix(request$rows)
  labels <- request$labels
  colnames(rows) <- labels
  stopifnot(nrow(rows) == request$n, all(rows %in% c(0L, 1L)))
  for (mode in c('0', '1', '12')) {
    warnings <- character()
    started <- proc.time()[['elapsed']]
    graph <- withCallingHandlers(fci(
      suffStat=list(dm=rows, nlev=rep(2L, length(labels)), adaptDF=FALSE),
      indepTest=disCItest, alpha=.05, labels=labels,
      contextVars=which(labels == 'C'), jci=mode,
      selectionBias=FALSE, NAdelete=FALSE, verbose=FALSE
    ), warning=function(w) {
      warnings <<- c(warnings, conditionMessage(w))
      invokeRestart('muffleWarning')
    })
    matrix <- graph@amat
    edges <- list()
    for (i in seq_len(length(labels)-1L)) {
      for (j in seq.int(i+1L, length(labels))) {
        if (matrix[i,j] != 0L || matrix[j,i] != 0L) {
          # pcalg 的矩阵元素记录列节点处的端点。
          edges[[length(edges)+1L]] <- c(labels[i], marks[matrix[j,i]+1L],
                                        marks[matrix[i,j]+1L], labels[j])
        }
      }
    }
    result <- list(identity=request$identity, method=paste0('FCI_JCI', mode),
                   edges=edges, warnings=as.list(unique(warnings)),
                   seconds=proc.time()[['elapsed']]-started,
                   pcalg=as.character(packageVersion('pcalg')),
                   jsonlite=as.character(packageVersion('jsonlite')))
    cat(toJSON(result, auto_unbox=TRUE, digits=16), '\n', sep='')
    flush(stdout())
  }
}
close(input)
