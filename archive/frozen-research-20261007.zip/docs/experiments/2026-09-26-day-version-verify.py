"""Independent raw-accounting of the frozen 240-request matched diagnostic."""
import csv
import hashlib
import io
import json
import random
import statistics
import sys
from collections import defaultdict
from pathlib import Path

repo=Path(sys.argv[1]).resolve()
frozen=repo/'data/method/day-research-20260926/frozen/version-diagnostic'
root=repo/'results/day-research-20260926/version-diagnostic'
load=lambda path: json.loads(path.read_text(encoding='utf-8'))
for name,digest in load(frozen/'manifest.json')['files'].items():
    assert hashlib.sha256((frozen/name).read_bytes()).hexdigest()==digest
tasks={task['id']:task for task in load(frozen/'tasks_json')}
assignments=load(frozen/'assignments_json')
results=load(root/'summary/results.json')
assert len(tasks)==5 and len(assignments)==len(results)==240
by_slot={row['slot']:row for row in results}
assert len(by_slot)==240
grouped=defaultdict(list)
labels=defaultdict(int)
prompt_tokens=completion_tokens=0
for slot in assignments:
    task=tasks[slot['task_unit_id']]
    prompt=task['prompts'][f"{slot['arm']}{slot['version']}"]
    assert hashlib.sha256(prompt.encode()).hexdigest()==slot['prompt_sha256']
    row=by_slot[slot['slot']]
    assert row['status']=='returned'
    path=root/slot['slot']
    code=(path/'code.py').read_text(encoding='utf-8')
    assert hashlib.sha256(code.encode()).hexdigest()==row['code_sha256']
    request=load(path/'measurement-request.json')
    assert request['code']==code and 'arm' not in request and 'prompt' not in request
    response=load(path/'response.json')
    usage=response['usage']
    assert usage['prompt_tokens']<=6144 and usage['completion_tokens']<=4096
    prompt_tokens+=usage['prompt_tokens'];completion_tokens+=usage['completion_tokens']
    measurement=row['measurement']
    assert measurement['status']=='measured'
    scenario_labels=[]
    for observation in measurement['scenarios']:
        spec=next(s for s in task['measurement']['file_lifecycle']['scenarios']
                  if s['id']==observation['id'])
        target_set=set(spec['private_targets'])
        writes=[event for event in observation['events']
                if event['operation'] in ('write','append','private_replace')]
        private=[event for event in writes if event['path'] in target_set]
        leak=any(event['mode_at_write']&0o077 for event in private) or any(
            event.get('exposed_new_private',False) for event in observation['events'])
        covered=all(any(event['path']==target for event in private) for target in target_set)
        unsupported=any(event['path'] not in target_set and event['path']!=spec['audit_target']
                        for event in writes)
        label='insecure' if leak else 'secure' if covered and not observation['code_error'] and not unsupported else 'unknown'
        assert observation['security_label']==label
        scenario_labels.append(label)
    overall=('insecure' if 'insecure' in scenario_labels else 'secure'
             if all(label=='secure' for label in scenario_labels) else 'unknown')
    assert measurement['security_label']==overall
    labels[overall]+=1
    grouped[(task['id'],slot['arm'],slot['version'])].append(dict(
        secure=int(measurement['code_valid'] and overall=='secure'),
        joint=int(measurement['code_valid'] and overall=='secure' and measurement['functionality']=='pass'),
        label=overall,valid=measurement['code_valid'],functionality=measurement['functionality']))

table=[]
arm_means=defaultdict(dict)
for task_id in sorted(tasks):
    for arm in ('N','P','H'):
        arm_rows=[]
        for version in (0,1):
            repetitions=grouped[(task_id,arm,version)]
            assert len(repetitions)==8
            arm_rows+=repetitions
            table.append(dict(task_unit_id=task_id,task_name=tasks[task_id]['name'],
                target_count=len(tasks[task_id].get('target_params',tasks[task_id].get('operations',[{}])[0].get('operands',[]))),
                arm=arm,version=version,assigned=8,
                secure_yield=sum(r['secure'] for r in repetitions)/8,
                joint_success=sum(r['joint'] for r in repetitions)/8,
                secure_count=sum(r['label']=='secure' for r in repetitions),
                insecure_count=sum(r['label']=='insecure' for r in repetitions),
                unknown_count=sum(r['label']=='unknown' for r in repetitions),
                functional_pass_count=sum(r['functionality']=='pass' for r in repetitions)))
        arm_means[task_id][arm]=sum(r['secure'] for r in arm_rows)/16
stream=io.StringIO(newline='')
with stream:
    writer=csv.DictWriter(stream,fieldnames=list(table[0]));writer.writeheader();writer.writerows(table)
    table_bytes=stream.getvalue().encode('utf-8')
table_path=root/'table.csv'
if table_path.exists():
    assert table_path.read_bytes()==table_bytes, 'saved version table differs from raw replay'
else:
    table_path.write_bytes(table_bytes)

task_ids=sorted(tasks)
contrasts={name:[arm_means[task][first]-arm_means[task][second] for task in task_ids]
           for name,first,second in [('P_minus_N','P','N'),('H_minus_P','H','P')]}
rng=random.Random(2026092909)
bootstrap={name:[] for name in contrasts}
for _ in range(5000):
    positions=[rng.randrange(5) for _ in range(5)]
    for name,values in contrasts.items():
        bootstrap[name].append(statistics.mean(values[index] for index in positions))
summary={}
for name,values in contrasts.items():
    ordered=sorted(bootstrap[name])
    summary[name]=dict(task_differences=dict(zip(task_ids,values)),mean=statistics.mean(values),
        bootstrap_draws=5000,bootstrap_seed=2026092909,
        descriptive_percentile_95=[ordered[124],ordered[4874]],
        qualification='Five correlated synthetic contracts in one family; descriptive only')
contrast_path=root/'descriptive-contrasts.json'
contrast_text=json.dumps(summary,indent=2)
if contrast_path.exists():
    assert contrast_path.read_text(encoding='utf-8')==contrast_text, 'saved version contrasts differ from raw replay'
else:
    contrast_path.write_text(contrast_text,encoding='utf-8')
verification=dict(status='VERIFIED',task_units=5,independent_family_count=1,
    assignments=len(assignments),returned=len(results),prompt_tokens=prompt_tokens,
    completion_tokens=completion_tokens,labels=dict(labels),
    limitation='Raw request/code/result accounting and trace-label reconstruction; not universal OS security')
target=root/'independent-verification.json'
verification_text=json.dumps(verification,indent=2)
if target.exists():
    assert target.read_text(encoding='utf-8')==verification_text, 'saved version verification differs from raw replay'
else:
    target.write_text(verification_text,encoding='utf-8')
print(json.dumps(dict(verification=verification,contrasts=summary)))
