import json
import math
from itertools import product

import numpy as np
from scipy.stats import binom


TASKS = 24
REPETITIONS = 8
ALPHA = 0.025


def coefficients(first_action, first_sign, second_action, second_sign):
    values = np.zeros(3, dtype=int)
    if first_action:
        values[first_action] += first_sign
        values[0] -= first_sign
    if second_action:
        values[second_action] -= second_sign
        values[0] += second_sign
    return values


def half_width(squared_coefficients, tasks=TASKS, repetitions=REPETITIONS):
    return math.sqrt(
        math.log(2 / ALPHA) * squared_coefficients / (2 * tasks * tasks * repetitions)
    )


def probability_of_positive_lower_bound(baseline, first, second, opposite=False):
    # 二项枚举仅用于同质概率情景的前瞻功效计算。
    count = TASKS * REPETITIONS
    values = np.arange(count + 1)
    first_pmf = binom.pmf(values, count, first)
    second_pmf = binom.pmf(values, count, second)
    if opposite:
        sum_pmf = np.convolve(first_pmf, second_pmf)
        estimates = (
            np.arange(2 * count + 1)[:, None] - 2 * values[None, :]
        ) / count
        probabilities = np.outer(sum_pmf, binom.pmf(values, count, baseline))
        target = first + second - 2 * baseline
        width = half_width(6 * TASKS)
    else:
        estimates = (values[:, None] - values[None, :]) / count
        probabilities = np.outer(first_pmf, second_pmf)
        target = first - second
        width = half_width(2 * TASKS)
    if not math.isclose(float(probabilities.sum()), 1.0, abs_tol=1e-10):
        raise ValueError("概率枚举未归一化")
    return {
        "baseline_probability": baseline,
        "jci_selected_probability": first,
        "ridge_selected_probability": second,
        "prediction_signs": [1, -1 if opposite else 1],
        "true_directional_advantage": target,
        "hoeffding_half_width": width,
        "probability_lower_bound_above_zero": float(
            probabilities[estimates > width].sum()
        ),
        "probability_lower_bound_above_0_10": float(
            probabilities[estimates > width + 0.10].sum()
        ),
    }


def main():
    # 穷举冻结动作与方向，核实来源请求的共享系数。
    checks = 0
    choices = [(0, 0), (1, -1), (1, 1), (2, -1), (2, 1)]
    for first_action, first_sign in choices:
        for second_action, second_sign in choices:
            values = coefficients(first_action, first_sign, second_action, second_sign)
            if values.sum() != 0:
                raise ValueError("政策对比系数之和必须为零")
            for outcomes in product([0, 1], repeat=3):
                direct = (
                    first_sign * (outcomes[first_action] - outcomes[0])
                    - second_sign * (outcomes[second_action] - outcomes[0])
                )
                if int(np.dot(values, outcomes)) != direct:
                    raise ValueError("共享系数与直接政策对比不一致")
                checks += 1

    same = coefficients(1, 1, 2, 1)
    opposite = coefficients(1, 1, 2, -1)
    identical = coefficients(1, -1, 1, -1)
    if list(same) != [0, 1, -1] or list(opposite) != [-2, 1, 1]:
        raise ValueError("主要比较系数错误")
    if np.any(identical):
        raise ValueError("相同动作与方向必须完全抵消")

    precision = []
    for target_width in [0.10, 0.05]:
        for total_squared in [2, 6]:
            repetitions = math.ceil(
                math.log(2 / ALPHA) * total_squared
                / (2 * TASKS * target_width**2)
            )
            width = half_width(total_squared * TASKS, repetitions=repetitions)
            previous = half_width(total_squared * TASKS, repetitions=repetitions - 1)
            if width > target_width or previous <= target_width:
                raise ValueError("目标半宽对应的最小重复次数错误")
            precision.append({
                "target_half_width": target_width,
                "coefficient_squared_sum_per_task": total_squared,
                "requests_per_arm": repetitions,
                "evaluation_requests_maximum": TASKS * 3 * repetitions,
                "total_requests_including_training": 64 * 3 * 4 + TASKS * 3 * repetitions,
            })

    result = {
        "status": "PROSPECTIVE_DESIGN_ARITHMETIC_ONLY",
        "training_tasks_target": 64,
        "evaluation_tasks_target": TASKS,
        "training_requests_maximum": 64 * 3 * 4,
        "evaluation_requests_maximum": TASKS * 3 * REPETITIONS,
        "total_requests_maximum": 64 * 3 * 4 + TASKS * 3 * REPETITIONS,
        "two_primary_comparisons_familywise_alpha": 2 * ALPHA,
        "coefficient_enumeration_checks": checks,
        "same_direction_half_width": half_width(2 * TASKS),
        "opposite_direction_half_width": half_width(6 * TASKS),
        "same_action_half_width": half_width(0),
        "scenario_assumption": "fixed actions; homogeneous probabilities; independent Bernoulli requests; all 24 tasks disagree",
        "scenarios": [
            probability_of_positive_lower_bound(0.4, 0.5, 0.5),
            probability_of_positive_lower_bound(0.4, 0.6, 0.5),
            probability_of_positive_lower_bound(0.4, 0.65, 0.5),
            probability_of_positive_lower_bound(0.4, 0.75, 0.5),
            probability_of_positive_lower_bound(0.85, 0.95, 0.9),
            probability_of_positive_lower_bound(0.5, 0.8, 0.3, opposite=True),
        ],
        "precision_requirements": precision,
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
