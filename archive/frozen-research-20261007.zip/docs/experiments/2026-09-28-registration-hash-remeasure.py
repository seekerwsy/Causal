import hashlib
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

from prompt_mechanism_study.artifact_io import read_json, write_bundle


ROOT = Path('data/method/graph-guided-20260928')
RESULTS = Path('results/graph-guided-20260928')
SOURCE = RESULTS / 'development-second-seven-diagnostic'
INPUTS = ROOT / 'registration_hash_remeasure_inputs'
BYTE_INPUTS = ROOT / 'measurement/registration_hash-byte-positive-inputs'
QUALIFICATION = RESULTS / 'registration_hash-qualification-v2'
BYTE_QUALIFICATION = RESULTS / 'registration_hash-byte-positive'
OUTPUTS = RESULTS / 'registration_hash_remeasure'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_manifest(directory):
    manifest = read_json(directory / 'manifest.json')
    for name, expected in manifest['files'].items():
        assert digest(directory / name) == expected
    return digest(directory / 'manifest.json')


def freeze():
    assignments = read_json(ROOT / 'development-execution-inputs-batch2/assignments.json')
    chosen = [row for row in assignments if row['index'] == 136]
    assert len(chosen) == 26
    measurement = ROOT / 'measurement'
    tests = {channel: (measurement / f'registration_hash-{channel}.py').read_text(encoding='utf-8')
             for channel in ('security', 'functionality')}
    controls = (measurement / 'registration_hash-controls.py').read_text(encoding='utf-8')
    request = dict(code=controls, entry_point='secure_bytes', tests=tests,
                   trace_assertions=False, channel_timeout_seconds=60)
    write_bundle(BYTE_INPUTS, {'secure_bytes.json': request})
    requests = {}
    for row in chosen:
        code_path = SOURCE / row['slot'] / 'code.py'
        code = code_path.read_text(encoding='utf-8')
        original = read_json(SOURCE / row['slot'] / 'result/result.json')
        assert original['status'] == 'returned' and original['code_sha256'] == hashlib.sha256(code.encode()).hexdigest()
        requests[f"{row['slot']}.json"] = dict(code=code, entry_point='register_user',
                                                  tests=tests, trace_assertions=False,
                                                  channel_timeout_seconds=60)
    write_bundle(INPUTS, requests)
    print(json.dumps(dict(status='frozen_exploratory_remeasurement', requests=len(requests),
                          input_manifest_sha256=verify_manifest(INPUTS))))


def verify():
    verify_manifest(INPUTS)
    verify_manifest(BYTE_INPUTS)
    verify_manifest(ROOT / 'measurement/registration_hash-qualification-inputs-v2')
    expected = {'secure': ('secure', 'pass'), 'vulnerable': ('insecure', 'pass'),
                'reject_all': ('unknown', 'fail'), 'overrestrictive': ('secure', 'fail')}
    for name, labels in expected.items():
        row = read_json(QUALIFICATION / f'{name}.json')
        assert row['status'] == 'measured'
        assert (row['channels']['security']['observation']['security_label'],
                row['channels']['functionality']['observation']['functionality']) == labels
    byte = read_json(BYTE_QUALIFICATION / 'secure_bytes.json')
    assert byte['status'] == 'measured'
    assert byte['channels']['security']['observation']['security_label'] == 'secure'
    assert byte['channels']['functionality']['observation']['functionality'] == 'pass'
    assignments = {row['slot']: row for row in
                   read_json(ROOT / 'development-execution-inputs-batch2/assignments.json')
                   if row['index'] == 136}
    assert len(assignments) == 26
    grouped = defaultdict(list)
    records = []
    for slot, assignment in assignments.items():
        request = read_json(INPUTS / f'{slot}.json')
        original = read_json(SOURCE / slot / 'result/result.json')
        assert hashlib.sha256(request['code'].encode()).hexdigest() == original['code_sha256']
        outcome = read_json(OUTPUTS / f'{slot}.json')
        assert outcome['status'] == 'measured'
        security = outcome['channels']['security']
        functionality = outcome['channels']['functionality']
        label = security['observation']['security_label'] if security['status'] == 'passed' else 'unknown'
        function = functionality['observation']['functionality'] if functionality['status'] == 'passed' else 'unknown'
        assert label in {'secure', 'insecure', 'unknown'}
        assert function in {'pass', 'fail', 'unknown'}
        entry = dict(slot=slot, candidate_slot=assignment['candidate_slot'],
                     arm=assignment['arm'], version=assignment['version'],
                     security=label, functionality=function, secure_yield=int(label == 'secure'))
        records.append(entry)
        grouped[entry['candidate_slot'], entry['arm']].append(entry)
    effects = {}
    for slot in range(6):
        p, n = grouped[slot, 'P'], grouped[slot, 'N']
        assert len(p) == len(n) == 2
        effects[str(slot)] = (sum(row['secure_yield'] for row in p) -
                              sum(row['secure_yield'] for row in n)) / 2
    assert len(grouped[None, 'R']) == 2
    destination = RESULTS / 'registration_hash_remeasure_verification.json'
    verified = dict(status='verified_exploratory_sensitivity', requests=len(records),
                    security_labels=dict(Counter(row['security'] for row in records)),
                    functionality_labels=dict(Counter(row['functionality'] for row in records)),
                    effects=effects, records=records)
    if destination.exists():
        assert read_json(destination) == verified
    else:
        destination.write_text(json.dumps(verified, indent=2), encoding='utf-8')
    print(json.dumps(dict(status='verified_exploratory_sensitivity', requests=len(records),
                          effects=effects, output=str(destination))))


if __name__ == '__main__':
    assert len(sys.argv) == 2 and sys.argv[1] in {'freeze', 'verify'}
    freeze() if sys.argv[1] == 'freeze' else verify()
