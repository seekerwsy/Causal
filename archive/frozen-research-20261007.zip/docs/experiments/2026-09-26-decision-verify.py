"""Standard-library reconstruction from raw rows/graphs; no production imports."""
import csv
import hashlib
import json
import math
import statistics
import sys
from collections import defaultdict
from fractions import Fraction
from pathlib import Path

root = Path(sys.argv[1])
load = lambda p: json.loads(p.read_text(encoding="utf-8"))
for folder in ("frozen", "tetrad", "analysis-corrected"):
    manifest = load(root / folder / "manifest.json")
    for name, expected in manifest["files"].items():
        assert hashlib.sha256((root / folder / name).read_bytes()).hexdigest() == expected
assert hashlib.sha256((root / "input.csv").read_bytes()).hexdigest() == load(root / "tetrad/input-identity.json")["sha256"]
design = load(root / "frozen/design.json")
groups = defaultdict(list)
with (root / "input.csv").open(newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        key = (row["scenario"], int(row["n_total"]), int(row["seed"]))
        groups[key].append(tuple(int(row[c]) for c in ("C", "X", "Z", "Y")))
assert len(groups) == len(design["scenarios"])*len(design["sizes"])*len(design["seeds"]) == 1050
gates, unusable = {}, {}
for row in load(root / "tetrad/graphs.json"):
    key = (row["scenario"], row["n_total"], row["seed"], row["method"])
    assert key not in gates
    observed = any({e[0], e[3]} == {"C", "Y"} for e in row["edges"])
    assert observed == row["adjacent"]
    unusable[key] = bool(row["error"] or row["warnings"])
    gates[key] = observed and not unusable[key]
with (root / "jci.csv").open(newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        key = (row["scenario"], int(row["n_total"]), int(row["seed"]), row["method"])
        assert key not in gates
        mat = list(map(int, row["matrix"].split(";"))) if row["matrix"] else [0]*16
        assert len(mat) == 16
        adjacent = mat[3] != 0 or mat[12] != 0
        assert adjacent == (row["adjacent"] == "TRUE")
        unusable[key] = bool(row["error"] or row["warnings"])
        gates[key] = adjacent and not unusable[key]
assert len(gates) == 5250

def effect(rows):
    sums, counts = [0,0], [0,0]
    for a,m,z,y in rows:
        sums[a] += y
        counts[a] += 1
    return Fraction(sums[1],counts[1])-Fraction(sums[0],counts[0]) if all(counts) else None

expected = {}
for key, rows in groups.items():
    assert len(rows) == key[1]
    assert key[0] in design["scenarios"] and key[1] in design["sizes"] and key[2] in design["seeds"]
    tau = list(map(lambda v: Fraction(str(v)), design["scenarios"][key[0]][1]))
    pooled = effect(rows)
    leaves = [effect([r for r in rows if r[1] == m]) for m in (0,1)]
    strata = [int(v is not None and v > 0) for v in leaves]
    strategies = {"no-edit":[0,0], "pooled-RD":[int(pooled is not None and pooled>0)]*2, "strata-RD":strata}
    for algorithm in ("FCI","GFCI","JCI0","JCI1","JCI12"):
        strategies[algorithm+"+strata-RD"] = strata if gates[key+(algorithm,)] else [0,0]
    for method, action in strategies.items():
        gain = sum(a*t for a,t in zip(action,tau))/2
        expected[key+(method,)] = dict(action=action, gain=float(gain),
            regret=float(sum(max(t,0) for t in tau)/2-gain),
            harmful_mass=sum(a for a,t in zip(action,tau) if t<0)/2,
            null_mass=sum(a for a,t in zip(action,tau) if t==0)/2)
actual = load(root / "analysis-corrected/decisions.json")
assert len(actual) == len(expected) == 8400
collected = defaultdict(list)
seen = set()
for row in actual:
    key = (row["scenario"],row["n_total"],row["seed"],row["method"])
    assert key not in seen
    seen.add(key)
    exp = expected[key]
    assert row["action"] == exp["action"]
    for field in ("gain","regret","harmful_mass","null_mass"):
        assert math.isclose(row[field],exp[field],abs_tol=1e-12)
    collected[(key[0],key[1],key[3])].append(exp)
for row in load(root / "analysis-corrected/summary.json"):
    values = collected[(row["scenario"],row["n_total"],row["method"])]
    assert len(values) == row["repetitions"] == 50
    for field in ("gain","regret","harmful_mass","null_mass"):
        assert math.isclose(row[field],statistics.mean(v[field] for v in values),abs_tol=1e-12)
    assert math.isclose(row["gain_mcse"],statistics.stdev(v["gain"] for v in values)/math.sqrt(50),abs_tol=1e-12)
report = dict(status="VERIFIED", matrices=len(groups), searches=len(gates), decisions=len(actual),
              unusable_graphs=sum(unusable.values()), method="stdlib fractions; raw rows and PAG adjacency; no production imports")
target = root / "independent-verification.json"
if target.exists(): raise FileExistsError(target)
target.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
print(json.dumps(report))
