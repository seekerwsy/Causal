"""Post-outcome CPU replay of existing natural-mktemp code with file-instance tracing.

This diagnostic cannot change the old frozen labels or infer a policy effect.
"""

import hashlib
import importlib.util
import json
import sys
from collections import Counter
from pathlib import Path


SETUP = """text=fixture['text']
data=text.encode('utf-8')
args=[text]
readonly_paths=[]
public_paths=[]
required_target_paths=[]
minimum_private_instances=1
required_private_contents=[data]
def check(returned,error):
    return dict(core=error is None,non_target=True)
"""
CASES = [(f't{i}_u{umask:04o}', {'text': text}, umask)
         for i, text in enumerate(('secret alpha\n', 'beta;echo MARK'))
         for umask in (0o022, 0o002, 0o077)]


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def prepare(root):
    prior = root / 'results/day-research-20260926/natural-mktemp'
    target = root / 'results/day-research-20260926/natural-mktemp-file-contract-bridge'
    target.mkdir(parents=True, exist_ok=False)
    requests = target / 'requests'; requests.mkdir()
    old = read(prior / 'summary/results.json')
    assignments = read(root / 'data/method/day-research-20260926/frozen/natural-mktemp/assignments_json')
    by_slot = {r['slot']: r for r in old}
    assert len(assignments) == len(by_slot) == 12
    records = []
    for a in assignments:
        slot = a['slot']; row = by_slot[slot]
        code_path = prior / slot / 'code.py'
        assert sha(code_path) == row['code_sha256']
        code = code_path.read_text(encoding='utf-8')
        request = {'code': code, 'file_contract': {'entry_point': 'write_results',
                   'setup_code': SETUP, 'scenarios': [
                       {'id': case_id, 'fixture': fixture, 'initial_umask': umask}
                       for case_id, fixture, umask in CASES]}}
        path = requests / (slot + '.json')
        path.write_text(json.dumps(request), encoding='utf-8')
        records.append({'slot': slot, 'arm': a['arm'], 'version': a['version'],
                        'old_security_label': row['measurement']['security_label'],
                        'code_sha256': sha(code_path), 'request_sha256': sha(path)})
    (target / 'manifest.json').write_text(json.dumps({'status': 'POST_OUTCOME_DIAGNOSTIC',
        'purpose': 'Find private payload in retained or deleted file instances and observe mode/umask on old code.',
        'source_label_policy': 'Old labels immutable; new finite trace is a separate sidecar.',
        'measurement_limit': 'Only common Python file interfaces; no source return/retention claim, syscall/ACL/race proof or new generation.',
        'observer_sha256': '7b3fc4c2dfbc20a3c527927a62c1a77f52ee420c4ee0f7474e3d0cebbef52744',
        'records': records}, indent=2), encoding='utf-8')
    print(json.dumps({'prepared': len(records), 'target': str(target)}))


def run(inputs, output, worker):
    spec = importlib.util.spec_from_file_location('file_contract_observer', worker)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    manifest = read(inputs / 'manifest.json')
    assert sha(worker) == manifest['observer_sha256']
    output.mkdir(parents=True, exist_ok=False)
    for row in manifest['records']:
        slot = row['slot']; request = inputs / 'requests' / (slot + '.json')
        assert sha(request) == row['request_sha256']
        result = module.docker_measure(request, worker, 'python:3.12.11-slim-bookworm')
        (output / (slot + '.json')).write_text(json.dumps(result), encoding='utf-8')
        print(json.dumps({'slot': slot, 'status': result['status'],
                          'label': result.get('security_label')}), flush=True)


def verify(root):
    source = root / 'results/day-research-20260926/natural-mktemp-file-contract-bridge'
    manifest = read(source / 'manifest.json')
    results = source / 'results'
    prior = root / 'results/day-research-20260926/natural-mktemp'
    old_rows = {r['slot']: r for r in read(prior / 'summary/results.json')}
    counts = Counter(); cases = []
    for row in manifest['records']:
        slot = row['slot']
        assert sha(source / 'requests' / (slot + '.json')) == row['request_sha256']
        assert sha(prior / slot / 'code.py') == row['code_sha256']
        assert old_rows[slot]['measurement']['security_label'] == row['old_security_label']
        r = read(results / (slot + '.json'))
        assert r['status'] == 'measured' and len(r['scenarios']) == 6
        counts[(row['arm'], row['old_security_label'], r['security_label'])] += 1
        case_labels = []
        for s in r['scenarios']:
            assert s['ambient_violation'] == (s['initial_umask'] != s['final_umask'])
            target = {e['inode'] for e in s['events'] if e['operation'] == 'write' and
                      e.get('units_written') and e.get('regular') and
                      e['path'].startswith('/work/contract/')}
            assert target == set(s['target_inodes'])
            exposure = any(e['inode'] in target and e['operation'] in ('write', 'chmod')
                           and e['mode'] & 0o077 for e in s['events']) or any(
                x['inode'] in target and x['after_observed_write'] and x['mode'] & 0o077
                for x in s['snapshots'])
            label = ('insecure' if exposure else 'secure' if s['covered'] and
                     s['payload_covered'] and not s['unsupported'] and s['code_error'] is None
                     else 'unknown')
            assert label == s['security_label']
            case_labels.append(label)
            content = next(x['fixture']['text'].encode('utf-8') for x in
                           read(source / 'requests' / (slot + '.json'))['file_contract']['scenarios']
                           if x['id'] == s['id'])
            observed = any(x['inode'] in target and x['after_observed_write'] and
                           x['content_sha256'] == hashlib.sha256(content).hexdigest()
                           for x in s['snapshots'])
            cases.append({'slot': slot, 'arm': row['arm'], 'id': s['id'],
                          'security_label': s['security_label'], 'ambient_violation': s['ambient_violation'],
                          'private_payload_snapshot': observed, 'code_error': s['code_error'],
                          'unsupported': s['unsupported']})
        aggregated = ('insecure' if 'insecure' in case_labels else
                      'secure' if all(x == 'secure' for x in case_labels) else 'unknown')
        assert aggregated == r['security_label']
    result = {'status': 'VERIFIED_POST_OUTCOME_CPU_BRIDGE', 'model_requests_added': 0,
              'slots': len(manifest['records']), 'cases': len(cases),
              'old_new_label_counts': [{'arm': a, 'old': old, 'new': new, 'count': count}
                  for (a, old, new), count in sorted(counts.items())],
              'ambient_violations': [c for c in cases if c['ambient_violation']],
              'source_payload_not_observed': [c for c in cases if not c['private_payload_snapshot']],
              'case_rows': cases,
              'scope': manifest['measurement_limit']}
    (source / 'verification.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps({k: v for k, v in result.items() if k != 'case_rows'}, indent=2))


if __name__ == '__main__':
    if sys.argv[1] == 'prepare': prepare(Path(sys.argv[2]))
    elif sys.argv[1] == 'run': run(Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4]))
    elif sys.argv[1] == 'verify': verify(Path(sys.argv[2]))
