import argparse
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
from markdown_it import MarkdownIt


ROOT = Path('data/method/graph-guided-20260928')
INPUTS = ROOT / 'heldout-execution-inputs'
OUTPUTS = Path('results/graph-guided-20260928/heldout-transfer-diagnostic')
DESTINATION = Path('results/graph-guided-20260928/heldout-independent-verification.json')


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def manifest(directory):
    for name, expected in load(directory / 'manifest.json')['files'].items():
        assert digest(directory / name) == expected
    return digest(directory / 'manifest.json')


def labels(result):
    if result['status'] != 'returned':
        return dict(security='unknown', functionality='unknown', secure_yield=0,
                    functional_yield=0, joint_yield=0, generation_status=result['status'])
    assert len(result['measurements']) == 1
    channels = result['measurements'][0]['measurement']['channels']
    security = (channels['security']['observation']['security_label']
                if channels['security']['status'] == 'passed' else 'unknown')
    functionality = (channels['functionality']['observation']['functionality']
                     if channels['functionality']['status'] == 'passed' else 'unknown')
    assert security in {'secure', 'insecure', 'unknown'}
    assert functionality in {'pass', 'fail', 'unknown'}
    return dict(security=security, functionality=functionality,
                secure_yield=int(security == 'secure'), functional_yield=int(functionality == 'pass'),
                joint_yield=int(security == 'secure' and functionality == 'pass'),
                generation_status='returned')


def means(rows):
    assert len(rows) == 3
    return {field: sum(row[field] for row in rows)/3
            for field in ('secure_yield', 'functional_yield', 'joint_yield')}


def main(remaining=False, performance=False, stream=False, download=False):
    global INPUTS, OUTPUTS, DESTINATION
    assert not (download and (remaining or performance or stream))
    single = stream or download
    if remaining or performance or single:
        cohort = 'download' if download else 'stream' if stream else 'performance' if performance else 'remaining'
        INPUTS = ROOT / ('heldout-execution-inputs-'+cohort)
        OUTPUTS = Path('results/graph-guided-20260928') / ('heldout-'+cohort+'-diagnostic')
        DESTINATION = Path('results/graph-guided-20260928') / ('heldout-'+cohort+'-independent-verification.json')
    input_hash = manifest(INPUTS)
    protocol = load(INPUTS / 'protocol.json')
    assignments = load(INPUTS / 'assignments.json')
    assert protocol['status'] == 'FROZEN_GRAPH_GUIDED_HELDOUT_TRANSFER'
    task_count = 1 if single else 4 if performance else 11 if remaining else 15
    request_count = task_count*21
    assert len(assignments) == protocol['code_requests'] == request_count
    assert Counter(row['arm'] for row in assignments) == dict(P=task_count*6, N=task_count*6, R=task_count*3, S=task_count*3, G=task_count*3)
    assert len({row['task_unit_id'] for row in assignments}) == task_count
    assert [row['slot'] for row in assignments] == [f'{number:04d}' for number in range(request_count)]
    manifest(OUTPUTS / 'preoutcome')
    assert load(OUTPUTS / 'preoutcome/protocol.json') == protocol
    assert load(OUTPUTS / 'preoutcome/assignments.json') == assignments
    manifest(OUTPUTS / 'summary')
    results = load(OUTPUTS / 'summary/results.json')
    assert len(results) == request_count
    by_slot = {result['slot']: result for result in results}
    assert len(by_slot) == request_count
    cases = {}
    for identity, settings in protocol['case_manifests'].items():
        directory = Path(settings['path'])
        assert manifest(directory) == settings['manifest_sha256']
        cases[int(identity)] = load(directory / 'case.json')
    assignment_seed = 20260941 if download else 20260940 if stream else 20260939 if performance else 20260936 if remaining else 20260931
    assert protocol['task_randomization_seed'] == assignment_seed
    rng = np.random.default_rng(assignment_seed)
    expected_assignments, expected_context = [], []
    for index in sorted(cases):
        seeds = rng.permutation([assignment_seed*10000+index*10+k for k in range(3)]).tolist()
        context = int(rng.binomial(1, .5))
        selected_version = int(rng.integers(3))
        expected_context.append((index, context, f'v{selected_version+1}', seeds[selected_version]))
        for number in range(3):
            expected_assignments.extend((index, f'v{number+1}', arm, None, seeds[number]) for arm in ('R', 'S', 'G'))
            for candidate_slot in (0, 2):
                expected_assignments.extend((index, f'v{number+1}', arm, candidate_slot, seeds[number]) for arm in ('P', 'N'))
    order = rng.permutation(request_count)
    assert [(row['index'], row['version'], row['arm'], row['candidate_slot'], row['seed']) for row in assignments] == [expected_assignments[int(number)] for number in order]
    context_rows = load(INPUTS / 'context_rows.json')
    assert [(row['index'], row['C'], row['version'], row['seed']) for row in context_rows] == expected_context
    for row in context_rows:
        assert row['X'] == cases[row['index']]['author_card']['source_x']['direct_security_requirement']
        for slot in (0, 2):
            assigned = assignments[int(row['request_slots'][str(slot)])]
            assert (assigned['index'], assigned['version'], assigned['arm'], assigned['candidate_slot']) == (row['index'], row['version'], 'P' if row['C'] else 'R', slot if row['C'] else None)
    rows = []
    for assigned in assignments:
        slot = assigned['slot']
        case = cases[assigned['index']]
        version = int(assigned['version'][1:])-1
        assert hashlib.sha256(assigned['prompt'].encode()).hexdigest() == assigned['prompt_sha256']
        if assigned['arm'] == 'R':
            expected = '\n\n'.join((case['source']['prompt'], case['author_card']['interface'],
                                     case['author_card']['shared_realization_instructions'][version]))
        else:
            candidate = (case['candidates'][0] if assigned['candidate_slot'] is None else
                         next(candidate for candidate in case['candidates'] if candidate['slot'] == assigned['candidate_slot']))
            expected = candidate['realizations'][version]['prompts'][assigned['arm']]
        assert assigned['prompt'] == expected
        directory = OUTPUTS / slot
        manifest(directory / 'result')
        result = load(directory / 'result/result.json')
        assert result == by_slot[slot]
        for field in ('index', 'task_unit_id', 'candidate_slot', 'version', 'arm', 'seed', 'prompt_sha256'):
            assert result[field] == assigned[field]
        if result['status'] == 'returned':
            code = (directory / 'code.py').read_text(encoding='utf-8')
            raw_code = (directory / 'raw_code.py').read_text(encoding='utf-8')
            content = load(directory / 'content.json')
            response_content = load(directory / 'response.json')['choices'][0]['message']['content']
            assert json.loads(response_content) == content
            assert content['code'] == raw_code
            assert hashlib.sha256(code.encode()).hexdigest() == result['code_sha256']
            assert hashlib.sha256(raw_code.encode()).hexdigest() == result['raw_code_sha256']
            tokens = MarkdownIt().parse(raw_code)
            expected_code = (tokens[0].content if len(tokens) == 1 and tokens[0].type == 'fence'
                             and tokens[0].info.strip().lower() in {'python', 'py'} else raw_code)
            assert code == expected_code
            request = load(directory / 'measurement-request.json')
            assert request['code'] == code
            assert request['tests'] == assigned['measurements'][0]['tests']
            assert request['entry_point'] == assigned['measurements'][0]['entry_point']
        rows.append(dict(slot=slot, index=assigned['index'], task_unit_id=assigned['task_unit_id'],
                         candidate_slot=assigned['candidate_slot'], version=assigned['version'],
                         arm=assigned['arm'], seed=assigned['seed'], **labels(result)))
    grouped = defaultdict(list)
    for row in rows:
        grouped[row['index'], row['candidate_slot'], row['arm']].append(row)
    effects = []
    for index, case in cases.items():
        for candidate in case['candidates']:
            slot = candidate['slot']
            arms = {arm: means(grouped[index, slot if arm in ('P', 'N') else None, arm])
                    for arm in ('P', 'N', 'R', 'S', 'G')}
            effects.append(dict(index=index, task_unit_id=case['source']['task_unit_id'], slot=slot,
                                representation=case['source']['representation'], arms=arms,
                                comparisons={f'{first}_minus_{second}': {
                                    field: arms[first][field]-arms[second][field]
                                    for field in ('secure_yield', 'functional_yield', 'joint_yield')}
                                    for first, second in (('P', 'N'), ('P', 'R'), ('N', 'R'), ('S', 'R'), ('G', 'R'))}))
    assert len(effects) == task_count*2
    effect_by_key = {(row['index'], row['slot']): row for row in effects}
    rng = np.random.default_rng(20260937 if remaining else 20260933)
    strata = defaultdict(list)
    for index, case in sorted(cases.items()):
        key = ((case['source']['source_lineage_id'], case['source']['representation']) if remaining
               else case['source']['representation'])
        strata[key].append(index)
    category_draws = {slot: [] for slot in (0, 2)}
    for _ in range(0 if performance or single else 2000):
        sampled = []
        for stratum in sorted(strata):
            sampled.extend(rng.choice(strata[stratum], len(strata[stratum]), replace=True))
        for slot in (0, 2):
            category_draws[slot].append(float(np.mean([
                effect_by_key[int(index), slot]['comparisons']['P_minus_N']['secure_yield'] for index in sampled])))
    category_effects = [dict(slot=slot, task_units=task_count,
                            mean_P_minus_N=float(np.mean([row['comparisons']['P_minus_N']['secure_yield']
                                                           for row in effects if row['slot'] == slot]))) for slot in (0, 2)]
    for row in category_effects:
        if performance or single:
            row['inference'] = ('descriptive_only_one_task_unit' if single else
                                'descriptive_only_four_task_units')
        else:
            row['interval_97_5'] = np.quantile(category_draws[row['slot']], [.0125, .9875]).tolist()
    policy_root = ROOT / ('heldout-policy-decisions-performance' if performance else
                         'heldout-policy-decisions-remaining' if remaining else 'heldout-policy-decisions')
    assert manifest(policy_root) == protocol['policy_manifest_sha256']
    choices = [] if single else load(policy_root / 'decisions.json')
    policy_count = 0 if single else 3 if performance else 4 if remaining else 8
    assert len(choices) == policy_count
    methods = sorted(choices[0]['choices']) if choices else []
    policy_rows = []
    for row in choices:
        for method, action in row['choices'].items():
            if action == 'R':
                outcome = effect_by_key[row['index'], 0]['arms']['R']
            else:
                outcome = effect_by_key[row['index'], int(action.split(':')[1])]['arms']['P']
            policy_rows.append(dict(index=row['index'], method=method, action=action, **outcome))
    policy_by_key = {(row['index'], row['method']): row for row in policy_rows}
    policy_values = [dict(method=method, task_units=policy_count,
                          **{field: float(np.mean([row[field] for row in policy_rows if row['method'] == method]))
                             for field in ('secure_yield', 'functional_yield', 'joint_yield')}) for method in methods]
    comparisons = () if single else ('source_semantics', 'overall_randomized_effect', 'text_ridge', 'two_arm_ridge')
    rng = np.random.default_rng(20260932)
    policy_draws = {method: [] for method in comparisons}
    indices = [row['index'] for row in choices]
    for _ in range(0 if single else 2000):
        sampled = rng.choice(indices, len(indices), replace=True)
        for method in comparisons:
            policy_draws[method].append(float(np.mean([policy_by_key[int(index), 'tsg_ridge']['secure_yield']
                                                       -policy_by_key[int(index), method]['secure_yield']
                                                       for index in sampled])))
    policy_contrasts = [dict(reference='tsg_ridge', comparison=method, task_units=policy_count,
                            difference=float(np.mean([policy_by_key[index, 'tsg_ridge']['secure_yield']
                                                      -policy_by_key[index, method]['secure_yield'] for index in indices])),
                            interval_98_75=np.quantile(policy_draws[method], [.00625, .99375]).tolist(),
                            action_agreement=sum(policy_by_key[index, 'tsg_ridge']['action'] ==
                                                policy_by_key[index, method]['action'] for index in indices)/policy_count)
                        for method in comparisons]
    if remaining or performance:
        for row in policy_contrasts:
            row.pop('interval_98_75')
            row['inference'] = 'descriptive_only_'+str(policy_count)+'_task_units'
    verified = dict(status='verified', input_manifest_sha256=input_hash,
        assignments=request_count, task_units=task_count,
        generation_statuses=dict(Counter(row['generation_status'] for row in rows)),
        security_labels=dict(Counter(row['security'] for row in rows)),
        functionality_labels=dict(Counter(row['functionality'] for row in rows)),
        records=rows, effects=effects, category_effects=category_effects,
        policy_rows=policy_rows, policy_values=policy_values, policy_contrasts=policy_contrasts)
    if DESTINATION.exists():
        assert load(DESTINATION) == verified
    else:
        DESTINATION.write_text(json.dumps(verified, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(dict(status='verified', assignments=request_count, category_effects=category_effects,
                          policy_values=policy_values, policy_contrasts=policy_contrasts)))


def verify_repair(source_cases=False):
    prefix = 'repair-source' if source_cases else 'repair-edit'
    inputs = ROOT / (prefix+'-execution-inputs')
    outputs = Path('results/graph-guided-20260928') / (prefix+'-diagnostic')
    input_hash = manifest(inputs)
    protocol = load(inputs / 'protocol.json')
    assignments = load(inputs / 'assignments.json')
    expected_count = 87 if source_cases else 180
    assert protocol['code_requests'] == len(assignments) == expected_count
    assert [r['slot'] for r in assignments] == [f'{i:04d}' for i in range(expected_count)]
    manifest(outputs / 'preoutcome')
    manifest(outputs / 'summary')
    assert load(outputs / 'preoutcome/assignments.json') == assignments
    assert load(outputs / 'preoutcome/protocol.json') == protocol
    results = {r['slot']:r for r in load(outputs / 'summary/results.json')}
    assert len(results) == expected_count
    prepared = {(r['index'],r['candidate_slot']):r for r in load(inputs / 'prepared.json')}
    assert len(prepared) == (10 if source_cases else 24)
    expected = []
    case_order = ([r['index'] for r in load(ROOT / 'preparation/repair-source-cases.json')['cases']]
                  if source_cases else sorted({r['index'] for r in assignments}))
    assert set(case_order) == {r['index'] for r in assignments}
    for index in case_order:
        candidates = sorted(slot for case,slot in prepared if case == index)
        for slot in candidates:
            for version in range(3):
                expected.extend((index,slot,f'v{version+1}',arm) for arm in ('P','N'))
        for version in range(3):
            expected.extend((index,None,f'v{version+1}',arm) for arm in ('R','S','G'))
    rng = np.random.default_rng(protocol['randomization_seed'])
    order = rng.permutation(expected_count)
    assert [(r['index'],r['candidate_slot'],r['version'],r['arm']) for r in assignments] == [expected[i] for i in order]
    records = []
    for assigned in assignments:
        directory = outputs / assigned['slot']
        manifest(directory / 'result')
        result = load(directory / 'result/result.json')
        assert result == results[assigned['slot']]
        assert hashlib.sha256(assigned['prompt'].encode()).hexdigest() == assigned['prompt_sha256']
        for field in ('index','task_unit_id','candidate_slot','version','arm','seed','prompt_sha256'):
            assert result[field] == assigned[field]
        if result['status'] == 'returned':
            content = load(directory / 'content.json')
            assert json.loads(load(directory / 'response.json')['choices'][0]['message']['content']) == content
            raw = (directory / 'raw_code.py').read_text(encoding='utf-8')
            assert content['code'] == raw
            parsed = MarkdownIt().parse(raw)
            code = (parsed[0].content if len(parsed) == 1 and parsed[0].type == 'fence'
                    and parsed[0].info.strip().lower() in {'python','py'} else raw)
            assert (directory / 'code.py').read_text(encoding='utf-8') == code
            assert hashlib.sha256(code.encode()).hexdigest() == result['code_sha256']
            request = load(directory / 'measurement-request.json')
            assert request['code'] == code and request['tests'] == assigned['measurements'][0]['tests']
            assert request['entry_point'] == assigned['measurements'][0]['entry_point']
            for option in ('workspace_megabytes','preload_test'):
                assert request.get(option) == assigned['measurements'][0].get(option)
        records.append(dict(index=assigned['index'],task_unit_id=assigned['task_unit_id'],slot=assigned['slot'],
            candidate_slot=assigned['candidate_slot'],version=assigned['version'],arm=assigned['arm'],**labels(result)))
    effects = []
    for (index,slot),candidate in sorted(prepared.items()):
        arms = {arm:means([r for r in records if r['index'] == index and r['arm'] == arm
            and r['candidate_slot'] == (slot if arm in ('P','N') else None)]) for arm in ('P','N','R','S','G')}
        effects.append(dict(index=index,candidate_slot=slot,operation=candidate['target']['operation'],arms=arms,
            P_minus_N={field:arms['P'][field]-arms['N'][field] for field in arms['P']},
            P_minus_R={field:arms['P'][field]-arms['R'][field] for field in arms['P']}))
    verified = dict(status='verified_exploratory_repair',requests=expected_count,
        task_units=len({r['task_unit_id'] for r in records}),hypotheses=len(prepared),
        labels=dict(Counter(r['security'] for r in records)),functionality=dict(Counter(r['functionality'] for r in records)),
        records=records,effects=effects,input_manifest_sha256=input_hash)
    destination = Path('results/graph-guided-20260928') / (prefix+'-independent-verification.json')
    if destination.exists():
        assert load(destination) == verified
    else:
        destination.write_text(json.dumps(verified,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in verified.items() if k not in ('records','effects')},ensure_ascii=False))
    print(json.dumps([dict(index=r['index'],operation=r['operation'],P_minus_N=r['P_minus_N']) for r in effects],ensure_ascii=False))


def verify_repair_preparation():
    import itertools
    import pandas as pd
    from sklearn.compose import ColumnTransformer
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import Ridge
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import OneHotEncoder, StandardScaler

    opportunities = ROOT / 'repair-target-opportunities'
    opportunity_hash = manifest(opportunities)
    tasks = load(opportunities / 'tasks.json')
    audit_indices = {r['index'] for r in load(Path('results/graph-guided-20260928/target-coverage-diagnostic/tasks.json'))}
    assert {r['index'] for r in tasks} == audit_indices and len(tasks) == 46
    proposal_count = 0
    for task in tasks:
        source = next(r for r in load(ROOT / 'registration/sources.json') if r['index'] == task['index'])
        target_path = ROOT / f"targets/case-{task['index']:04d}.json"
        assert digest(target_path) == task['original_target_selection_sha256']
        target = load(target_path)
        nodes = {r['id']:r for r in target['nodes']}
        edges = {r['id']:r for r in target['relations']}
        proposals = task['proposals']
        proposal_count += len(proposals)
        if nodes:
            expected = {(frozenset([n]),frozenset()) for n in nodes}
            expected.update((frozenset([r['from'],r['to']]),frozenset([r['id']])) for r in edges.values())
            for a,b in itertools.combinations(edges.values(),2):
                if {a['from'],a['to']} & {b['from'],b['to']}:
                    expected.add((frozenset([a['from'],a['to'],b['from'],b['to']]),frozenset([a['id'],b['id']])))
            assert {(frozenset(r['nodes']),frozenset(r['relations'])) for r in proposals} == expected
            assert len(proposals) == len(expected)
            for row in proposals:
                assert row['semantic_review'] == 'pending' and row['operation_screening'] == 'AUTHOR_BINDING_REQUIRED_BEFORE_GENERATION'
                evidence = [nodes[n] for n in row['nodes']]+[edges[e] for e in row['relations']]
                assert row['evidence'] == evidence and all(r['quote'] in source['prompt'] for r in evidence)
        else:
            assert [r['quote'] for r in proposals] == [r['quote'] for r in target['source_spans']]
        selected = {r['id'] for r in target['selected_targets']}
        assert {r['id'] for r in task['original_unselected']} == {r['id'] for r in target['enumerated_targets'] if r['id'] not in selected}
        assert all(r['prior_reason'] is None for r in task['original_unselected'])
    assert proposal_count == load(opportunities / 'protocol.json')['proposals'] == 318

    inputs = ROOT / 'repair-semantic-selection-inputs'
    outputs = Path('results/graph-guided-20260928/repair-semantic-selection')
    input_hash, output_hash = manifest(inputs), manifest(outputs)
    training, targets = load(inputs / 'training.json'), load(inputs / 'targets.json')
    assert len(training) == 14 and len(targets) == 30
    for row in training+targets:
        suffix = '-v2' if row['index'] in (38,206) else ''
        case = load(ROOT / f"prepared/case-{row['index']:04d}{suffix}/case.json")
        candidate = next(r for r in case['candidates'] if r['slot'] == row['slot'])
        nodes = {r['id']:r for r in case['targets']['nodes']}
        edges = {r['id']:r for r in case['targets']['relations']}
        node_text = '\n'.join(sorted(' | '.join((nodes[n]['type'],nodes[n]['meaning'],nodes[n]['quote'])) for n in candidate['target']['nodes']))
        edge_text = '\n'.join(sorted(' | '.join((nodes[edges[e]['from']]['type'],nodes[edges[e]['from']]['meaning'],edges[e]['type'],nodes[edges[e]['to']]['type'],nodes[edges[e]['to']]['meaning'],edges[e]['quote'])) for e in candidate['target']['relations']))
        assert row['node_semantics'] == node_text and row['graph_semantics'] == node_text+'\n'+edge_text
    folds = sorted({r['task_unit_id'] for r in training})
    assert len(folds) == 7
    categorical = ['operation','outcome','node_types','relation_types','object_role_explicit',
                   'condition_recipient_explicit','direct_security_requirement','operation_order_explicit']
    def predictions(train,test,mode,alpha):
        if mode == 'tsg_ridge':
            transform = ColumnTransformer([('categorical',OneHotEncoder(handle_unknown='ignore',sparse_output=False),categorical),
                ('numeric',StandardScaler(),['node_count','relation_count'])])
        else:
            field = {'text_ridge':'text','semantic_node_ridge':'node_semantics','semantic_graph_ridge':'graph_semantics'}[mode]
            vectorizer = (TfidfVectorizer(ngram_range=(1,2),max_features=128) if mode == 'text_ridge' else
                          TfidfVectorizer(analyzer='char',ngram_range=(2,4),max_features=128))
            transform = ColumnTransformer([('content',vectorizer,field),
                ('common',OneHotEncoder(handle_unknown='ignore',sparse_output=False),['operation','outcome'])],sparse_threshold=0)
        model = Pipeline([('features',transform),('estimator',Ridge(alpha=alpha))])
        return model.fit(pd.DataFrame(train),[r['P_minus_R'] for r in train]).predict(pd.DataFrame(test))
    def action(rows,values):
        value,slot = max(zip(values,[r['slot'] for r in rows]),key=lambda r:(r[0],-r[1]))
        return 'R' if value <= 0 else f'P:{slot}'
    raw_records = []
    for name in ('heldout-independent-verification.json','heldout-remaining-independent-verification.json','heldout-performance-independent-verification.json'):
        raw_records.extend(load(Path('results/graph-guided-20260928') / name)['records'])
    revised = {}
    for prefix in ('source-measurement-review','privacy-property-review'):
        directory = Path('results/graph-guided-20260928') / (prefix+'-verification')
        manifest(directory)
        revised.update({(r['index'],r['slot']):r for r in load(directory / 'verification.json')['records']})
    reported_cv, reported_decisions = load(outputs / 'cross-validation.json'), load(outputs / 'decisions.json')
    values = []
    for mode in load(inputs / 'protocol.json')['modes']:
        grid = []
        for alpha in (.1,1.,10.,100.):
            gains = []
            cv = next(r for r in reported_cv[mode]['evaluations'] if r['parameter']['alpha'] == alpha)
            for identity in folds:
                train = [r for r in training if r['task_unit_id'] != identity]
                test = [r for r in training if r['task_unit_id'] == identity]
                predicted = predictions(train,test,mode,alpha)
                choice = action(test,predicted)
                expected = next(r for r in cv['folds'] if r['task_unit_id'] == identity)
                assert choice == expected['choice']
                assert all(np.isclose(v,expected['scores'][str(r['slot'])],atol=1e-12,rtol=0) for r,v in zip(test,predicted,strict=True))
                gain = 0. if choice == 'R' else next(r['P_minus_R'] for r in test if r['slot'] == int(choice.split(':')[1]))
                assert gain == expected['gain']
                gains.append(gain)
            assert float(np.mean(gains)) == cv['mean_gain']
            grid.append((float(np.mean(gains)),alpha))
        alpha = max(grid)[1]
        assert alpha == reported_cv[mode]['parameter']['alpha']
        scores = predictions(training,targets,mode,alpha)
        rows = []
        for index in sorted({r['index'] for r in targets}):
            positions = [i for i,r in enumerate(targets) if r['index'] == index]
            choice = action([targets[i] for i in positions],[scores[i] for i in positions])
            reported = next(r for r in reported_decisions[mode] if r['index'] == index)
            assert reported['choice'] == choice
            assert all(np.isclose(scores[i],reported['scores'][str(targets[i]['slot'])],atol=1e-12,rtol=0) for i in positions)
            arm,slot = ('R',None) if choice == 'R' else ('P',int(choice.split(':')[1]))
            observed = [r for r in raw_records if r['index'] == index and r['arm'] == arm and r['candidate_slot'] == slot]
            assert len(observed) == 3
            original_value = float(np.mean([r['secure_yield'] for r in observed]))
            revised_value = float(np.mean([revised.get((r['index'],r['slot']),r)['secure_yield'] for r in observed]))
            assert reported['original_yield'] == original_value and reported['source_sensitive_yield'] == revised_value
            rows.append((original_value,revised_value))
        values.append(dict(method=mode,task_units=len(rows),original_yield=float(np.mean([r[0] for r in rows])),source_sensitive_yield=float(np.mean([r[1] for r in rows]))))
    assert values == load(outputs / 'policy-values.json')

    policy_path = ROOT / 'measurement/repair-preparation-policy.json'
    policy = load(policy_path)
    measurement_bindings = []
    for index,revision in policy['cases'].items():
        directory = ROOT / f'prepared/case-{int(index):04d}-repair'
        manifest(directory)
        prepared = load(directory / 'case.json')
        original = load(ROOT / f'prepared/case-{int(index):04d}/case.json')
        assert prepared['source'] == original['source'] and prepared['targets'] == original['targets']
        assert prepared['author_card']['prior_results_visible'] is True
        assert prepared['measurement_revision_policy_sha256'] == digest(policy_path)
        prefix = ('registration_hash_remeasure_inputs' if index == '136' else
                  'source-measurement-review-inputs' if index in ('122','235','240') else 'privacy-property-review-inputs')
        directory = ROOT / prefix
        manifest(directory)
        tests = prepared['measurements']['tests']
        assert any(load(directory / name)['tests'] == tests for name in load(directory / 'manifest.json')['files'])
        if index == '122':
            assert prepared['author_card']['interface'] == revision['interface']
            assert prepared['author_card']['non_target_requirements'] == revision['non_target_requirements']
        measurement_bindings.append(dict(index=int(index),measurement=revision['measurement'],prepared_manifest_sha256=digest(ROOT / f'prepared/case-{int(index):04d}-repair/manifest.json')))
    verified = dict(status='verified_post_outcome_preparation_and_selection',task_units=46,proposals=318,
        opportunity_manifest_sha256=opportunity_hash,selector_input_manifest_sha256=input_hash,
        selector_output_manifest_sha256=output_hash,policy_values=values,measurement_bindings=measurement_bindings,
        independent_semantic_review=False,new_model_calls=0)
    destination = Path('results/graph-guided-20260928/repair-preparation-independent-verification.json')
    if destination.exists():
        assert load(destination) == verified
    else:
        destination.write_text(json.dumps(verified,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(verified,ensure_ascii=False))


def verify_repair_material():
    directory = ROOT / 'repair-representation-audit'
    graph_hash = manifest(directory)
    original = ROOT / 'representation-preparation-audit'
    manifest(original)
    old_graphs = {r['index']:r for r in load(original / 'graphs.json')}
    graphs = load(directory / 'graphs.json')
    selected = {r['index']:r for r in load(ROOT / 'representation-review/selection.json')}
    assert len(graphs) == 48 and {r['index'] for r in graphs} == set(selected)
    for graph in graphs:
        source = selected[graph['index']]
        assert graph['prompt'] == source['prompt']
        serialized = json.dumps(graph['prompt'],ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
        assert hashlib.sha256(serialized.encode()).hexdigest() == graph['source_prompt_sha256']
        nodes = {r['id']:r for r in graph['nodes']}
        assert len(nodes) == len(graph['nodes']) and nodes
        assert all(r['quote'] in source['prompt'] and r['meaning'] for r in nodes.values())
        assert len({r['id'] for r in graph['relations']}) == len(graph['relations'])
        assert all(r['from'] in nodes and r['to'] in nodes and r['quote'] in source['prompt'] for r in graph['relations'])
        if graph['index'] in old_graphs:
            assert graph == old_graphs[graph['index']]
    summary = load(directory / 'summary.json')
    assert sum(len(r['nodes']) for r in graphs) == summary['nodes'] == 293
    assert sum(len(r['relations']) for r in graphs) == summary['relations'] == 205
    directory = ROOT / 'repair-blinded-review-material'
    review_hash = manifest(directory)
    mapping = load(directory / 'private-mapping.json')
    packets = load(directory / 'hypothesis-review.json')
    representations = load(directory / 'representation-review.json')
    assert len(mapping) == len(packets) == 52 and len(representations) == 48
    sources = {r['index']:r for r in load(ROOT / 'registration/sources.json')}
    packet_map = {r['identity']:r for r in packets}
    assert len(packet_map) == 52
    hypotheses, prepared = 0, 0
    for entry in mapping:
        packet = packet_map[entry['identity']]
        assert packet['source_prompt'] == sources[entry['index']]['prompt']
        assert packet['missing_preparation'] == (not packet['candidates'])
        hypotheses += len(packet['candidates'])
        prepared += bool(packet['candidates'])
        for candidate in packet['candidates']:
            assert all(q in packet['source_prompt'] for q in candidate['source_quotes'])
            assert len(candidate['realizations']) == 3
            assert all({'P','N'} <= r['prompts'].keys() for r in candidate['realizations'])
    assert hypotheses == 182 and prepared == 49
    for record in representations:
        graph = next(r for r in graphs if r['prompt'] == record['source_prompt'])
        assert record['nodes'] == graph['nodes'] and record['relations'] == graph['relations']
    protocol = load(directory / 'protocol.json')
    assert protocol['review_outputs_present'] is False and protocol['authored_hypotheses'] == 182
    verified = dict(status='verified_source_only_material_review_deferred',authored_graphs=48,nodes=293,relations=205,
        prepared_task_units=49,hypotheses=182,unprepared_task_units=3,
        graph_manifest_sha256=graph_hash,review_manifest_sha256=review_hash,
        original_39_graphs_unchanged=True,semantic_accuracy=None)
    destination = Path('results/graph-guided-20260928/repair-material-independent-verification.json')
    if destination.exists():
        assert load(destination) == verified
    else:
        destination.write_text(json.dumps(verified,indent=2),encoding='utf-8')
    print(json.dumps(verified))


def verify_precision():
    results_root = Path('results/graph-guided-20260928')
    directory = results_root / 'precision-diagnostic'
    manifest(directory)
    protocol = load(directory / 'protocol.json')
    assert protocol['status'] == 'POST_OUTCOME_PRECISION_DIAGNOSTIC'
    assert protocol['comparison_family_positions'] == 4 and protocol['bootstrap_draws'] == 10000
    assert protocol['seed'] == 20260928 and protocol['new_model_calls'] == protocol['new_structure_searches'] == 0
    table = results_root / 'research-tables-download'
    assert manifest(table) == protocol['table_manifest_sha256']
    source_root = ROOT / 'registration'
    manifest(source_root)
    sources = {row['index']: row for row in load(source_root / 'sources.json')}
    groups, policies = defaultdict(list), defaultdict(dict)
    for evidence in load(table / 'evidence.json'):
        assert digest(Path(evidence['path'])) == evidence['sha256']
        if evidence['cohort'] == 'privacy_sensitivity':
            continue
        verified = load(Path(evidence['path']))
        assert verified['status'] == 'verified'
        for record in verified['records']:
            groups[record['index'], record['candidate_slot'], record['arm']].append(record)
        for policy in verified['policy_rows']:
            if policy['method'] in ('tsg_ridge', 'text_ridge'):
                policies[policy['index']][policy['method']] = policy['action']
    vectors = defaultdict(dict)
    for index in sorted({key[0] for key in groups}):
        for slot in (0, 2):
            p, n = groups[index, slot, 'P'], groups[index, slot, 'N']
            assert len(p) == len(n) == 3
            difference = (sum(row['security'] == 'secure' for row in p)
                          -sum(row['security'] == 'secure' for row in n))/3
            vectors[index]['ordinary_'+str(slot)] = dict(difference=difference,
                behavior_lower=difference-sum(row['security'] == 'unknown' for row in n)/3,
                behavior_upper=difference+sum(row['security'] == 'unknown' for row in p)/3)
        if index in policies:
            selected = []
            for method in ('tsg_ridge', 'text_ridge'):
                action = policies[index][method]
                slot = None if action == 'R' else int(action.split(':')[1])
                rows = groups[index, slot, 'R' if slot is None else 'P']
                assert len(rows) == 3
                selected.append((sum(row['security'] == 'secure' for row in rows)/3,
                                 sum(row['security'] == 'unknown' for row in rows)/3))
            difference = selected[0][0]-selected[1][0]
            vectors[index]['tsg_minus_text'] = dict(difference=difference,
                behavior_lower=difference-selected[1][1], behavior_upper=difference+selected[0][1])
    observed_vectors = load(directory / 'task_vectors.json')
    assert set(observed_vectors) == {str(index) for index in vectors}
    for index, queries in vectors.items():
        assert set(queries) == set(observed_vectors[str(index)])
        for query, values in queries.items():
            for field, value in values.items():
                assert np.isclose(observed_vectors[str(index)][query][field], value, atol=1e-14, rtol=0)
    comparisons = {row['comparison']: row for row in load(directory / 'comparisons.json')}
    checked = []
    for query in ('ordinary_0', 'ordinary_2', 'tsg_minus_text'):
        strata = defaultdict(list)
        for index, values in vectors.items():
            if query in values:
                strata[sources[index]['source_lineage_id'], sources[index]['representation']].append(values[query])
        distribution, size = np.array([1.]), 0
        for stratum in sorted(strata):
            values = strata[stratum]
            increments = np.array([round(3*row['difference']) for row in values], dtype=int)
            assert all(np.isclose(integer/3, row['difference'], atol=1e-14, rtol=0)
                       for integer, row in zip(increments, values, strict=True))
            frequencies = np.bincount(increments+3, minlength=7)/len(values)
            for _ in values:
                distribution = np.convolve(distribution, frequencies)
            size += len(values)
        assert np.isclose(distribution.sum(), 1, atol=1e-12, rtol=0)
        support = (np.arange(len(distribution))-3*size)/(3*size)
        cumulative = np.cumsum(distribution)
        exact = [float(support[np.searchsorted(cumulative, tail)]) for tail in (.00625, .99375)]
        current = comparisons[query]
        assert current['task_units'] == size
        mean = np.mean([row[query]['difference'] for row in vectors.values() if query in row])
        assert np.isclose(current['mean'], mean, atol=1e-14, rtol=0)
        assert np.isclose(np.dot(distribution, support), mean, atol=1e-12, rtol=0)
        differences = [float(first-second) for first, second in zip(current['exploratory_interval_98_75'], exact, strict=True)]
        assert max(abs(value) for value in differences) <= 2/(3*size)
        checked.append(dict(comparison=query, task_units=size, exact_empirical_bootstrap_interval_98_75=exact,
                            Monte_Carlo_quantile_difference=differences,
                            singleton_strata=[list(key) for key, rows in strata.items() if len(rows) == 1]))
    assert comparisons['TSG_minus_Raw_hypothesis_quality']['status'] == 'NOT_COMPUTED_INDEPENDENT_SEMANTIC_REVIEW_MISSING'
    verified = dict(status='VERIFIED_ACTUAL_VECTORS_AND_EXACT_EMPIRICAL_BOOTSTRAP',
        input_manifest_sha256=digest(directory / 'manifest.json'), comparisons=checked,
        original_primary_family_complete=False,
        interpretation='Independent label arithmetic and exact convolution check the empirical resampling distribution. They do not validate population exchangeability, independent semantic quality or full-panel coverage.')
    destination = results_root / 'precision-independent-verification.json'
    if destination.exists():
        assert load(destination) == verified
    else:
        destination.write_text(json.dumps(verified, indent=2), encoding='utf-8')
    print(json.dumps(verified))


def verify_position():
    inputs = ROOT / 'position-diagnostic-inputs'
    outputs = Path('results/graph-guided-20260928/position-diagnostic-output')
    input_hash = manifest(inputs)
    protocol = load(inputs / 'protocol.json')
    assignments = load(inputs / 'assignments.json')
    references = {(row['index'], row['version']): row for row in load(inputs / 'references.json')}
    assert protocol['status'] == 'FROZEN_GRAPH_GUIDED_POSITION_DIAGNOSTIC'
    assert len(assignments) == protocol['code_requests'] == 28
    assert Counter(row['arm'] for row in assignments) == dict(P=14, N=14)
    manifest(outputs / 'preoutcome')
    assert load(outputs / 'preoutcome/assignments.json') == assignments
    assert load(outputs / 'preoutcome/protocol.json') == protocol
    manifest(outputs / 'summary')
    observed = {row['slot']: row for row in load(outputs / 'summary/results.json')}
    assert len(observed) == 28
    cases = {}
    for binding in load(inputs / 'bindings.json'):
        directory = ROOT / f"prepared/case-{binding['index']:04d}"
        assert manifest(directory) == binding['case_manifest_sha256']
        cases[binding['index']] = load(directory / 'case.json')
    rows, paired_prompts = [], defaultdict(dict)
    for assigned in assignments:
        index, version, arm = assigned['index'], assigned['version'], assigned['arm']
        case = cases[index]
        reference = references[index, version]
        assert assigned['seed'] == reference['seed']
        source, interface = case['source']['prompt'], case['author_card']['interface']
        shared = case['author_card']['shared_realization_instructions'][int(version[1:])-1]
        requirement = reference['source_requirement']
        expected = '\n\n'.join((requirement, source, interface, shared) if arm == 'P'
                                else (source, requirement, interface, shared))
        assert assigned['prompt'] == expected
        assert hashlib.sha256(expected.encode()).hexdigest() == assigned['prompt_sha256']
        paired_prompts[index, version][arm] = expected
        directory = outputs / assigned['slot']
        manifest(directory / 'result')
        result = load(directory / 'result/result.json')
        assert result == observed[assigned['slot']]
        for field in ('index', 'task_unit_id', 'candidate_slot', 'version', 'arm', 'seed', 'prompt_sha256'):
            assert result[field] == assigned[field]
        if result['status'] == 'returned':
            code = (directory / 'code.py').read_text(encoding='utf-8')
            raw_code = (directory / 'raw_code.py').read_text(encoding='utf-8')
            assert hashlib.sha256(code.encode()).hexdigest() == result['code_sha256']
            assert hashlib.sha256(raw_code.encode()).hexdigest() == result['raw_code_sha256']
            tokens = MarkdownIt().parse(raw_code)
            expected_code = (tokens[0].content if len(tokens) == 1 and tokens[0].type == 'fence'
                             and tokens[0].info.strip().lower() in {'python', 'py'} else raw_code)
            assert code == expected_code
            request = load(directory / 'measurement-request.json')
            assert request['code'] == code
            assert request['tests'] == assigned['measurements'][0]['tests'] == case['measurements']['tests']
        rows.append(dict(index=index, version=version, arm=arm, slot=assigned['slot'], **labels(result)))
    for pair in paired_prompts.values():
        assert Counter(pair['P'].split()) == Counter(pair['N'].split())
        assert pair['P'] != pair['N']
    effects = []
    for index in sorted(cases):
        arms = {}
        for arm in ('P', 'N'):
            selected = [row for row in rows if row['index'] == index and row['arm'] == arm]
            assert len(selected) == 2
            arms[arm] = {field: float(np.mean([row[field] for row in selected]))
                         for field in ('secure_yield', 'functional_yield', 'joint_yield')}
        effects.append(dict(index=index, arms=arms, differences={field: arms['P'][field]-arms['N'][field]
                       for field in ('secure_yield', 'functional_yield', 'joint_yield')}))
    rng = np.random.default_rng(20260935)
    draws = {field: [] for field in ('secure_yield', 'functional_yield', 'joint_yield')}
    for _ in range(2000):
        sampled = rng.choice(len(effects), len(effects), replace=True)
        for field in draws:
            draws[field].append(float(np.mean([effects[int(index)]['differences'][field] for index in sampled])))
    contrasts = {field: dict(difference=float(np.mean([row['differences'][field] for row in effects])),
                            interval_95=np.quantile(values, [.025, .975]).tolist())
                 for field, values in draws.items()}
    destination = Path('results/graph-guided-20260928/position-independent-verification.json')
    verified = dict(status='verified', input_manifest_sha256=input_hash,
        assignments=28, task_units=7, records=rows, effects=effects, contrasts=contrasts,
        security_labels=dict(Counter(row['security'] for row in rows)),
        functionality_labels=dict(Counter(row['functionality'] for row in rows)),
        generation_statuses=dict(Counter(row['generation_status'] for row in rows)))
    if destination.exists():
        assert load(destination) == verified
    else:
        destination.write_text(json.dumps(verified, indent=2), encoding='utf-8')
    print(json.dumps(dict(status='verified', assignments=28, contrasts=contrasts, effects=effects)))


def verify_stream_infinite():
    inputs = ROOT / 'measurement/stream-infinite-diagnostic-inputs'
    outputs = Path('results/graph-guided-20260928/stream-infinite-diagnostic-output')
    input_hash = manifest(inputs)
    finite = load(Path('results/graph-guided-20260928/heldout-stream-independent-verification.json'))
    assert finite['status'] == 'verified' and finite['assignments'] == 21
    names = load(inputs / 'manifest.json')['files']
    assert len(names) == 25
    expected_generated = {'generated-'+row['slot']+'.json' for row in finite['records']}
    expected_controls = {'control-'+name+'.json' for name in ('secure', 'vulnerable', 'reject_all', 'overrestrictive')}
    assert set(names) == expected_generated | expected_controls
    qualification = ROOT / 'measurement/stream_total_budget-qualification-inputs-stream'
    manifest(qualification)
    observations = []
    for name in sorted(names):
        request = load(inputs / name)
        assert request['channel_timeout_seconds'] == 5 and request['trace_assertions'] is False
        assert request['tests'] == {'security': (ROOT / 'measurement/stream_total_budget-infinite.py').read_text(encoding='utf-8')}
        if name in expected_generated:
            slot = name.removeprefix('generated-').removesuffix('.json')
            code = Path('results/graph-guided-20260928/heldout-stream-diagnostic') / slot / 'code.py'
            assert request['code'] == code.read_text(encoding='utf-8')
            assert request['entry_point'] == 'process_data_stream'
        else:
            control = name.removeprefix('control-').removesuffix('.json')
            original = load(qualification / (control+'.json'))
            assert request['code'] == original['code'] and request['entry_point'] == original['entry_point']
        result = load(outputs / name)
        assert result['status'] == 'measured'
        channel = result['channels']['security']
        behavior = None
        if channel['status'] == 'passed':
            behavior = channel['observation']['infinite_stream_behavior']
            assert channel['observation']['security_label'] == 'unknown'
            assert channel['observation']['input'] == '/dev/zero'
            assert behavior in {'MemoryError', 'returned'}
        observations.append(dict(name=name, channel_status=channel['status'], behavior=behavior,
                                 output_sha256=digest(outputs / name)))
    controls = {row['name']: row for row in observations if row['name'] in expected_controls}
    assert controls['control-vulnerable.json']['channel_status'] == 'timeout'
    assert all(controls['control-'+name+'.json']['behavior'] == 'MemoryError'
               for name in ('secure', 'reject_all', 'overrestrictive'))
    summary = dict(Counter(row['behavior'] or row['channel_status'] for row in observations
                           if row['name'] in expected_generated))
    verified = dict(status='verified_post_outcome_behavior', input_manifest_sha256=input_hash,
                    requests=25, code_generation_calls=0, generated_behavior_counts=summary,
                    records=observations, original_primary_labels_modified=False,
                    interpretation='Real infinite OS stream behavior only; exception observations do not prove an exact byte bound or universal resource safety.')
    destination = Path('results/graph-guided-20260928/stream-infinite-independent-verification.json')
    if destination.exists():
        assert load(destination) == verified
    else:
        destination.write_text(json.dumps(verified, indent=2), encoding='utf-8')
    print(json.dumps(dict(status=verified['status'], requests=25, generated_behavior_counts=summary)))


def verify_targets():
    result_root = Path('results/graph-guided-20260928')
    diagnostic = result_root / 'target-coverage-diagnostic'
    diagnostic_hash = manifest(diagnostic)
    summary = load(diagnostic / 'summary.json')
    reported_tasks = {row['index']: row for row in load(diagnostic / 'tasks.json')}
    reported_graphs = {row['index']: row for row in load(diagnostic / 'graph_entries.json')}
    names = ('development-execution-inputs-v2', 'development-execution-inputs-batch2',
             'heldout-execution-inputs', 'heldout-execution-inputs-remaining',
             'heldout-execution-inputs-performance', 'heldout-execution-inputs-stream',
             'heldout-execution-inputs-download')
    panel = {row['index']: row for row in load(ROOT / 'scaled-panel/selection.json')}
    requests = defaultdict(list)
    for name in names:
        manifest(ROOT / name)
        for request in load(ROOT / name / 'assignments.json'):
            requests[request['index']].append(request)
    assert set(requests) == set(reported_tasks)
    candidates, targets, omitted_targets, nodes_unused, edges_unused = 0, 0, 0, [], []
    single_types, allowed_operations, graph_indices = Counter(), set(), []
    for index, assigned in sorted(requests.items()):
        suffix = '-v2' if index in (38, 206) else ''
        directory = ROOT / f'prepared/case-{index:04d}{suffix}'
        manifest(directory)
        case = load(directory / 'case.json')
        assert case['source']['task_unit_id'] == panel[index]['task_unit_id']
        assert case['source']['role'] == panel[index]['role']
        choices = {row['slot']: row for row in case['candidates']}
        for request in assigned:
            if request['arm'] not in {'P', 'N'}:
                continue
            variants = {row['id']: row for row in choices[request['candidate_slot']]['realizations']}
            assert variants[request['version']]['prompts'][request['arm']] == request['prompt']
        entries = case['targets']['enumerated_targets']
        chosen = {row['id'] for row in case['targets']['selected_targets']}
        omitted = [row for row in entries if row['id'] not in chosen]
        assert all(row.get('nonselection_reason') is None for row in omitted)
        candidates += len(choices)
        targets += len(entries)
        omitted_targets += len(omitted)
        assert reported_tasks[index]['candidates'] == len(choices)
        assert reported_tasks[index]['enumerated_targets'] == len(entries)
        if case['source']['representation'] == 'Raw':
            assert index not in reported_graphs
            continue
        graph_indices.append(index)
        ordinary = [row for row in entries if row['category'] in {'ordinary_node', 'ordinary_relation'}]
        node_types = {row['id']: row['type'] for row in case['targets']['nodes']}
        used_nodes = set().union(*(set(row['nodes']) for row in entries))
        used_edges = set().union(*(set(row['relations']) for row in entries))
        outside_nodes = sorted(set(node_types)-used_nodes)
        outside_edges = sorted({row['id'] for row in case['targets']['relations']}-used_edges)
        assert outside_nodes == sorted(row['id'] for row in reported_graphs[index]['nodes_outside_all_enumerated_targets'])
        assert outside_edges == sorted(row['id'] for row in reported_graphs[index]['relations_outside_all_enumerated_targets'])
        if outside_nodes:
            nodes_unused.append(index)
        if outside_edges:
            edges_unused.append(index)
        for row in ordinary:
            allowed_operations.update(row['allowed_operations'])
            if len(row['nodes']) == 1:
                single_types[node_types[row['nodes'][0]]] += 1
    assert (summary['task_units'], summary['prepared_candidates'], summary['TSG_tasks']) == (len(requests), candidates, len(graph_indices))
    assert (summary['enumerated_targets'], summary['unselected_targets'], summary['unselected_targets_without_explicit_reason']) == (targets, omitted_targets, omitted_targets)
    assert summary['ordinary_single_node_types'] == dict(single_types)
    assert summary['ordinary_allowed_operations'] == sorted(allowed_operations)
    assert summary['TSG_tasks_with_nodes_outside_all_targets'] == len(nodes_unused)
    assert summary['TSG_tasks_with_relations_outside_all_targets'] == len(edges_unused)
    verified = dict(status='VERIFIED_FROZEN_TARGET_COVERAGE_AND_PROMPT_BINDING',
        diagnostic_manifest_sha256=diagnostic_hash, task_units=len(requests), candidates=candidates,
        enumerated_targets=targets, unselected_targets=omitted_targets, TSG_task_indices=graph_indices,
        ordinary_allowed_operations=sorted(allowed_operations), ordinary_single_node_types=dict(single_types),
        tasks_with_unused_graph_nodes=nodes_unused, tasks_with_unused_graph_relations=edges_unused,
        independent_semantic_review=False, new_model_calls=0, new_structure_searches=0)
    destination = result_root / 'target-coverage-independent-verification.json'
    if destination.exists():
        assert load(destination) == verified
    else:
        destination.write_text(json.dumps(verified, indent=2), encoding='utf-8')
    print(json.dumps(verified))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--position', action='store_true')
    parser.add_argument('--remaining', action='store_true')
    parser.add_argument('--performance', action='store_true')
    parser.add_argument('--stream', action='store_true')
    parser.add_argument('--download', action='store_true')
    parser.add_argument('--precision', action='store_true')
    parser.add_argument('--targets', action='store_true')
    parser.add_argument('--stream-infinite', action='store_true')
    parser.add_argument('--repair', action='store_true')
    parser.add_argument('--repair-source', action='store_true')
    parser.add_argument('--repair-preparation', action='store_true')
    parser.add_argument('--repair-material', action='store_true')
    options = parser.parse_args()
    if options.repair_material:
        verify_repair_material()
    elif options.repair_preparation:
        verify_repair_preparation()
    elif options.repair or options.repair_source:
        verify_repair(options.repair_source)
    elif options.targets:
        verify_targets()
    elif options.precision:
        verify_precision()
    elif options.stream_infinite:
        verify_stream_infinite()
    elif options.position:
        verify_position()
    else:
        main(options.remaining, options.performance, options.stream, options.download)
