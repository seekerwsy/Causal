from collections import defaultdict
from math import isclose, isfinite
from pathlib import Path

from prompt_mechanism_study.artifact_io import read_json, verify_bundle
from prompt_mechanism_study.records import canonical_json, content_hash


REPO = Path(__file__).resolve().parents[2]
INPUT = REPO / 'data/method/graph-guided-20260930/training-semantic-inputs'
MAPPING = REPO / 'data/method/graph-guided-20260930/training-semantic-mapping/frozen'
EFFECTS = REPO / 'results/graph-guided-20260930/training-uniform-measurement'
LEARNING = REPO / 'results/graph-guided-20260930/training-learning'


def main():
    for folder in (INPUT, MAPPING, EFFECTS, LEARNING):
        verify_bundle(folder)
    candidates = {row['mapping_id']: row for row in read_json(INPUT / 'candidates.json')}
    mapping = read_json(MAPPING / 'mapping.json')
    effects = {(row['batch'], row['candidate_id']): row
               for row in read_json(EFFECTS / 'effects.json')}
    rows = read_json(LEARNING / 'training-rows.json')
    category = read_json(LEARNING / 'category.json')
    ridge = read_json(LEARNING / 'ridge.json')
    summary = read_json(LEARNING / 'summary.json')
    eligible = {row['mapping_id']: row for row in mapping['records']
                if row['training_qualification'] == 'eligible'}
    if len(candidates) != 71 or len(effects) != 71 or len(eligible) != len(rows) != 37:
        raise ValueError('训练候选或效果身份数量不符')
    if {row['mapping_id'] for row in rows} != set(eligible):
        raise ValueError('冻结训练样本不等于结果盲资格集合')
    by_task = defaultdict(list)
    by_class = defaultdict(lambda: defaultdict(list))
    for row in rows:
        source = candidates[row['mapping_id']]
        definition = mapping['classes'][eligible[row['mapping_id']]['class_key']]['semantic_class']
        effect = effects[(source['batch'], source['candidate_id'])]
        if (row['candidate_id'] != source['candidate_id']
                or row['task_unit_id'] != source['task_unit_id']):
            raise ValueError('训练任务身份不一致')
        if row['task_unit_id'] != effect['task_unit_id']:
            raise ValueError('统一效果任务身份不一致')
        if row['semantic_class_id'] != content_hash(canonical_json(definition)):
            raise ValueError('六字段类身份不一致')
        if row['canonical_text'] != source['source_prompt'] + '\n' + source['execution_interface']:
            raise ValueError('文本学习器来源特征不一致')
        for arm in ('p', 'n'):
            if row[f'{arm}_versions'] != list(dict.fromkeys(source[f'{arm}_versions'])):
                raise ValueError('真实编辑版本去重不一致')
        if row['orientation'] != 1 or row['delta_pn'] != effect['delta_pn']:
            raise ValueError('效果方向或数值不一致')
        by_task[row['task_unit_id']].append(row['delta_pn'])
        by_class[row['semantic_class_id']][row['task_unit_id']].append(row['delta_pn'])
    global_mean = sum(sum(values) / len(values) for values in by_task.values()) / len(by_task)
    if not isclose(global_mean, category['global_mean'], abs_tol=1e-12):
        raise ValueError('任务等权总体效果不一致')
    if set(category['categories']) != set(by_class):
        raise ValueError('训练语义类别集合不一致')
    for identity, tasks in by_class.items():
        record = category['categories'][identity]
        means = [sum(values) / len(values) for values in tasks.values()]
        expected = ((sum(means) + 2 * global_mean) / (len(means) + 2)
                    if len(means) >= 4 else global_mean)
        if (record['tasks'] != len(tasks)
                or not isclose(record['prediction'], expected, abs_tol=1e-12)):
            raise ValueError('类别任务数或收缩预测不一致')
    if (len(by_task) != summary['tasks'] or max(len(tasks) for tasks in by_class.values()) != 2
            or summary['supported_semantic_classes'] != 0):
        raise ValueError('类别独立支持结论不一致')
    if (ridge['alpha'] not in (.1, 1., 10., 100.)
            or len(ridge['coefficients']) != 513
            or any(not isfinite(value) for value in ridge['coefficients'])):
        raise ValueError('冻结文本模型参数无效')
    baseline_errors = []
    for task, values in by_task.items():
        other = [sum(group) / len(group) for identity, group in by_task.items()
                 if identity != task]
        prediction = sum(other) / len(other)
        baseline_errors.append(sum((value - prediction) ** 2 for value in values) / len(values))
    baseline_mse = sum(baseline_errors) / len(baseline_errors)
    print(f"已独立核对{len(rows)}项训练候选、{len(by_task)}项任务和"
          f"{len(by_class)}个类别；最大类别任务支持数为2；"
          f"常数预测的任务留一误差为{baseline_mse:.6f}")


if __name__ == '__main__':
    main()
