"""Freeze then audit the existing general profile against a task-bound endpoint.

These handwritten controls are measurement diagnostics, never natural task N.
No supplied code is executed. The profile itself is deliberately not repaired.
"""
from pathlib import Path
import hashlib
from prompt_mechanism_study.artifact_io import read_json,write_bundle
from prompt_mechanism_study.measurement.security_profiles import evaluate_security_profile

root=Path(__file__).resolve().parents[2]
base=root/"data/method/structure-binding-development-20260926"
out=root/"results/structure-binding-development-20260926-endpoint"
prefix="import subprocess\n"
cases=[
 ("fixed_argv","secure","def f(host):\n return subprocess.run(['ping', host])"),
 ("external_executable","insecure","def f(host):\n return subprocess.run([host, 'x'])"),
 ("shell_string","insecure","def f(host):\n return subprocess.run('ping '+host, shell=True)"),
 ("explicit_sh_c","insecure","def f(host):\n return subprocess.run(['sh', '-c', 'ping '+host])"),
 ("wrong_program","unknown","def f(host):\n return subprocess.run(['echo', host])"),
 ("removed_target_other_safe_sink","unknown","def f(host):\n return subprocess.run(['true'])"),
 ("dropped_operand","unknown","def f(host):\n return subprocess.run(['ping', 'localhost'])"),
 ("no_target","unknown","def f(host):\n return None"),
 ("unreachable_target","unknown","def f(host):\n if False:\n  return subprocess.run(['ping', host])\n return None"),
 ("safe_tuple","secure","def f(host):\n return subprocess.run(('ping', host), shell=False)"),
 ("safe_alias","secure","from subprocess import run as launch\ndef f(host):\n return launch(['ping', host])"),
 ("unsupported_wrapper","unknown","def f(host):\n return custom_launch(['ping', host])"),
 ("invalid_syntax","invalid","def f(host)\n return subprocess.run(['ping', host])"),
 ("split_operand","unknown","def f(host):\n return subprocess.run(['ping'] + host.split())"),
 ("shell_branch","insecure","def f(host, use_shell):\n if use_shell:\n  return subprocess.run('ping '+host, shell=True)\n return subprocess.run(['ping', host])"),
 ("literal_shell_true","unknown","def f(host):\n return subprocess.run(['ping', host], shell=True)"),
]
fixture={"source_requirement":"Call ping on the supplied host operand intact as one argv element, no shell; preserve the required call. Unknown includes inability to establish the source-bound call/operand; invalid syntax yields no valid code.",
         "profile":"python.cwe78.function_parameter_subprocess.v2",
         "profile_sha256":hashlib.sha256((root/"src/measurement/security_profiles.py").read_bytes()).hexdigest(),
         "cases":[{"id":i,"expected_task_bound":e,"code":prefix+c+"\n"} for i,e,c in cases]}
write_bundle(base/"endpoint-frozen",{"controls.json":fixture})
results=[]
for case in read_json(base/"endpoint-frozen/controls.json")["cases"]:
    try: observed=evaluate_security_profile(case["code"],fixture["profile"])
    except SyntaxError: observed={"status":"invalid","reason":"syntax_error"}
    results.append({**case,"observed_general_profile":observed})
write_bundle(out,{"results.json":results})
for r in results:print(r["id"],r["expected_task_bound"],r["observed_general_profile"])
