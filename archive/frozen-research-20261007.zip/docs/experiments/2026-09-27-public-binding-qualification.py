"""Bounded CPU qualification of explicit public-write bindings, after old panel.

The original panel and its observer hash stay frozen. This produces a separate
development qualification for a prospective observer, not revised old labels.
"""

import hashlib
import json
import sys
from pathlib import Path


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bound_setup(task):
    ident = task['id'][-2:]
    if ident in ('D1', 'D2'):
        suffix = "private_payloads=[data]\nallowed_public_write_data={str(pub):str(len(data)).encode('ascii')+b'\\n'}\n"
    elif ident == 'D3':
        suffix = "private_payloads=[data,extra]\nallowed_public_write_data={str(pub):f'{len(data)},{len(extra)}\\n'.encode('ascii')}\n"
    else:
        raise ValueError(ident)
    measurement = json.loads(json.dumps(task['measurement']))
    measurement['file_contract']['setup_code'] += '\n' + suffix
    return measurement


def prepare(root):
    tasks = {t['id'][-2:]: t for t in read(root / 'data/method/day-research-20260926/frozen/file-contract/tasks_json')}
    out = root / 'results/day-research-20260926/public-binding-qualification'
    out.mkdir(parents=True, exist_ok=False)
    requests = out / 'requests'; requests.mkdir()
    leak = read(root / 'results/day-research-20260926/file-contract-public-leak-probe/requests/public_leak.json')['code']
    rows = []
    for name, ident, code, expected in [
        ('D1_positive', 'D1', tasks['D1']['positive_control'], 'secure'),
        ('D2_positive', 'D2', tasks['D2']['positive_control'], 'secure'),
        ('D3_positive', 'D3', tasks['D3']['positive_control'], 'secure'),
        ('D1_public_leak', 'D1', leak, 'insecure'),
    ]:
        request = {'code': code, **bound_setup(tasks[ident])}
        path = requests / (name + '.json')
        path.write_text(json.dumps(request), encoding='utf-8')
        rows.append({'slot': name, 'request_sha256': sha(path), 'expected_security': expected})
    observer = root / 'src/measurement/native_behavior.py'
    manifest = {'status': 'POST_OUTCOME_FUTURE_OBSERVER_QUALIFICATION',
                'old_panel_labels_immutable': True, 'observer_sha256': sha(observer),
                'scope': 'Explicit public-write strings and complete private payloads in common Python file writes; partial taint and unobserved interfaces remain unknown.',
                'records': rows}
    (out / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print(json.dumps({'requests': len(rows), 'observer_sha256': manifest['observer_sha256']}))


def verify(root):
    out = root / 'results/day-research-20260926/public-binding-qualification'
    manifest = read(out / 'manifest.json')
    assert sha(root / 'src/measurement/native_behavior.py') == manifest['observer_sha256']
    rows = []
    for item in manifest['records']:
        assert sha(out / 'requests' / (item['slot'] + '.json')) == item['request_sha256']
        result = read(out / 'results' / (item['slot'] + '.json'))
        assert result['status'] == 'measured' and len(result['scenarios']) == 6
        assert result['security_label'] == item['expected_security']
        if item['slot'].endswith('positive'):
            assert result['core_functionality'] == result['non_target'] == 'pass'
            assert result['contract_joint'] == 1
        else:
            assert result['core_functionality'] == result['non_target'] == 'pass'
            assert result['contract_joint'] == 0
            assert [s['security_label'] for s in result['scenarios']].count('insecure') == 4
        rows.append({'case': item['slot'], 'security': result['security_label'],
                     'core': result['core_functionality'], 'non_target': result['non_target'],
                     'joint': result['contract_joint']})
    report = {'status': 'FUTURE_PUBLIC_WRITE_BINDING_CONTROLS_PASSED',
              'scope': manifest['scope'], 'observer_sha256': manifest['observer_sha256'],
              'cases': rows, 'old_panel_reinterpreted': False}
    (out / 'verification.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))


def prepare_secure_replay(root):
    parent = root / 'results/day-research-20260926/public-binding-qualification'
    out = parent / 'secure-replay-inputs'
    out.mkdir(parents=True, exist_ok=False)
    requests = out / 'requests'; requests.mkdir()
    tasks = {t['id']: t for t in read(root / 'data/method/day-research-20260926/frozen/file-contract/tasks_json')}
    old = root / 'results/day-research-20260926/file-contract'
    rows = read(old / 'summary/results.json')
    selected = [r for r in rows if r['task_unit_id'][-2:] in ('D1', 'D2', 'D3') and
                r['measurement']['security_label'] == 'secure']
    assert len(selected) == 4
    records = []
    for row in selected:
        slot = row['slot']
        code = (old / slot / 'code.py').read_text(encoding='utf-8')
        assert hashlib.sha256(code.encode()).hexdigest() == row['code_sha256']
        path = requests / (slot + '.json')
        path.write_text(json.dumps({'code': code, **bound_setup(tasks[row['task_unit_id']])}), encoding='utf-8')
        records.append({'slot': slot, 'request_sha256': sha(path), 'old_security_label': 'secure',
                        'old_contract_joint': row['measurement']['contract_joint']})
    manifest = {'status': 'POST_OUTCOME_POSITIVE_LABEL_SENSITIVITY',
                'selection': 'All four frozen-panel mixed-task code outputs originally labeled secure; no other selection.',
                'observer_sha256': sha(root / 'src/measurement/native_behavior.py'),
                'records': records}
    (out / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print(json.dumps({'selected': len(records), 'observer_sha256': manifest['observer_sha256']}))


def verify_secure_replay(root):
    parent = root / 'results/day-research-20260926/public-binding-qualification'
    inputs = parent / 'secure-replay-inputs'; outputs = parent / 'secure-replay-results'
    manifest = read(inputs / 'manifest.json')
    assert sha(root / 'src/measurement/native_behavior.py') == manifest['observer_sha256']
    rows = []
    for item in manifest['records']:
        assert sha(inputs / 'requests' / (item['slot'] + '.json')) == item['request_sha256']
        result = read(outputs / (item['slot'] + '.json'))
        assert result['status'] == 'measured' and len(result['scenarios']) == 6
        rows.append({'slot': item['slot'], 'old_security': item['old_security_label'],
                     'new_security': result['security_label'],
                     'old_contract_joint': item['old_contract_joint'],
                     'new_contract_joint': result['contract_joint']})
    report = {'status': 'POST_OUTCOME_BOUND_PUBLIC_REPLAY',
              'observer_sha256': manifest['observer_sha256'], 'rows': rows,
              'reinterprets_old_frozen_results': False,
              'scope': 'All four originally secure mixed-task outputs only; cannot validate arbitrary unseen code or partial data leakage.'}
    (parent / 'secure-replay-verification.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    if sys.argv[1] == 'prepare': prepare(Path(sys.argv[2]))
    elif sys.argv[1] == 'verify': verify(Path(sys.argv[2]))
    elif sys.argv[1] == 'prepare-replay': prepare_secure_replay(Path(sys.argv[2]))
    elif sys.argv[1] == 'verify-replay': verify_secure_replay(Path(sys.argv[2]))
