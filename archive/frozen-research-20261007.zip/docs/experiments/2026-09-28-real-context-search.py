import argparse
import json
import subprocess
import time
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

from prompt_mechanism_study.artifact_io import file_sha256, read_json, verify_bundle, write_bundle
from prompt_mechanism_study.development.context_algorithms import RSCRIPT, gfci, gfci_temporal
from pytetrad.tools.TetradSearch import TetradSearch


ROOT = Path('data/method/graph-guided-20260928')
INPUTS = ROOT / 'real-context-matrices'
RWORKER = Path('docs/experiments/2026-09-28-real-context-search.R')
OUTPUT_BASE = Path('results/graph-guided-20260928/real-context-search')
METHODS = ('FCI_JCI0', 'FCI_JCI1', 'FCI_JCI12', 'GFCI')


def freeze_repair():
    matrices = []
    verify_bundle(INPUTS)
    for matrix in read_json(INPUTS / 'matrices.json'):
        matrices.append(dict(matrix, role='development', identity='development:'+matrix['identity']))
    records = []
    for filename in ('heldout-independent-verification.json', 'heldout-remaining-independent-verification.json',
                     'heldout-performance-independent-verification.json', 'heldout-stream-independent-verification.json',
                     'heldout-download-independent-verification.json'):
        records.extend(read_json(Path('results/graph-guided-20260928') / filename)['records'])
    indices = sorted({row['index'] for row in records})
    assert len(indices) == 32
    rng = np.random.default_rng(2026092807)
    selected = {index: (int(rng.binomial(1, .5)), int(rng.integers(1, 4))) for index in indices}
    for category, slot in (('input_object_emphasis', 0), ('input_role_clarification', 2)):
        rows = []
        for index in indices:
            c, version = selected[index]
            observed = next(row for row in records if row['index'] == index and row['arm'] == ('P' if c else 'R')
                            and row['version'] == f'v{version}' and row['candidate_slot'] == (slot if c else None))
            source = next(row for row in read_json(ROOT / 'registration/sources.json') if row['index'] == index)
            card = read_json(ROOT / f'preparation/case-{index:04d}.json')
            x = card['source_x']['direct_security_requirement']
            assert isinstance(x, bool)
            rows.append(dict(index=index, task_unit_id=source['task_unit_id'], source_lineage_id=source['source_lineage_id'],
                             C=c, X=int(x), Y=observed['secure_yield'], request_slot=observed['slot']))
        matrices.append(dict(identity='heldout:'+category, role='heldout', n=len(rows), labels=['C','X','Y'], records=rows))
    verify_bundle(ROOT / 'algorithm-inputs')
    for matrix in read_json(ROOT / 'algorithm-inputs/matrices.json'):
        if matrix['scenario'] in ('edit_direct', 'edit_latent') and matrix['n'] in (33, 1000):
            matrices.append(dict(identity='synthetic:'+matrix['identity'], role='synthetic', n=matrix['n'],
                labels=['C','X','Y'], rows=[[row[0],row[1],row[3]] for row in matrix['rows']],
                scenario=matrix['scenario'], truth=[row for row in matrix['truth'] if row[0] != 'Z']))
    assert len(matrices) == 84
    write_bundle(ROOT / 'repair-structure-inputs', {'matrices.json': matrices, 'protocol.json': dict(
        status='FROZEN_POST_OUTCOME_DEVELOPMENT_REPAIR', searches=3536, methods=METHODS,
        random_request_seed=2026092807, bootstrap_seed=20260929, bootstrap_draws=200,
        common_knowledge=['no C/X adjacency', 'Y cannot cause C', 'Y cannot cause X'],
        JCI12_knowledge='C has no latent common cause with Y; X/Y latent confounding remains allowed',
        GFCI_knowledge='same temporal prohibitions and randomized C as JCI12',
        implementation_sha256=file_sha256(Path(__file__)), r_sha256=file_sha256(RWORKER),
        algorithms_sha256=file_sha256(Path('src/development/context_algorithms.py')),
        maximum_seconds=7200, code_generation_calls=0,
        interpretation='Heldout request sampling and all revised searches are post-outcome diagnostics; original outputs unchanged.')})


def adequate_cells(rows):
    values = np.asarray(rows)
    minima = []
    for a, b, other in ((0,2,1),(1,2,0)):
        for conditioned in (False, True):
            for value in ((0,1) if conditioned else (None,)):
                subset = values[values[:,other] == value] if conditioned else values
                cells = np.zeros((2,2))
                for row in subset:
                    cells[row[a],row[b]] += 1
                expected = np.outer(cells.sum(axis=1), cells.sum(axis=0)) / max(1,len(subset))
                minima.append(float(expected.min()))
    return min(minima) >= 5, min(minima)


def run_repair(limit):
    source = ROOT / 'repair-structure-inputs'
    verify_bundle(source)
    protocol = read_json(source / 'protocol.json')
    assert file_sha256(Path(__file__)) == protocol['implementation_sha256']
    assert file_sha256(RWORKER) == protocol['r_sha256']
    assert file_sha256(Path('src/development/context_algorithms.py')) == protocol['algorithms_sha256']
    matrices = read_json(source / 'matrices.json')
    jobs = []
    for role in ('development', 'heldout'):
        group = [m for m in matrices if m['role'] == role]
        for draw_name, task_ids in draws(group):
            for matrix in group:
                by_id = {r['task_unit_id']: r for r in matrix['records']}
                rows = [[by_id[t][key] for key in ('C','X','Y')] for t in task_ids if t in by_id]
                jobs.append((matrix,draw_name,rows))
    jobs.extend((m,'original',m['rows']) for m in matrices if m['role'] == 'synthetic')
    if limit is not None:
        jobs = jobs[:limit]
    destination = Path('results/graph-guided-20260928') / ('repair-structure-canary' if limit else 'repair-structure')
    destination.mkdir(parents=True, exist_ok=False)
    results = []
    start = time.monotonic()
    with (destination / 'r-stderr.log').open('w', encoding='utf-8') as stderr:
        process = subprocess.Popen([str(RSCRIPT),str(RWORKER)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,
            stderr=stderr,text=True,encoding='utf-8',bufsize=1)
        assert process.stdin is not None and process.stdout is not None
        for matrix, draw_name, rows in jobs:
            assert time.monotonic()-start < protocol['maximum_seconds']
            identity = matrix['identity']+':'+draw_name
            request = dict(identity=identity,n=len(rows),labels=['C','X','Y'],rows=rows,
                           fixed_gap_cx=True,temporal_background=True)
            process.stdin.write(json.dumps(request)+'\n')
            process.stdin.flush()
            adequate, minimum = adequate_cells(rows)
            for method in METHODS[:3]:
                line = process.stdout.readline()
                assert line, identity
                response = json.loads(line)
                assert response['identity'] == identity and response['method'] == method
                assert response['failure'] is None
                response.update(role=matrix['role'],category=matrix['identity'],draw=draw_name,
                                valid=adequate and not response['warnings'],minimum_expected=minimum)
                response['possible_C_to_Y'] = possible_path(response['edges'])
                results.append(response)
            edges = gfci_temporal(pd.DataFrame(rows,columns=['C','X','Y'],dtype=int))
            results.append(dict(identity=identity,method='GFCI',edges=edges,role=matrix['role'],
                category=matrix['identity'],draw=draw_name,valid=adequate,minimum_expected=minimum,
                possible_C_to_Y=possible_path(edges)))
            if len(results) % 400 == 0:
                print(json.dumps(dict(searches=len(results),seconds=time.monotonic()-start)),flush=True)
        process.stdin.close()
        assert process.wait(timeout=30) == 0
    grouped = defaultdict(list)
    for result in results:
        grouped[result['category'],result['method']].append(result)
    summary = []
    for (category,method), group in sorted(grouped.items()):
        bootstrap = [r for r in group if r['draw'] != 'original']
        valid = [r for r in bootstrap if r['valid']]
        excluded = sum(not r['possible_C_to_Y'] for r in valid)
        summary.append(dict(category=category,method=method,original=group[0],
            valid_bootstrap=len(valid),total_bootstrap=len(bootstrap),excludes_path=excluded,
            action='forbid_P' if len(valid) >= 160 and excluded >= .8*len(valid) else 'retain_common_selector'))
    write_bundle(destination / 'bundle', {'searches.json':results,'summary.json':summary,
        'completion.json':dict(searches=len(results),seconds=time.monotonic()-start,
            input_manifest_sha256=file_sha256(source / 'manifest.json'),status='EXECUTED_POST_OUTCOME_DIAGNOSTIC')})
    print(json.dumps(dict(searches=len(results),originals=[dict(category=r['category'],method=r['method'],
        edges=r['original']['edges'],valid_bootstrap=r['valid_bootstrap'],action=r['action'])
        for r in summary if not r['category'].startswith('synthetic:')]),ensure_ascii=False))


def draws(matrices):
    primary = matrices[0]['records']
    assert len({row['task_unit_id'] for row in primary}) == len(primary)
    strata = defaultdict(list)
    for row in primary:
        strata[row['source_lineage_id']].append(row['task_unit_id'])
    rng = np.random.default_rng(20260929)
    yield 'original', [row['task_unit_id'] for row in primary]
    for number in range(200):
        selected = []
        for lineage in sorted(strata):
            source = sorted(strata[lineage])
            selected.extend(rng.choice(source, size=len(source), replace=True).tolist())
        yield f'bootstrap-{number:03d}', selected


def possible_path(edges):
    adjacency = defaultdict(list)
    for source, source_end, target_end, target in edges:
        if source_end != 'ARROW' and target_end != 'TAIL':
            adjacency[source].append(target)
        if target_end != 'ARROW' and source_end != 'TAIL':
            adjacency[target].append(source)
    frontier = ['C']
    seen = {'C'}
    while frontier:
        current = frontier.pop()
        if current == 'Y':
            return True
        for nxt in adjacency[current]:
            if nxt not in seen:
                seen.add(nxt)
                frontier.append(nxt)
    return False


def gfci_with_gap(rows):
    search = TetradSearch(pd.DataFrame(rows, columns=['C', 'X', 'Y'], dtype=int))
    search.set_verbose(False)
    search.use_bdeu(sample_prior=10, structure_prior=0)
    search.use_g_square(alpha=.05)
    search.set_forbidden('C', 'X')
    search.set_forbidden('X', 'C')
    search.run_gfci(depth=-1, max_degree=-1, max_disc_path_length=-1)
    return sorted([[str(edge.getNode1().getName()), str(edge.getEndpoint1()),
                    str(edge.getEndpoint2()), str(edge.getNode2().getName())]
                   for edge in search.get_java().getEdges()])


def run(limit, common_gap):
    verify_bundle(INPUTS)
    matrices = read_json(INPUTS / 'matrices.json')
    protocol = read_json(INPUTS / 'protocol.json')
    assert protocol['structural_methods'] == list(METHODS)
    assert [matrix['n'] for matrix in matrices] == [14, 13]
    selected_draws = list(draws(matrices))
    if limit is not None:
        selected_draws = selected_draws[:limit]
    output = (OUTPUT_BASE.with_name('real-context-search-common-gap') if common_gap
              else OUTPUT_BASE if limit is not None
              else OUTPUT_BASE.with_name('real-context-search-full'))
    output.mkdir(parents=True, exist_ok=False)
    identities = {matrix['identity']: {row['task_unit_id']: row for row in matrix['records']}
                  for matrix in matrices}
    results = []
    with (output / 'r-stderr.log').open('w', encoding='utf-8') as stderr:
        process = subprocess.Popen([str(RSCRIPT), str(RWORKER)], stdin=subprocess.PIPE,
                                   stdout=subprocess.PIPE, stderr=stderr, text=True,
                                   encoding='utf-8', bufsize=1)
        assert process.stdin is not None and process.stdout is not None
        for draw_name, task_ids in selected_draws:
            for matrix in matrices:
                name = matrix['identity']
                records = [identities[name][task_id] for task_id in task_ids
                           if task_id in identities[name]]
                rows = [[record['C'], record['X'], record['Y']] for record in records]
                identity = f'{name}:{draw_name}'
                request = dict(identity=identity, n=len(rows),
                               labels=['C', 'X', 'Y'], rows=rows,
                               fixed_gap_cx=common_gap)
                process.stdin.write(json.dumps(request)+'\n')
                process.stdin.flush()
                insufficient = any(len({row[column] for row in records}) < 2
                                   for column in ('C', 'X', 'Y'))
                for method in METHODS[:3]:
                    line = process.stdout.readline()
                    if not line:
                        raise RuntimeError(f'R worker ended at {identity}; inspect r-stderr.log')
                    response = json.loads(line)
                    assert response['identity'] == identity and response['method'] == method
                    response.update(category=name, draw=draw_name, n=len(rows),
                                    input_insufficient=insufficient,
                                    valid=not insufficient and not response['warnings']
                                          and response['failure'] is None)
                    response['possible_C_to_Y'] = (possible_path(response['edges'])
                                                   if response['failure'] is None else None)
                    results.append(response)
                started = time.monotonic()
                try:
                    edges = (gfci_with_gap(rows) if common_gap else
                             gfci(pd.DataFrame(rows, columns=['C', 'X', 'Y'], dtype=int)))
                    failure = None
                except Exception as error:
                    edges = []
                    failure = f'{type(error).__name__}: {error}'
                results.append(dict(identity=identity, category=name, draw=draw_name,
                                    n=len(rows), method='GFCI', edges=edges,
                                    warnings=[], failure=failure,
                                    seconds=time.monotonic()-started,
                                    input_insufficient=insufficient,
                                    valid=not insufficient and failure is None,
                                    possible_C_to_Y=(possible_path(edges) if failure is None
                                                     else None)))
            if len(results) % 80 == 0:
                print(json.dumps(dict(searches=len(results), draws=draw_name)), flush=True)
        process.stdin.close()
        if process.wait(timeout=30):
            raise RuntimeError('R worker failed; inspect r-stderr.log')
    assert len(results) == len(selected_draws)*len(matrices)*len(METHODS)
    by_group = defaultdict(list)
    for result in results:
        by_group[(result['category'], result['method'])].append(result)
    summary = []
    for (category, method), group in sorted(by_group.items()):
        bootstrap = [row for row in group if row['draw'] != 'original']
        valid = [row for row in bootstrap if row['valid']]
        exclude = sum(not row['possible_C_to_Y'] for row in valid)
        summary.append(dict(category=category, method=method,
                            original=group[0], bootstrap_draws=len(bootstrap),
                            valid_bootstrap=len(valid),
                            failure_bootstrap=sum(row['failure'] is not None for row in bootstrap),
                            input_insufficient_bootstrap=sum(row['input_insufficient'] for row in bootstrap),
                            warning_bootstrap=sum(bool(row['warnings']) for row in bootstrap),
                            excludes_possible_path=exclude,
                            action='forbid_P' if len(valid) >= 160 and
                              exclude >= .8*len(valid) else 'retain_common_selector'))
    write_bundle(output / 'bundle', {'searches.json': results, 'summary.json': summary,
                                    'protocol.json': dict(status='EXECUTED_EXPLORATORY',
                                      input_manifest_sha256=file_sha256(INPUTS / 'manifest.json'),
                                      r_worker_sha256=file_sha256(RWORKER),
                                      python_sha256=file_sha256(Path(__file__)),
                                      seed=20260929, requested_draws=200,
                                      fixed_gap_cx=common_gap,
                                      interpretation=('POST_OUTCOME_EXPLORATORY_SENSITIVITY'
                                                      if common_gap else 'ORIGINAL_EXPLORATORY'),
                                      executed_draws=len(selected_draws)-1)})
    print(json.dumps(dict(searches=len(results), summary=[dict(
        category=row['category'], method=row['method'], original_edges=row['original']['edges'],
        valid_bootstrap=row['valid_bootstrap'], failure_bootstrap=row['failure_bootstrap'],
        input_insufficient_bootstrap=row['input_insufficient_bootstrap'],
        warning_bootstrap=row['warning_bootstrap'],
        excludes_possible_path=row['excludes_possible_path'], action=row['action'])
        for row in summary])))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--limit', type=int)
    parser.add_argument('--common-gap', action='store_true')
    parser.add_argument('--repair', action='store_true')
    parser.add_argument('--freeze-repair', action='store_true')
    args = parser.parse_args()
    if args.freeze_repair:
        freeze_repair()
    elif args.repair:
        run_repair(args.limit)
    else:
        run(args.limit, args.common_gap)
