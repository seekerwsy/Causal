import hashlib
import argparse
import itertools
import json
import math
import platform
from collections import Counter
from pathlib import Path

import numpy as np
import scipy
import sklearn
from scipy.optimize import brentq
from scipy.special import logsumexp
from scipy.stats import binomtest
from sklearn.feature_extraction import DictVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import Ridge
from sklearn.preprocessing import normalize

from prompt_mechanism_study.artifact_io import read_json, verify_bundle, write_bundle, file_sha256
from prompt_mechanism_study.development.graph_guided_decisions import DiscoveryFeatures


# 合成面板只核验统计与编码，不代表模型实验或自然任务。
PROTOCOL = Path("docs/graph-guided-discovery-protocol.md")
OUTPUT = Path(".codex-runtime/discovery-design-check.json")
C = np.array([0, 0.05, 0.10, 0.20, 0.35, 0.50, 0.65, 0.80, 0.95])
ALPHAS = (0.02, 0.02, 0.01)
RANGES = ((-2, 2), (-2, 2), (-1, 1))
REPLICATES = 10000


def log_product_mixture(x, m):
    x = np.asarray(x, dtype=float)
    assert np.all((x >= 0) & (x <= 1))
    assert 0 <= m <= 1
    n = x.shape[-1]
    if m == 0:
        zero_value = logsumexp(n * np.log1p(-C)) - math.log(len(C))
        return np.where(np.any(x > 0, axis=-1), np.inf, zero_value)
    terms = np.log1p(C[:, None] * (x[..., None, :] / m - 1))
    return logsumexp(terms.sum(axis=-1), axis=-1) - math.log(len(C))


def interval(z, bounds, alpha):
    a, b = bounds
    x = (np.asarray(z, dtype=float) - a) / (b - a)
    assert np.all((x >= 0) & (x <= 1))
    if not len(x):
        return (float(a), float(b))
    threshold = math.log(2 / alpha)

    def lower_endpoint(values):
        if log_product_mixture(values, 0) <= threshold:
            return 0.0
        root = brentq(
            lambda m: float(log_product_mixture(values, m)) - threshold,
            0,
            1,
            xtol=1e-13,
        )
        return max(0.0, root - 1e-10)

    lower = lower_endpoint(x)
    upper = 1 - lower_endpoint(1 - x)
    assert lower <= upper
    return (float(a + (b - a) * lower), float(a + (b - a) * upper))


def excludes_truth(z, truth, bounds, alpha):
    a, b = bounds
    x = (z - a) / (b - a)
    m = (truth - a) / (b - a)
    threshold = math.log(2 / alpha)
    return (log_product_mixture(x, m) > threshold) | (
        log_product_mixture(1 - x, 1 - m) > threshold
    )


def panel(rng, n, p, delta1, delta2, shared):
    base = np.broadcast_to(np.asarray(p), (n,))
    differences = []
    for delta in (delta1, delta2):
        assert np.all((base + delta >= 0) & (base + delta <= 1))
        u_n = rng.random((REPLICATES, n, 2))
        u_p = u_n if shared else rng.random((REPLICATES, n, 2))
        y_n = (u_n < base[None, :, None]).astype(float)
        y_p = (u_p < (base + delta)[None, :, None]).astype(float)
        # 每个seed的两个版本完全相关，版本均值等于此seed的观测。
        differences.append((y_p - y_n).mean(axis=-1))
    d1, d2 = differences
    return (d1 - d2, d1, d1)


def calibration():
    rng = np.random.Generator(np.random.PCG64(2026092910))
    settings = [
        ("S1", 0.05, 0, 0, False),
        ("S2", 0.50, 0, 0, False),
        ("S3", 0.95, 0, 0, False),
        ("S4", np.tile([0.10, 0.90], 13), 0, 0, False),
        ("S5", 0.50, 0, 0, True),
        ("S6", 0, 1, 1, True),
        ("S7", 0.50, 0.10, 0, False),
        ("S8", 0.50, 0.25, 0, True),
    ]
    records, diagnostics = [], []
    for name, p, d1, d2, shared in settings:
        vectors = list(panel(rng, 26, p, d1, d2, shared))
        vectors[2] = vectors[2][:, :13]
        truths = (d1 - d2, d1, d1)
        failures = [
            excludes_truth(z, t, bounds, alpha)
            for z, t, bounds, alpha in zip(vectors, truths, RANGES, ALPHAS)
        ]
        failures.append(np.logical_or.reduce(failures))
        counts = [int(np.count_nonzero(x)) for x in failures]
        rates = np.asarray(counts) / REPLICATES
        for j, (count, null) in enumerate(zip(counts, (*ALPHAS, 0.05))):
            diagnostics.append({
                "setting": name,
                "position": j + 1,
                "p_value": float(binomtest(count, REPLICATES, null, alternative="greater").pvalue),
            })
        records.append({
            "setting": name,
            "true_effects": truths,
            "noncoverage_counts_T1_T2_T3_family": counts,
            "noncoverage_rates": rates.tolist(),
            "mc_standard_errors": np.sqrt(rates * (1 - rates) / REPLICATES).tolist(),
            "interval_defined_fraction": [1, 1, 1],
        })
    ordered = sorted(diagnostics, key=lambda x: x["p_value"])
    maximum = 0.0
    for rank, entry in enumerate(ordered):
        maximum = max(maximum, (len(ordered) - rank) * entry["p_value"])
        entry["holm_adjusted_p"] = min(1.0, maximum)
    assert len(ordered) == 32
    assert all(x["holm_adjusted_p"] >= 0.01 for x in ordered)
    return {"settings": records, "diagnostics": ordered, "passed": True}


def power(sample_sizes=(12, 26)):
    rng = np.random.Generator(np.random.PCG64(2026092911))
    records = []
    for n, delta, shared in itertools.product(sample_sizes, (0.10, 0.25, 0.40), (False, True)):
        generated = panel(rng, n, 0.50, delta, 0, shared)
        # 两项策略比较均选择不同候选；基线候选期望为零但保留其观测噪声。
        vectors = (generated[0], generated[0], generated[2])
        entries = []
        for z, bounds, alpha in zip(vectors, RANGES, ALPHAS):
            a, b = bounds
            x = (z - a) / (b - a)
            entries.append({
                "exclude_zero": float(np.mean(log_product_mixture(x, (0 - a) / (b - a)) > math.log(2 / alpha))),
                "exceed_0_10": float(np.mean(log_product_mixture(x, (0.10 - a) / (b - a)) > math.log(2 / alpha))),
            })
        records.append({"n": n, "delta": delta, "shared_seed": shared, "T1_T2_T3": entries})
    return records


def exact_and_boundary_checks():
    examples = {
        "no_tasks": interval([], (-1, 1), 0.01),
        "single_positive": interval([1], (-1, 1), 0.01),
        "constant_positive_26": interval(np.ones(26), (-1, 1), 0.01),
        "constant_zero_26": interval(np.zeros(26), (-1, 1), 0.01),
        "rare_positive_26": interval(np.r_[1, np.zeros(25)], (-1, 1), 0.01),
    }
    assert examples["constant_positive_26"][0] > 0
    assert examples["constant_zero_26"][0] < -0.10
    assert examples["constant_zero_26"][1] > 0.10
    probabilities = []
    for p in ((0.1, 0.3, 0.7, 0.9), (0.01, 0.1, 0.2, 0.95), (0.5,) * 4):
        failure, expectation = 0.0, np.zeros(len(C))
        m = np.mean(p)
        for bits in itertools.product((0, 1), repeat=4):
            x = np.asarray(bits)
            mass = float(np.prod(np.where(x, p, 1 - np.asarray(p))))
            expectation += mass * np.prod(1 + C[:, None] * (x / m - 1), axis=1)
            ci = interval(x, (0, 1), 0.05)
            failure += mass * (m < ci[0] or m > ci[1])
        assert np.all(expectation <= 1 + 1e-12)
        assert failure <= 0.05
        probabilities.append({"means": p, "exact_noncoverage": failure, "max_product_expectation": float(max(expectation))})
    z = np.linspace(-0.8, 0.7, 26)
    lo, hi = interval(z, (-1, 1), 0.01)
    reverse = interval(-z, (-1, 1), 0.01)
    np.testing.assert_allclose(reverse, [-hi, -lo], atol=1e-12)
    lower, upper = z.copy(), z.copy()
    lower[:2], upper[:2] = -1, 1
    envelope = (interval(lower, (-1, 1), 0.01)[0], interval(upper, (-1, 1), 0.01)[1])
    for a, b in itertools.product((-1, -0.5, 0, 0.5, 1), repeat=2):
        completed = z.copy()
        completed[:2] = (a, b)
        ci = interval(completed, (-1, 1), 0.01)
        assert envelope[0] <= ci[0] <= ci[1] <= envelope[1]
    assert interval(np.full(26, -1), (-1, 1), 0.01)[0] == -1
    assert interval(np.ones(26), (-1, 1), 0.01)[1] == 1
    # 两个策略引用同一请求时先合并系数，未知贡献相消。
    coefficients = Counter()
    for key, coefficient in (("shared_P", 0.25), ("shared_P", -0.25), ("shared_R", 1), ("shared_R", -1)):
        coefficients[key] += coefficient
    assert all(value == 0 for value in coefficients.values())
    return {"boundary_intervals": examples, "exact_enumeration": probabilities, "missing_envelope": envelope}


def feature_checks():
    common = "Render a form and route submitted records to the handler. Keep task behavior unchanged."
    p = ["Place the input description before the implementation request.", "Present the input description first, then the request."]
    n = ["Place the input description after the implementation request.", "Present the request first, then the input description."]
    c_encoder = TfidfVectorizer(analyzer="char", ngram_range=(2, 4), max_features=256, norm="l2")
    common_vector = c_encoder.fit_transform([common, "Create a form and process submitted values."]).toarray()[0]
    d_encoder = TfidfVectorizer(analyzer="char", ngram_range=(2, 4), max_features=256, norm="l2")
    policy_vectors = d_encoder.fit_transform(p + n).toarray()
    difference = normalize((policy_vectors[:2].mean(axis=0) - policy_vectors[2:].mean(axis=0))[None, :])[0]
    graphs = [
        [("input", "flows_to", "handler", "submit", "positive"), ("error", "flows_to", "view", "submit", "positive")],
        [("input", "flows_to", "view", "submit", "positive"), ("error", "flows_to", "handler", "submit", "positive")],
        [("input", "flows_to", "handler", "preview", "positive"), ("error", "flows_to", "view", "submit", "positive")],
        [("input", "flows_to", "handler", "submit", "negative"), ("error", "flows_to", "view", "submit", "positive")],
    ]
    tuples = [Counter(json.dumps(edge, ensure_ascii=False, separators=(",", ":")) for edge in g) for g in graphs]
    dictionary = DictVectorizer(sparse=False)
    relation_vectors = normalize(dictionary.fit_transform(tuples))
    marginal_encoder = DictVectorizer(sparse=False)
    marginals = [Counter(f"{position}:{value}" for edge in g for position, value in enumerate(edge)) for g in graphs]
    marginal_vectors = normalize(marginal_encoder.fit_transform(marginals))
    np.testing.assert_array_equal(marginal_vectors[0], marginal_vectors[1])
    distances = [float(np.linalg.norm(relation_vectors[0] - relation_vectors[j])) for j in (1, 2, 3)]
    assert all(d > 0 for d in distances)
    common_block = np.r_[1, common_vector, difference]
    full = np.r_[common_block, marginal_vectors[0], relation_vectors[0]]
    ablated = np.r_[common_block, marginal_vectors[0], np.zeros_like(relation_vectors[0])]
    np.testing.assert_array_equal(full[:len(common_block)], ablated[:len(common_block)])
    reverse_difference = normalize((policy_vectors[2:].mean(axis=0) - policy_vectors[:2].mean(axis=0))[None, :])[0]
    reverse = np.r_[-1, -common_vector, reverse_difference, -marginal_vectors[0], -relation_vectors[0]]
    np.testing.assert_allclose(reverse, -full, atol=0)
    learner = Ridge(alpha=1, fit_intercept=False).fit(np.vstack([full, reverse]), [0.25, -0.25])
    predictions = learner.predict(np.vstack([full, reverse]))
    np.testing.assert_allclose(predictions[0], -predictions[1], atol=1e-14)
    unseen = {json.dumps(("unknown_role", "flows_to", "view", "submit", "positive"), separators=(",", ":")): 1}
    assert dictionary.transform([unseen]).sum() == 0
    assert len(set(unseen) - set(dictionary.vocabulary_)) == 1
    rng = np.random.default_rng(2026092912)
    x = rng.normal(size=(16, 5))
    yp, yn = rng.random((2, 16))
    rp = Ridge(alpha=1, fit_intercept=False).fit(x, yp)
    rn = Ridge(alpha=1, fit_intercept=False).fit(x, yn)
    rd = Ridge(alpha=1, fit_intercept=False).fit(x, yp - yn)
    gap = float(np.max(np.abs(rp.predict(x) - rn.predict(x) - rd.predict(x))))
    assert gap < 1e-12
    return {
        "rewiring_scope_polarity_distances": distances,
        "reversed_prediction_sum": float(predictions.sum()),
        "common_block_unchanged": True,
        "unseen_tuple_audited": True,
        "two_arm_ridge_equivalence_error": gap,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--task-frame-power', action='store_true')
    parser.add_argument('--analysis-environment', action='store_true')
    arguments = parser.parse_args()
    if arguments.analysis_environment:
        f0 = Path('data/method/graph-guided-20260929/development-preparation')
        verify_bundle(f0)
        features = DiscoveryFeatures()
        parameters = {}
        for name, estimator in [('common', features.common), ('policy', features.policy),
                                ('marginals', features.marginal), ('relations', features.relation),
                                ('ridge', Ridge(fit_intercept=False, solver='svd'))]:
            parameters[name] = {key: value.__module__ + '.' + value.__qualname__ if isinstance(value, type) else value
                                for key, value in estimator.get_params(deep=True).items()}
        write_bundle(Path('data/method/graph-guided-20260929/analysis-environment'), {
            'environment.json': dict(status='PROSPECTIVE_ANALYSIS_ENVIRONMENT_RECORDED',
                python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__, sklearn=sklearn.__version__,
                estimator_defaults=parameters, ridge_alpha_grid=[.1, 1., 10., 100.],
                selection='leave-one-task-out task-equal MSE; ties choose larger alpha',
                f0_manifest_sha256=file_sha256(f0 / 'manifest.json'),
                checker_sha256=file_sha256(Path(__file__)), generated_outcomes_read=False,
                model_calls=0)})
        print(json.dumps(dict(status='PROSPECTIVE_ANALYSIS_ENVIRONMENT_RECORDED', model_calls=0)))
        return
    if arguments.task_frame_power:
        frame_root = Path('data/method/graph-guided-20260929/task-frame')
        verify_bundle(frame_root)
        count = len(read_json(frame_root / 'tasks.json')['evaluation'])
        assert count == 18
        records = power((count,))
        for row in records:
            row['T1_T2'] = row.pop('T1_T2_T3')[:2]
            row['power_status'] = ['LOW_POWER_FOR_PLANNED_EFFECT' if item['exclude_zero'] < .8
                                   else 'POWER_TARGET_MET_IN_THIS_MATHEMATICAL_SETTING'
                                   for item in row['T1_T2']]
        result = dict(identity='actual_frozen_task_count_mathematical_power_only',
            frame_manifest_sha256=file_sha256(frame_root / 'manifest.json'),
            checker_sha256=file_sha256(Path(__file__)), simulation_seed=2026092911,
            replicates=REPLICATES, evaluation_tasks=count, power=records, model_calls=0,
            T3=dict(status='UNASSESSED_PENDING_INDEPENDENT_REVIEW', frozen_low_expected_tasks=0))
        write_bundle(Path('results/graph-guided-20260929/task-frame-power'), {'power.json': result})
        print(json.dumps(result, ensure_ascii=False))
        return
    assert 16 * 36 + 26 * 44 + 32 == 1752
    result = {
        "identity": "synthetic_mathematical_design_validation_only",
        "protocol_sha256": hashlib.sha256(PROTOCOL.read_bytes()).hexdigest(),
        "checker_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "environment": {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__, "sklearn": sklearn.__version__},
        "budget": {"max_requests": 1752, "service_seconds_per_request": 14400 / 1752, "preparation_hours": 84 * 6 / 60},
        "features": feature_checks(),
        "interval_checks": exact_and_boundary_checks(),
        "calibration": calibration(),
        "power": power(),
        "model_calls": 0,
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({key: result[key] for key in ("identity", "environment", "budget", "features", "interval_checks", "power", "model_calls")}, ensure_ascii=False, indent=2))
    print("Calibration passed across all 8 settings and 32 multiplicity-adjusted diagnostics.")


if __name__ == "__main__":
    main()
