import itertools
import json
from pathlib import Path

import numpy as np
from scipy.stats import fisher_exact

from prompt_mechanism_study.development.structure_policy_cpu import (
    CommonCI, conditional_mean, consumers, design, evaluate_policy, make_matrix,
    population_joint, ridge, select_penalty,
)


def test_rational_observable_policy_reference_values():
    for mechanism, expected in [(1, (.45, .5, .6)), (2, (.4, .55, .55)), (3, (.45, .5, .55))]:
        joint = population_joint(mechanism)
        assert sum(p for _, p in joint) == 1
        states = list(itertools.product((0, 1), repeat=3))
        values = [sum(conditional_mean(mechanism, c, m) for m in states)/8 for c in (0, 1)]
        values.append(sum(max(conditional_mean(mechanism, c, m) for c in (0, 1)) for m in states)/8)
        assert tuple(float(v) for v in values) == expected
        ci = CommonCI(mechanism=mechanism)
        assert ci.query('M3', 'Y', ['C', 'M1', 'M2'])['independent']
        assert not ci.query('M1', 'Y', ['C', 'M2'])['independent']


def test_exact_conditional_tail_and_attainability():
    rows = []
    for x, y, count in [(0, 0, 8), (0, 1, 2), (1, 0, 2), (1, 1, 8)]:
        rows.extend([[x, y, 0, 0, 0, 0, 0, 0]]*count)
    ci = CommonCI(dict(identity='balanced-margins-qualification', rows=rows))
    result = ci.query('C', 'M1', [])
    assert result['mode'] == 'exact'
    assert abs(result['p_value']-fisher_exact([[8, 2], [2, 8]]).pvalue) < 1e-12
    assert result == ci.query('M1', 'C', [])
    undefined = ci.query('C', 'Y', [])
    assert undefined['p_value'] is None
    assert undefined['minimum_attainable_p'] == 1
    assert undefined['status'] == 'statistically_undetermined'


def test_monte_carlo_query_is_shared_and_reproducible():
    matrix = make_matrix(1, 512, 0)
    first, second = CommonCI(matrix), CommonCI(matrix)
    a = first.query('M1', 'Y', ['C', 'M2'])
    b = second.query('Y', 'M1', ['M2', 'C'])
    assert a == b
    assert a['mode'] == 'conditional_monte_carlo'
    assert abs(a['p_value']*10000-round(a['p_value']*10000)) < 1e-9


def test_ridge_penalty_excludes_intercept_and_keeps_main_effects():
    matrix = make_matrix(1, 128, 0)
    rows = np.asarray(matrix['rows'])[:, [0, 1, 2, 3, 7]]
    selected = [1]
    x = design(rows, selected)
    beta = ridge(rows, selected, 10.)
    penalty = np.diag([0, 10, 10, 10, 10, 10])
    assert np.max(np.abs(x.T@(x@beta-rows[:, -1])+penalty@beta)) < 1e-9
    chosen, cv = select_penalty(rows, np.asarray(matrix['folds']))
    assert chosen in (.1, 1., 10., 100.) and cv['status'] == 'determined'
    empty = evaluate_policy(rows, 1, [], chosen)
    assert len(empty['actions']) == 8 and len(set(empty['actions'])) == 1


def test_uniform_subset_baseline_averages_separate_policies():
    matrix = make_matrix(1, 128, 2)
    result = consumers(matrix, 3, {'FCI_JCI12': {'selected': [1]}, 'GFCI_JCI12': {'selected': [2]}})
    uniform = result['policies']['uniform_k1']
    assert [p['selected'] for p in uniform['subsets']] == [[1], [2], [3]]
    assert uniform['value'] == sum(p['value'] for p in uniform['subsets'])/3
    assert len(result['policies']['full']['selected']) == 3


def test_missing_assignment_arm_preserves_abstention():
    rows = np.array([[0, *m, y] for m in itertools.product((0, 1), repeat=3) for y in (0, 1)])
    result = evaluate_policy(rows, 1, [1], 1.)
    assert result['status'] == 'missing_arm_abstention'
    assert result['value'] == .45 and set(result['actions']) == {0}


def test_missing_arm_is_local_to_its_cv_fit():
    rows = np.array([[int(i == 0), i % 2, (i//2) % 2, (i//4) % 2, i % 2] for i in range(20)])
    folds = np.arange(20) % 5
    penalty, diagnostics = select_penalty(rows, folds)
    assert penalty in (.1, 1., 10., 100.)
    assert diagnostics['missing_arm_cv_folds'] == [0]
    assert evaluate_policy(rows, 1, [1], penalty)['status'] == 'fitted'


def test_frozen_matrix_consumers_reproduce_exactly():
    root = Path('data/method/graph-guided-20260930/cpu')
    output = Path('results/graph-guided-20260930/cpu')
    matrices = {m['identity']: m for m in json.loads((root/'matrices.json').read_text())}
    searches = [json.loads(line) for line in (output/'searches.jsonl').read_text().splitlines()]
    for line in (output/'policies.jsonl').read_text().splitlines():
        original = json.loads(line)
        d, identity = original['d'], original['identity']
        structures = {r['method']: r for r in searches if r['identity'] == identity and r['d'] == d}
        structures['population_FCI'] = next(r for r in searches if r['identity'] ==
            f'population-m{original["mechanism"]}' and r['d'] == d)
        actual = consumers(matrices[identity], d, structures)
        assert json.loads(json.dumps(actual)) == original
