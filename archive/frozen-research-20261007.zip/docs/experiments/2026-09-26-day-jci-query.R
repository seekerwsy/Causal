# Randomized complete-version mixture: JCI0 and JCI12 on the same C,B,Y rows.
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args)==2L, !file.exists(args[[2]]))
.libPaths(c(".codex-runtime/r-lib",.libPaths()))
dat <- read.csv(args[[1]],stringsAsFactors=FALSE)
labels <- c("C","B","Y")
keys <- unique(dat[c("mechanism","n_total","seed")])
stopifnot(nrow(keys)==600L)
records <- vector("list",nrow(keys)*2L)
index <- 0L
for (i in seq_len(nrow(keys))) {
  key <- keys[i,]
  rows <- dat[dat$mechanism==key$mechanism & dat$n_total==key$n_total & dat$seed==key$seed,labels]
  stopifnot(nrow(rows)==key$n_total)
  for (mode in c("0","12")) {
    warns <- character(); err <- ""
    amat <- tryCatch(withCallingHandlers(pcalg::fci(
      suffStat=list(dm=as.matrix(rows),nlev=rep(2L,3L),adaptDF=FALSE),
      indepTest=pcalg::disCItest,alpha=.05,labels=labels,
      contextVars=1L,jci=mode,selectionBias=FALSE,NAdelete=FALSE,
      verbose=FALSE)@amat,warning=function(w) {
        warns <<- c(warns,conditionMessage(w)); invokeRestart("muffleWarning")
      }),error=function(e) {err <<- conditionMessage(e);NULL})
    index <- index+1L
    records[[index]] <- data.frame(mechanism=key$mechanism,n_total=key$n_total,seed=key$seed,
      method=paste0("JCI",mode),cy_adjacent=if(is.null(amat)) FALSE else
        (amat["C","Y"]!=0 || amat["Y","C"]!=0),
      cb_adjacent=if(is.null(amat)) FALSE else (amat["C","B"]!=0 || amat["B","C"]!=0),
      matrix=if(is.null(amat)) "" else paste(as.vector(amat),collapse=";"),
      warnings=paste(unique(warns),collapse="|"),error=err)
  }
  if(i%%100L==0L) cat("JCI query matrices",i,"/",nrow(keys),"\n")
}
write.csv(do.call(rbind,records),args[[2]],row.names=FALSE)
cat("saved",index,"graphs\n")
