.libPaths(c('.codex-runtime/r-lib', .libPaths()))
suppressPackageStartupMessages(library(pcalg))
suppressPackageStartupMessages(library(jsonlite))
input <- file('stdin', open='r')
marks <- c('NONE', 'CIRCLE', 'ARROW', 'TAIL')
complete_temporal <- function(pag, sepset, labels, mode) {
  stopifnot(identical(labels, c('C', 'X', 'Y')), pag[1,2] == 0, pag[2,1] == 0)
  rules <- rep(TRUE, 10)
  rules[5:7] <- FALSE
  for (iteration in seq_len(12)) {
    previous <- pag
    # JCI1只规定时间方向，保留X与Y的潜在混杂。
    pag <- udag2pag(pag, sepset, rules=rules, jci='1',
                    contextVars=c(1L, 2L), orientCollider=FALSE)
    if (mode == '12') {
      pag <- udag2pag(pag, sepset, rules=rules, jci='12',
                      contextVars=1L, orientCollider=FALSE)
    }
    if (identical(previous, pag)) break
    stopifnot(iteration < 12)
  }
  stopifnot(all(pag[c(1L,2L),3L] %in% c(0L,2L)))
  if (mode == '12') stopifnot(pag[3L,1L] %in% c(0L,3L))
  pag
}
repeat {
  line <- readLines(input, n=1L, warn=FALSE)
  if (length(line) == 0L) break
  request <- fromJSON(line)
  rows <- as.matrix(request$rows)
  labels <- request$labels
  colnames(rows) <- labels
  stopifnot(nrow(rows) == request$n, all(rows %in% c(0L, 1L)))
  gaps <- matrix(FALSE, nrow=length(labels), ncol=length(labels))
  if (isTRUE(request$fixed_gap_cx)) {
    gaps[which(labels == 'C'), which(labels == 'X')] <- TRUE
    gaps[which(labels == 'X'), which(labels == 'C')] <- TRUE
  }
  for (mode in c('0', '1', '12')) {
    warnings <- character()
    ci_diagnostics <- list()
    checked_ci <- function(x, y, S, suffStat) {
      groups <- if (length(S)) interaction(as.data.frame(suffStat$dm[,S,drop=FALSE]), drop=TRUE) else rep(1L, nrow(suffStat$dm))
      minima <- numeric()
      for (group in unique(groups)) {
        subset <- suffStat$dm[groups == group,,drop=FALSE]
        cells <- table(factor(subset[,x], levels=0:1), factor(subset[,y], levels=0:1))
        expected <- outer(rowSums(cells), colSums(cells)) / sum(cells)
        minima <- c(minima, min(expected))
      }
      ci_diagnostics[[length(ci_diagnostics)+1L]] <<- list(x=labels[x], y=labels[y], S=as.list(labels[S]),
        minimum_expected=min(minima), sparse=any(minima < 5))
      disCItest(x, y, S, suffStat)
    }
    started <- proc.time()[['elapsed']]
    graph <- tryCatch(withCallingHandlers(fci(
      suffStat=list(dm=rows, nlev=rep(2L, length(labels)), adaptDF=FALSE),
      indepTest=if (isTRUE(request$temporal_background)) checked_ci else disCItest, alpha=.05, labels=labels,
      contextVars=which(labels == 'C'), jci=mode,
      fixedGaps=gaps,
      selectionBias=FALSE, NAdelete=FALSE, verbose=FALSE
    ), warning=function(w) {
      warnings <<- c(warnings, conditionMessage(w))
      invokeRestart('muffleWarning')
    }), error=function(e) e)
    edges <- list()
    failure <- NULL
    if (inherits(graph, 'error')) {
      if (isTRUE(request$temporal_background)) stop(graph)
      failure <- conditionMessage(graph)
    } else {
      matrix <- graph@amat
      before <- matrix
      if (isTRUE(request$temporal_background)) matrix <- complete_temporal(matrix, graph@sepset, labels, mode)
      for (i in seq_len(length(labels)-1L)) {
        for (j in seq.int(i+1L, length(labels))) {
          if (matrix[i,j] != 0L || matrix[j,i] != 0L) {
            edges[[length(edges)+1L]] <- c(labels[i], marks[matrix[j,i]+1L],
                                          marks[matrix[i,j]+1L], labels[j])
          }
        }
      }
    }
    result <- list(identity=request$identity, method=paste0('FCI_JCI', mode),
                   edges=edges, warnings=as.list(unique(warnings)), failure=failure,
                   temporal_background=isTRUE(request$temporal_background),
                   ci_diagnostics=ci_diagnostics,
                   seconds=proc.time()[['elapsed']]-started,
                   pcalg=as.character(packageVersion('pcalg')),
                   jsonlite=as.character(packageVersion('jsonlite')))
    cat(toJSON(result, auto_unbox=TRUE, null='null', digits=16), '\n', sep='')
    flush(stdout())
  }
}
close(input)
