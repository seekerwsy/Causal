# Exploratory synthetic FCI-JCI check. Reads the exact rows produced by the
# adjacent Python benchmark. These are never natural tasks or study evidence.
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2L) stop("usage: Rscript benchmark.R INPUT.csv OUTPUT.csv")
if (file.exists(args[[2]])) stop("refusing to overwrite existing results")
.libPaths(c(".codex-runtime/r-lib", .libPaths()))
if (!requireNamespace("pcalg", quietly = TRUE)) stop("pcalg unavailable")

dat <- read.csv(args[[1]], stringsAsFactors = FALSE)
labels <- c("C", "X", "Z", "Y")
truth <- c("C-X", "X-Y", "Y-Z")
keys <- unique(dat[c("scenario", "n_total", "seed")])
records <- list()

for (i in seq_len(nrow(keys))) {
  key <- keys[i, ]
  rows <- dat[dat$scenario == key$scenario & dat$n_total == key$n_total &
                dat$seed == key$seed, labels]
  stopifnot(nrow(rows) == key$n_total)
  for (jci_mode in c("0", "1", "12")) {
    ci_warnings <- character()
    outcome <- tryCatch({
      graph <- withCallingHandlers(pcalg::fci(
        suffStat = list(dm = as.matrix(rows), nlev = rep(2L, 4L), adaptDF = FALSE),
        indepTest = pcalg::disCItest, alpha = 0.05, labels = labels,
        contextVars = 1L, jci = jci_mode, selectionBias = FALSE,
        NAdelete = FALSE, verbose = FALSE), warning = function(w) {
          ci_warnings <<- c(ci_warnings, conditionMessage(w))
          invokeRestart("muffleWarning")
        })
      amat <- graph@amat
      pairs <- combn(labels, 2L, simplify = FALSE)
      predicted <- vapply(pairs, function(pair) {
        if (amat[pair[1], pair[2]] == 0 && amat[pair[2], pair[1]] == 0) ""
        else paste(sort(pair), collapse = "-")
      }, character(1))
      predicted <- sort(predicted[predicted != ""])
      data.frame(scenario = key$scenario, n_total = key$n_total,
                 seed = key$seed, method = paste0("pcalg_FCI_JCI", jci_mode),
                 tp = sum(predicted %in% truth),
                 fp = sum(!predicted %in% truth),
                 fn = sum(!truth %in% predicted),
                 predicted = paste(predicted, collapse = "|"),
                 xy_left = amat["X", "Y"], xy_right = amat["Y", "X"],
                 matrix = paste(as.vector(amat), collapse = ";"),
                 ci_warning_count = length(ci_warnings),
                 ci_warning = paste(unique(ci_warnings), collapse = "|"),
                 error = "", stringsAsFactors = FALSE)
    }, error = function(e) {
      data.frame(scenario = key$scenario, n_total = key$n_total,
                 seed = key$seed, method = paste0("pcalg_FCI_JCI", jci_mode),
                 tp = NA_integer_, fp = NA_integer_, fn = NA_integer_,
                 predicted = "", xy_left = NA_integer_, xy_right = NA_integer_,
                 matrix = "", ci_warning_count = length(ci_warnings),
                 ci_warning = paste(unique(ci_warnings), collapse = "|"),
                 error = conditionMessage(e), stringsAsFactors = FALSE)
    })
    records[[length(records) + 1L]] <- outcome
  }
}

write.csv(do.call(rbind, records), args[[2]], row.names = FALSE)
cat("wrote", length(records), "records to", args[[2]], "with pcalg",
    as.character(utils::packageVersion("pcalg")), "\n")
