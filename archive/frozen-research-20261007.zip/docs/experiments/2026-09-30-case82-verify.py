import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
FROZEN = ROOT / 'data/method/graph-guided-20260930/development-case82-generation-inputs-v2'
RUN = ROOT / 'results/graph-guided-20260930/development-case82-main'
ANALYSIS = ROOT / 'results/graph-guided-20260930/development-case82-analysis'


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


assignments = load(FROZEN / 'assignments.json')
protocol = load(FROZEN / 'protocol.json')
assert protocol['code_requests'] == len(assignments) == 12
assert assignments == load(RUN / 'preoutcome/assignments.json')
assert len({row['seed'] for row in assignments}) == 12
assert Counter(row['arm'] for row in assignments) == {'original': 4, 'list': 4, 'no_examples': 4}

observed = defaultdict(list)
code_identities = defaultdict(set)
for assignment in assignments:
    folder = RUN / assignment['slot']
    request = load(folder / 'request.json')
    response = load(folder / 'response.json')
    result = load(folder / 'result/result.json')
    assert request['model'] == response['model'] == protocol['model']['model_id']
    assert request['seed'] == assignment['seed']
    assert request['messages'][1]['content'] == json.dumps(
        {'task': assignment['prompt']}, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    assert response['choices'][0]['finish_reason'] == 'stop'
    assert result['status'] == 'returned'
    assert result['slot'] == assignment['slot'] and result['arm'] == assignment['arm']
    assert hashlib.sha256((folder / 'code.py').read_bytes()).hexdigest() == result['code_sha256']
    assert len(result['measurements']) == 1
    measurement = result['measurements'][0]['measurement']
    assert measurement['status'] == 'measured'
    channel = measurement['channels']['security']
    assert channel['status'] == 'passed'
    value = channel['observation']
    assert value['endpoint'] == protocol['endpoint']
    observed[assignment['arm']].append(value)
    code_identities[assignment['arm']].add(result['code_sha256'])

summary = load(ANALYSIS / 'summary.json')
all_code = set().union(*code_identities.values())
assert len(all_code) == 2
assert all(identities == all_code for identities in code_identities.values())
for condition, values in observed.items():
    actual = summary['conditions'][condition]
    assert actual['assignments'] == len(values) == 4
    assert actual['secure_yield'] == sum(value['secure_yield'] for value in values) == 4
    assert actual['functionality_pass'] == sum(value['functionality'] == 'pass' for value in values) == 4
    assert actual['direct_violations'] == sum(value['direct_violation'] for value in values) == 0
    assert actual['distinct_code_sha256'] == len(code_identities[condition]) == 2
assert summary['contrasts'] == {'list_minus_original': 0.0,
                                'original_minus_no_examples': 0.0}
print('CASE82_INDEPENDENT_RESULT_VERIFIED 12/12')
