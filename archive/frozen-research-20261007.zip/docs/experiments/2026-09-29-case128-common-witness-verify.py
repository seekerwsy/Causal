from collections import Counter
import hashlib
from pathlib import Path

from prompt_mechanism_study.artifact_io import file_sha256, read_json, verify_bundle, write_bundle


root = Path('data/method/graph-guided-20260929')
diagnostic = root / 'case128-common-witness'
results = Path('results/graph-guided-20260929')
verify_bundle(diagnostic / 'requests')
verify_bundle(diagnostic / 'identity')
verify_bundle(root / 'development-analysis')
protocol = read_json(diagnostic / 'identity/protocol.json')
assert file_sha256(root / 'development-analysis/manifest.json') == protocol['development_analysis_manifest_sha256']
assert file_sha256(root / 'development-preparation/manifest.json') == protocol['f0_manifest_sha256']
assert file_sha256(diagnostic / 'requests/manifest.json') == protocol['requests_manifest_sha256']
assert file_sha256(Path('src/measurement/native_behavior.py')) == protocol['native_worker_sha256']
test = Path('docs/experiments/2026-09-29-case128-common-witness-security.py')
assert file_sha256(test) == protocol['security_test_sha256']
assert file_sha256(Path('.codex-runtime/case128-common-witness-results-20260929.tar.gz')) == 'ba58e33c85683ac525adfc6b8a67f6d0295aff06d102fea5eb2bafc7b32b36b9'
expected_names = {row['slot'] + '.json' for row in protocol['original_assignments']} | set(protocol['control_expectations'])
assert {path.name for path in (results / 'case128-common-witness').glob('*.json')} == expected_names
rows, controls = [], []


def observation(name):
    result = read_json(results / 'case128-common-witness' / name)
    assert result['status'] == 'measured'
    assert set(result['channels']) == {'security', 'functionality'}
    assert all(channel['status'] == 'passed' for channel in result['channels'].values())
    return result['channels']['security']['observation'], result['channels']['functionality']['observation']


for identity in protocol['original_assignments']:
    name = identity['slot'] + '.json'
    original = results / 'development-main' / identity['slot']
    verify_bundle(original / 'result')
    assert file_sha256(original / 'measurement-request.json') == identity['original_request_sha256']
    request = read_json(diagnostic / 'requests' / name)
    old_request = read_json(original / 'measurement-request.json')
    assert hashlib.sha256(request['code'].encode()).hexdigest() == identity['code_sha256']
    assert request['code'] == old_request['code']
    assert request['tests']['security'] == test.read_text(encoding='utf-8')
    assert dict(request, tests=old_request['tests']) == old_request
    original_result = read_json(original / 'result/result.json')
    assert len(original_result['measurements']) == 1
    old_measurement = original_result['measurements'][0]['measurement']
    old_security = old_measurement['channels']['security']['observation']
    security, functionality = observation(name)
    # 功能见证及攻击探针保持一致，普通见证独立记录。
    assert functionality == old_measurement['channels']['functionality']['observation']
    assert security['execution_marker'] == old_security['execution_marker']
    assert security['attack_status'] == old_security['attack_status']
    assert security['endpoint'] == old_security['endpoint']
    assert security['ordinary_quantity'] == 1
    rows.append(dict(identity, original_security=old_security['security_label'],
                     diagnostic_security=security['security_label'],
                     original_ordinary_witness=old_security['ordinary_witness'],
                     diagnostic_ordinary_witness=security['ordinary_witness'],
                     execution_marker=security['execution_marker'], functionality=functionality['functionality'],
                     diagnostic_result_sha256=file_sha256(results / 'case128-common-witness' / name)))

for name, expected in protocol['control_expectations'].items():
    request = read_json(diagnostic / 'requests' / name)
    old_request = read_json(root / 'measurement/yaml_price-qualification-inputs' / name.removeprefix('control-'))
    assert dict(request, tests=old_request['tests']) == old_request
    security, functionality = observation(name)
    assert security['security_label'] == expected
    controls.append(dict(name=name, security=security, functionality=functionality,
                         diagnostic_result_sha256=file_sha256(results / 'case128-common-witness' / name)))

arms = {}
for arm in ('P', 'N', 'R'):
    selected = [row for row in rows if row['arm'] == arm]
    assert len(selected) == 4
    arms[arm] = dict(original_labels=dict(Counter(row['original_security'] for row in selected)),
                     diagnostic_labels=dict(Counter(row['diagnostic_security'] for row in selected)),
                     original_secure_yield=sum(row['original_security'] == 'secure' for row in selected) / 4,
                     diagnostic_secure_yield=sum(row['diagnostic_security'] == 'secure' for row in selected) / 4,
                     unchanged_functionality=dict(Counter(row['functionality'] for row in selected)))
effect = [row for row in read_json(root / 'development-analysis/effects.json') if row['index'] == 128]
assert len(effect) == 1
assert arms['P']['original_secure_yield'] - arms['N']['original_secure_yield'] == effect[0]['delta_pn']
report = dict(status='POST_HOC_COMMON_WITNESS_DIAGNOSTIC_VERIFIED', new_model_calls=0,
              original_primary_labels_unchanged=True, original_effect=effect[0]['primary_pn'],
              original_sensitivity=effect[0]['sensitivity_pn'], arms=arms,
              diagnostic_pn=arms['P']['diagnostic_secure_yield'] - arms['N']['diagnostic_secure_yield'],
              diagnostic_pr=arms['P']['diagnostic_secure_yield'] - arms['R']['diagnostic_secure_yield'],
              code_identity_verified=12, controls=controls, rows=rows,
              input_identity_manifest_sha256=file_sha256(diagnostic / 'identity/manifest.json'),
              verifier_sha256=file_sha256(Path(__file__)),
              scientific_scope='Exploratory measurement compatibility diagnosis; no replacement of primary labels, training or F1.')
write_bundle(results / 'case128-common-witness-verification', {'verification.json': report})
print({'status': report['status'], 'arms': arms, 'diagnostic_pn': report['diagnostic_pn'],
       'diagnostic_pr': report['diagnostic_pr'], 'real_controls': len(controls), 'new_model_calls': 0})
