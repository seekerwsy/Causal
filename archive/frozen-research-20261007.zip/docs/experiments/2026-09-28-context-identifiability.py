import itertools
import json
import math
from pathlib import Path


def probability(c, x, z):
    return 1 / (1 + math.exp(-(-2 + 1.5*c + 1.5*x + 1.2*z)))


states = []
causal_effects = []
context_effects = []
for c, x, z, y in itertools.product((0, 1), repeat=4):
    p0, p1 = probability(c, 0, z), probability(c, 1, z)
    q = ((.9*p0-.1*p1)/.8, (.9*p1-.1*p0)/.8)
    assert all(0 < value < 1 for value in q)
    p = probability(c, x, z)
    direct = .125 * (p if y else 1-p)
    confounded = 0.0
    for h in (0, 1):
        px = .1 + .8*h
        confounded += .125 * (px if x else 1-px) * (q[h] if y else 1-q[h])
    states.append(dict(C=c, X=x, Z=z, Y=y, direct_model=direct,
                       confounded_model=confounded, absolute_difference=abs(direct-confounded)))
for c, z in itertools.product((0, 1), repeat=2):
    causal_effects.append(probability(c, 1, z)-probability(c, 0, z))
for x, z in itertools.product((0, 1), repeat=2):
    context_effects.append(probability(1, x, z)-probability(0, x, z))
assert abs(sum(row['direct_model'] for row in states)-1) < 1e-14
assert abs(sum(row['confounded_model'] for row in states)-1) < 1e-14
assert max(row['absolute_difference'] for row in states) < 1e-14
result = dict(status='POSTHOC_EXACT_IDENTIFIABILITY_DIAGNOSTIC',
    motivation='Explain unresolved X/Y endpoints in the prospectively specified edit-direct mechanism.',
    direct_model='Independent C,X,Z~Bern(.5); Y~Bern(sigmoid(-2+1.5C+1.5X+1.2Z)).',
    confounded_model='Independent C,H,Z~Bern(.5); X~Bern(.1+.8H); Y~Bern(q_H(C,Z)). H is unobserved.',
    q_definition='p_x(C,Z)=sigmoid(-2+1.5C+1.5x+1.2Z); q_0=(.9p_0-.1p_1)/.8; q_1=(.9p_1-.1p_0)/.8.',
    shared_jci_assumptions='C is randomized, has no system causes and no latent common causes with the system.',
    maximum_observed_probability_difference=max(row['absolute_difference'] for row in states),
    direct_model_do_X_effect=sum(causal_effects)/4, confounded_model_do_X_effect=0,
    common_randomized_C_effect=sum(context_effects)/4,
    limitation='A model-class nonidentifiability witness; no real prompt safety result or universal algorithm ranking.',
    states=states)
output = Path('results/graph-guided-20260928/context-identifiability.json')
assert not output.exists()
output.write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({k: v for k, v in result.items() if k != 'states'}))
