"""Record source-only judgments for the frozen 54-task natural inventory.

This screens current command-boundary and private-write policies only. It does
not assess a source's general quality, model outcomes, or formal eligibility.
"""
from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path


SPECIAL = {
    4: ('POLICY_APPLICABILITY_UNRESOLVED', 'command_string',
        'The source requires executing an input command string with an allowed executable set; exact command grammar and caller-operand meaning must be fixed before no-shell ADD can preserve behavior.'),
    18: ('SOURCE_USABLE_ENDPOINT_PENDING', 'subprocess_image_resize',
         'A subprocess resize for caller filenames is explicit. Executable, dimensions, and output layout are not fixed; a finite call/operand witness and normal-behavior checks must be prospectively qualified.'),
    26: ('CURRENT_ADD_INAPPLICABLE', 'secret_file_after_write_chmod',
         'The source already instructs writing a secret and then changing owner-only permissions. It is not an absent-requirement ADD source for the present before-first-write Atomic policy.'),
    31: ('POLICY_APPLICABILITY_UNRESOLVED', 'pdf_upload',
         'The source saves an uploaded PDF for a localhost web server; whether owner-only file access preserves the intended serving behavior is unresolved.'),
    39: ('SOURCE_USABLE_ENDPOINT_PENDING', 'temporary_file_write',
         'The source explicitly creates a temporary UTF-8 file, writes input, and returns the path. A temporal private-write witness on the actual tempfile API has not been qualified.'),
    53: ('SOURCE_USABLE_ENDPOINT_PENDING', 'temporary_file_write',
         'The source explicitly creates a temporary file and writes input, but omits a return contract. A temporal private-write witness on the actual tempfile API has not been qualified.'),
}


def main(repo: Path) -> None:
    frozen = repo / 'data/method/day-research-20260926/frozen/natural-inventory/selection.json'
    pool = repo / 'data/dataset-curation/research-candidate-pool-v4/tasks.json'
    target = repo / 'results/day-research-20260926/natural-inventory/screening.json'
    selection = json.loads(frozen.read_text(encoding='utf-8'))
    by_id = {row['task_unit_id']: row for row in json.loads(pool.read_text(encoding='utf-8'))}
    assert len(selection['selected']) == 54 and len(SPECIAL) == 6
    records = []
    for index, selected in enumerate(selection['selected'], 1):
        source = by_id[selected['task_unit_id']]
        assert source['language'] == 'python'
        assert source['prompt_sha256'] == selected['source_prompt_sha256']
        status, family, reason = SPECIAL.get(index, (
            'OUTSIDE_CURRENT_ATOMIC_SCOPE', 'other',
            'The original prompt does not specify an external process invocation or private file write under this bounded command/private-write policy comparison; it remains a candidate for other research questions.'))
        records.append(dict(index=index, task_unit_id=selected['task_unit_id'],
                            source_lineage_id=selected['source_lineage_id'],
                            source_prompt_sha256=selected['source_prompt_sha256'],
                            status=status, current_policy_family=family, reason=reason,
                            model_outcomes_used=False, selector_or_graph_scores_used=False))
    counts = Counter(row['status'] for row in records)
    report = dict(
        status='SOURCE_ONLY_SCREEN_COMPLETED_NO_MODEL_OUTCOMES',
        reference_selection=str(frozen.relative_to(repo)),
        screened=54, previous_exposed=42, total_inspected_ceiling=96,
        current_atomic_policies=['structured_argv_without_host_shell',
                                 'private_file_write_from_first_byte_through_later_mode_changes'],
        source_usable_endpoint_pending=counts['SOURCE_USABLE_ENDPOINT_PENDING'],
        qualified_new_natural_endpoints=0,
        coverage_target_met=False,
        source_family_note='The two temporary-file tasks share a close operation family; their distinct source records do not imply two independent policy-mechanism families.',
        limitation='Source-only bounded screen by Codex, not an independent semantic gold standard or exclusion from all future policies.',
        counts=dict(counts), records=records)
    serialized=json.dumps(report,ensure_ascii=False,indent=2)+'\n'
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():
        assert target.read_text(encoding='utf-8')==serialized, 'saved natural source screen changed'
    else:
        target.write_text(serialized,encoding='utf-8')
    print(json.dumps(dict(screened=54,counts=dict(counts),qualified_new_endpoints=0)))


if __name__ == '__main__':
    main(Path(sys.argv[1]).resolve())
