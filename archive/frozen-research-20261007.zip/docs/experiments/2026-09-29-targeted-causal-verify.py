import argparse
import hashlib
import itertools
import json
import math
import subprocess
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
from scipy.stats import chi2


PREPARATION = Path('data/method/graph-guided-20260929/targeted-generation-preparation')
OUTCOMES = Path('results/graph-guided-20260929/targeted-generation-analysis')
LABELS = ['C', 'X', 'Y']


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bundle(path):
    for name, expected in read(path / 'manifest.json')['files'].items():
        assert digest(path / name) == expected, path / name


def cells_for(first, second):
    cells = [[0, 0], [0, 0]]
    for a, b in zip(first, second, strict=True):
        cells[a][b] += 1
    return cells


def pearson(cells):
    total = sum(map(sum, cells))
    score = 0.
    minimum = float('inf')
    for a in range(2):
        for b in range(2):
            expected = sum(cells[a]) * sum(row[b] for row in cells) / total
            minimum = min(minimum, expected)
            if expected:
                score += (cells[a][b] - expected) ** 2 / expected
    return score, minimum


def enumerate_exact(rows, first, second, conditioned):
    groups = [rows] if conditioned is None else [
        [row for row in rows if row[conditioned] == value] for value in (0, 1)]
    scores, observed, minima, tables = [], 0., [], []
    for group in groups:
        if not group:
            continue
        x = [row[first] for row in group]
        y = [row[second] for row in group]
        cells = cells_for(x, y)
        value, minimum = pearson(cells)
        observed += value
        minima.append(minimum)
        tables.append(cells)
        permutation_scores = []
        # 枚举观测位置上的标签分配，不使用超几何分布或生产统计公式。
        for selected in itertools.combinations(range(len(group)), sum(y)):
            indices = set(selected)
            assigned = [int(i in indices) for i in range(len(group))]
            permutation_scores.append(pearson(cells_for(x, assigned))[0])
        scores.append(permutation_scores)
    count, tail = 0, 0
    for values in itertools.product(*scores):
        count += 1
        tail += sum(values) >= observed - 1e-12
    return tail / count, observed, min(minima), tables, count


def independent_interval(values, alpha=.05):
    weights = [0, .05, .1, .2, .35, .5, .65, .8, .95]
    x = [(value + 1) / 2 for value in values]
    def wealth(m, lower):
        z = x if lower else [1 - value for value in x]
        target = m if lower else 1 - m
        return sum(math.prod(1 + c * (value / target - 1) for value in z)
                   for c in weights) / len(weights)
    left, right = 0., 1.
    if any(value > 0 for value in x):
        a, b = 1e-15, 1 - 1e-15
        for _ in range(100):
            m = (a + b) / 2
            if wealth(m, True) > 2 / alpha:
                a = m
            else:
                b = m
        left = max(0, (a + b) / 2 - 1e-10)
    if any(value < 1 for value in x):
        a, b = 1e-15, 1 - 1e-15
        for _ in range(100):
            m = (a + b) / 2
            if wealth(m, False) > 2 / alpha:
                b = m
            else:
                a = m
        right = min(1, (a + b) / 2 + 1e-10)
    return 2 * left - 1, 2 * right - 1


def normal_edges(edges):
    return sorted([a, left, right, b] if a < b else [b, right, left, a]
                  for a, left, right, b in edges)


def main(source, output, replay_backend):
    bundle(PREPARATION)
    bundle(OUTCOMES)
    bundle(source / 'inputs')
    bundle(source / 'summary')
    plan = read(source / 'inputs/plan.json')
    assert plan['preparation_manifest_sha256'] == digest(PREPARATION / 'manifest.json')
    assert plan['analysis_manifest_sha256'] == digest(OUTCOMES / 'manifest.json')
    candidates = read(PREPARATION / 'candidates.json')
    qualified = [row for row in candidates if row['quality_qualified']]
    assert len(qualified) == 19
    policy_map = {row['candidate_id']: row['policy_id'] for row in read(PREPARATION / 'bindings.json')}
    by_candidate = {row['candidate_id']: row for row in qualified}
    by_policy = defaultdict(list)
    for row in qualified:
        by_policy[policy_map[row['candidate_id']]].append(row)
    assert len(by_policy) == 18
    assignments = read(PREPARATION / 'assignments.json')
    by_request = {row['request_id']: row for row in assignments}
    outcomes = read(OUTCOMES / 'outcomes.json')
    matrices = read(source / 'inputs/matrices.json')
    selection = {}
    for panel in ('policy_family', 'tsg_support'):
        grouped = defaultdict(list)
        for group in by_policy.values():
            included = [row for row in group if panel == 'policy_family' or row['flow'] == 'TSG']
            if included:
                selected = min(included, key=lambda row: row['candidate_id'])
                grouped[selected['task_unit_id']].append(selected)
        selection[panel] = [min(group, key=lambda row: row['candidate_id'])
                            for _, group in sorted(grouped.items())]
    assert [len(selection[p]) for p in selection] == [10, 7]
    rng = np.random.default_rng(2026092930)
    replay = {}
    for panel, chosen in selection.items():
        for draw in range(32):
            ids = []
            for candidate in chosen:
                arm = ['N', 'P'][int(rng.integers(2))]
                requests = sorted([row for row in assignments
                                   if row['policy_id'] == policy_map[candidate['candidate_id']]
                                   and row['arm'] == arm], key=lambda row: (row['seed'], row['version']))
                ids.append(requests[int(rng.integers(4))]['request_id'])
            replay[panel, draw] = ids
    exact_count, permutations, opposed_strata = 0, 0, 0
    test_lookup = {}
    for matrix in matrices:
        records = matrix['records']
        assert matrix['n'] == len(records) == len({r['task_unit_id'] for r in records})
        assert matrix['n'] == len(selection[matrix['panel']])
        assert [r['request_id'] for r in records] == replay[matrix['panel'], matrix['draw']]
        assert [r['candidate_id'] for r in records] == [r['candidate_id'] for r in selection[matrix['panel']]]
        for record, row in zip(records, matrix['rows'], strict=True):
            request = by_request[record['request_id']]
            candidate = by_candidate[record['candidate_id']]
            observation = outcomes[record['request_id']]
            for field in ('task_unit_id', 'policy_id', 'index', 'slot', 'seed', 'version', 'arm'):
                assert record[field] == request[field]
            assert record['policy_id'] == policy_map[record['candidate_id']]
            assert record['candidate_id'] in request['candidate_memberships']
            assert digest_text(request['prompt']) == request['prompt_sha256']
            expected_x = int(candidate['operation'] == 'REMOVE') if matrix['panel'] == 'policy_family' else int(len(candidate['source_unit_ids']) > 1)
            assert record['X'] == expected_x
            assert record['C'] == int(record['arm'] == 'P')
            assert record['primary'] == int(observation['primary'][0])
            assert record['coverage'] == int(observation['security'] in ('secure', 'insecure'))
            assert row == [record['C'], expected_x, record[matrix['endpoint']]]
        for test in matrix['exact_tests']:
            first, second = LABELS.index(test['x']), LABELS.index(test['y'])
            conditioned = LABELS.index(test['S'][0]) if test['S'] else None
            p, statistic, minimum, tables, count = enumerate_exact(matrix['rows'], first, second, conditioned)
            assert abs(p - test['p_value']) < 1e-10, (matrix['identity'], test)
            assert abs(statistic - test['statistic']) < 1e-10
            assert abs(minimum - test['minimum_expected']) < 1e-10
            assert tables == [s['cells'] for s in test['strata']]
            signs = [table[1][1] * table[0][0] - table[1][0] * table[0][1] for table in tables]
            if any(value > 0 for value in signs) and any(value < 0 for value in signs):
                opposed_strata += 1
                assert statistic > 0
            key = '|'.join(sorted([test['x'], test['y']]) + test['S'])
            assert abs(matrix['exact_p'][key] - p) < 1e-10
            test_lookup[matrix['identity'], key] = (p, minimum, tables)
            exact_count += 1
            permutations += count
    searches = [json.loads(line) for line in (source / 'searches.jsonl').read_text().splitlines()]
    completion = read(source / 'summary/completion.json')
    assert completion['searches'] == len(searches) == len(matrices) * 14
    assert completion['matrices'] == len(matrices)
    assert completion['searches_sha256'] == digest(source / 'searches.jsonl')
    assert completion['input_manifest_sha256'] == digest(source / 'inputs/manifest.json')
    assert completion['stderr_sha256'] == digest(source / 'r-stderr.log')
    matrix_map = {m['identity']: m for m in matrices}
    query_count = guarded = 0
    for result in searches:
        matrix = matrix_map[result['identity']]
        for query in result.get('ci_diagnostics', []):
            key = '|'.join(sorted([query['x'], query['y']]) + query['S'])
            p, minimum, tables = test_lookup[result['identity'], key]
            assert abs(query['minimum_expected'] - minimum) < 1e-10
            guard = result['method'].endswith('_g2') and matrix['n'] < 10 * 2 ** len(query['S'])
            assert query['insufficient_n_guard'] == guard
            assert query['sparse'] == (minimum < 5)
            if result['method'].endswith('_exact'):
                assert abs(query['p_value'] - p) < 1e-10
            elif guard:
                assert query['p_value'] == 1
            else:
                likelihood = 0.
                for cells in tables:
                    total = sum(map(sum, cells))
                    for a in range(2):
                        for b in range(2):
                            observed = cells[a][b]
                            expected = sum(cells[a]) * sum(row[b] for row in cells) / total
                            if observed:
                                likelihood += 2 * observed * math.log(observed / expected)
                expected_p = float(chi2.sf(likelihood, 2 ** len(query['S'])))
                assert abs(query['p_value'] - expected_p) < 1e-9
            query_count += 1
            guarded += guard
        if 'temporal' in result['method']:
            for a, left, right, b in normal_edges(result['edges']):
                assert (a, b) != ('C', 'X')
                assert b != 'Y' or right == 'ARROW'
                if a == 'C' and b == 'Y' and 'JCI12' in result['method']:
                    assert left == 'TAIL'
    tables = read(source / 'summary/tables.json')
    for summary in tables['methods']:
        group = [r for r in searches if r['method'] == summary['method']
                 and matrix_map[r['identity']]['panel'] == summary['panel']
                 and matrix_map[r['identity']]['endpoint'] == summary['endpoint']]
        assert summary['draws'] == len(group)
        for key, first, second in [('cy', 'C', 'Y'), ('xy', 'X', 'Y')]:
            marks = []
            for row in group:
                found = [e for e in normal_edges(row['edges']) if e[0] == first and e[3] == second]
                marks.append(found[0][1] + '-' + found[0][2] if found else 'absent')
            assert summary[key] == dict(Counter(marks))
        queries = [q for row in group for q in row.get('ci_diagnostics', [])]
        assert summary['ci_queries'] == len(queries)
        assert summary['sparse_queries'] == sum(q['sparse'] for q in queries)
        assert summary['guarded_queries'] == sum(q['insufficient_n_guard'] for q in queries)
        assert summary['warning_draws'] == sum(bool(r.get('warnings')) for r in group)
        assert summary['empty_graphs'] == sum(not r['edges'] for r in group)
    search_map = {(r['identity'], r['method']): r for r in searches}
    for comparison in tables['jci_comparisons']:
        expected = []
        for matrix in matrices:
            if matrix['panel'] != comparison['panel'] or matrix['endpoint'] != comparison['endpoint']:
                continue
            suffix = '_' + comparison['background'] + '_' + comparison['test']
            first = search_map[matrix['identity'], 'FCI_JCI0' + suffix]
            second = search_map[matrix['identity'], 'FCI_JCI12' + suffix]
            if normal_edges(first['edges']) != normal_edges(second['edges']):
                expected.append(dict(identity=matrix['identity'], zero=first['edges'], jci12=second['edges']))
        assert comparison['changes'] == expected
        assert comparison['changed_graphs'] == len(expected)
    direct = read(source / 'inputs/direct.json')
    task_values = defaultdict(list)
    policy_values = {}
    for policy, group in by_policy.items():
        reqs = [r for r in assignments if r['policy_id'] == policy]
        means = {}
        for arm in ('P', 'N'):
            observed = [outcomes[r['request_id']] for r in reqs if r['arm'] == arm]
            assert len(observed) == 4
            means[arm] = [sum(o['primary'][0] for o in observed) / 4,
                          sum(o['security'] in ('secure', 'insecure') for o in observed) / 4,
                          sum(o['sensitivity'][0] for o in observed) / 4,
                          sum(o['sensitivity'][1] for o in observed) / 4]
        p, n = means['P'], means['N']
        values = [p[0]-n[0], p[1]-n[1], p[2]-n[3], p[3]-n[2]]
        task_values[group[0]['task_unit_id']].append(values)
        policy_values[policy] = values
    for record in direct['task_effects']:
        values = task_values[record['task_unit_id']]
        expected = [sum(row[i] for row in values) / len(values) for i in range(4)]
        assert record['policies'] == len(values)
        assert np.allclose([record['primary'], record['coverage'], *record['sensitivity']], expected)
    assert abs(direct['primary_mean'] - np.mean([r['primary'] for r in direct['task_effects']])) < 1e-12
    assert abs(direct['coverage_mean'] - np.mean([r['coverage'] for r in direct['task_effects']])) < 1e-12
    assert np.allclose(direct['sensitivity_mean'], np.mean([r['sensitivity'] for r in direct['task_effects']], axis=0))
    lower, upper = independent_interval([r['primary'] for r in direct['task_effects']])
    assert np.allclose([lower, upper], [direct['primary_interval']['lower'], direct['primary_interval']['upper']], atol=1e-9)
    lower = independent_interval([r['sensitivity'][0] for r in direct['task_effects']])[0]
    upper = independent_interval([r['sensitivity'][1] for r in direct['task_effects']])[1]
    assert np.allclose([lower, upper], [direct['sensitivity_interval']['lower'], direct['sensitivity_interval']['upper']], atol=1e-9)
    for panel, selected in direct.get('selected_panels', {}).items():
        assert [r['candidate_id'] for r in selected['tasks']] == [r['candidate_id'] for r in selection[panel]]
        values = []
        for task in selected['tasks']:
            expected = policy_values[policy_map[task['candidate_id']]]
            assert np.allclose([task['primary'], task['coverage'], *task['sensitivity']], expected)
            values.append(expected)
        means = [sum(row[i] for row in values) / len(values) for i in range(4)]
        assert np.allclose([selected['primary_mean'], selected['coverage_mean'], *selected['sensitivity_mean']], means)
    replay_results = []
    if replay_backend:
        from prompt_mechanism_study.development.context_algorithms import gfci, gfci_temporal
        import pandas as pd

        matrix = next(m for m in matrices if any(search_map[m['identity'], method]['edges']
                      for method in ['FCI_JCI0_original_g2', 'FCI_JCI12_original_g2']))
        request = {key: matrix[key] for key in ('identity', 'n', 'labels', 'rows', 'exact_p')}
        process = subprocess.run(['D:/R/R-4.3.1/bin/x64/Rscript.exe', 'src/development/targeted_context_search.R'],
                                 input=json.dumps(request) + '\n', capture_output=True, text=True,
                                 encoding='utf-8', check=True)
        replay_results.extend(json.loads(line) for line in process.stdout.splitlines())
        assert len(replay_results) == 12
        frame = pd.DataFrame(matrix['rows'], columns=LABELS, dtype=int)
        for method, function in [('GFCI_original', gfci), ('GFCI_JCI12_temporal', gfci_temporal)]:
            replay_results.append(dict(identity=matrix['identity'], method=method, edges=function(frame)))
        for result in replay_results:
            original = search_map[result['identity'], result['method']]
            assert normal_edges(result['edges']) == normal_edges(original['edges'])
            if 'ci_diagnostics' in result:
                assert result['ci_diagnostics'] == original['ci_diagnostics']
    findings = dict(exact_searches=sum(r['method'].endswith('_exact') for r in searches),
                    exact_empty_graphs=sum(r['method'].endswith('_exact') and not r['edges'] for r in searches),
                    primary_xy_edges=sum(matrix_map[r['identity']]['endpoint'] == 'primary'
                                         and any(e[0] == 'X' and e[3] == 'Y' for e in normal_edges(r['edges']))
                                         for r in searches),
                    original_cx_edges=sum('original' in r['method']
                                          and any(e[0] == 'C' and e[3] == 'X' for e in normal_edges(r['edges']))
                                          for r in searches),
                    temporal_cx_edges=sum('temporal' in r['method']
                                          and any(e[0] == 'C' and e[3] == 'X' for e in normal_edges(r['edges']))
                                          for r in searches))
    report = dict(status='INDEPENDENT_POSITION_ENUMERATION_AND_RESULT_VERIFIED', matrices=len(matrices),
                  searches=len(searches), exact_tests=exact_count, enumerated_label_assignments=permutations,
                  actual_ci_queries=query_count, guarded_queries=guarded, unique_policies=18,
                  opposed_strata_tests=opposed_strata, backend_replay=replay_results, findings=findings,
                  qualified_nominations=19, task_counts={p: len(v) for p, v in selection.items()},
                  source=str(source), verifier_sha256=digest(Path(__file__)),
                  input_manifest_sha256=digest(source / 'inputs/manifest.json'),
                  searches_sha256=digest(source / 'searches.jsonl'))
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x', encoding='utf-8') as stream:
        json.dump(report, stream, ensure_ascii=False, indent=2)
    print(json.dumps(report))


def digest_text(text):
    return hashlib.sha256(json.dumps(text, ensure_ascii=False, separators=(',', ':')).encode('utf-8')).hexdigest()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('source', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--replay-backend', action='store_true')
    args = parser.parse_args()
    main(args.source, args.output, args.replay_backend)
