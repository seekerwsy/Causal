import argparse
import hashlib
import json
import os
import signal
import socket
import subprocess
import sys
import time
from datetime import datetime, timezone
from importlib.metadata import version
from pathlib import Path

from prompt_mechanism_study.artifact_io import file_sha256, read_json, verify_bundle, write_bundle
from prompt_mechanism_study.development.source_generation import MODEL, SYSTEM, run_jci, jci_measurement_worker
import prompt_mechanism_study.development.source_generation as generator
import prompt_mechanism_study.development.source_output_envelope as envelope
import prompt_mechanism_study.llm as transport
import prompt_mechanism_study.measurement.native_behavior as native


ROOT = Path('/home/wsy/work/prompt-mechanism-study')
INPUTS = ROOT / 'inputs/controlled-semantic-20260930'
RESULTS = ROOT / 'results/controlled-semantic-20260930'
CHECKPOINT = Path('/home/ubuntu/RAID5/data/model_zoo/CodeLLMs/Qwen2.5-Coder-32B-Instruct')


def identify_checkpoint():
    previous = ROOT / 'inputs/graph-guided-20260929/model-identity'
    verify_bundle(previous)
    records = read_json(previous / 'files.json')
    started = time.perf_counter()
    for row in records:
        path = CHECKPOINT / row['name']
        if path.parent != CHECKPOINT or path.stat().st_size != row['bytes']:
            raise ValueError('模型文件大小或路径与已核实身份不符')
        with path.open('rb') as stream:
            actual = hashlib.file_digest(stream, 'sha256').hexdigest()
        if actual != row['sha256']:
            raise ValueError('模型文件内容改变')
        print(json.dumps(dict(verified=path.name)), flush=True)
    identity = read_json(previous / 'identity.json')
    identity.update(captured_utc=datetime.now(timezone.utc).isoformat(),
                    prior_manifest_sha256=file_sha256(previous / 'manifest.json'),
                    versions={name: version(name) for name in ('vllm', 'torch', 'transformers', 'safetensors')},
                    hash_elapsed_seconds=time.perf_counter()-started)
    write_bundle(INPUTS / 'model-identity', {'files.json': records, 'identity.json': identity,
                                          'chat-template.json': read_json(previous / 'chat-template.json')})


def serve(phase, maximum_new=None, generation_workers=1, gpu_memory_utilization=.48,
          measurement_recovery=None):
    prepared = INPUTS / ('development-qualified-inputs' if phase == 'development' else
                        'natural-qualified-inputs' if phase == 'natural' else 'experiment-qualified-inputs')
    evaluation = INPUTS / 'evaluation-decisions' if phase == 'evaluation' else None
    for path in (prepared, INPUTS / 'model-identity', INPUTS / 'launch'):
        verify_bundle(path)
    if evaluation is not None:
        verify_bundle(evaluation)
    metadata = read_json(prepared / 'metadata.json')
    if phase == 'natural':
        from prompt_mechanism_study.development.jci_ridge import validate_controlled_natural_binding
        validate_controlled_natural_binding(prepared, INPUTS / 'evaluation-decisions',
            INPUTS / 'experiment-qualified-inputs', INPUTS / 'natural-preparation', RESULTS / 'analysis/analysis')
    launch = read_json(INPUTS / 'launch/launch.json')
    amendment_path = INPUTS / 'execution-resource-amendment'
    execution = dict(generation_workers=generation_workers, measurement_workers=1,
                     maximum_pending_measurements=generation_workers)
    recovered = None
    recovery_directory = None
    if measurement_recovery is not None:
        recovery_directory = RESULTS / phase / measurement_recovery / 'measurement-recovery'
        verify_bundle(recovery_directory)
        recovered = read_json(recovery_directory / 'identity.json')
        if (recovered['input_manifest_sha256'] != file_sha256(prepared / 'manifest.json')
                or recovered['generation_sha256'] != file_sha256(Path(generator.__file__))
                or recovered['runtime_sha256'] != file_sha256(Path(__file__))
                or generator.read_jci_result(recovery_directory.parent)['status'] != 'returned'):
            raise ValueError('恢复测量与实际输入或实现不符')
    amendment = None
    if amendment_path.exists():
        verify_bundle(amendment_path)
        amendment = read_json(amendment_path / 'amendment.json')
        if recovered is not None and (recovered['execution_amendment_manifest_sha256'] != file_sha256(amendment_path / 'manifest.json')
                or recovered['previous_generation_sha256'] != amendment['generation_sha256']
                or recovered['previous_runtime_sha256'] != amendment['runtime_sha256']):
            raise ValueError('恢复测量没有绑定原冻结执行身份')
        if (amendment['input_manifest_sha256'] != file_sha256(prepared / 'manifest.json')
                or dict(execution=execution, gpu_memory_utilization=gpu_memory_utilization)
                    not in amendment['service_configurations']
                or amendment['authorization'] != 'OWNER_AUTHORIZED_RESOURCE_ADAPTATION_20261004'
                or amendment['previous_execution_amendment_manifest_sha256']
                    != file_sha256(INPUTS / 'execution-amendment/manifest.json')
                or (recovered or amendment)['generation_sha256'] != file_sha256(Path(generator.__file__))
                or (recovered or amendment)['runtime_sha256'] != file_sha256(Path(__file__))):
            raise ValueError('并发执行修订与实际输入或实现不符')
    else:
        raise ValueError('当前资源配置尚未冻结')
    if (launch['protocol_id'] != metadata['protocol_id']
            or launch['generation_call_limit'] != 28510
            or launch['model_service_seconds_limit'] != 432000):
        raise ValueError('研究范围或预算不匹配')
    prior_calls, prior_seconds = 0, 0.
    previous_services = sorted(RESULTS.glob('service-*'))
    previous_phases = set()
    for previous in previous_services:
        verify_bundle(previous / 'stopped')
        record = read_json(previous / 'stopped/service.json')
        if not record['process_absent']:
            raise ValueError('已有研究模型服务尚未终止')
        prior_seconds += record['service_seconds']
        previous_phases.add(record['phase'])
    prior_calls = sum(len(list((RESULTS / old_phase).glob('*/assigned/manifest.json')))
                      for old_phase in previous_phases if old_phase != phase)
    existing_phase_calls = len(list((RESULTS / phase).glob('*/assigned/manifest.json')))
    if phase == 'evaluation':
        verify_bundle(RESULTS / 'training/summary')
        planned = len(read_json(evaluation / 'evaluation-requests.json'))
    else:
        planned = len(read_json(prepared / f'{phase}-requests.json'))
    if (prior_calls + planned > launch['generation_call_limit']
            or prior_seconds >= launch['model_service_seconds_limit']):
        raise ValueError('计划超过累计预算')
    if datetime.now(timezone.utc) >= datetime.fromisoformat(launch['deadline_utc']):
        raise TimeoutError('研究期限已经耗尽')
    with socket.socket() as probe:
        if probe.connect_ex(('127.0.0.1', 18584)) == 0:
            raise RuntimeError('端口已被其他服务占用')
    tasks = {row['task_unit_id']: row for row in read_json(prepared / 'tasks.json')}
    allocation = read_json((evaluation or prepared) / f'{phase}-requests.json')
    if phase == 'natural':
        from prompt_mechanism_study.development.jci_ridge import validate_controlled_natural_execution
        validate_controlled_natural_execution(list(tasks.values()), allocation)
    for request in allocation:
        prompt = tasks[request['task_unit_id']]['prompts'][request['prompt_hash']]
        if generator.content_hash(prompt) != request['prompt_hash']:
            raise ValueError('事前全文摘要核验未通过')
        if request['messages'] != [dict(role='system', content=SYSTEM),
                dict(role='user', content=generator.canonical_json({'task': prompt}))]:
            raise ValueError('事前完整传输消息核验未通过')
    runtime = RESULTS / f'service-{phase}-{len(previous_services)+1}'
    scratch = RESULTS / f'{phase}-work-{len(previous_services)+1}'
    rpc = ROOT / 'results' / f'csrpc-{phase}-{len(previous_services)+1}'
    if len(str(rpc).encode()) + 37 > 107:
        raise ValueError('进程通信路径超过系统长度限制')
    assigned_environment = dict(CUDA_VISIBLE_DEVICES='0,1', HF_HUB_OFFLINE='1',
        TRANSFORMERS_OFFLINE='1', VLLM_DO_NOT_TRACK='1', TMPDIR=str(scratch),
        VLLM_RPC_BASE_PATH=str(rpc), VLLM_CACHE_ROOT=str(scratch / 'vllm-cache'),
        TRITON_CACHE_DIR=str(scratch / 'triton-cache'), TORCHINDUCTOR_CACHE_DIR=str(scratch / 'torch-cache'),
        CUDA_CACHE_PATH=str(scratch / 'cuda-cache'))
    environment = dict(os.environ, **assigned_environment)
    argv = [sys.executable, '-m', 'vllm.entrypoints.openai.api_server', '--model', str(CHECKPOINT),
            '--served-model-name', MODEL['model_id'], '--host', '127.0.0.1', '--port', '18584',
            '--tensor-parallel-size', '2', '--dtype', 'bfloat16', '--max-model-len', '8192',
            '--max-num-seqs', str(generation_workers),
            '--gpu-memory-utilization', str(gpu_memory_utilization), '--enforce-eager',
            '--no-enable-prefix-caching', '--disable-custom-all-reduce', '--generation-config', 'vllm',
            '--seed', str(launch['master_seed'])]
    input_identities = read_json(prepared / 'input-identities.json')
    worker = jci_measurement_worker(INPUTS, phase, input_identities)
    if (file_sha256(Path(native.__file__)) != input_identities['src/measurement/native_behavior.py']
            or file_sha256(Path(generator.__file__)) != ((recovered or amendment)['generation_sha256'] if amendment is not None
                else input_identities['src/development/source_generation.py'])
            or file_sha256(Path(transport.__file__)) != input_identities['src/llm.py']):
        raise ValueError('实际测量实现与通过资格的冻结实现不匹配')
    planned_environment = read_json(prepared / 'environment.json')
    if (planned_environment['model'] != MODEL or planned_environment['system_prompt'] != SYSTEM
            or planned_environment['worker_sha256'] != file_sha256(worker)
            or planned_environment['measurement_sha256'] != input_identities['src/measurement/controlled_command.py']
            or planned_environment['model_manifest_sha256'] != file_sha256(INPUTS / 'model-identity/manifest.json')
            or ((recovered or amendment)['runtime_sha256'] if amendment is not None
                else planned_environment['runtime_sha256']) != file_sha256(Path(__file__))):
        raise ValueError('实际模型及服务参数实现与请求冻结身份不符')
    if recovered is not None and (recovered['worker_sha256'] != file_sha256(worker)
            or recovered['docker_image'] != metadata['docker_image']):
        raise ValueError('恢复观察环境与冻结测量身份不同')
    frozen = dict(phase=phase, model=MODEL, system_prompt=SYSTEM, argv=argv, execution=execution,
        environment=assigned_environment, frozen_utc=datetime.now(timezone.utc).isoformat(),
        input_manifest_sha256=file_sha256(prepared / 'manifest.json'),
        evaluation_manifest_sha256=file_sha256(evaluation / 'manifest.json') if evaluation else None,
        model_manifest_sha256=file_sha256(INPUTS / 'model-identity/manifest.json'),
        generation_sha256=file_sha256(Path(generator.__file__)), worker_sha256=file_sha256(worker),
        implementation_sha256={name: file_sha256(Path(module.__file__)) for name, module in (
            ('transport', transport), ('envelope', envelope), ('native_container', native))},
        runner_sha256=file_sha256(Path(__file__)), prior_attempts=prior_calls,
        existing_phase_attempts=existing_phase_calls, prior_service_seconds=prior_seconds,
        model_service_seconds_limit=launch['model_service_seconds_limit'],
        generation_call_limit=launch['generation_call_limit'],
        planned_requests=planned, docker_image=metadata['docker_image'],
        execution_amendment_manifest_sha256=(file_sha256(amendment_path / 'manifest.json')
                                            if amendment is not None else None),
        measurement_recovery=(dict(request_id=measurement_recovery,
            manifest_sha256=file_sha256(recovery_directory / 'manifest.json')) if recovered is not None else None),
        deadline_utc=launch['deadline_utc'],
        gpu_at_start=subprocess.run(['nvidia-smi', '--query-gpu=index,name,memory.total,memory.used',
            '--format=csv,noheader'], capture_output=True, text=True, check=True).stdout.splitlines())
    image = subprocess.run(['docker', 'image', 'inspect', '--format', '{{.Id}}', metadata['docker_image']],
                           capture_output=True, text=True, check=True).stdout.strip()
    if image != metadata['docker_image']:
        raise ValueError('观察镜像身份不匹配')
    runtime.mkdir(parents=True, exist_ok=False)
    scratch.mkdir()
    rpc.mkdir()
    write_bundle(runtime / 'frozen', {'runtime.json': frozen})
    started = time.monotonic()
    service_record = dict(started_utc=datetime.now(timezone.utc).isoformat(), phase=phase)
    stop_requested = False
    def finish_current_requests(signum, frame):
        nonlocal stop_requested
        stop_requested = True
    signal.signal(signal.SIGUSR1, finish_current_requests)
    with (runtime / 'vllm.log').open('w') as log:
        process = subprocess.Popen(argv, cwd=scratch, env=environment, stdout=log,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        service_record['pid'] = process.pid
        try:
            ready = False
            for _ in range(300):
                if process.poll() is not None:
                    raise RuntimeError('vLLM 启动进程终止')
                reply = subprocess.run(['curl', '--silent', '--fail', '--max-time', '2',
                    'http://127.0.0.1:18584/v1/models'], capture_output=True)
                if reply.returncode == 0:
                    listed = json.loads(reply.stdout)
                    if [row['id'] for row in listed['data']] != [MODEL['model_id']]:
                        raise ValueError('模型服务身份不匹配')
                    ready = True
                    break
                time.sleep(2)
            if not ready:
                raise TimeoutError('模型服务启动超时')
            write_bundle(runtime / 'ready', {'service.json': service_record})
            remaining = min(launch['model_service_seconds_limit']-prior_seconds-(time.monotonic()-started),
                (datetime.fromisoformat(launch['deadline_utc'])-datetime.now(timezone.utc)).total_seconds())-60
            if remaining <= 0:
                raise TimeoutError('模型服务或研究期限已经耗尽')
            def deadline_reached(signum, frame):
                raise TimeoutError('累计模型服务或研究时限已经达到')
            signal.signal(signal.SIGALRM, deadline_reached)
            signal.setitimer(signal.ITIMER_REAL, remaining)
            run_jci(prepared, runtime, RESULTS / phase, worker, phase, evaluation,
                    maximum_new=maximum_new, stop_requested=lambda: stop_requested)
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGTERM)
                process.wait(timeout=60)
            service_record.update(stopped_utc=datetime.now(timezone.utc).isoformat(),
                                  service_seconds=time.monotonic()-started,
                                  cumulative_service_seconds=prior_seconds+time.monotonic()-started,
                                  process_absent=process.poll() is not None)
            write_bundle(runtime / 'stopped', {'service.json': service_record})


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('identify-checkpoint', 'development', 'training', 'evaluation', 'natural'))
    parser.add_argument('--maximum-new', type=int)
    parser.add_argument('--generation-workers', type=int, choices=(1, 4), default=1)
    parser.add_argument('--gpu-memory-utilization', type=float, choices=(.48, .50), default=.48)
    parser.add_argument('--measurement-recovery')
    arguments = parser.parse_args()
    if arguments.action == 'identify-checkpoint':
        identify_checkpoint()
    else:
        serve(arguments.action, arguments.maximum_new, arguments.generation_workers,
              arguments.gpu_memory_utilization, arguments.measurement_recovery)
