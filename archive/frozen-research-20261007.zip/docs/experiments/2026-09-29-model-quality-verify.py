from __future__ import annotations

import argparse
from collections import Counter
from importlib.metadata import version
from pathlib import Path
import platform
import re
import sys

from prompt_mechanism_study.artifact_io import (
    file_sha256,
    read_json_exact,
    verify_bundle,
    write_bundle,
)


CRITERIA = (
    "source_support",
    "atomic_boundary",
    "non_target_preservation",
    "state_and_version_consistency",
    "distinguishable",
)
VALUES = ("support", "not_support", "unknown")
FLOWS = ("TSG", "Raw")
BASE = Path("data/method/graph-guided-20260929")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def index_rows(rows: list[dict], label: str, expected_positions: int) -> dict[str, dict]:
    require(isinstance(rows, list), f"{label}: rows must be a list")
    require(len(rows) == expected_positions, f"{label}: expected {expected_positions} positions")
    indexed = {}
    for row in rows:
        require(isinstance(row, dict), f"{label}: position must be an object")
        blind_id = row["blind_id"]
        require(
            isinstance(blind_id, str)
            and len(blind_id) == 64
            and all(character in "0123456789abcdef" for character in blind_id),
            f"{label}: invalid blind_id",
        )
        require(blind_id not in indexed, f"{label}: repeated blind_id {blind_id}")
        indexed[blind_id] = row
    return indexed


def evidence_text(evidence: str | dict) -> str:
    if isinstance(evidence, str):
        require(bool(evidence.strip()), "empty evidence")
        return evidence
    require(isinstance(evidence, dict) and bool(evidence), "invalid evidence")
    require(
        all(isinstance(value, str) and value.strip() for value in evidence.values()),
        "evidence fields must contain nonempty text",
    )
    return "\n".join(evidence.values())


def estimate(numerator: int, denominator: int) -> dict:
    return {
        "numerator": numerator,
        "denominator": denominator,
        "rate": numerator / denominator,
    }


def flow_label_mentions(packets: dict[str, dict], include_source: bool = False) -> list[dict]:
    mentions = []
    for blind_id, packet in packets.items():
        pending = [(["policy"], packet["policy"])]
        if include_source:
            pending.append((["source"], packet["source"]))
        while pending:
            path, value = pending.pop()
            if isinstance(value, dict):
                pending.extend((path + [key], child) for key, child in value.items())
            elif isinstance(value, list):
                pending.extend((path + [index], child) for index, child in enumerate(value))
            elif isinstance(value, str) and re.search(r"(?<![A-Za-z0-9_])(?:Raw|TSG)(?![A-Za-z0-9_])", value):
                mentions.append({"blind_id": blind_id, "field": path, "quote": value})
    return mentions


def verify_graph_reviews(root: Path, requested_output: Path | None, registration: dict | None = None) -> None:
    material = root / (Path(registration['material_root']) if registration else BASE / "model-quality-repair")
    graph_task_count = sum(row['flow'] == 'TSG' for row in registration['streams']) if registration else 18
    graph_position_count = graph_task_count * 2
    common_position_count = len(registration['streams']) * 2 if registration else 72
    public = material / "graph-public"
    verify_bundle(public)
    protocol = read_json_exact(public / "protocol.json")
    packets = read_json_exact(public / "packets.json")
    criteria = ("graph_source_fidelity", "graph_source_coverage", "selected_support_completeness")
    require(tuple(protocol["criteria"]) == criteria, "graph criteria changed")
    require(protocol["tasks"] == graph_task_count and protocol["positions"] == graph_position_count, "graph denominator changed")
    require(protocol["outcomes_visible"] is False and protocol["preparation_qualification_visible"] is False,
            "graph review visibility changed")
    require(protocol["common_review_changes_permitted"] is False, "common review freeze changed")
    common_result = root / (Path(registration['common_verification_root']) if registration
                            else Path("results/graph-guided-20260929/repair-model-quality-verification"))
    verify_bundle(common_result)
    require(file_sha256(common_result / "manifest.json") == protocol["common_verification_manifest_sha256"],
            "common verification identity changed")
    common = read_json_exact(common_result / "summary.json")
    require(common["population"] == "repair", "common population changed")
    common_positions = index_rows(read_json_exact(common_result / "positions.json"), "common positions", common_position_count)
    if registration:
        require(common['flow_blinding_protocol_passed'] is True, 'registered common blinding failed')
        public_packets = index_rows(read_json_exact(material / 'public/packets.json'), 'common packets', common_position_count)
        require(not flow_label_mentions(public_packets, include_source=True), 'common public flow labels exposed')
    for role in ("reviewer_a", "reviewer_b"):
        path = root / common["input_identity"][role]["path"]
        require(file_sha256(path) == protocol["common_review_sha256"][role]
                == common["input_identity"][role]["sha256"], "common review changed after graph release")
    require(file_sha256(material / "public/manifest.json") == protocol["common_public_manifest_sha256"],
            "common public material changed")
    tasks = {row["task_id"]: row for row in packets["tasks"]}
    require(len(tasks) == len(packets["tasks"]) == graph_task_count, "graph task identities changed")
    positions = index_rows(packets["positions"], "graph positions", graph_position_count)
    require(Counter(row["task_id"] for row in positions.values()) == {task: 2 for task in tasks},
            "graph task position accounting changed")
    public_sha = file_sha256(public / "manifest.json")
    reviews, identities, reviewers = {}, {}, set()
    for label in ("reviewer_a", "reviewer_b"):
        path = material / ("graph-" + label.replace("_", "-") + ".json")
        review = read_json_exact(path)
        require(review["reviewer_kind"] == "isolated_model_session", "graph reviewer kind changed")
        require(review["independent_from_preparation"] is True, "graph reviewer participated in preparation")
        require(review["generated_code_or_outcomes_seen"] is False, "graph reviewer has outcomes")
        require(review["graph_public_manifest_sha256"] == public_sha, "graph review material identity differs")
        require(review["common_review_sha256"] == protocol["common_review_sha256"], "common review references changed")
        require(review["reviewer_id"] not in reviewers, "graph reviewer identity repeated")
        reviewers.add(review["reviewer_id"])
        judgments = index_rows(review["judgments"], "graph " + label, graph_position_count)
        require(set(judgments) == set(positions), "graph review position coverage changed")
        for blind_id, judgment in judgments.items():
            position = positions[blind_id]
            require(judgment["task_id"] == position["task_id"], "graph review task binding changed")
            for criterion in criteria:
                require(judgment[criterion] in VALUES, "invalid graph judgment value")
            evidence_text(judgment["evidence"])
            graph = tasks[position["task_id"]]["graph"]
            if not graph or not graph.get("nodes"):
                require(all(judgment[criterion] == "unknown" for criterion in criteria),
                        "missing graph receives determinate judgment")
            if position["target"] is None or position["subgraph"] is None:
                require(judgment["selected_support_completeness"] == "unknown", "missing target receives determinate judgment")
        for task_id in tasks:
            paired = [judgments[key] for key, position in positions.items() if position["task_id"] == task_id]
            require(all(paired[0][name] == paired[1][name] for name in criteria[:2]),
                    "same complete graph received inconsistent source judgments within one reviewer")
        reviews[label] = judgments
        identities[label] = {"path": path.relative_to(root).as_posix(), "sha256": file_sha256(path)}
    results = []
    for blind_id, position in sorted(positions.items()):
        local_support = all(rows[blind_id]["selected_support_completeness"] == "support"
                            for rows in reviews.values())
        common_support = common_positions[blind_id]["conservative_model_quality_support"]
        results.append({"blind_id": blind_id, "task_id": position["task_id"],
                        "judgments": {label: {name: rows[blind_id][name] for name in criteria}
                                      for label, rows in reviews.items()},
                        "conservative_support": all(rows[blind_id][name] == "support"
                                                    for rows in reviews.values() for name in criteria),
                        "selected_support_completeness_both": local_support,
                        "common_five_criteria_both": common_support,
                        "common_and_selected_support_both": common_support and local_support,
                        "evidence": {label: rows[blind_id]["evidence"] for label, rows in reviews.items()}})
    summary = {"status": "EXECUTED_SEPARATE_GRAPH_SOURCE_MODEL_REVIEW_VERIFIED", "population": "repair",
               "tasks": graph_task_count, "positions": graph_position_count, "criteria": list(criteria),
               "common_review_sha256": protocol["common_review_sha256"],
               "common_reviews_preserved": True, "graph_public_manifest_sha256": public_sha,
               "common_verification_manifest_sha256": file_sha256(common_result / "manifest.json"),
               "flow_blinding_protocol_passed": common["flow_blinding_protocol_passed"],
               "conservative_support": estimate(sum(row["conservative_support"] for row in results), graph_position_count),
               "selected_support_completeness_both": estimate(sum(row["selected_support_completeness_both"] for row in results), graph_position_count),
               "common_and_selected_support_both": estimate(sum(row["common_and_selected_support_both"] for row in results), graph_position_count),
               "whole_graph_tasks": {
                   name: estimate(len({row["task_id"] for row in results
                                       if all(row["judgments"][label][name] == "support" for label in reviews)}), graph_task_count)
                   for name in criteria[:2]
               },
               "qualification_scope": "Whole-graph quality and local candidate support are separate. The all-three graph metric is not a local admission gate. Common-plus-local counts describe these recorded reviews and do not establish code effects.",
               "per_model": {label: {name: {value: sum(row[name] == value for row in judgments.values())
                                            for value in VALUES} for name in criteria}
                             for label, judgments in reviews.items()},
               "input_identity": identities, "verifier_sha256": file_sha256(Path(__file__)),
               "semantic_claim_boundary": "Checks identities, accounting and declared judgments; semantic correctness requires inspection of graph, source and model evidence."}
    destination = requested_output or (common_result.parent / (common_result.name + '-graph') if registration
                                       else Path("results/graph-guided-20260929/repair-graph-quality-verification"))
    if not destination.is_absolute():
        destination = root / destination
    write_bundle(destination, {"summary.json": summary, "positions.json": results})
    verify_bundle(destination)
    print(f"Verified {graph_position_count} graph positions and {graph_position_count * 6} graph criterion values: {destination}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--population", choices=("development", "evaluation", "repair"), default="development")
    parser.add_argument("--graph-review", action="store_true")
    parser.add_argument("--repair-registration", type=Path)
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
    )
    args = parser.parse_args()
    root = args.root.resolve()
    registration = read_json_exact(root / args.repair_registration) if args.repair_registration else None
    if registration:
        require(args.population == 'repair', 'registration only supports repair population')
        streams = registration['streams']
        require(isinstance(streams, list) and bool(streams), 'missing registered streams')
        coordinates = {(row['index'], row['flow']) for row in streams}
        require(len(coordinates) == len(streams) and all(flow in FLOWS for _, flow in coordinates),
                'invalid registered stream identities')
        material_identity = read_json_exact(root / registration['material_root'] / 'private/identity.json')
        require(material_identity['repair_registration_sha256'] == file_sha256(root / args.repair_registration),
                'registered material identity changed')
    if args.graph_review:
        require(args.population == "repair", "graph review only supports repair population")
        verify_graph_reviews(root, args.output, registration)
        return
    source_root = root / BASE
    material = {"development": "human-quality-development", "evaluation": "model-quality-evaluation",
                "repair": "model-quality-repair"}[args.population]
    reviews = {"development": "model-quality-development", "evaluation": "model-quality-evaluation",
               "repair": "model-quality-repair"}[args.population]
    task_count = 16 if args.population == "development" else 18
    expected_positions, flow_denominator = task_count * 4, task_count * 2
    flow_denominators = {flow: flow_denominator for flow in FLOWS}
    if registration:
        material = reviews = str(root / registration['material_root'])
        task_count = len({index for index, _ in coordinates})
        expected_positions = len(coordinates) * 2
        flow_denominators = {flow: sum(registered_flow == flow for _, registered_flow in coordinates) * 2
                             for flow in FLOWS}
        require(all(flow_denominators.values()), 'both registered flows require assigned positions')
    paths = {
        "protocol": source_root / material / "public/protocol.json",
        "packets": source_root / material / "public/packets.json",
        "template": source_root / material / "public/judgments-template.json",
        "mapping": source_root / material / "private/mapping.json",
        "reviewer_a": source_root / reviews / "reviewer-a.json",
        "reviewer_b": source_root / reviews / "reviewer-b.json",
    }
    inputs = {label: read_json_exact(path) for label, path in paths.items()}
    protocol = inputs["protocol"]
    public_manifest_sha256 = file_sha256(source_root / material / "public/manifest.json")
    if args.population == "repair":
        verify_bundle(source_root / material / "public")
        verify_bundle(source_root / material / "private")
        for field in ("flow_labels_visible", "graphs_visible", "preparation_qualification_visible"):
            require(protocol[field] is False, f"repair blind condition changed: {field}")
    require(protocol["positions"] == expected_positions and protocol["tasks"] == task_count, "protocol size drift")
    require(tuple(protocol["judgment_values"]) == VALUES, "protocol values drift")
    for field in ("generated_codes_visible", "outcomes_visible", "selector_scores_visible"):
        require(protocol[field] is False, f"unexpected visible field {field}")
    packets = index_rows(inputs["packets"], "packets", expected_positions)
    label_mentions = flow_label_mentions(packets, include_source=bool(registration)) if args.population == "repair" else []
    if registration:
        require(protocol.get('public_flow_label_audit_passed') is True, 'pre-publication flow audit is absent')
        require(not label_mentions, f'PUBLIC_FLOW_BLINDING_FAILED: {label_mentions}')
    mapping = index_rows(inputs["mapping"], "mapping", expected_positions)
    template = index_rows(inputs["template"]["judgments"], "template", expected_positions)
    ids = set(packets)
    require(ids == set(mapping) == set(template), "input blind_id sets differ")
    require(len({row["task_id"] for row in packets.values()}) == task_count, "task count drift")
    require(Counter(row["flow"] for row in mapping.values()) == flow_denominators,
            "flow denominators changed")
    units = Counter()
    sources = {}
    source_quote_count = 0
    missing_source_citation_ids = set()
    null_policy_ids = set()
    for blind_id, packet in packets.items():
        if args.population == "repair":
            require(set(packet) == {"blind_id", "task_id", "source", "policy"}, "unexpected public packet metadata")
            require(set(packet["source"]) == {"source_prompt", "system_prompt", "shared_execution_interface", "measurement"},
                    "unexpected repair source metadata")
        mapped = mapping[blind_id]
        require(packet["task_id"] == mapped["task_id"], f"task binding drift {blind_id}")
        require(mapped["flow"] in FLOWS and mapped["position"] in (0, 1),
                f"invalid assigned position {blind_id}")
        units[(mapped["task_id"], mapped["flow"], mapped["position"])] += 1
        source = packet["source"]
        require(sources.setdefault(packet["task_id"], source) == source,
                f"same-task source differs {blind_id}")
        for criterion in CRITERIA:
            require(template[blind_id][criterion] is None, "template already has judgments")
        policy = packet["policy"]
        if policy is None:
            null_policy_ids.add(blind_id)
            continue
        if args.population == "repair":
            require(set(policy) == {"target", "operation", "scope", "state_p", "state_n", "p_versions",
                                   "n_versions", "non_target_requirements", "contract", "source_citations"},
                    "unexpected public policy metadata")
            if registration:
                require(isinstance(policy['contract'], dict) and set(policy['contract']) <= {
                    'target_proposition', 'source_state', 'object_roles', 'state_p', 'state_n',
                    'operation', 'scope', 'non_target_requirements', 'measurement_endpoint',
                    'version_rules', 'cross_task_role_mapping', 'applicable_conditions', 'unknown_conditions'},
                    'unexpected public contract metadata')
        for state in ("p_versions", "n_versions"):
            require(isinstance(policy[state], list) and len(policy[state]) == 2,
                    f"missing complete versions {blind_id}:{state}")
            require(all(isinstance(text, str) and text.strip() for text in policy[state]),
                    f"empty version {blind_id}:{state}")
        require(isinstance(policy["source_citations"], list), f"invalid original source citations {blind_id}")
        if not policy["source_citations"]:
            require(mapped["frozen_status"] != "qualified", f"qualified policy lacks source citations {blind_id}")
            missing_source_citation_ids.add(blind_id)
        for quote in policy["source_citations"]:
            require(isinstance(quote, str) and quote and quote in source["source_prompt"],
                    f"source citation does not match original {blind_id}: {quote!r}")
            source_quote_count += 1
    require(len(units) == expected_positions and set(units.values()) == {1}, "repeated task/flow/position")
    if registration:
        require({(row['index'], row['flow'], row['position']) for row in mapping.values()}
                == {(index, flow, position) for index, flow in coordinates for position in (0, 1)},
                'registered positions changed')
    else:
        require(all((task, flow, position) in units for task in sources
                    for flow in FLOWS for position in (0, 1)), "missing assigned position")
    require(len(packets) - len(null_policy_ids) == protocol["materialized_policies"],
            "materialized policy count drift")

    reviewers = {}
    blinding_exposures = {}
    duplicate_edges = {}
    same_flow_duplicate_ids = {}
    reviewer_ids = set()
    for label in ("reviewer_a", "reviewer_b"):
        review = inputs[label]
        require(review["reviewer_kind"] == "isolated_model_session", "unexpected reviewer kind")
        require(review["generated_code_or_outcomes_seen"] is False,
                f"outcome access declared by {label}")
        require(review["independent_from_preparation"] is True,
                f"preparation participation declared by {label}")
        if args.population == "repair":
            require(review["repair_graphs_seen"] is False, f"repair graph exposure declared by {label}")
            exposure_seen = review["preparation_flow_or_qualification_seen"]
            require(isinstance(exposure_seen, bool), f"missing exposure declaration: {label}")
            exposures = review.get("blinding_exposure", [])
            require(isinstance(exposures, list) and bool(exposures) == exposure_seen,
                    f"exposure declaration lacks evidence: {label}")
            for exposure in exposures:
                require(exposure["blind_id"] in packets, "exposure references unknown position")
                field = exposure["field"]
                require(isinstance(field, list) and field and all(isinstance(key, (str, int)) for key in field),
                        "exposure field path is invalid")
                value = packets[exposure["blind_id"]]
                for key in field:
                    if isinstance(value, list) and isinstance(key, str) and key.isdecimal():
                        key = int(key)
                    require((isinstance(value, dict) and key in value)
                            or (isinstance(value, list) and isinstance(key, int) and 0 <= key < len(value)),
                            "exposure field does not exist")
                    value = value[key]
                quote = exposure["quote"]
                require(isinstance(value, str) and isinstance(quote, str) and quote and quote in value,
                        "exposure quote does not match public material")
            blinding_exposures[label] = exposures
            require(review["public_manifest_sha256"] == public_manifest_sha256,
                    f"review public material identity differs: {label}")
        require(review["reviewer_id"] not in reviewer_ids, "repeated reviewer_id")
        reviewer_ids.add(review["reviewer_id"])
        judgments = index_rows(review["judgments"], label, expected_positions)
        require(set(judgments) == ids, f"{label}: blind_id coverage differs")
        reviewers[label] = judgments
        edges = set()
        duplicates = set()
        for blind_id, judgment in judgments.items():
            for criterion in CRITERIA:
                require(judgment[criterion] in VALUES, f"invalid {label}:{blind_id}:{criterion}")
            evidence_text(judgment["evidence"])
            if blind_id in null_policy_ids:
                require(all(judgment[criterion] == "unknown" for criterion in CRITERIA),
                        f"missing policy receives determinate judgment {label}:{blind_id}")
            nominations = judgment["duplicate_of"]
            require(isinstance(nominations, list) and len(nominations) == len(set(nominations)),
                    f"invalid duplicates {label}:{blind_id}")
            for other in nominations:
                require(other in ids and other != blind_id, f"invalid duplicate reference {other}")
                require(packets[blind_id]["task_id"] == packets[other]["task_id"],
                        f"cross-task duplicate {blind_id}:{other}")
                require(packets[blind_id]["policy"] is not None
                        and packets[other]["policy"] is not None,
                        f"duplicate reference to missing policy {blind_id}:{other}")
                edges.add(tuple(sorted((blind_id, other))))
                if mapping[blind_id]["flow"] == mapping[other]["flow"]:
                    later = max((blind_id, other), key=lambda value: mapping[value]["position"])
                    duplicates.add(later)
        duplicate_edges[label] = edges
        same_flow_duplicate_ids[label] = duplicates

    positions = []
    disagreements = []
    evidence_audit = []
    for blind_id in sorted(ids):
        mapped = mapping[blind_id]
        judgments = {label: rows[blind_id] for label, rows in reviewers.items()}
        all_support = {
            label: all(judgment[criterion] == "support" for criterion in CRITERIA)
            for label, judgment in judgments.items()
        }
        quality = {label: supported and blind_id not in same_flow_duplicate_ids[label]
                   for label, supported in all_support.items()}
        differed = [criterion for criterion in CRITERIA
                    if judgments["reviewer_a"][criterion] != judgments["reviewer_b"][criterion]]
        duplicate_disagreement = (
            set(judgments["reviewer_a"]["duplicate_of"])
            != set(judgments["reviewer_b"]["duplicate_of"])
        )
        row = {
            **mapped,
            "materialized": blind_id not in null_policy_ids,
            "judgments": {label: {criterion: judgment[criterion] for criterion in CRITERIA}
                          for label, judgment in judgments.items()},
            "all_five_support": all_support,
            "all_five_support_and_no_same_flow_duplicate": quality,
            "conservative_model_quality_support": all(quality.values()),
            "different_criteria": differed,
            "duplicate_disagreement": duplicate_disagreement,
        }
        positions.append(row)
        if differed or duplicate_disagreement:
            disagreements.append({
                **row,
                "evidence": {label: judgment["evidence"] for label, judgment in judgments.items()},
            })
        packet = packets[blind_id]
        policy = packet["policy"]
        evidence_audit.append({
            "blind_id": blind_id,
            "task_id": packet["task_id"],
            "source_prompt": packet["source"]["source_prompt"],
            "shared_execution_interface": packet["source"]["shared_execution_interface"],
            "policy": policy,
            "source_citation_offsets": [] if policy is None else [
                {"quote": quote, "offset": packet["source"]["source_prompt"].index(quote)}
                for quote in policy["source_citations"]
            ],
            "model_evidence": {label: judgment["evidence"] for label, judgment in judgments.items()},
        })

    flow_statistics = {}
    for flow in FLOWS:
        flow_denominator = flow_denominators[flow]
        assigned = [row for row in positions if row["flow"] == flow]
        require(len(assigned) == flow_denominator, "assigned denominator changed")
        per_model = {}
        for label in reviewers:
            per_model[label] = {
                "all_five_support": estimate(sum(row["all_five_support"][label]
                                                   for row in assigned), flow_denominator),
                "all_five_support_and_no_same_flow_duplicate": estimate(
                    sum(row["all_five_support_and_no_same_flow_duplicate"][label]
                        for row in assigned), flow_denominator),
                "criteria": {
                    criterion: {value: sum(row["judgments"][label][criterion] == value
                                           for row in assigned) for value in VALUES}
                    for criterion in CRITERIA
                },
            }
        flow_statistics[flow] = {
            "denominator": flow_denominator,
            "materialized": sum(row["materialized"] for row in assigned),
            "missing_policy": sum(not row["materialized"] for row in assigned),
            "frozen_status_counts": dict(sorted(Counter(row["frozen_status"]
                                                        for row in assigned).items())),
            "per_model": per_model,
            "conservative_model_quality_support": estimate(
                sum(row["conservative_model_quality_support"] for row in assigned), flow_denominator),
            "conservative_model_support_among_frozen_qualified": estimate(
                sum(row["conservative_model_quality_support"] and row["frozen_status"] == "qualified"
                    for row in assigned), flow_denominator),
            "criterion_disagreement_positions": sum(bool(row["different_criteria"])
                                                     for row in assigned),
            "criterion_disagreement_cells": sum(len(row["different_criteria"])
                                                 for row in assigned),
            "criterion_disagreements": {criterion: sum(criterion in row["different_criteria"]
                                                        for row in assigned)
                                        for criterion in CRITERIA},
            "all_five_support_disagreements": sum(
                row["all_five_support"]["reviewer_a"] != row["all_five_support"]["reviewer_b"]
                for row in assigned),
        }
    nominations = []
    for edge in sorted(set.union(*duplicate_edges.values())):
        first, second = edge
        nominations.append({
            "blind_ids": list(edge),
            "task_id": packets[first]["task_id"],
            "flows": [mapping[first]["flow"], mapping[second]["flow"]],
            "same_flow": mapping[first]["flow"] == mapping[second]["flow"],
            "nominated_by": [label for label, edges in duplicate_edges.items() if edge in edges],
        })
    summary = {
        "status": "EXECUTED_OUTCOME_BLIND_MODEL_QUALITY_VERIFICATION",
        "evidence_level": "bounded_development_model_review",
        "evaluation_kind": "model_evaluation",
        "human_identity_or_statistical_independence_established": False,
        "protected_protocol_or_frozen_artifacts_changed": False,
        "population": args.population,
        "public_manifest_sha256": public_manifest_sha256,
        "flow_blinding_protocol_passed": (
            not label_mentions and not any(blinding_exposures.values()) if args.population == "repair" else None
        ),
        "public_policy_flow_label_mentions": label_mentions,
        "reviewer_reported_blinding_exposures": blinding_exposures,
        "blinding_verification_scope": (
            "Reported exposure quotes are checked against frozen public materials. Exposure makes "
            "the flow-blinding protocol fail; retained semantic judgments remain outcome-blind. "
            "Absence of reported exposure does not prove absence of inferable flow identity."
        ),
        "positions": expected_positions,
        "tasks": task_count,
        "criteria_per_position": len(CRITERIA),
        "materialized_policies": expected_positions - len(null_policy_ids),
        "missing_policies": len(null_policy_ids),
        "validated_source_citations": source_quote_count,
        "materialized_policy_positions_without_source_citations": sorted(missing_source_citation_ids),
        "validated_model_evidence_positions": {label: len(rows) for label, rows in reviewers.items()},
        "evidence_verification_scope": (
            "Every evidence value is nonempty; every policy source citation matches the original "
            "source exactly. Complete source, shared interface, four versions and both model "
            "evidence texts are retained for semantic inspection. Mechanical checks do not "
            "certify semantic correctness of every model judgment."
        ),
        "support_rule": (
            "Five support values in each model evaluation; later positions in a nominated "
            "same-flow duplicate pair do not count as distinct discoveries. Cross-flow equivalence remains visible. "
            "All assigned positions per flow remain in every rate denominator. "
            "Frozen qualification labels do not alter this model-quality numerator."
        ),
        "flows": flow_statistics,
        "criterion_disagreement_positions": len([row for row in positions if row["different_criteria"]]),
        "criterion_disagreement_cells": sum(len(row["different_criteria"]) for row in positions),
        "duplicate_nomination_disagreement_positions": sum(row["duplicate_disagreement"]
                                                           for row in positions),
        "duplicate_nominations": nominations,
        "same_flow_duplicate_positions": {label: sorted(duplicates)
                                          for label, duplicates in same_flow_duplicate_ids.items()},
        "input_identity": {label: {"path": path.relative_to(root).as_posix(),
                                   "sha256": file_sha256(path)} for label, path in paths.items()},
        "verifier_identity": {"path": Path(__file__).resolve().relative_to(root).as_posix(),
                              "sha256": file_sha256(Path(__file__).resolve())},
        "environment": {"python": sys.version, "platform": platform.platform(),
                        "prompt_mechanism_study": version("prompt-mechanism-study")},
        "command": f".venv/Scripts/python.exe docs/experiments/2026-09-29-model-quality-verify.py --population {args.population}",
    }
    default_result = {"development": "model-quality-verification", "evaluation": "evaluation-model-quality-verification",
                      "repair": "repair-model-quality-verification"}[args.population]
    if registration:
        summary['repair_registration'] = {'path': args.repair_registration.as_posix(),
                                          'sha256': file_sha256(root / args.repair_registration)}
        summary['command'] += f' --repair-registration {args.repair_registration.as_posix()}'
    target = args.output or (Path(registration['common_verification_root']) if registration
                            else Path("results/graph-guided-20260929/" + default_result))
    output = target if target.is_absolute() else root / target
    write_bundle(output, {
        "summary.json": summary,
        "positions.json": positions,
        "disagreements.json": disagreements,
        "evidence-audit.json": evidence_audit,
    })
    verify_bundle(output)
    print(f"Verified {expected_positions} positions, {expected_positions * 10} criterion values and {source_quote_count} source citations.")
    for flow, statistics in flow_statistics.items():
        flow_denominator = flow_denominators[flow]
        counts = [statistics["per_model"][label]["all_five_support"]["numerator"]
                  for label in reviewers]
        combined = statistics["conservative_model_quality_support"]["numerator"]
        print(f"{flow}: model A={counts[0]}/{flow_denominator}, model B={counts[1]}/{flow_denominator}, both={combined}/{flow_denominator}")
    print(f"Output: {output}")


if __name__ == "__main__":
    main()
