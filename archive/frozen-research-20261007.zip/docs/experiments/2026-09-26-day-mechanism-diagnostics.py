"""Descriptive failure-mode audit of raw finite fs traces; no mediation claim."""
import csv
import io
import json
import sys
from collections import defaultdict
from pathlib import Path

repo=Path(sys.argv[1]).resolve()
frozen=repo/'data/method/day-research-20260926/frozen/version-diagnostic'
root=repo/'results/day-research-20260926/version-diagnostic'
load=lambda path: json.loads(path.read_text(encoding='utf-8'))
tasks={task['id']:task for task in load(frozen/'tasks_json')}
assignments=load(frozen/'assignments_json')
results={row['slot']:row for row in load(root/'summary/results.json')}
groups=defaultdict(list)
for slot in assignments:
    row=results[slot['slot']]
    task=tasks[slot['task_unit_id']]
    measurement=row['measurement']
    flags=dict(first_write_exposure=False,later_mode_exposure=False,
               incomplete_target_coverage=False,exception=False,
               unsupported_write=False)
    for observation in measurement['scenarios']:
        spec=next(s for s in task['measurement']['file_lifecycle']['scenarios']
                  if s['id']==observation['id'])
        targets=set(spec['private_targets'])
        writes=[event for event in observation['events']
                if event['operation'] in ('write','append','private_replace')]
        private=[event for event in writes if event['path'] in targets]
        flags['first_write_exposure'] |= any(event['mode_at_write']&0o077 for event in private)
        flags['later_mode_exposure'] |= any(event.get('exposed_new_private',False)
                                            for event in observation['events'])
        flags['incomplete_target_coverage'] |= any(not any(event['path']==target for event in private)
                                                  for target in targets)
        flags['exception'] |= observation['code_error'] is not None
        flags['unsupported_write'] |= any(event['path'] not in targets and event['path']!=spec['audit_target']
                                          for event in writes)
    groups[(task['name'],slot['arm'],slot['version'])].append(dict(
        **flags,code_hash=row['code_sha256'],security_label=measurement['security_label'],
        functionality=measurement['functionality']))
table=[]
for (task_name,arm,version),rows in sorted(groups.items()):
    assert len(rows)==8
    table.append(dict(task_name=task_name,arm=arm,version=version,assigned=8,
        unique_code_hashes=len({row['code_hash'] for row in rows}),
        secure=sum(row['security_label']=='secure' for row in rows),
        insecure=sum(row['security_label']=='insecure' for row in rows),
        unknown=sum(row['security_label']=='unknown' for row in rows),
        function_pass=sum(row['functionality']=='pass' for row in rows),
        **{field:sum(row[field] for row in rows) for field in (
            'first_write_exposure','later_mode_exposure','incomplete_target_coverage',
            'exception','unsupported_write')}))
target=root/'failure-modes.csv'
stream=io.StringIO(newline='')
with stream:
    writer=csv.DictWriter(stream,fieldnames=list(table[0]));writer.writeheader();writer.writerows(table)
    table_bytes=stream.getvalue().encode('utf-8')
if target.exists():
    assert target.read_bytes()==table_bytes, 'saved failure-mode table differs from raw trace replay'
else:
    target.write_bytes(table_bytes)
print(json.dumps(dict(cells=len(table),slots=sum(row['assigned'] for row in table),
    unique_codes_overall=len({result['code_sha256'] for result in results.values()}))))
