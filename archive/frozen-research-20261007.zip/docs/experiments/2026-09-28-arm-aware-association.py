import json
import sys
from pathlib import Path

import numpy as np
from sklearn.linear_model import Ridge
from sklearn.preprocessing import OneHotEncoder

from prompt_mechanism_study.artifact_io import read_json, verify_bundle, write_bundle


repo = Path(sys.argv[1]).resolve()
destination = Path(sys.argv[2]).resolve()
root = repo / 'data/method/source-hypotheses-20260927'
selection = root / 'heldout-decisions'
verify_bundle(selection)
protocol = read_json(selection / 'protocol.json')
development = read_json(selection / 'development.json')
decisions = read_json(selection / 'decisions.json')
alpha = protocol['causal_alpha']


def compare_regressions(training: list[dict], candidate: dict) -> dict:
    encoder = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
    features = encoder.fit_transform([[row['representation'], row['operation_family']]
                                      for row in training])
    input_features = encoder.transform([[candidate['representation'],
                                         candidate['operation_family']]])
    predictions = {}
    for target in ('P_yield', 'R_yield', 'effect_P_R'):
        model = Ridge(alpha=alpha)
        model.fit(features, np.array([row[target] for row in training]))
        predictions[target] = float(model.predict(input_features)[0])
    arm_aware = predictions['P_yield'] - predictions['R_yield']
    direct_effect = predictions['effect_P_R']
    if not np.isclose(arm_aware, direct_effect, rtol=0, atol=1e-12):
        raise ValueError('arm-aware regression differs from paired-effect regression')
    return dict(treated_prediction=predictions['P_yield'],
                control_prediction=predictions['R_yield'],
                arm_aware_effect=arm_aware,
                direct_effect_prediction=direct_effect)

rows = []
for task in decisions:
    case_root = root / f"prepared/case-{task['index']:04d}"
    verify_bundle(case_root)
    case = read_json(case_root / 'case.json')
    for score in task['scores']:
        training = [row for row in development if
                    (row['policy_family'], row['direction']) ==
                    (score['policy_family'], score['direction'])]
        prediction = None
        if score['support_tasks'] >= protocol['minimum_independent_support']:
            prediction = compare_regressions(training, dict(
                representation=case['assignment']['representation'],
                operation_family=score['operation_family']))
            if not np.isclose(prediction['direct_effect_prediction'], score['causal_effect'],
                              rtol=0, atol=1e-12):
                raise ValueError('frozen policy score differs from replay')
        rows.append(dict(index=task['index'], candidate_slot=score['candidate_slot'],
                         support_tasks=score['support_tasks'], prediction=prediction,
                         frozen_effect=score.get('causal_effect')))

folds = []
supported = [row for row in development if
             (row['policy_family'], row['direction']) == ('html_output', 'ADD')]
for heldout in supported:
    training = [row for row in supported if row['task_unit_id'] != heldout['task_unit_id']]
    folds.append(dict(index=heldout['index'], prediction=compare_regressions(training, heldout)))

write_bundle(destination, {
    'diagnostic.json': dict(status='POSTHOC_METHOD_EQUIVALENCE_DIAGNOSTIC',
                            evidence_role='development_only_training_replay',
                            formal_protocol='SPECIFIED_DRAFT',
                            selection_manifest=read_json(selection / 'manifest.json'),
                            alpha=alpha, candidates=rows, development_folds=folds,
                            explanation=('With identical design matrices, sample weights, regularization '
                                         'and an intercept, linear ridge predictions for P minus R equal '
                                         'ridge predictions fitted to paired P minus R outcomes.'))})
verify_bundle(destination)
print(json.dumps(dict(status='VERIFIED', candidates=len(rows),
                      supported=sum(row['support_tasks'] >= protocol['minimum_independent_support']
                                    for row in rows),
                      development_folds=len(folds),
                      maximum_difference=max(abs(row['prediction']['arm_aware_effect'] -
                                                 row['prediction']['direct_effect_prediction'])
                                             for row in rows if row['prediction'] is not None))))
