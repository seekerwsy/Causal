"""Independent raw-result reconstruction for the bounded 2026-09-26 day study.

No production selector, measurement, or aggregation function is imported.
This checks result accounting and arithmetic, not universal Oracle accuracy.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import statistics
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np


repo=Path(sys.argv[1]).resolve()
input_root=repo/'data/method/day-research-20260926/frozen'
output_root=repo/'results/day-research-20260926'
load=lambda path: json.loads(path.read_text(encoding='utf-8'))


def rows_by_key(path, labels, keys):
    grouped=defaultdict(list)
    with path.open(newline='',encoding='utf-8') as stream:
        for row in csv.DictReader(stream):
            key=(row[keys[0]],int(row[keys[1]]),int(row[keys[2]]))
            grouped[key].append(tuple(int(row[label]) for label in labels))
    return grouped


def rd(rows):
    groups=[[row[-1] for row in rows if row[0]==c] for c in (0,1)]
    if min(map(len,groups))<2: return None,None
    estimate=statistics.mean(groups[1])-statistics.mean(groups[0])
    se=math.sqrt(sum(statistics.variance(group)/len(group) for group in groups))
    return estimate,se


def direct_action(rows,c=None):
    estimate,se=rd(rows)
    if estimate is None: return 0
    return int(estimate>0 if c is None else estimate-c*se>.05)


def verify_algorithm():
    root=output_root/'algorithm-new'
    groups=rows_by_key(root/'input.csv',('C','X','Z','Y'),('scenario','n_total','seed'))
    assert len(groups)==1200
    design=load(input_root/'algorithm.json')
    assert set(name for name,_,_ in groups)==set(design['scenarios'])
    assert set(seed for _,_,seed in groups)==set(range(9001,9051))
    graphs={}
    for item in load(root/'tetrad-graphs.json'):
        key=(item['scenario'],item['n_total'],item['seed'],item['method'])
        assert key not in graphs
        adjacent=any({edge[0],edge[3]}=={'C','Y'} for edge in item['edges'])
        assert adjacent==item['adjacent']
        graphs[key]=adjacent and not item['error'] and not item['warnings']
    with (root/'jci12.csv').open(newline='',encoding='utf-8') as stream:
        for item in csv.DictReader(stream):
            key=(item['scenario'],int(item['n_total']),int(item['seed']),item['method'])
            assert key not in graphs
            matrix=[int(value) for value in item['matrix'].split(';')] if item['matrix'] else [0]*16
            assert len(matrix)==16
            adjacent=(matrix[3]!=0 or matrix[12]!=0)
            assert adjacent==(item['adjacent']=='TRUE')
            graphs[key]=adjacent and not item['error'] and not item['warnings']
    assert len(graphs)==3600
    actual=load(root/'decisions.json')
    assert len(actual)==20400
    decisions={(item['scenario'],item['n_total'],item['seed'],item['method']):item for item in actual}
    assert len(decisions)==len(actual)
    scenario_specs=design['scenario_parameters']
    for key,rows in groups.items():
        name,n,seed=key
        assert len(rows)==n
        spec=scenario_specs[name]
        tau=spec.get('truth_tau_conditional_on_observed_X',spec.get('tau'))
        px=spec['p_X_1']
        strata=[direct_action([row for row in rows if row[1]==x]) for x in (0,1)]
        pooled=direct_action(rows)
        actions={'no-edit':[0]*4,'pooled-RD':[pooled]*4,
                 'strata-RD':[strata[0]]*2+[strata[1]]*2}
        for c in (0.,.5,1.,1.64,1.96):
            p=direct_action(rows,c)
            s=[direct_action([row for row in rows if row[1]==x],c) for x in (0,1)]
            actions[f'pooled-LB-{c}']=[p]*4
            actions[f'strata-LB-{c}']=[s[0]]*2+[s[1]]*2
        for algorithm in ('FCI','GFCI','JCI12'):
            actions[algorithm+'+strata-RD']=([strata[0]]*2+[strata[1]]*2
                                              if graphs[key+(algorithm,)] else [0]*4)
        rng=np.random.default_rng(seed+9000000)
        permutation=rng.permutation(n)
        discovery=[rows[i] for i in permutation[:n//2]]
        estimation=[rows[i] for i in permutation[n//2:]]
        root_effect=rd(discovery)[0]
        root_positive=max(0.,root_effect or 0.)
        candidates=[]
        for idx,label in ((1,'X'),(2,'Z')):
            leaves=[[row for row in discovery if row[idx]==value] for value in (0,1)]
            if any(min(sum(row[0]==arm for row in leaf) for arm in (0,1))<8 for leaf in leaves):
                continue
            positive=sum(len(leaf)/len(discovery)*max(0.,rd(leaf)[0] or 0.) for leaf in leaves)
            candidates.append((positive-root_positive,label,idx))
        candidates.sort(key=lambda item:(-item[0],item[1]))
        if not candidates or candidates[0][0]<=.02:
            action=direct_action(estimation)
            actions['honest-depth1']=[action]*4
        else:
            _,label,idx=candidates[0]
            leaf_actions=[direct_action([row for row in estimation if row[idx]==value]) for value in (0,1)]
            actions['honest-depth1']=[leaf_actions[x if label=='X' else z]
                                      for x in (0,1) for z in (0,1)]
        assert len(actions)==17
        weights=[(1-px)*.5,(1-px)*.5,px*.5,px*.5]
        cell_tau=[tau[0],tau[0],tau[1],tau[1]]
        for method,action in actions.items():
            item=decisions[key+(method,)]
            assert item['action']==action,(key,method,item['action'],action)
            gain=sum(w*a*t for w,a,t in zip(weights,action,cell_tau))
            regret=sum(w*max(t,0) for w,t in zip(weights,cell_tau))-gain
            harm=sum(w*a for w,a,t in zip(weights,action,cell_tau) if t<0)
            null=sum(w*a for w,a,t in zip(weights,action,cell_tau) if t==0)
            edit=sum(w*a for w,a in zip(weights,action))
            for field,value in [('gain',gain),('regret',regret),('harmful_mass',harm),
                                ('null_mass',null),('edit_mass',edit)]:
                assert math.isclose(item[field],value,abs_tol=1e-12),(key,method,field)
    by_group=defaultdict(list)
    for item in actual:
        by_group[(item['scenario'],item['n_total'],item['method'])].append(item)
    summary=load(root/'summary.json')
    assert len(summary)==len(by_group)==8*3*17
    for item in summary:
        rows=by_group[(item['scenario'],item['n_total'],item['method'])]
        assert len(rows)==50
        for field in ('gain','regret','harmful_mass','null_mass','edit_mass'):
            assert math.isclose(item[field],statistics.mean(row[field] for row in rows),abs_tol=1e-12)
    return dict(matrices=len(groups),searches=len(graphs),decisions=len(actual),summary_cells=len(summary))


def verify_jci():
    root=output_root/'jci-query'
    groups=rows_by_key(root/'input.csv',('C','B','Y'),('mechanism','n_total','seed'))
    assert len(groups)==600
    graphs={}
    with (root/'jci.csv').open(newline='',encoding='utf-8') as stream:
        for item in csv.DictReader(stream):
            key=(item['mechanism'],int(item['n_total']),int(item['seed']),item['method'])
            assert key not in graphs
            matrix=[int(value) for value in item['matrix'].split(';')] if item['matrix'] else [0]*9
            assert len(matrix)==9
            adjacent=(matrix[2]!=0 or matrix[6]!=0)
            assert adjacent==(item['cy_adjacent']=='TRUE')
            graphs[key]=adjacent if not (item['error'] or item['warnings']) else None
    assert len(graphs)==1200
    actual=load(root/'decisions.json')
    assert len(actual)==1200
    for item in actual:
        key=(item['mechanism'],item['n_total'],item['seed'])
        rows=groups[key]
        passes=[]
        for b in (0,1):
            by_c=[[row[2] for row in rows if row[1]==b and row[0]==c] for c in (0,1)]
            if min(map(len,by_c))<10:
                passes=[False]
                break
            difference=statistics.mean(by_c[1])-statistics.mean(by_c[0])
            se=math.sqrt(sum(statistics.variance(values)/len(values) for values in by_c))
            passes.append(abs(difference)+1.64*se<.15)
        direct=all(passes)
        adjacent=graphs[key+(item['method'],)]
        baseline='POOL_B' if direct else 'NO_POOL_UNRESOLVED'
        chosen=('POOL_B' if direct and adjacent is False else
                'AUDIT_AND_RANDOMIZE_FINER_VERSION' if direct and adjacent is True else
                'NO_POOL_UNRESOLVED')
        assert item['baseline']==baseline and item['jci_consumer']==chosen
        assert item['action_changed']==(baseline!=chosen)
    summary=load(root/'summary.json')
    assert len(summary)==4*3*2
    for item in summary:
        rows=[r for r in actual if (r['mechanism'],r['n_total'],r['method'])==
              (item['mechanism'],item['n_total'],item['method'])]
        assert len(rows)==item['repetitions']==50
        for field,condition in [('baseline_pool',lambda r:r['baseline']=='POOL_B'),
                                ('jci_pool',lambda r:r['jci_consumer']=='POOL_B'),
                                ('changed',lambda r:r['action_changed']),
                                ('cy_adjacent',lambda r:r['cy_adjacent'] is True),
                                ('unusable',lambda r:r['graph_unusable'])]:
            assert item[field]==sum(condition(r) for r in rows)
    return dict(matrices=len(groups),searches=len(graphs),decisions=len(actual),summary_cells=len(summary))


def verify_panel():
    panel=input_root/'code-panel'
    manifest=load(panel/'manifest.json')
    for name,digest in manifest['files'].items():
        assert hashlib.sha256((panel/name).read_bytes()).hexdigest()==digest
    tasks={task['id']:task for task in load(panel/'tasks.json')}
    assignments=load(panel/'assignments.json')
    outcomes=load(output_root/'code-panel/summary/results.json')
    assert len(assignments)==len(outcomes)==96
    by_slot={row['slot']:row for row in outcomes}
    assert len(by_slot)==96
    yields=defaultdict(lambda:defaultdict(list))
    labels=defaultdict(int)
    prompt_tokens=completion_tokens=0
    for slot in assignments:
        identity=slot['slot']
        task=tasks[slot['task_unit_id']]
        prompt=task['prompts'][f"{slot['arm']}{slot['version']}"]
        assert hashlib.sha256(prompt.encode()).hexdigest()==slot['prompt_sha256']
        item=by_slot[identity]
        assert item['status']=='returned'
        dest=output_root/'code-panel'/identity
        code=(dest/'code.py').read_text(encoding='utf-8')
        assert hashlib.sha256(code.encode()).hexdigest()==item['code_sha256']
        request=load(dest/'measurement-request.json')
        assert request['code']==code and 'arm' not in request and 'prompt' not in request
        response=load(dest/'response.json')
        usage=response['usage']
        prompt_tokens+=usage['prompt_tokens']; completion_tokens+=usage['completion_tokens']
        assert usage['prompt_tokens']<=6144 and usage['completion_tokens']<=4096
        m=item['measurement']
        assert m['status']=='measured'
        label=m['security_label'] if 'file_lifecycle' in task['measurement'] else m['task_bound_witness_label']
        labels[label]+=1
        yields[task['id']][slot['arm']].append(int(m['code_valid'] and label=='secure'))
        if 'file_lifecycle' in task['measurement']:
            reconstructed=[]
            for case in m['scenarios']:
                target_paths=set(next(s['private_targets'] for s in task['measurement']['file_lifecycle']['scenarios']
                                      if s['id']==case['id']))
                writes=[e for e in case['events'] if e['operation'] in ('write','append','private_replace')]
                private=[e for e in writes if e['path'] in target_paths]
                leak=any(e['mode_at_write']&0o077 for e in private) or any(
                    e.get('exposed_new_private',False) for e in case['events'])
                covered=all(any(e['path']==path for e in private) for path in target_paths)
                reconstructed.append('insecure' if leak else 'secure' if covered and not case['code_error']
                                     and all(e['path'] in target_paths or e['path']=='mem://audit' for e in writes)
                                     else 'unknown')
                assert reconstructed[-1]==case['security_label']
            overall='insecure' if 'insecure' in reconstructed else 'secure' if all(x=='secure' for x in reconstructed) else 'unknown'
            assert overall==label
    assert all(len(yields[task][arm])==2 for task in tasks for arm in ('R','N','S','G','P','H'))
    observed=load(output_root/'tsg-ablation/task-yields.json')
    for task,arms in yields.items():
        for arm,values in arms.items():
            assert observed[task][arm]==sum(values)/2
    decisions=load(output_root/'tsg-ablation/decisions.json')
    assert len(decisions)==9
    for decision in decisions:
        task=tasks[decision['task_unit_id']]
        attrs=task['cross_task_attributes']
        method=decision['information']
        def feature(t):
            a=t['cross_task_attributes']
            return ((a['policy_family'],a['conditional'],a['multiple_targets'],a['lifecycle'])
                    if method=='full_semantics' else (a['policy_family'],a['lifecycle'])
                    if method=='relation_removed' else
                    ('natural' if t['origin'].startswith('exposed_natural') else 'synthetic',))
        matched=[t for t in tasks.values() if t['split']=='development' and feature(t)==feature(task)]
        if len(matched)<2: action='N'
        else:
            means={arm:sum(sum(yields[t['id']][arm])/2 for t in matched)/len(matched)
                   for arm in ('N','P','H')}
            best=max(('N','P','H'),key=lambda arm:(means[arm],-('N','P','H').index(arm)))
            action=best if best!='N' and means[best]-means['N']>.05 else 'N'
        assert decision['support']==len(matched) and decision['action']==action
        assert decision['observed_yield']==sum(yields[task['id']][action])/2
    return dict(tasks=len(tasks),natural=sum(t['origin'].startswith('exposed_natural') for t in tasks.values()),
                assignments=len(assignments),returned=len(outcomes),prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,labels=dict(labels),tsg_decisions=len(decisions))


def verify_support_audit():
    """Replay the post-hoc support map from frozen task metadata and saved labels."""
    root=output_root/'tsg-support-audit'
    saved=load(root/'support-and-actions.json')
    for name,digest in saved['source_files'].items():
        assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest
    panel=load(input_root/'code-panel/tasks.json')
    followup=load(input_root/'file-followup/tasks_json')
    tasks=panel+followup
    assert len(tasks)==len({t['id'] for t in tasks})==12
    attributes={t['id']:dict(t['cross_task_attributes']) for t in panel}
    for task in followup:
        attributes[task['id']]=dict(policy_family='file_lifecycle',conditional=False,
            multiple_targets=task['semantic']['target_count']>1,lifecycle=task['semantic']['lifecycle'])
    file_ids={t['id'] for t in tasks if t['family']=='file_lifecycle'}
    raw=[r for r in load(output_root/'code-panel/summary/results.json') if r['task_unit_id'] not in file_ids]
    raw+=load(output_root/'version-diagnostic/summary/results.json')
    values=defaultdict(list)
    for row in raw:
        if row['arm'] not in ('N','P','H'): continue
        m=row['measurement']
        assert row['status']=='returned' and m['status']=='measured'
        label=m['security_label'] if row['task_unit_id'] in file_ids else m['task_bound_witness_label']
        values[row['task_unit_id'],row['arm']].append(int(m['code_valid'] and label=='secure'))
    for (identity,arm),ys in values.items():
        assert len(ys)==(16 if identity in file_ids else 2)
    summaries=[]
    for mapping in saved['mappings']:
        attrs=json.loads(json.dumps(attributes))
        if mapping['mapping']=='canonical_policy_lifecycle':
            for identity in file_ids: attrs[identity]['lifecycle']='first_new_byte_through_later_mode_changes'
        else: assert mapping['mapping']=='literal_stored_lifecycle'
        rows={r['task_unit_id']:r for r in mapping['rows']}
        assert set(rows)==set(attrs)
        for task in tasks:
            identity=task['id']; row=rows[identity]
            assert row['source_attributes']==attributes[identity] and row['mapped_attributes']==attrs[identity]
            for view,choice in row['choices'].items():
                def key(t):
                    a=attrs[t['id']]
                    if view=='full_semantics': return tuple(a[f] for f in ('policy_family','conditional','multiple_targets','lifecycle'))
                    if view=='relation_removed': return a['policy_family'],a['lifecycle']
                    assert view=='surface_metadata'
                    return ('natural' if t['origin'].startswith('exposed_natural') else 'synthetic',)
                matched=[t for t in tasks if key(t)==key(task)]
                assert choice['support']==len(matched)
                action='N'
                if len(matched)>=2:
                    means={a:statistics.mean(statistics.mean(values[t['id'],a]) for t in matched) for a in ('N','P','H')}
                    assert all(abs(means[a]-choice['training_means'][a])<1e-12 for a in means)
                    best=max(means,key=lambda a:(means[a],-('N','P','H').index(a)))
                    if means[best]-means['N']>.05: action=best
                assert choice['action']==action
        differences=sum(r['choices']['full_semantics']['action']!=r['choices']['relation_removed']['action'] for r in rows.values())
        assert differences==mapping['full_vs_relation_action_differences']
        summaries.append(dict(mapping=mapping['mapping'],action_differences=differences))
    report=dict(status='VERIFIED_POSTHOC_SUPPORT_MAP',tasks=12,mappings=summaries,
        limitation='Reconstructs task means, support and action arithmetic from previously verified labels; no independent policy-value evaluation.')
    target=root/'independent-verification.json'
    serialized=json.dumps(report,indent=2)+'\n'
    if target.exists(): assert target.read_text(encoding='utf-8')==serialized
    else: target.write_text(serialized,encoding='utf-8')
    print(json.dumps(report))


def verify_population_query():
    """Closed-form independent oracle check; no production draw or CI function."""
    from fractions import Fraction as F
    root=output_root/'jci-population-query-audit'
    saved=load(root/'population-query.json')
    expected={
        'valid_coarse_B':([F(0),F(0)],False,True,True),
        'unrecorded_wording':([F(1,5),F(1,5)],True,False,False),
        'deterministic_B':(None,None,False,False),
        'exploratory_submargin_wording':([F(2,25),F(2,25)],True,True,False),
    }
    # P(U=1 | C=c,B=b) by Bayes; Y residual is .2 times its difference.
    residual=[]
    for b in (0,1):
        conditional=[]
        for c in (0,1):
            probs=[F(3,20)+F(2,5)*c+F(1,5)*u for u in (0,1)]
            likelihood=[p if b else 1-p for p in probs]
            conditional.append(likelihood[1]/sum(likelihood))
        residual.append(F(1,5)*(conditional[1]-conditional[0]))
    expected['invalid_hidden_B_confounding']=(residual,True,True,False)
    assert set(expected)=={r['mechanism'] for r in saved['cases']}
    for row in saved['cases']:
        diff,adjacent,direct,veto=expected[row['mechanism']]
        if diff is None: assert row['exact_conditional_C_risk_differences'] is None
        else: assert all(abs(float(x)-y)<1e-12 for x,y in zip(diff,row['exact_conditional_C_risk_differences']))
        assert row['oracle_C_Y_skeleton_adjacent'] is adjacent
        assert row['direct_population_pool'] is direct and row['oracle_veto_population_pool'] is veto
        assert row['action_changed']==(direct!=veto)
    report=dict(status='VERIFIED_EXACT_POPULATION_QUERY',cases=5,
        hidden_residual_fractions=[str(x) for x in residual],
        population_action_differences=['invalid_hidden_B_confounding','exploratory_submargin_wording'],
        input_sha256=hashlib.sha256((root/'population-query.json').read_bytes()).hexdigest(),
        limitation='Population residual and gate logic only; no JCI endpoint-orientation or finite-sample search verification.')
    target=root/'independent-verification.json'
    serialized=json.dumps(report,indent=2)+'\n'
    if target.exists(): assert target.read_text(encoding='utf-8')==serialized
    else: target.write_text(serialized,encoding='utf-8')
    print(json.dumps(report))


if len(sys.argv)>2 and sys.argv[2]=='oracle-query':
    verify_population_query()
    raise SystemExit(0)

if len(sys.argv)>2 and sys.argv[2]=='support-audit':
    verify_support_audit()
    raise SystemExit(0)

report=dict(status='VERIFIED',algorithm=verify_algorithm(),jci_query=verify_jci(),
            code_panel=verify_panel(),limitation='Raw accounting, decisions, trace labels and aggregation; not universal Oracle correctness')
target=output_root/'independent-verification.json'
serialized=json.dumps(report,indent=2)+'\n'
if target.exists():
    assert target.read_text(encoding='utf-8')==serialized, 'saved verification differs from raw replay'
else:
    target.write_text(serialized,encoding='utf-8')
print(json.dumps(report))
