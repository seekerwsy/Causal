"""Independent arithmetic/wire verifier for this diagnostic, standard library only.

Does not import the renderer, transport, or summary producer. It verifies
accounting and method delivery, not the author's semantic judgments.
"""
import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/"data/method/structure-binding-development-20260926/frozen"
OUT=ROOT/"results/structure-binding-development-20260926"
def read(p):return json.loads(p.read_text(encoding="utf-8"))
def check_bundle(p):
    m=read(p/"manifest.json")
    assert {x.name for x in p.iterdir() if x.is_file()}==set(m["files"])|{"manifest.json"}
    for name,h in m["files"].items():assert hashlib.sha256((p/name).read_bytes()).hexdigest()==h
check_bundle(BASE)
tasks={t["task_unit_id"]:t for t in read(BASE/"tasks.json")}
slots=read(BASE/"assignments.json");protocol=read(BASE/"protocol.json")
summary=read(OUT/"summary/summary.json")
counts={m:Counter() for m in "RFG"};usage={m:Counter() for m in "RFG"};by={}
assert len(slots)==27 and len({s["seed"] for s in slots})==27
assert len({(s["task_unit_id"],s["method"]) for s in slots})==27
for slot in slots:
    uid,m=slot["task_unit_id"],slot["method"];task=tasks[uid]
    folder=OUT/f"{uid[-12:]}-{m}"
    check_bundle(folder/"result")
    row=read(folder/"result/result.json");wire=read(folder/"request.json");outer=read(folder/"response.json")
    assert all(row[k]==v for k,v in slot.items())
    assert row["status"]=="RETURNED" and outer["choices"][0]["finish_reason"]=="stop"
    assert row["binding"]==json.loads(outer["choices"][0]["message"]["content"])
    assert row["target_sha256"]==hashlib.sha256(row["target_prompt"].encode()).hexdigest()
    assert row["target_prompt"].startswith(task["source_prompt"])
    if row["render_status"]!="RENDERED":assert row["target_prompt"]==task["source_prompt"]
    assert wire["seed"]==slot["seed"] and wire["temperature"]==0 and wire["max_tokens"]==2048
    assert wire["messages"][0]["content"]==protocol["system_prompt"]
    request=json.loads(wire["messages"][1]["content"])
    assert request["source_prompt"]==task["source_prompt"] and request["source_spans"]==task["spans"]
    assert set(request)==({"source_prompt","source_spans","fixed_policy","output_schema"}|({"source_semantics"} if m!="R" else set()))
    by[uid,m]=(row,request);counts[m][row["render_status"]]+=1
    usage[m].update({"calls":1,**{k:outer["usage"][k] for k in ("prompt_tokens","completion_tokens")}})
for uid,task in tasks.items():
    f=by[uid,"F"][1]["source_semantics"];g=by[uid,"G"][1]["source_semantics"]
    assert len(f["fact_records"])==len(g["nodes"])
    for record,node in zip(f["fact_records"],g["nodes"]):
        nid,kind,txt,src=record.split(" | ")
        assert (nid,kind[5:],json.loads(txt[5:]),json.loads(src[7:]))==(node["id"],node["type"],node["text"],node["source"])
    assert f["relation_records"]==[f'{e["source"]} | relation={e["type"]} | object={e["target"]}' for e in g["edges"]]
    stated=next(c for c in summary["comparisons"] if c["task_unit_id"]==uid)
    assert stated["fg_request_differs"]==(by[uid,"F"][0]["target_prompt"]!=by[uid,"G"][0]["target_prompt"])
assert {m:dict(u) for m,u in usage.items()}==summary["usage"]
assert summary["assigned"]==summary["returned"]==27
assert sum(c["fg_request_differs"] for c in summary["comparisons"])==5
assert summary["main_generation_status"]=="STOP_SOURCE_N_LT_24"
check_bundle(ROOT/"data/method/structure-binding-development-20260926/endpoint-frozen")
controls=read(ROOT/"results/structure-binding-development-20260926-endpoint/results.json")
false_secure=[r["id"] for r in controls if r["expected_task_bound"]!="secure" and r["observed_general_profile"].get("security_label")=="secure"]
assert len(controls)==16 and len(false_secure)==5
print(json.dumps({"status":"VERIFIED","requests":27,"render_counts":{m:dict(c) for m,c in counts.items()},
                  "fg_request_differences":5,"general_profile_not_sufficient_cases":false_secure,
                  "usage":{m:dict(u) for m,u in usage.items()}},indent=2))
