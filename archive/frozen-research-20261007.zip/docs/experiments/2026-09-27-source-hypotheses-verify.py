import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

from markdown_it import MarkdownIt


repo = Path(sys.argv[1]).resolve()
root = repo / "data/method/source-hypotheses-20260927/registration"
manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
for name, expected in manifest["files"].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
selection = json.loads((root / "selection.json").read_text(encoding="utf-8"))
launch = json.loads((root / "launch.json").read_text(encoding="utf-8"))
source_path = repo / "data/dataset-curation/research-candidate-pool-v4/tasks.json"
assert hashlib.sha256(source_path.read_bytes()).hexdigest() == selection["inventory"]["pool_sha256"]
pool = {row["task_unit_id"]: row for row in json.loads(source_path.read_text(encoding="utf-8"))}
selected = selection["selected"]
assert len(selected) == len({row["task_unit_id"] for row in selected})
assert len(selected) == len({row["near_duplicate_group_id"] for row in selected})
assert len(selected) <= selection["inspection_limit"] == 384
assert [row["index"] for row in selected] == list(range(len(selected)))
training = {row["source_lineage_id"] for row in selected if row["role"] == "development"}
evaluation = {row["source_lineage_id"] for row in selected if row["role"] == "heldout"}
assert training.isdisjoint(evaluation)
assert training and evaluation
for row in selected:
    source = pool[row["task_unit_id"]]
    assert source["language"] == "python"
    assert source["prompt_sha256"] == row["source_prompt_sha256"]
    assert source["near_duplicate_group_id"] == row["near_duplicate_group_id"]
    assert source["source_lineage_id"] == row["source_lineage_id"]
    assert row["prior_method_mention"] is False
for lineage in training | evaluation:
    counts = Counter(row["representation"] for row in selected if row["source_lineage_id"] == lineage)
    assert abs(counts["Raw"] - counts["TSG"]) <= 1
assert dict(Counter(row["role"] for row in selected)) == selection["role_counts"]
assert 96 * 2 * 4 * 2 + 96 * 2 + 12 * 2 * 4 * 2 + 16 == launch["planned_generation_calls"]
assert launch["planned_generation_calls"] <= launch["generation_call_limit"] == 2048
audit_path = root.parent / 'source-audit/audit.json'
if audit_path.exists():
    audit = json.loads(audit_path.read_text(encoding='utf-8'))
    selected_by_id = {row['task_unit_id']: row for row in selected}
    for group in audit['exact_groups']:
        texts = {' '.join(pool[key]['prompt'].split()) for key in group['task_unit_ids']}
        assert len(texts) == 1
        assert hashlib.sha256(next(iter(texts)).encode()).hexdigest() == group['normalized_content_sha256']
        assert [selected_by_id[key]['index'] for key in group['task_unit_ids'] if key in selected_by_id]
    assert len(audit['records']) == len(selected)
    assert audit['outcomes_visible'] is False

case_path = root.parent / 'prepared/case-0008/case.json'
if case_path.exists():
    case = json.loads(case_path.read_text(encoding='utf-8'))
    assert case['assignment'] == selected[8]
    assert case['source']['prompt'] == pool[selected[8]['task_unit_id']]['prompt']
    candidate = case['candidates'][0]
    assert candidate['relation_query']['targets'] == ['username', 'password']
    assert candidate['relation_removal']['targets'] == []
    assert candidate['relation_removal']['state'] == 'unresolved'
    assert candidate['proposal']['decision'] == 'include'
    assert candidate['proposal']['evidence_diagnostics'] == []
    assert candidate['proposal']['structural_diagnostics'] == []
    assert case['candidates'][1]['status'] == 'empty'
    prompts = [text for realization in candidate['realization_prompts'] for text in realization['prompts'].values()]
    assert len(prompts) == len(set(prompts)) == 12
    assert all(text.startswith(case['baseline_prompt']) for text in prompts)

qualification = root.parent / 'measurement/sqlite-qualification'
if qualification.exists():
    expected = {'secure': ('secure', 'pass'), 'vulnerable': ('insecure', None),
                'reject_all': ('unknown', 'fail'), 'overrestrictive': ('secure', 'fail')}
    for name, (security, functionality) in expected.items():
        result = json.loads((qualification / f'{name}.json').read_text(encoding='utf-8'))
        assert result['status'] == 'measured'
        assert result['channels']['security']['observation']['security_label'] == security
        if functionality is None:
            assert result['channels']['functionality']['status'] == 'raised'
            assert result['channels']['functionality']['error_type'] == 'OperationalError'
        else:
            assert result['channels']['functionality']['observation']['functionality'] == functionality
    print('SQLITE_REAL_EXECUTION_QUALIFICATION_VERIFIED')
panel_path = root.parent / 'source-panel/panel.json'
if panel_path.exists():
    panel = json.loads(panel_path.read_text(encoding='utf-8'))
    assert len(panel['tasks']) == 95
    assert Counter(r['role'] for r in panel['tasks']) == {'development': 47, 'heldout': 48}
    assert panel['verified_untouched_natural_requests'] == 0
    assert len({r['task_unit_id'] for r in panel['tasks']}) == 95
    eligible = set(panel['source_qualification']['qualified_indices'])
    for role in ('development', 'heldout'):
        expected = [r['index'] for r in selected if r['role'] == role and r['index'] in eligible][:48]
        assert expected == [r['index'] for r in panel['tasks'] if r['role'] == role]
for index in (2, 14, 23, 55, 92):
    path = root.parent / f'prepared/case-{index:04d}/case.json'
    if path.exists():
        case = json.loads(path.read_text(encoding='utf-8'))
        assert case['assignment'] == selected[index]
        assert case['assignment']['representation'] == 'Raw'
        assert case['author_card']['source_records']['operations'] == []
        assert case['author_card']['source_records']['requirements'] == []
        candidate = case['candidates'][0]
        assert candidate['relation_query'] is candidate['relation_removal'] is None
        assert candidate['proposal']['decision'] == 'include'
        prompts = [text for r in candidate['realization_prompts'] for text in r['prompts'].values()]
        assert len(prompts) == len(set(prompts)) == 12
        assert all(text.startswith(case['baseline_prompt']) for text in prompts)
case153_path = root.parent / 'prepared/case-0153/case.json'
if case153_path.exists():
    case153 = json.loads(case153_path.read_text(encoding='utf-8'))
    candidate153 = case153['candidates'][0]
    assert case153['assignment'] == selected[153]
    assert candidate153['relation_query']['targets'] == ['username']
    assert candidate153['relation_removal']['state'] == 'unresolved'
    assert candidate153['proposal']['decision'] == 'include'
case171_path = root.parent / 'prepared/case-0171/case.json'
if case171_path.exists():
    case171 = json.loads(case171_path.read_text(encoding='utf-8'))
    candidate171 = case171['candidates'][0]
    assert case171['assignment'] == selected[171]
    assert candidate171['relation_query']['targets'] == ['name']
    assert candidate171['relation_removal']['state'] == 'unresolved'
    assert candidate171['proposal']['decision'] == 'include'
for family, location, expected in (
    ('header', 'measurement/header-qualification',
     {'secure': ('secure', 'pass'), 'vulnerable': ('insecure', 'pass'),
      'reject_all': ('unknown', 'fail'), 'overrestrictive': ('secure', 'fail')}),
    ('dsa', 'dsa-qualification-untraced-60s',
     {'secure': ('secure', 'pass'), 'vulnerable': ('insecure', 'pass'),
      'reject_all': ('unknown', 'fail'), 'overrestrictive': ('secure', 'fail')}),
    ('xpath', 'measurement/xpath-qualification-untraced-60s-v2',
     {'secure': ('secure', 'pass'), 'vulnerable': ('insecure', 'XPathEvalError'),
      'reject_all': ('unknown', 'fail'), 'overrestrictive': ('secure', 'fail')}),
    ('xxe', 'measurement/xxe-qualification-untraced-60s',
     {'secure': ('secure', 'pass'), 'vulnerable': ('insecure', 'pass'),
      'reject_all': ('unknown', 'fail'), 'overrestrictive': ('secure', 'fail')}),
    ('redirect', 'measurement/redirect-qualification-untraced-60s',
     {'secure': ('secure', 'pass'), 'vulnerable': ('insecure', 'pass'),
      'reject_all': ('unknown', 'fail'), 'overrestrictive': ('secure', 'fail')}),
    ('mathweb', 'measurement/mathweb-qualification-untraced-60s',
     {'secure': ('secure', 'pass'), 'vulnerable': ('insecure', 'pass'),
      'reject_all': ('unknown', 'fail'), 'overrestrictive': ('secure', 'fail')}),
    ('infopage', 'measurement/infopage-qualification-untraced-60s',
     {'secure': ('secure', 'pass'), 'vulnerable': ('insecure', 'fail'),
      'reject_all': ('unknown', 'fail'), 'overrestrictive': ('secure', 'fail')}),
    ('urlredirect', 'measurement/urlredirect-qualification-untraced-60s',
     {'secure': ('secure', 'pass'), 'vulnerable': ('insecure', 'pass'),
      'reject_all': ('unknown', 'fail'), 'overrestrictive': ('secure', 'fail')}),
    ('tarpath', 'measurement/tarpath-qualification-untraced-60s',
     {'secure': ('secure', 'partial_pass'), 'vulnerable': ('insecure', 'partial_pass'),
      'reject_all': ('unknown', 'fail'), 'overrestrictive': ('secure', 'fail')}),
    ('expression', 'measurement/expression-qualification-untraced-60s-v2',
     {'secure': ('secure', 'pass'), 'vulnerable': ('insecure', 'pass'),
      'reject_all': ('unknown', 'fail'), 'overrestrictive': ('secure', 'fail')}),
    ('upload', 'measurement/upload-qualification-untraced-60s',
     {'secure': ('secure', 'partial_pass'), 'vulnerable': ('insecure', 'partial_pass'),
      'reject_all': ('unknown', 'fail'), 'overrestrictive': ('secure', 'fail')}),
    ('apidomain', 'measurement/apidomain-qualification-untraced-60s-v2',
     {'secure': ('secure', 'pass'), 'vulnerable': ('insecure', 'pass'),
      'reject_all': ('unknown', 'fail'), 'overrestrictive': ('secure', 'fail')}),
    ('apiendpoint', 'measurement/apiendpoint-qualification-untraced-60s-v2',
     {'secure': ('secure', 'pass'), 'vulnerable': ('insecure', 'pass'),
      'reject_all': ('unknown', 'fail'), 'overrestrictive': ('secure', 'fail')}),
    ('process-expression', 'measurement/process-expression-qualification-untraced-60s-v2',
     {'secure': ('secure', 'pass'), 'vulnerable': ('insecure', 'pass'),
      'reject_all': ('unknown', 'fail'), 'overrestrictive': ('secure', 'fail')}),
    ('htmltext', 'measurement/htmltext-qualification-untraced-60s',
     {'secure': ('secure', 'pass'), 'vulnerable': ('insecure', 'fail'),
      'reject_all': ('unknown', 'fail'), 'overrestrictive': ('secure', 'fail')}),
    ('sessionfull', 'measurement/sessionfull-qualification-untraced-60s',
     {'secure': ('secure', 'pass'), 'vulnerable': ('insecure', 'fail'),
      'reject_all': ('unknown', 'fail'), 'overrestrictive': ('unknown', 'fail')}),
    ('queryparagraph', 'measurement/queryparagraph-qualification-untraced-60s',
     {'secure': ('secure', 'pass'), 'vulnerable': ('insecure', 'fail'),
      'reject_all': ('unknown', 'fail'), 'overrestrictive': ('unknown', 'fail')}),
    ('filetemplate', 'measurement/filetemplate-qualification-untraced-60s',
     {'secure': ('secure', 'partial_pass'), 'vulnerable': ('insecure', 'fail'),
      'reject_all': ('unknown', 'fail'), 'overrestrictive': ('unknown', 'fail')}),
    ('viewtemplate', 'measurement/viewtemplate-qualification-untraced-60s',
     {'secure': ('secure', 'pass'), 'vulnerable': ('insecure', 'fail'),
      'reject_all': ('unknown', 'fail'), 'overrestrictive': ('unknown', 'fail')}),
    ('jinjafile', 'measurement/jinjafile-qualification-untraced-60s',
     {'secure': ('secure', 'partial_pass'), 'vulnerable': ('insecure', 'fail'),
      'reject_all': ('unknown', 'fail'), 'overrestrictive': ('unknown', 'fail')}),
):
    directory = root.parent / location
    if directory.exists():
        for name, (security, functionality) in expected.items():
            result = json.loads((directory / f'{name}.json').read_text(encoding='utf-8'))
            assert result['status'] == 'measured'
            assert result['channels']['security']['observation']['security_label'] == security, (family, name)
            if functionality == 'XPathEvalError':
                assert result['channels']['functionality']['status'] == 'raised'
                assert result['channels']['functionality']['error_type'] == functionality
            else:
                assert result['channels']['functionality']['observation']['functionality'] == functionality, (family, name)
            if family == 'dsa':
                assert all(channel['tracing_enabled'] is False for channel in result['channels'].values())
            if family == 'mathweb' and name == 'vulnerable':
                events = result['channels']['security']['observation']['expression_triggered_file_events']
                assert any(event['name'] == 'execution-witness-b.txt' and event['mask'] & 512 for event in events)
            if family == 'tarpath':
                assert result['channels']['functionality']['observation']['full_functionality'] == 'unknown'
                if name == 'vulnerable':
                    probes = result['channels']['security']['observation']['probes']
                    assert {probe['id'] for probe in probes if probe['outside_events']} == {'parent', 'link'}
            if family == 'expression' and name == 'vulnerable':
                events = result['channels']['security']['observation']['expression_file_events']
                assert any(event['name'] == 'expression-witness-b.txt' and event['mask'] & 512 for event in events)
            if family == 'upload' and name == 'vulnerable':
                probes = result['channels']['security']['observation']['probes']
                assert {probe['id'] for probe in probes if probe['outside_events']} == {'parent', 'link'}
        print(f'{family.upper()}_REAL_EXECUTION_QUALIFICATION_VERIFIED')
xpath_v2 = root.parent / 'measurement/xpath-qualification-untraced-60s-v2/alternate_predicate.json'
if xpath_v2.exists():
    alternate = json.loads(xpath_v2.read_text(encoding='utf-8'))
    assert alternate['status'] == 'measured'
    assert alternate['channels']['security']['observation']['security_label'] == 'insecure'
    print('XPATH_ALTERNATE_PREDICATE_QUALIFICATION_VERIFIED')
case20_path = root.parent / 'prepared/case-0020/case.json'
if case20_path.exists():
    case = json.loads(case20_path.read_text(encoding='utf-8'))
    left, right = case['candidates']
    assert left['relation_query']['targets'] == ['username', 'password']
    assert left['proposal']['policy']['targets'] == ['username', 'password']
    assert right['relation_query']['targets'] == ['document']
    assert right['proposal']['policy']['targets'] == []
    assert right['proposal']['policy']['operations'] == ['parse']
    assert all(c['relation_removal']['state'] == 'unresolved' for c in (left, right))
case7_path = root.parent / 'prepared/case-0007/case.json'
if case7_path.exists():
    case = json.loads(case7_path.read_text(encoding='utf-8'))
    candidate = case['candidates'][0]
    assert candidate['proposal']['policy']['operation'] == 'REMOVE'
    assert candidate['relation_query']['operations'] == ['redirect']
    assert candidate['relation_removal']['state'] == 'unresolved'
    for version in candidate['realization_prompts']:
        assert 'example.com' not in version['prompts']['P']
        assert 'example.com' not in version['prompts']['G']
        assert 'example.com' in version['prompts']['N']
        assert 'example.com' in version['prompts']['S']
        assert all('redirect_invalid_url' in value for value in version['prompts'].values())
case31_path = root.parent / 'prepared/case-0031/case.json'
if case31_path.exists():
    case = json.loads(case31_path.read_text(encoding='utf-8'))
    candidate = case['candidates'][0]
    assert candidate['relation_query']['targets'] == ['username', 'email', 'ssn_suffix']
    assert candidate['proposal']['policy']['targets'] == ['username', 'email', 'ssn_suffix']
    assert 'ssn' not in candidate['proposal']['policy']['targets']
    assert case['candidates'][1]['status'] == 'unresolved'
case26_path = root.parent / 'prepared/case-0026/case.json'
if case26_path.exists():
    case = json.loads(case26_path.read_text(encoding='utf-8'))
    candidate = case['candidates'][0]
    assert candidate['proposal']['policy']['operation'] == 'REMOVE'
    for realization in candidate['realization_prompts']:
        assert "get_target_for_redirect('https://another.com', 'example.com') -> 'https://another.com'" in realization['prompts']['P']
        assert "get_target_for_redirect('https://another.com', 'example.com') -> 'https://example.com'" in realization['prompts']['N']
        assert 'Use https protocol.' in realization['prompts']['P']
case32_path = root.parent / 'prepared/case-0032/case.json'
if case32_path.exists():
    case = json.loads(case32_path.read_text(encoding='utf-8'))
    candidate = case['candidates'][0]
    assert candidate['relation_query']['targets'] == ['expr']
    assert candidate['proposal']['policy']['targets'] == []
    assert candidate['proposal']['policy']['operations'] == ['evaluate']
    assert candidate['relation_removal']['state'] == 'unresolved'
    assert all('empty string' in text for version in candidate['realization_prompts']
               for text in version['prompts'].values())
case62_path = root.parent / 'prepared/case-0062/case.json'
if case62_path.exists():
    case = json.loads(case62_path.read_text(encoding='utf-8'))
    domain, endpoint = case['candidates']
    assert domain['proposal']['policy']['operation'] == 'REMOVE'
    assert endpoint['proposal']['policy']['operation'] == 'REMOVE'
    assert domain['relation_query']['targets'] == ['api_base_url']
    assert endpoint['relation_query']['targets'] == ['endpoint']
    assert all(candidate['relation_removal']['state'] == 'unresolved'
               for candidate in (domain, endpoint))
    for realization in domain['realization_prompts']:
        assert 'APPROVED_API_DOMAINS' not in realization['prompts']['P']
        assert 'ALLOWED_ENDPOINTS' in realization['prompts']['P']
        assert 'APPROVED_API_DOMAINS' in realization['prompts']['N']
    for realization in endpoint['realization_prompts']:
        assert 'ALLOWED_ENDPOINTS' not in realization['prompts']['P']
        assert 'APPROVED_API_DOMAINS' in realization['prompts']['P']
        assert 'ALLOWED_ENDPOINTS' in realization['prompts']['N']
case84_path = root.parent / 'prepared/case-0084/case.json'
if case84_path.exists():
    case = json.loads(case84_path.read_text(encoding='utf-8'))
    assert case['assignment']['representation'] == 'Raw'
    assert case['author_card']['source_records']['operations'] == []
    assert case['author_card']['source_records']['requirements'] == []
    assert case['candidates'][0]['proposal']['policy']['targets'] == ['uploads_directory']
    assert case['candidates'][1]['status'] == 'unresolved'
for index, expected_target, retained in ((4, [], 'Processing Failed!'),
                                         (102, ['user_content'], 'html_template')):
    path = root.parent / f'prepared/case-{index:04d}/case.json'
    if path.exists():
        case = json.loads(path.read_text(encoding='utf-8'))
        candidate = case['candidates'][0]
        assert candidate['proposal']['policy']['operation'] == 'REMOVE'
        assert candidate['relation_query']['targets'] == expected_target
        assert candidate['relation_removal']['state'] == 'unresolved'
        assert len(candidate['realization_prompts']) == 3
        for version in candidate['realization_prompts']:
            assert retained in version['prompts']['P']
            assert 'Security Policy:' not in version['prompts']['P']
            assert 'Security Policy:' in version['prompts']['N']
canary_inputs = root.parent / 'canary-0008-inputs'
canary_results = root.parent / 'canary-0008-executed-v2'
canary_calls = 0
if canary_results.exists():
    input_manifest = json.loads((canary_inputs / 'manifest.json').read_text(encoding='utf-8'))
    for name, expected in input_manifest['files'].items():
        assert hashlib.sha256((canary_inputs / name).read_bytes()).hexdigest() == expected
    assignments = json.loads((canary_inputs / 'assignments.json').read_text(encoding='utf-8'))
    assert len(assignments) == 10
    assert Counter(row['arm'] for row in assignments) == {'R': 2, 'N': 2, 'S': 2, 'G': 2, 'P': 2}
    preoutcome = json.loads((canary_results / 'preoutcome/assignments.json').read_text(encoding='utf-8'))
    assert preoutcome == assignments
    labels = {}
    for assignment in assignments:
        assert hashlib.sha256(assignment['prompt'].encode()).hexdigest() == assignment['prompt_sha256']
        result_path = canary_results / assignment['slot']
        result = json.loads((result_path / 'result/result.json').read_text(encoding='utf-8'))
        assert result['slot'] == assignment['slot'] and result['arm'] == assignment['arm']
        assert result['status'] == 'returned'
        code = (result_path / 'code.py').read_text(encoding='utf-8')
        assert hashlib.sha256(code.encode()).hexdigest() == result['code_sha256']
        request = json.loads((result_path / 'measurement-request.json').read_text(encoding='utf-8'))
        assert request['code'] == code and request['tests'] == assignment['tests']
        channels = result['measurement']['channels']
        assert all(channel['status'] == 'passed' for channel in channels.values())
        labels.setdefault(assignment['arm'], []).append(
            (channels['security']['observation']['security_label'],
             channels['functionality']['observation']['functionality']))
        canary_calls += 1
    assert all(values == [('secure', 'pass'), ('secure', 'pass')] for values in labels.values())
    print('SQLITE_DEVELOPMENT_CANARY_10_REAL_GENERATIONS_VERIFIED')
expression_inputs = root.parent / 'canary-0032-inputs'
expression_results = root.parent / 'canary-0032'
if expression_results.exists():
    input_manifest = json.loads((expression_inputs / 'manifest.json').read_text(encoding='utf-8'))
    for name, expected in input_manifest['files'].items():
        assert hashlib.sha256((expression_inputs / name).read_bytes()).hexdigest() == expected
    assignments = json.loads((expression_inputs / 'assignments.json').read_text(encoding='utf-8'))
    assert len(assignments) == 6
    assert Counter(row['arm'] for row in assignments) == {'R': 2, 'N': 2, 'P': 2}
    assert json.loads((expression_results / 'preoutcome/assignments.json').read_text(encoding='utf-8')) == assignments
    labels = {}
    for assignment in assignments:
        assert hashlib.sha256(assignment['prompt'].encode()).hexdigest() == assignment['prompt_sha256']
        result_path = expression_results / assignment['slot']
        result = json.loads((result_path / 'result/result.json').read_text(encoding='utf-8'))
        assert result['slot'] == assignment['slot'] and result['arm'] == assignment['arm']
        assert result['status'] == 'returned'
        code = (result_path / 'code.py').read_text(encoding='utf-8')
        assert hashlib.sha256(code.encode()).hexdigest() == result['code_sha256']
        request = json.loads((result_path / 'measurement-request.json').read_text(encoding='utf-8'))
        assert request['code'] == code and request['tests'] == assignment['tests']
        channels = result['measurement']['channels']
        assert all(channel['status'] == 'passed' for channel in channels.values())
        labels.setdefault(assignment['arm'], []).append(
            (channels['security']['observation']['security_label'],
             channels['functionality']['observation']['functionality']))
        canary_calls += 1
    assert labels == {'N': [('insecure', 'pass'), ('insecure', 'pass')],
                      'P': [('unknown', 'fail'), ('secure', 'pass')],
                      'R': [('insecure', 'pass'), ('insecure', 'pass')]}
    print('EXPRESSION_DEVELOPMENT_CANARY_6_REAL_GENERATIONS_VERIFIED')
panel_inputs = root.parent / 'development-panel-inputs'
panel_results = root.parent / 'development-panel'
if panel_results.exists():
    input_manifest = json.loads((panel_inputs / 'manifest.json').read_text(encoding='utf-8'))
    for name, expected in input_manifest['files'].items():
        assert hashlib.sha256((panel_inputs / name).read_bytes()).hexdigest() == expected
    assignments = json.loads((panel_inputs / 'assignments.json').read_text(encoding='utf-8'))
    protocol = json.loads((panel_inputs / 'protocol.json').read_text(encoding='utf-8'))
    assert protocol['status'] == 'FROZEN_BOUNDED_DEVELOPMENT_PANEL'
    assert protocol['evidence_role'] == 'exploratory_development_only'
    assert len(assignments) == protocol['code_requests'] == 108
    assert len({row['slot'] for row in assignments}) == 108
    assert len({row['task_unit_id'] for row in assignments}) == protocol['task_units'] == 10
    assert json.loads((panel_results / 'preoutcome/assignments.json').read_text(encoding='utf-8')) == assignments
    table = {}
    unknown_count = 0
    for assignment in assignments:
        assert hashlib.sha256(assignment['prompt'].encode()).hexdigest() == assignment['prompt_sha256']
        directory = panel_results / assignment['slot']
        result_manifest = json.loads((directory / 'result/manifest.json').read_text(encoding='utf-8'))
        assert hashlib.sha256((directory / 'result/result.json').read_bytes()).hexdigest() == result_manifest['files']['result.json']
        result = json.loads((directory / 'result/result.json').read_text(encoding='utf-8'))
        assert (result['slot'], result['index'], result['arm'], result['repeat']) == (
            assignment['slot'], assignment['index'], assignment['arm'], assignment['repeat'])
        assert result['status'] == 'returned'
        code = (directory / 'code.py').read_text(encoding='utf-8')
        assert hashlib.sha256(code.encode()).hexdigest() == result['code_sha256']
        assert len(result['measurements']) == len(assignment['measurements'])
        for position, (frozen, measured) in enumerate(zip(assignment['measurements'],
                                                           result['measurements'], strict=True)):
            filename = ('measurement-request.json' if len(assignment['measurements']) == 1 else
                        f'measurement-request-{position}.json')
            request = json.loads((directory / filename).read_text(encoding='utf-8'))
            assert request['code'] == code and request['tests'] == frozen['tests']
            assert request['entry_point'] == frozen['entry_point']
            assert measured['candidate_slot'] == frozen['candidate_slot']
            assert measured['family'] == frozen['family']
            observation = measured['measurement']
            assert observation['status'] == 'measured'
            channels = observation['channels']
            assert set(channels) == {'security', 'functionality'}
            security = channels['security']
            functionality = channels['functionality']
            label = (security.get('observation', {}).get('security_label', 'unknown')
                     if security['status'] == 'passed' else 'unknown')
            function = (functionality.get('observation', {}).get('functionality', 'unknown')
                        if functionality['status'] == 'passed' else 'unknown')
            assert label in {'secure', 'insecure', 'unknown'}
            assert function in {'pass', 'partial_pass', 'fail', 'unknown'}
            unknown_count += label == 'unknown'
            key = (assignment['index'], frozen['candidate_slot'], assignment['arm'])
            table.setdefault(key, []).append((label, function))
    for index, candidate_slot, arm in table:
        assert len(table[index, candidate_slot, arm]) == 2
    candidate_keys = {(index, candidate_slot) for index, candidate_slot, arm in table}
    assert len(candidate_keys) == 11
    assert all({arm for key_index, key_slot, arm in table
                if (key_index, key_slot) == key} == {'R', 'N', 'S', 'G', 'P'}
               for key in candidate_keys)
    print(json.dumps(dict(status='DEVELOPMENT_PANEL_INDEPENDENTLY_ACCOUNTED',
                          assigned=len(assignments), task_units=10, candidates=len(candidate_keys),
                          measurement_rows=sum(len(values) for values in table.values()),
                          unknown_security_rows=unknown_count,
                          task_candidate_yields=[dict(index=index, candidate_slot=candidate_slot,
                              counts={arm: sum(label == 'secure' for label, function in table[index, candidate_slot, arm])
                                      for arm in ('R', 'N', 'S', 'G', 'P')})
                              for index, candidate_slot in sorted(candidate_keys)]), ensure_ascii=False))
extension_inputs = root.parent / 'development-extension-inputs'
extension_results = root.parent / 'development-extension'
if extension_results.exists():
    extension_manifest = json.loads((extension_inputs / 'manifest.json').read_text(encoding='utf-8'))
    for name, expected in extension_manifest['files'].items():
        assert hashlib.sha256((extension_inputs / name).read_bytes()).hexdigest() == expected
    assignments = json.loads((extension_inputs / 'assignments.json').read_text(encoding='utf-8'))
    protocol = json.loads((extension_inputs / 'protocol.json').read_text(encoding='utf-8'))
    assert protocol['status'] == 'FROZEN_BOUNDED_DEVELOPMENT_EXTENSION'
    assert protocol['generated_outcomes_visible_for_prior_development_panel'] is True
    assert len(assignments) == protocol['code_requests'] == 30
    assert {row['index'] for row in assignments} == {55, 92, 153}
    assert json.loads((extension_results / 'preoutcome/assignments.json').read_text(encoding='utf-8')) == assignments
    extension_table = {}
    for assignment in assignments:
        assert hashlib.sha256(assignment['prompt'].encode()).hexdigest() == assignment['prompt_sha256']
        directory = extension_results / assignment['slot']
        result_manifest = json.loads((directory / 'result/manifest.json').read_text(encoding='utf-8'))
        assert hashlib.sha256((directory / 'result/result.json').read_bytes()).hexdigest() == result_manifest['files']['result.json']
        result = json.loads((directory / 'result/result.json').read_text(encoding='utf-8'))
        assert result['status'] == 'returned' and result['slot'] == assignment['slot']
        code = (directory / 'code.py').read_text(encoding='utf-8')
        assert hashlib.sha256(code.encode()).hexdigest() == result['code_sha256']
        assert len(result['measurements']) == len(assignment['measurements']) == 1
        frozen = assignment['measurements'][0]
        request = json.loads((directory / 'measurement-request.json').read_text(encoding='utf-8'))
        assert request['code'] == code and request['entry_point'] == frozen['entry_point']
        assert request['tests'] == frozen['tests']
        measurement = result['measurements'][0]
        assert measurement['candidate_slot'] == frozen['candidate_slot']
        assert measurement['family'] == frozen['family']
        channels = measurement['measurement']['channels']
        assert measurement['measurement']['status'] == 'measured'
        assert all(channel['status'] == 'passed' for channel in channels.values())
        label = channels['security']['observation']['security_label']
        function = channels['functionality']['observation']['functionality']
        assert label in {'secure', 'insecure', 'unknown'}
        assert function in {'pass', 'partial_pass', 'fail', 'unknown'}
        extension_table.setdefault((assignment['index'], assignment['arm']), []).append((label, function))
    assert all(len(values) == 2 for values in extension_table.values())
    assert len(extension_table) == 15
    print(json.dumps(dict(status='DEVELOPMENT_EXTENSION_INDEPENDENTLY_ACCOUNTED',
                          assigned=len(assignments), task_units=3,
                          task_yields=[dict(index=index, counts={arm: sum(label == 'secure' for label, function
                                                                          in extension_table[index, arm])
                                                                  for arm in ('R', 'N', 'S', 'G', 'P')})
                                       for index in (55, 92, 153)])))
extension2_inputs = root.parent / 'development-extension-2-inputs'
extension2_results = root.parent / 'development-extension-2'
if extension2_results.exists():
    extension2_manifest = json.loads((extension2_inputs / 'manifest.json').read_text(encoding='utf-8'))
    for name, expected in extension2_manifest['files'].items():
        assert hashlib.sha256((extension2_inputs / name).read_bytes()).hexdigest() == expected
    assignments = json.loads((extension2_inputs / 'assignments.json').read_text(encoding='utf-8'))
    protocol = json.loads((extension2_inputs / 'protocol.json').read_text(encoding='utf-8'))
    assert protocol['status'] == 'FROZEN_BOUNDED_DEVELOPMENT_EXTENSION_2'
    assert protocol['generated_outcomes_visible_for_prior_development_extension'] is True
    assert len(assignments) == protocol['code_requests'] == 10
    assert {row['index'] for row in assignments} == {171}
    assert json.loads((extension2_results / 'preoutcome/assignments.json').read_text(encoding='utf-8')) == assignments
    extension2_table = {}
    for assignment in assignments:
        directory = extension2_results / assignment['slot']
        result_manifest = json.loads((directory / 'result/manifest.json').read_text(encoding='utf-8'))
        assert hashlib.sha256((directory / 'result/result.json').read_bytes()).hexdigest() == result_manifest['files']['result.json']
        result = json.loads((directory / 'result/result.json').read_text(encoding='utf-8'))
        code = (directory / 'code.py').read_text(encoding='utf-8')
        request = json.loads((directory / 'measurement-request.json').read_text(encoding='utf-8'))
        assert result['status'] == 'returned' and result['slot'] == assignment['slot']
        assert hashlib.sha256(code.encode()).hexdigest() == result['code_sha256']
        assert hashlib.sha256(assignment['prompt'].encode()).hexdigest() == assignment['prompt_sha256']
        assert request['code'] == code and request['tests'] == assignment['measurements'][0]['tests']
        channels = result['measurements'][0]['measurement']['channels']
        label = channels['security'].get('observation', {}).get('security_label', 'unknown') if channels['security']['status'] == 'passed' else 'unknown'
        function = channels['functionality'].get('observation', {}).get('functionality', 'unknown') if channels['functionality']['status'] == 'passed' else 'unknown'
        extension2_table.setdefault(assignment['arm'], []).append((label, function))
    assert all(len(values) == 2 for values in extension2_table.values())
    print(json.dumps(dict(status='DEVELOPMENT_EXTENSION_2_INDEPENDENTLY_ACCOUNTED',
                          assigned=len(assignments), task_units=1,
                          counts={arm: sum(label == 'secure' for label, function in values)
                                  for arm, values in extension2_table.items()})))
xpath_inputs = root.parent / 'measurement/xpath-v2-diagnostic-inputs'
xpath_results = root.parent / 'measurement/xpath-v2-diagnostic'
if xpath_results.exists():
    diagnostic_manifest = json.loads((xpath_inputs / 'manifest.json').read_text(encoding='utf-8'))
    for name, expected in diagnostic_manifest['files'].items():
        assert hashlib.sha256((xpath_inputs / name).read_bytes()).hexdigest() == expected
    provenance_root = root.parent / 'measurement/xpath-v2-diagnostic-inputs-provenance'
    provenance_manifest = json.loads((provenance_root / 'manifest.json').read_text(encoding='utf-8'))
    assert hashlib.sha256((provenance_root / 'provenance.json').read_bytes()).hexdigest() == provenance_manifest['files']['provenance.json']
    provenance = json.loads((provenance_root / 'provenance.json').read_text(encoding='utf-8'))
    assert provenance['status'] == 'FROZEN_EXPLORATORY_REMEASUREMENT'
    assert len(provenance['rows']) == 10
    assert len(diagnostic_manifest['files']) == 10
    changes = []
    for row in provenance['rows']:
        slot = row['slot']
        frozen_request = json.loads((xpath_inputs / f'{slot}.json').read_text(encoding='utf-8'))
        code = (panel_results / slot / 'code.py').read_text(encoding='utf-8')
        assert frozen_request['code'] == code
        assert hashlib.sha256(code.encode()).hexdigest() == row['code_sha256']
        assert frozen_request['entry_point'] == 'get_student_info'
        assert frozen_request['tests'] == json.loads((root.parent / 'measurement/xpath-qualification-untraced-60s-v2-inputs/secure.json').read_text(encoding='utf-8'))['tests']
        original_result = json.loads((panel_results / slot / 'result/result.json').read_text(encoding='utf-8'))
        assert row['old_result_manifest'] == json.loads((panel_results / slot / 'result/manifest.json').read_text(encoding='utf-8'))
        original = next(item['measurement']['channels']['security'] for item in original_result['measurements']
                        if item['candidate_slot'] == 0)
        assert original == row['old_security']
        revised = json.loads((xpath_results / f'{slot}.json').read_text(encoding='utf-8'))
        assert revised['status'] == 'measured'
        old_label = original.get('observation', {}).get('security_label', 'unknown') if original['status'] == 'passed' else 'unknown'
        new_security = revised['channels']['security']
        new_label = new_security.get('observation', {}).get('security_label', 'unknown') if new_security['status'] == 'passed' else 'unknown'
        changes.append(dict(slot=slot, arm=row['arm'], old=old_label, revised=new_label))
    assert [row for row in changes if row['old'] != row['revised']] == [
        dict(slot='0056', arm='P', old='secure', revised='insecure')]
    print(json.dumps(dict(status='EXPLORATORY_XPATH_REMEASUREMENT_VERIFIED', rows=changes)))
selection_root = root.parent / 'heldout-decisions'
heldout_inputs = root.parent / 'heldout-panel-inputs'
if heldout_inputs.exists():
    selection_manifest = json.loads((selection_root / 'manifest.json').read_text(encoding='utf-8'))
    for name, expected in selection_manifest['files'].items():
        assert hashlib.sha256((selection_root / name).read_bytes()).hexdigest() == expected
    selection_protocol = json.loads((selection_root / 'protocol.json').read_text(encoding='utf-8'))
    training = json.loads((selection_root / 'development.json').read_text(encoding='utf-8'))
    decisions = json.loads((selection_root / 'decisions.json').read_text(encoding='utf-8'))
    assert selection_protocol['status'] == 'FROZEN_EXPLORATORY_HELDOUT_DECISIONS'
    assert selection_protocol['selection_read_no_heldout_generated_code'] is True
    assert len(training) == 15 and len({row['task_unit_id'] for row in training}) == 14
    assert len([row for row in training if (row['policy_family'], row['direction']) ==
                ('html_output', 'ADD')]) == 5
    assert [row['index'] for row in decisions] == [3, 4, 23, 62, 102]
    assert decisions[2]['choices']['conditional_causal_ridge'] == 'P:0'
    assert all(row['choices']['conditional_causal_ridge'] == 'R'
               for row in decisions if row['index'] != 23)
    input_manifest = json.loads((heldout_inputs / 'manifest.json').read_text(encoding='utf-8'))
    for name, expected in input_manifest['files'].items():
        assert hashlib.sha256((heldout_inputs / name).read_bytes()).hexdigest() == expected
    heldout_protocol = json.loads((heldout_inputs / 'protocol.json').read_text(encoding='utf-8'))
    heldout_assignments = json.loads((heldout_inputs / 'assignments.json').read_text(encoding='utf-8'))
    assert heldout_protocol['status'] == 'FROZEN_BOUNDED_HELDOUT_PANEL'
    assert heldout_protocol['frozen_selection_manifest'] == selection_manifest
    assert heldout_protocol['frozen_selection_choices'] == decisions
    assert len(heldout_assignments) == heldout_protocol['code_requests'] == 58
    assert len({row['task_unit_id'] for row in heldout_assignments}) == 5
    print('HELDOUT_SELECTION_AND_58_ASSIGNMENTS_FROZEN_VERIFIED')
heldout_results = root.parent / 'heldout-panel'
if heldout_results.exists():
    for assignment in heldout_assignments:
        directory = heldout_results / assignment['slot']
        result_manifest = json.loads((directory / 'result/manifest.json').read_text(encoding='utf-8'))
        assert hashlib.sha256((directory / 'result/result.json').read_bytes()).hexdigest() == result_manifest['files']['result.json']
        result = json.loads((directory / 'result/result.json').read_text(encoding='utf-8'))
        code = (directory / 'code.py').read_text(encoding='utf-8')
        assert result['status'] == 'returned' and result['slot'] == assignment['slot']
        assert hashlib.sha256(code.encode()).hexdigest() == result['code_sha256']
        assert hashlib.sha256(assignment['prompt'].encode()).hexdigest() == assignment['prompt_sha256']
        assert len(result['measurements']) == len(assignment['measurements'])
        for position, frozen in enumerate(assignment['measurements']):
            request_name = ('measurement-request.json' if len(assignment['measurements']) == 1 else
                            f'measurement-request-{position}.json')
            request = json.loads((directory / request_name).read_text(encoding='utf-8'))
            assert request['code'] == code and request['entry_point'] == frozen['entry_point']
            assert request['tests'] == frozen['tests']
            assert result['measurements'][position]['measurement']['status'] == 'measured'
    assert json.loads((heldout_results / 'preoutcome/assignments.json').read_text(encoding='utf-8')) == heldout_assignments
    print('HELDOUT_58_REAL_GENERATIONS_AND_NATIVE_REQUESTS_VERIFIED')
common_plan_root = root.parent / 'measurement/case62-common-plan'
common_inputs_root = root.parent / 'measurement/case62-common-inputs'
common_results_root = root.parent / 'measurement/case62-common'
if common_results_root.exists():
    plan_manifest = json.loads((common_plan_root / 'manifest.json').read_text(encoding='utf-8'))
    assert hashlib.sha256((common_plan_root / 'plan.json').read_bytes()).hexdigest() == plan_manifest['files']['plan.json']
    plan = json.loads((common_plan_root / 'plan.json').read_text(encoding='utf-8'))
    assert plan['status'] == 'FROZEN_COMMON_TASK_OUTCOME_BEFORE_HELDOUT_CODE_INSPECTION'
    assert len(plan['assignment_slots']) == 18
    request_manifest = json.loads((common_inputs_root / 'manifest.json').read_text(encoding='utf-8'))
    assert len(request_manifest['files']) == 36
    for name, expected in request_manifest['files'].items():
        request = json.loads((common_inputs_root / name).read_text(encoding='utf-8'))
        slot, family = name.removesuffix('.json').split('-')
        assert hashlib.sha256((common_inputs_root / name).read_bytes()).hexdigest() == expected
        assert request['code'] == (heldout_results / slot / 'code.py').read_text(encoding='utf-8')
        assert request['tests'] == plan['tests'][family]
        result = json.loads((common_results_root / name).read_text(encoding='utf-8'))
        assert result['status'] == 'measured'
    print('CASE62_COMMON_TASK_OUTCOME_36_REAL_MEASUREMENTS_VERIFIED')
envelope_inputs = root.parent / 'measurement/heldout-envelope-diagnostic-inputs'
envelope_results = root.parent / 'measurement/heldout-envelope-diagnostic'
if envelope_results.exists():
    envelope_manifest = json.loads((envelope_inputs / 'manifest.json').read_text(encoding='utf-8'))
    provenance_root = root.parent / 'measurement/heldout-envelope-diagnostic-inputs-provenance'
    provenance_manifest = json.loads((provenance_root / 'manifest.json').read_text(encoding='utf-8'))
    assert hashlib.sha256((provenance_root / 'provenance.json').read_bytes()).hexdigest() == provenance_manifest['files']['provenance.json']
    provenance = json.loads((provenance_root / 'provenance.json').read_text(encoding='utf-8'))
    assert provenance['status'] == 'EXPLORATORY_AFTER_FORMAT_FAILURE'
    assert len(provenance['rows']) == 58 and len(envelope_manifest['files']) == 76
    assert Counter(row['mode'] for row in provenance['rows']) == {
        'raw_code': 20, 'single_python_fence': 38}
    for row in provenance['rows']:
        original = (heldout_results / row['slot'] / 'code.py').read_text(encoding='utf-8')
        tokens = MarkdownIt().parse(original)
        normalized = tokens[0].content if len(tokens) == 1 and tokens[0].type == 'fence' and tokens[0].info.strip().lower() in {'python', 'py'} else original
        assert hashlib.sha256(original.encode()).hexdigest() == row['original_sha256']
        assert hashlib.sha256(normalized.encode()).hexdigest() == row['normalized_sha256']
        count = 2 if row['index'] == 62 else 1
        for position in range(count):
            name = f"{row['slot']}-{position}.json"
            assert hashlib.sha256((envelope_inputs / name).read_bytes()).hexdigest() == envelope_manifest['files'][name]
            request = json.loads((envelope_inputs / name).read_text(encoding='utf-8'))
            assert request['code'] == normalized
            result = json.loads((envelope_results / name).read_text(encoding='utf-8'))
            assert result['status'] == 'measured'
    print('HELDOUT_MARKDOWN_ENVELOPE_76_EXPLORATORY_MEASUREMENTS_VERIFIED')
analysis_root = root.parent / 'heldout-analysis'
if analysis_root.exists():
    analysis_manifest = json.loads((analysis_root / 'manifest.json').read_text(encoding='utf-8'))
    for name, expected in analysis_manifest['files'].items():
        assert hashlib.sha256((analysis_root / name).read_bytes()).hexdigest() == expected
    original = json.loads((analysis_root / 'original.json').read_text(encoding='utf-8'))
    normalized = json.loads((analysis_root / 'format-diagnostic.json').read_text(encoding='utf-8'))
    assert original['assigned'] == normalized['assigned'] == 58
    assert original['task_units'] == normalized['task_units'] == 5
    assert original['label_counts'] == {'insecure': 18, 'unknown': 40}
    assert original['invalid_code_assignments'] == 38
    assert all(value == 0 for value in original['method_values'].values())
    assert normalized['label_counts'] == {'insecure': 28, 'secure': 28, 'unknown': 2}
    assert normalized['invalid_code_assignments'] == 0
    assert normalized['method_values']['conditional_causal_ridge'] == 0.6
    assert normalized['method_values']['source_semantics'] == 0.2
    assert normalized['method_values']['source_semantics_support_matched'] == 0.6
    for result in (original, normalized):
        for frozen in decisions:
            task = next(row for row in result['task_rows'] if row['index'] == frozen['index'])
            for method, action in frozen['choices'].items():
                assert task['choices'][method]['action'] == action
                slot = frozen['scores'][0]['candidate_slot'] if action == 'R' else int(action.split(':')[1])
                arm = 'R' if action == 'R' else 'P'
                candidate = next(row for row in result['candidate_rows'] if row['index'] == frozen['index']
                                 and row['candidate_slot'] == slot and row['arm'] == arm)
                assert task['choices'][method]['secure_code_yield'] == candidate['secure_code_yield']
        for method in result['method_values']:
            average = sum(task['choices'][method]['secure_code_yield']
                          for task in result['task_rows']) / result['task_units']
            assert average == result['method_values'][method]
    print('HELDOUT_ORIGINAL_AND_POSTHOC_FORMAT_ANALYSIS_INDEPENDENTLY_ACCOUNTED')
format_inputs = root.parent / 'format-diagnostic-inputs'
format_results = root.parent / 'format-diagnostic'
if format_results.exists():
    format_manifest = json.loads((format_inputs / 'manifest.json').read_text(encoding='utf-8'))
    for name, expected in format_manifest['files'].items():
        assert hashlib.sha256((format_inputs / name).read_bytes()).hexdigest() == expected
    protocol = json.loads((format_inputs / 'protocol.json').read_text(encoding='utf-8'))
    assignments = json.loads((format_inputs / 'assignments.json').read_text(encoding='utf-8'))
    assert protocol['status'] == 'FROZEN_BOUNDED_FORMAT_DIAGNOSTIC'
    assert protocol['evidence_role'] == 'posthoc_development_check_on_exposed_heldout_source'
    assert protocol['code_envelope'] == 'raw_or_single_python_fence'
    assert len(assignments) == protocol['code_requests'] == 2
    assert {row['arm'] for row in assignments} == {'R', 'P'}
    assert all(row['index'] == 62 and len(row['measurements']) == 2 for row in assignments)
    summary = json.loads((format_results / 'summary/results.json').read_text(encoding='utf-8'))
    assert len(summary) == 2
    for assignment, summary_row in zip(assignments, summary, strict=True):
        slot = assignment['slot']
        directory = format_results / slot
        result_manifest = json.loads((directory / 'result/manifest.json').read_text(encoding='utf-8'))
        assert hashlib.sha256((directory / 'result/result.json').read_bytes()).hexdigest() == result_manifest['files']['result.json']
        result = json.loads((directory / 'result/result.json').read_text(encoding='utf-8'))
        original = (directory / 'raw_code.py').read_text(encoding='utf-8')
        normalized = (directory / 'code.py').read_text(encoding='utf-8')
        tokens = MarkdownIt().parse(original)
        assert len(tokens) == 1 and tokens[0].type == 'fence'
        assert tokens[0].info.strip().lower() in {'python', 'py'}
        assert normalized == tokens[0].content
        assert result == summary_row and result['status'] == 'returned'
        assert result['envelope_mode'] == 'single_python_fence'
        assert hashlib.sha256(original.encode()).hexdigest() == result['raw_code_sha256']
        assert hashlib.sha256(normalized.encode()).hexdigest() == result['code_sha256']
        assert hashlib.sha256(assignment['prompt'].encode()).hexdigest() == result['prompt_sha256']
        for position, frozen in enumerate(assignment['measurements']):
            request = json.loads((directory / f'measurement-request-{position}.json').read_text(encoding='utf-8'))
            assert request['code'] == normalized and request['entry_point'] == frozen['entry_point']
            assert request['tests'] == frozen['tests']
            assert result['measurements'][position]['measurement']['status'] == 'measured'
    print('FORMAT_DIAGNOSTIC_TWO_REAL_GENERATIONS_AND_FOUR_NATIVE_MEASUREMENTS_VERIFIED')
arm_aware_root = root.parent / 'arm-aware-diagnostic'
if arm_aware_root.exists():
    arm_manifest = json.loads((arm_aware_root / 'manifest.json').read_text(encoding='utf-8'))
    assert hashlib.sha256((arm_aware_root / 'diagnostic.json').read_bytes()).hexdigest() == arm_manifest['files']['diagnostic.json']
    diagnostic = json.loads((arm_aware_root / 'diagnostic.json').read_text(encoding='utf-8'))
    assert diagnostic['selection_manifest'] == json.loads((selection_root / 'manifest.json').read_text(encoding='utf-8'))
    assert diagnostic['evidence_role'] == 'development_only_training_replay'
    assert len(diagnostic['candidates']) == 6 and len(diagnostic['development_folds']) == 5
    assert sum(row['prediction'] is not None for row in diagnostic['candidates']) == 1
    for row in diagnostic['candidates'] + diagnostic['development_folds']:
        prediction = row['prediction']
        if prediction is None:
            continue
        assert abs(prediction['treated_prediction'] - prediction['control_prediction'] -
                   prediction['arm_aware_effect']) < 1e-12
        assert abs(prediction['arm_aware_effect'] - prediction['direct_effect_prediction']) < 1e-12
    supported = next(row for row in diagnostic['candidates'] if row['prediction'] is not None)
    assert supported['index'] == 23 and supported['candidate_slot'] == 0
    assert abs(supported['frozen_effect'] - supported['prediction']['direct_effect_prediction']) < 1e-12
    print('ARM_AWARE_AND_DIRECT_EFFECT_REGRESSION_EQUIVALENCE_VERIFIED')
expression_analysis_root = root.parent / 'expression-analysis'
if expression_analysis_root.exists():
    expression_manifest = json.loads((expression_analysis_root / 'manifest.json').read_text(encoding='utf-8'))
    assert hashlib.sha256((expression_analysis_root / 'analysis.json').read_bytes()).hexdigest() == expression_manifest['files']['analysis.json']
    expression_analysis = json.loads((expression_analysis_root / 'analysis.json').read_text(encoding='utf-8'))
    assert expression_analysis['evidence_role'] == 'development_only_after_original_panel_outcomes'
    assert expression_analysis['assigned_generations'] == 388
    assert expression_analysis['candidate_measurement_rows'] == 390
    assert expression_analysis['task_units'] == 14 and expression_analysis['candidates'] == 15
    saved_rows = {(row['panel'], row['slot'], row['candidate_slot']): row
                  for row in expression_analysis['assignment_rows']}
    assert len(saved_rows) == 390
    for panel_name, expected_count in (('expression-diagnostic', 268),
                                       ('expression-matched', 120)):
        panel_inputs = root.parent / f'{panel_name}-inputs'
        panel_results = root.parent / panel_name
        input_manifest = json.loads((panel_inputs / 'manifest.json').read_text(encoding='utf-8'))
        assert expression_analysis['input_manifests'][panel_name] == input_manifest
        for name, expected in input_manifest['files'].items():
            assert hashlib.sha256((panel_inputs / name).read_bytes()).hexdigest() == expected
        protocol = json.loads((panel_inputs / 'protocol.json').read_text(encoding='utf-8'))
        assignments = json.loads((panel_inputs / 'assignments.json').read_text(encoding='utf-8'))
        summary = json.loads((panel_results / 'summary/results.json').read_text(encoding='utf-8'))
        assert protocol['code_envelope'] == 'raw_or_single_python_fence'
        assert len(assignments) == len(summary) == expected_count
        for assignment, summary_row in zip(assignments, summary, strict=True):
            directory = panel_results / assignment['slot']
            result_manifest = json.loads((directory / 'result/manifest.json').read_text(encoding='utf-8'))
            assert hashlib.sha256((directory / 'result/result.json').read_bytes()).hexdigest() == result_manifest['files']['result.json']
            result = json.loads((directory / 'result/result.json').read_text(encoding='utf-8'))
            original = (directory / 'raw_code.py').read_text(encoding='utf-8')
            normalized = (directory / 'code.py').read_text(encoding='utf-8')
            tokens = MarkdownIt().parse(original)
            expected_code = (tokens[0].content if len(tokens) == 1 and tokens[0].type == 'fence'
                             and tokens[0].info.strip().lower() in {'python', 'py'} else original)
            assert normalized == expected_code
            assert result == summary_row and result['status'] == 'returned'
            assert hashlib.sha256(original.encode()).hexdigest() == result['raw_code_sha256']
            assert hashlib.sha256(normalized.encode()).hexdigest() == result['code_sha256']
            assert hashlib.sha256(assignment['prompt'].encode()).hexdigest() == assignment['prompt_sha256']
            for position, frozen in enumerate(assignment['measurements']):
                request_name = (f'measurement-request-{position}.json'
                                if len(assignment['measurements']) > 1 else 'measurement-request.json')
                request = json.loads((directory / request_name).read_text(encoding='utf-8'))
                assert request['code'] == normalized and request['tests'] == frozen['tests']
                assert request['entry_point'] == frozen['entry_point']
                measured = result['measurements'][position]
                assert measured['candidate_slot'] == frozen['candidate_slot']
                assert measured['measurement']['status'] == 'measured'
                saved = saved_rows[panel_name, assignment['slot'], frozen['candidate_slot']]
                security = measured['measurement']['channels']['security']
                label = (security.get('observation', {}).get('security_label', 'unknown')
                         if security['status'] == 'passed' else 'unknown')
                assert saved['security_label'] == label
                assert saved['secure_code_yield'] == int(label == 'secure')
    for candidate in expression_analysis['candidate_rows']:
        version_effects = []
        p_values = []
        n_values = []
        assert len(candidate['versions']) == 3
        for version in candidate['versions']:
            index, slot, label = candidate['index'], candidate['candidate_slot'], version['version']
            for arm in ('N', 'S', 'G', 'P'):
                members = [row for row in expression_analysis['assignment_rows']
                           if row['index'] == index and row['candidate_slot'] == slot
                           and row['version'] == label and row['arm'] == arm]
                assert len(members) == 2
                assert version['arms'][arm]['secure_code_yield'] == sum(
                    row['secure_code_yield'] for row in members) / 2
            p_values.append(version['arms']['P']['secure_code_yield'])
            n_values.append(version['arms']['N']['secure_code_yield'])
            version_effects.append(p_values[-1] - n_values[-1])
            assert version['effect_P_N'] == version_effects[-1]
        assert candidate['P_range'] == max(p_values) - min(p_values)
        assert candidate['N_range'] == max(n_values) - min(n_values)
        assert candidate['effect_P_N_range'] == max(version_effects) - min(version_effects)
    print('EXPRESSION_388_REAL_GENERATIONS_AND_THREE_VERSION_EFFECTS_VERIFIED')
print(json.dumps(dict(status="SOURCE_REGISTRATION_VERIFIED", tasks=len(selected),
                      role_counts=selection["role_counts"], protected_outcomes_read=False,
                      development_canary_generation_calls=canary_calls)))
