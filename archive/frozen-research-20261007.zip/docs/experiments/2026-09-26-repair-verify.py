"""Independent standard-library verification and descriptive tables; no model calls."""
import csv
import hashlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'data/method/command-binding-repair-20260926/frozen'
RESULT=ROOT/'results'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def bundle(p):
    m=read(p/'manifest.json')
    for name,digest in m['files'].items():assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest
    return m
bundle(BASE)
for r in read(BASE/'representations.json'):
    assert r['flat']['facts']==[[n['id'],n['type'],n['attributes']] for n in r['graph']['nodes']]
    assert r['flat']['relations']==r['graph']['edges']
    for op in r['operations']:
        for arg in op['operands']:assert arg['source_quote'] in r['source_prompt']
    if r['name']=='ssh-keygen':assert all('logger' not in a['source_quote'] for op in r['operations'] for a in op['operands'])
    if r['name']=='curl':assert [(o['when'],len(o['operands'])) for o in r['operations']]==[('TLS is not enabled',1),('TLS is enabled',2)]
control_counts=Counter()
for c in read(BASE/'controls.json'):
    measured=read(RESULT/'command-binding-repair-20260926-controls'/(c['id']+'.json'))
    assert measured['task_bound_witness_label']==c['expected']
    control_counts[c['expected']]+=1
gen=RESULT/'command-binding-repair-20260926-generation'
slots=read(BASE/'assignments.json');tasks={t['task_unit_id']:t for t in read(BASE/'generation-tasks.json')}
assert len(slots)==len({(s['task_unit_id'],s['arm']) for s in slots})==len({s['seed'] for s in slots})==12
rows=read(gen/'summary/results.json');assert len(rows)==12
generation=[];usage=Counter()
for slot in slots:
    folder=gen/slot['slot'];bundle(folder/'result')
    r=read(folder/'result/result.json');task=tasks[slot['task_unit_id']]
    assert r in rows and all(r[k]==v for k,v in slot.items()) and r['status']=='returned'
    wire=read(folder/'request.json');response=read(folder/'response.json')
    assert json.loads(wire['messages'][1]['content'])=={'task':task['prompts'][slot['arm']]}
    assert wire['seed']==slot['seed'] and wire['temperature']==.7
    code=(folder/'code.py').read_text(encoding='utf-8')
    assert hashlib.sha256(code.encode()).hexdigest()==r['code_sha256']
    assert json.loads(response['choices'][0]['message']['content'])['code']==code
    measure_input=read(folder/'measurement-request.json')
    assert set(measure_input)=={'code','command_binding'} and measure_input['command_binding']==task['command_binding']
    usage.update({k:response['usage'][k] for k in ('prompt_tokens','completion_tokens')})
    m=r['measurement']
    # Recompute label aggregation, preserving invalid/unknown, without importing
    # the measurement producer. Individual raw call matching remains reviewable.
    labels=[x['witness_label'] for x in m['probes']]
    expected='insecure' if 'insecure' in labels else 'secure' if labels and all(x=='secure' for x in labels) else 'unknown'
    assert m['task_bound_witness_label']==expected
    generation.append(dict(task=task['name'],source_kind=task['source_kind'],arm=slot['arm'],
                           witness=expected,return_witness=m['functionality_witness']))
algo=RESULT/'command-binding-repair-20260926-algorithms'
p=read(algo/'matched.json');rr=list(csv.DictReader((algo/'jci.csv').open(encoding='utf-8-sig')))
assert len(p['records'])==80 and len(rr)==120
csvrows=list(csv.DictReader((algo/'matched.csv').open(encoding='utf-8')))
matrices=defaultdict(list)
for row in csvrows:matrices[(row['scenario'],int(row['n_total']),int(row['seed']))].append(row)
assert len(matrices)==40
for key,matrix in matrices.items():
    scenario,n,seed=key;assert len(matrix)==n
    if scenario.endswith('_proxy'):
        clean=matrices[(scenario.replace('_proxy','_clean'),n,seed)]
        for a,b in zip(matrix,clean):
            assert all(a[k]==b[k] for k in ['C','X','Z','target_Y']) and int(a['Y'])>=int(b['Y'])
truth={'C-X','X-Y','Y-Z'};groups=defaultdict(list);edges_by={}
def add(scenario,n,method,seed,pred,xy,warnings=0):
    assert (scenario,n,seed) in matrices
    groups[(scenario,n,method)].append(dict(full=pred==truth,xy=xy,warnings=warnings))
for r in p['records']:
    assert not r.get('error') and r['n_used']==r['n_total']
    pred={'-'.join(sorted([a,d])) for a,b,c,d in r['edges']}
    s=r['target_truth_score'];assert (s['tp'],s['fp'],s['fn'])==(len(pred&truth),len(pred-truth),len(truth-pred))
    xy=next(((b,c) if a=='X' else (c,b) for a,b,c,d in r['edges'] if {a,d}=={'X','Y'}),('NONE','NONE'))
    add(r['scenario'],r['n_total'],r['method'],r['seed'],pred,xy)
    edges_by[r['scenario'],r['n_total'],r['seed'],r['method']]=(pred,xy)
endpoint={'0':'NONE','1':'CIRCLE','2':'ARROW','3':'TAIL'}
for r in rr:
    assert not r['error'];pred=set(filter(None,r['predicted'].split('|')))
    assert (int(r['tp']),int(r['fp']),int(r['fn']))==(len(pred&truth),len(pred-truth),len(truth-pred))
    matrix=r['matrix'].split(';')
    # R column-major matrix, variable order C,X,Z,Y. [X,Y]=row1+col3*4.
    assert r['xy_left']==matrix[13] and r['xy_right']==matrix[7]
    add(r['scenario'],int(r['n_total']),r['method'],int(r['seed']),pred,
        (endpoint[r['xy_right']],endpoint[r['xy_left']]),int(r['ci_warning_count']))
table=[]
for (scenario,n,method),group in sorted(groups.items()):
    assert len(group)==5
    table.append(dict(scenario=scenario,n=n,method=method,full_target_skeleton=sum(x['full'] for x in group),
        xy_counts={' '.join(k):v for k,v in Counter(x['xy'] for x in group).items()},
        ci_warning_runs=sum(x['warnings']>0 for x in group)))
same_skeleton=sum(edges_by[*key,'Tetrad_FCI'][0]==edges_by[*key,'Tetrad_GFCI'][0] for key in matrices)
same_xy=sum(edges_by[*key,'Tetrad_FCI'][1]==edges_by[*key,'Tetrad_GFCI'][1] for key in matrices)
# Independent finite-state arithmetic check, without the benchmark sigmoid.
delta=sum(1/(1+math.exp(-(1.2*z+.8*u)))-1/(1+math.exp(-(-2+1.2*z+.8*u))) for z in (0,1) for u in (0,1))/4
assert abs(delta-p['counterexample']['do_X1_effect_fixed_A_NOOP_SCM_T'])<1e-12
assert len(p['counterexample']['observational_state_probabilities'])==16
assert all(x['p_SCM_T']==x['p_SCM_A'] for x in p['counterexample']['observational_state_probabilities'])
summary=dict(status='VERIFIED',representation_cases=4,control_counts=dict(control_counts),
 generation=sorted(generation,key=lambda x:(x['task'],x['arm'])),code_calls=12,llm_binding_calls=0,llm_judge_calls=0,
 usage=dict(usage),generation_seconds=max(r['ended_unix'] for r in rows)-min(r['started_unix'] for r in rows),
 algorithm_searches=200,algorithm_rows=table,tetrad_same_skeleton_of_40=same_skeleton,
 tetrad_same_xy_of_40=same_xy,counterexample_do_difference=delta,
 formal_claim_allowed=False,source_probe_limitation='curl IP-versus-authority ambiguity; unknowns not policy gains')
print(json.dumps(summary,indent=2))
