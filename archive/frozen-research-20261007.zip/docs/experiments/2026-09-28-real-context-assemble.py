import hashlib
import json
from collections import Counter
from pathlib import Path

from prompt_mechanism_study.artifact_io import write_bundle


ROOT = Path('data/method/graph-guided-20260928')
INPUTS = ROOT / 'real-context-exploratory-inputs'
OUTPUTS = Path('results/graph-guided-20260928/real-context-exploratory-output')


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_manifest(directory):
    manifest = load(directory / 'manifest.json')
    for name, expected in manifest['files'].items():
        assert digest(directory / name) == expected
    return digest(directory / 'manifest.json')


def outcome(result):
    if result['status'] != 'returned':
        return dict(Y=0, security='unknown', functionality='unknown',
                    generation_status=result['status'])
    assert len(result['measurements']) == 1
    measurement = result['measurements'][0]['measurement']
    assert measurement['status'] == 'measured'
    channels = measurement['channels']
    security = (channels['security']['observation']['security_label']
                if channels['security']['status'] == 'passed' else 'unknown')
    functionality = (channels['functionality']['observation']['functionality']
                     if channels['functionality']['status'] == 'passed' else 'unknown')
    assert security in {'secure', 'insecure', 'unknown'}
    assert functionality in {'pass', 'fail', 'unknown'}
    return dict(Y=int(security == 'secure'), security=security,
                functionality=functionality, generation_status='returned')


def main():
    input_manifest = verify_manifest(INPUTS)
    protocol = load(INPUTS / 'protocol.json')
    assignments = load(INPUTS / 'assignments.json')
    assert protocol['status'] == 'FROZEN_GRAPH_GUIDED_REAL_CONTEXT_EXPLORATORY'
    assert len(assignments) == protocol['code_requests'] == 21
    assert [row['slot'] for row in assignments] == [f'{index:04d}' for index in range(21)]
    verify_manifest(OUTPUTS / 'preoutcome')
    verify_manifest(OUTPUTS / 'summary')
    assert load(OUTPUTS / 'preoutcome/assignments.json') == assignments
    assert load(OUTPUTS / 'preoutcome/protocol.json') == protocol
    summary = load(OUTPUTS / 'summary/results.json')
    assert len(summary) == len(assignments)
    by_slot = {}
    result_hashes = {}
    for assignment in assignments:
        slot = assignment['slot']
        assert hashlib.sha256(assignment['prompt'].encode()).hexdigest() == assignment['prompt_sha256']
        directory = OUTPUTS / slot / 'result'
        result_hashes[slot] = verify_manifest(directory)
        result = load(directory / 'result.json')
        assert result == summary[int(slot)]
        for key in ('index', 'task_unit_id', 'candidate_slot', 'version', 'arm', 'seed',
                    'prompt_sha256'):
            assert result[key] == assignment[key]
        by_slot[slot] = outcome(result)
    assert len(by_slot) == len(assignments)
    matrices = []
    for name, candidate_slot in protocol['categories'].items():
        records = []
        for task in protocol['task_rows']:
            if candidate_slot not in task['applicable_candidate_slots']:
                continue
            slot = task['request_slots'][str(candidate_slot) if task['C'] else 'None']
            observed = by_slot[slot]
            records.append(dict(index=task['index'], task_unit_id=task['task_unit_id'],
                                source_lineage_id=task['source_lineage_id'],
                                C=task['C'], X=task['X'], Y=observed['Y'],
                                request_slot=slot, version=task['version'], seed=task['seed'],
                                security=observed['security'], functionality=observed['functionality'],
                                generation_status=observed['generation_status']))
        matrices.append(dict(identity=name, n=len(records), labels=['C', 'X', 'Y'],
                             rows=[[row['C'], row['X'], row['Y']] for row in records],
                             records=records,
                             cell_counts={f'{c},{x}': sum(row['C'] == c and row['X'] == x
                                                        for row in records)
                                          for c in (0, 1) for x in (0, 1)},
                             outcome_counts=dict(Counter(row['security'] for row in records))))
    assert [matrix['n'] for matrix in matrices] == [14, 13]
    write_bundle(ROOT / 'real-context-matrices', {'matrices.json': matrices, 'protocol.json': dict(
        status='FROZEN_EXPLORATORY_REAL_CONTEXT_INPUT',
        formal_protocol='SPECIFIED_DRAFT',
        source_input_manifest_sha256=input_manifest,
        result_manifest_sha256_by_slot=result_hashes,
        categories=protocol['categories'],
        structural_methods=protocol['structural_methods'],
        structural_resampling=protocol['structural_resampling'],
        structural_action_rule=protocol['structural_action_rule'],
        context_modifier_multiplicity=protocol['context_modifier_multiplicity'],
        interpretive_limit='Small heterogeneous task population; context is an assigned prompt edit, X is a pre-edit source attribute.',
    )})
    print(json.dumps(dict(status='assembled', matrices=[dict(name=row['identity'],
                                                            n=row['n'], cells=row['cell_counts'],
                                                            outcomes=row['outcome_counts'])
                                                         for row in matrices])))


if __name__ == '__main__':
    main()
