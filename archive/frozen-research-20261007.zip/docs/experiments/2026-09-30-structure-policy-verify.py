import hashlib
import itertools
import json
from fractions import Fraction
from math import comb
from pathlib import Path

import numpy as np


ROOT = Path('data/method/graph-guided-20260930/cpu')
RESULTS = Path('results/graph-guided-20260930/cpu')


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def lines(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bundle(path):
    manifest = load(path/'manifest.json')
    assert set(p.name for p in path.iterdir()) == set(manifest['files']) | {'manifest.json'}
    for name, expected in manifest['files'].items():
        assert digest(path/name) == expected, name


def fit(rows, selected, penalty):
    d = rows.shape[1]-2
    if len(set(rows[:, 0])) < 2:
        return None
    treatment = 2*rows[:, 0]-1
    attributes = 2*rows[:, 1:-1]-1
    columns = [np.ones(len(rows)), treatment, *attributes.T,
               *[treatment*attributes[:, j-1] for j in selected]]
    matrix = np.column_stack(columns)
    regularizer = np.eye(d+2+len(selected))*np.sqrt(penalty)
    regularizer[0, 0] = 0
    return np.linalg.lstsq(np.vstack((matrix, regularizer)),
                          np.concatenate((rows[:, -1], np.zeros(len(regularizer)))), rcond=None)[0]


def predict(beta, attributes, selected):
    if beta is None:
        return np.zeros(len(attributes))
    return np.array([2*beta[1]+sum(2*beta[attributes.shape[1]+2+i]*(2*m[j-1]-1)
                                  for i, j in enumerate(selected)) for m in attributes])


def check_independence_values(matrices):
    labels = ['C', 'M1', 'M2', 'M3', 'M4', 'M5', 'M6', 'Y']
    checked = {'rational_population': 0, 'exact': 0, 'conditional_monte_carlo': 0,
               'attainability': 0}
    for record in lines(RESULTS/'ci.jsonl'):
        identity = record['identity']
        population = identity in {f'population-m{m}' for m in (1, 2, 3)}
        if population:
            mechanism = next(m for m in (1, 2, 3) if identity == f'population-m{m}')
            states = list(itertools.product((0, 1), repeat=8))
            masses = []
            for state in states:
                c, m1, m2 = state[:3]
                if mechanism == 1:
                    p = Fraction(4, 10) + Fraction(m2, 10) + c*(Fraction(m1, 2)-Fraction(2, 10))
                elif mechanism == 2:
                    p = Fraction(2, 10) + Fraction(3*m1, 10) + Fraction(m2, 10) + Fraction(15*c, 100)
                else:
                    p = sum((Fraction(4, 5) if u == m1 else Fraction(1, 5)) *
                            (Fraction(4, 10)+Fraction(m2, 10)+c*(Fraction(u, 2)-Fraction(2, 10)))
                            for u in (0, 1))
                masses.append((p if state[-1] else 1-p)/128)
            assert sum(masses) == 1
        else:
            states = matrices[identity]['rows']
        for query in record['tests']:
            x, y = labels.index(query['x']), labels.index(query['y'])
            conditioning = [labels.index(value) for value in query['conditioned']]
            tables = {}
            for position, state in enumerate(states):
                key = tuple(state[index] for index in conditioning)
                if key not in tables:
                    tables[key] = [Fraction(0) for _ in range(4)] if population else [0]*4
                tables[key][2*state[x]+state[y]] += masses[position] if population else 1
            if population:
                independent = all(a*d == b*c for a, b, c, d in tables.values())
                assert query['independent'] == independent
                assert query['p_value'] == int(independent)
                checked['rational_population'] += 1
                continue
            distributions = []
            observed_statistic, minimum_p, feasible = 0., 1., 1

            def pearson(cells):
                actual = np.asarray(cells, dtype=float).reshape(-1, 2, 2)
                expected = (actual.sum(axis=2)[:, :, None] * actual.sum(axis=1)[:, None, :]
                            / actual.sum(axis=(1, 2))[:, None, None])
                contributions = np.zeros_like(expected)
                np.divide((actual-expected)**2, expected, out=contributions, where=expected > 0)
                return contributions.sum(axis=(1, 2))

            for key in sorted(tables):
                table = tables[key]
                n = sum(table)
                nx, ny = table[2]+table[3], table[1]+table[3]
                support = list(range(max(0, nx+ny-n), min(nx, ny)+1))
                cells = [[n-nx-ny+a, ny-a, nx-a, a] for a in support]
                stats = pearson(cells)
                probabilities = np.asarray([float(Fraction(comb(ny, a)*comb(n-ny, nx-a), comb(n, nx)))
                                            for a in support])
                observed_statistic += pearson([table])[0]
                minimum_p *= probabilities[np.isclose(stats, stats.max(), atol=1e-12, rtol=0)].sum()
                feasible *= len(support)
                distributions.append((stats, probabilities, n, nx, ny))
            assert abs(observed_statistic-query['statistic']) < 1e-10
            assert abs(minimum_p-query['minimum_attainable_p']) < 1e-10
            assert feasible == query['feasible_tables']
            if minimum_p > .05:
                assert query['p_value'] is None and query['status'] == 'statistically_undetermined'
                checked['attainability'] += 1
                continue
            if feasible <= 100000:
                total_stats, total_probabilities = np.array([0.]), np.array([1.])
                for stats, probabilities, *_ in distributions:
                    total_stats = np.add.outer(total_stats, stats).flatten()
                    total_probabilities = np.multiply.outer(total_probabilities, probabilities).flatten()
                expected_p = total_probabilities[total_stats >= observed_statistic-1e-12].sum()
                mode = 'exact'
            else:
                purpose = [20260930, identity, query['key'], 'conditional_monte_carlo']
                seed = int.from_bytes(hashlib.sha256(json.dumps(purpose, separators=(',', ':')).encode()).digest()[:16], 'big')
                generator = np.random.Generator(np.random.PCG64(seed))
                randomized = np.zeros(9999)
                for _, _, n, nx, ny in distributions:
                    if nx in (0, n) or ny in (0, n):
                        continue
                    a = generator.hypergeometric(ny, n-ny, nx, 9999)
                    cells = np.column_stack([n-nx-ny+a, ny-a, nx-a, a])
                    randomized += pearson(cells)
                expected_p = (1+np.count_nonzero(randomized >= observed_statistic-1e-12))/10000
                mode = 'conditional_monte_carlo'
            assert query['mode'] == mode
            assert abs(expected_p-query['p_value']) < 1e-10, (identity, query['key'], mode, expected_p, query['p_value'])
            checked[mode] += 1
    return checked


def verify():
    bundle(ROOT)
    bundle(RESULTS/'summary')
    matrices = load(ROOT/'matrices.json')
    by_id = {m['identity']: m for m in matrices}
    assert len(by_id) == 126
    searches = lines(RESULTS/'searches.jsonl')
    keys = {(r['identity'], r['d'], r['method']) for r in searches}
    assert len(keys) == len(searches) == 510
    expected = {(m['identity'], d, name) for m in matrices for d in (3, 6)
                for name in ('FCI_JCI12', 'GFCI_JCI12')}
    expected |= {(f'population-m{m}', d, 'FCI_JCI12') for m in (1, 2, 3) for d in (3, 6)}
    assert keys == expected
    for row in searches:
        assert row['status'] == 'determined'
        for a, left, right, b in row['edges']:
            assert not ('C' in (a, b) and (a.startswith('M') or b.startswith('M')))
            if 'Y' in (a, b):
                assert (left if a == 'Y' else right) == 'ARROW'
                if 'C' in (a, b):
                    assert (left if a == 'C' else right) == 'TAIL'
    lookup = {(r['identity'], r['d'], r['method']): r for r in searches}
    policies = lines(RESULTS/'policies.jsonl')
    assert len(policies) == 252
    missing_arm_folds = []
    checked_subsets = 0
    for matrix in matrices:
        rows, folds = np.asarray(matrix['rows']), np.asarray(matrix['folds'])
        for fold in range(5):
            if len(set(rows[folds != fold, 0])) != 2:
                missing_arm_folds.append([matrix['identity'], fold])
    for record in policies:
        matrix = by_id[record['identity']]
        d, mechanism = record['d'], record['mechanism']
        rows = np.asarray(matrix['rows'])[:, [*range(d+1), 7]]
        folds = np.asarray(matrix['folds'])
        losses = {}
        for penalty in (.1, 1., 10., 100.):
            predictions = np.zeros(len(rows))
            for fold in range(5):
                beta = fit(rows[folds != fold], range(1, d+1), penalty)
                predictions[folds == fold] = predict(beta, rows[folds == fold, 1:-1], range(1, d+1))
            losses[penalty] = np.mean((2*(2*rows[:, 0]-1)*rows[:, -1]-predictions)**2)
            assert abs(losses[penalty]-record['cv']['losses'][str(penalty)]) < 1e-10
        assert record['penalty'] == min(losses, key=lambda value: (losses[value], -value))
        assert record['policies']['full']['selected'] == list(range(1, d+1))
        assert record['policies']['empty']['selected'] == []
        for name in ('FCI_JCI12', 'GFCI_JCI12', 'population_FCI'):
            key = (record['identity'], d, name) if name != 'population_FCI' else (f'population-m{mechanism}', d, 'FCI_JCI12')
            graph = lookup[key]
            selected = sorted(int(node[1:]) for edge in graph['edges'] if 'Y' in (edge[0], edge[3])
                              for node in (edge[0], edge[3]) if node.startswith('M'))
            assert record['policies'][name]['selected'] == selected
        states = np.array(list(itertools.product((0, 1), repeat=d)))
        for name, policy in record['policies'].items():
            fitted = policy['subsets'] if name.startswith('uniform_') else [policy]
            if name.startswith('uniform_'):
                k = policy['k']
                assert [p['selected'] for p in fitted] == [list(s) for s in itertools.combinations(range(1, d+1), k)]
                assert abs(policy['value']-np.mean([p['value'] for p in fitted])) < 1e-12
                assert abs(policy['regret']-np.mean([p['regret'] for p in fitted])) < 1e-12
            for result in fitted:
                beta = fit(rows, result['selected'], record['penalty'])
                tau = predict(beta, states, result['selected'])
                assert np.max(np.abs(tau-result['tau'])) < 1e-10
                actions = (tau > 1e-12).astype(int)
                assert actions.tolist() == result['actions']
                m1, m2 = states[:, 0], states[:, 1]
                if mechanism == 1:
                    values = .4+.1*m2+actions*(.5*m1-.2)
                    optimum = .6
                elif mechanism == 2:
                    values = .2+.3*m1+.1*m2+.15*actions
                    optimum = .55
                else:
                    values = .4+.1*m2+actions*(.3*m1-.1)
                    optimum = .55
                assert abs(np.mean(values)-result['value']) < 1e-12
                assert abs(optimum-result['value']-result['regret']) < 1e-12
                checked_subsets += 1
    groups = load(RESULTS/'summary/comparisons.json')['groups']
    assert len(groups) == 18
    for group in groups:
        records = [r for r in policies if (r['mechanism'], r['n'], r['d']) ==
                   (group['mechanism'], group['n'], group['d'])]
        assert len(records) == 14
        for contrast in group['comparisons']:
            differences = []
            for r in records:
                method = contrast['method']
                baseline = contrast['baseline']
                if baseline == 'uniform':
                    baseline = f'uniform_k{len(r["policies"][method]["selected"])}'
                differences.append(r['policies'][method]['value']-r['policies'][baseline]['value'])
            assert np.allclose(differences, contrast['paired_differences'], atol=1e-12, rtol=0)
            assert abs(np.mean(differences)-contrast['value_difference']) < 1e-12
            assert abs(np.std(differences, ddof=1)/np.sqrt(14)-contrast['paired_mcse']) < 1e-12
    frozen = load(RESULTS/'summary/completion.json')
    for name in ('ci.jsonl', 'policies.jsonl', 'searches.jsonl', 'checkpoint.json', 'r-stderr.log'):
        assert digest(RESULTS/name) == frozen['output_sha256'][name]
    checked_ci = check_independence_values(by_id)
    report = dict(status='VERIFIED', matrices=126, searches=510, views=252,
                  independently_checked_policy_fits=checked_subsets,
                  independently_replayed_cv_fits=252*4*5,
                  missing_arm_training_folds=missing_arm_folds,
                  independently_checked_ci=checked_ci,
                  scientific_output_sha256={name: digest(RESULTS/name) for name in
                      ('searches.jsonl', 'policies.jsonl', 'ci.jsonl')})
    print(json.dumps(report, sort_keys=True))


if __name__ == '__main__':
    verify()
