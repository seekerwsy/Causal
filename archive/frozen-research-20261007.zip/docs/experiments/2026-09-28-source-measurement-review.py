import argparse
import hashlib
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from prompt_mechanism_study.artifact_io import read_json, verify_bundle, write_bundle


ROOT = Path('data/method/graph-guided-20260928')
RESULTS = Path('results/graph-guided-20260928')
INPUTS = ROOT / 'source-measurement-review-inputs'
OUTPUTS = RESULTS / 'source-measurement-review-output'
FAMILIES = {122: 'blog_html', 235: 'header_buffer', 240: 'request_json_dict'}
PRIVACY_FAMILIES = {126: 'patient_template', 190: 'student_template', 224: 'receipt_template',
                    230: 'performance_template', 237: 'directory_template'}


def freeze(privacy=False):
    families = PRIVACY_FAMILIES if privacy else FAMILIES
    suffix = '-remaining' if privacy else ''
    prefix = 'privacy-property-review' if privacy else 'source-measurement-review'
    inputs = ROOT / (prefix+'-inputs')
    source_inputs = ROOT / ('heldout-execution-inputs'+suffix)
    source_outputs = RESULTS / ('heldout-remaining-diagnostic' if privacy else 'heldout-transfer-diagnostic')
    verify_bundle(source_inputs)
    assignments = read_json(source_inputs / 'assignments.json')
    chosen = [row for row in assignments if row['index'] in families]
    assert len(chosen) == 21*len(families)
    requests, qualification, identities = {}, {}, []
    for index, family in families.items():
        tests = {channel: (ROOT / ('measurement/'+family+('-property-' if channel == 'security' else '-')+channel+'.py')
                          if privacy else ROOT / f'measurement/{family}-source-{channel}.py').read_text(encoding='utf-8')
                 for channel in ('security', 'functionality')}
        controls = (ROOT / ('measurement/'+family+('-controls.py' if privacy else '-source-controls.py'))).read_text(encoding='utf-8')
        if privacy:
            controls += '\n'+(ROOT / 'measurement/privacy-redactor-control.py').read_text(encoding='utf-8')
        for name in (('secure', 'vulnerable', 'reject_all', 'overrestrictive', 'redact') if privacy else
                     ('secure', 'vulnerable', 'reject_all', 'overrestrictive')):
            qualification[f'{index}-{name}.json'] = dict(code=controls, entry_point=name, tests=tests,
                trace_assertions=False, channel_timeout_seconds=60)
        for row in chosen:
            if row['index'] != index:
                continue
            directory = source_outputs / row['slot']
            verify_bundle(directory / 'result')
            result = read_json(directory / 'result/result.json')
            code = (directory / 'code.py').read_text(encoding='utf-8')
            assert result['status'] == 'returned'
            assert hashlib.sha256(code.encode()).hexdigest() == result['code_sha256']
            requests[f"{row['slot']}.json"] = dict(code=code, tests=tests,
                entry_point=row['measurements'][0]['entry_point'], trace_assertions=False, channel_timeout_seconds=60)
            identities.append({key: row[key] for key in ('index', 'slot', 'arm', 'candidate_slot', 'version')})
    write_bundle(ROOT / (prefix+'-qualification-inputs'), qualification)
    write_bundle(inputs, requests)
    write_bundle(ROOT / (prefix+'-protocol'), {
        'identities.json': identities,
        'protocol.json': dict(status='FROZEN_POST_OUTCOME_SOURCE_SENSITIVITY', formal_protocol='SPECIFIED_DRAFT',
            requests=len(chosen), task_units=len(families), code_generation_calls=0,
            selection='Every output from all arms of the specified source families; no output-based omissions.',
            primary_result_policy='Original frozen labels and policy evaluation remain unchanged.',
            differences=({str(index): 'Finite secret nondisclosure is measured separately from the prescribed ValueError contract; original ordinary witness retained.'
                          for index in families} if privacy else
                         {'122': 'Source admits a title/body pair; frozen generation interface requested a string.',
                         '235': 'Server source: request framing replaces response framing in the witness.',
                         '240': 'Source unspecified dictionary header casing: evaluate canonical Content-Type.'}),
            interpretation='Exploratory source-relative measurements; results cannot promote revised eligibility or confirmatory effects.',
            input_manifest_sha256=hashlib.sha256((inputs / 'manifest.json').read_bytes()).hexdigest(),
            image='phase-graph-guided-h11:20260928')})
    print(dict(frozen_requests=len(chosen), qualification_programs=len(qualification)))


def verify(privacy=False):
    global INPUTS, OUTPUTS
    families = PRIVACY_FAMILIES if privacy else FAMILIES
    prefix = 'privacy-property-review' if privacy else 'source-measurement-review'
    if privacy:
        INPUTS, OUTPUTS = ROOT / (prefix+'-inputs'), RESULTS / (prefix+'-output')
    source_outputs = RESULTS / ('heldout-remaining-diagnostic' if privacy else 'heldout-transfer-diagnostic')
    verify_bundle(INPUTS)
    verify_bundle(ROOT / (prefix+'-qualification-inputs'))
    verify_bundle(ROOT / (prefix+'-protocol'))
    expected = {'secure': ('secure', 'pass'), 'vulnerable': ('insecure', 'pass'),
                'reject_all': ('unknown', 'fail'), 'overrestrictive': ('secure', 'fail')}
    if privacy:
        expected['redact'] = ('secure', 'pass')
    for index in families:
        for name, labels in expected.items():
            row = read_json(RESULTS / (prefix+'-qualification') / f'{index}-{name}.json')
            assert row['status'] == 'measured'
            assert tuple(row['channels'][channel]['observation'][field] for channel, field in
                         (('security', 'security_label'), ('functionality', 'functionality'))) == labels
    original = read_json(RESULTS / ('heldout-remaining-independent-verification.json' if privacy else 'heldout-independent-verification.json'))
    originals = {row['slot']: row for row in original['records']}
    identities = read_json(ROOT / (prefix+'-protocol/identities.json'))
    rows = []
    for identity in identities:
        slot = identity['slot']
        request = read_json(INPUTS / f'{slot}.json')
        prior = read_json(source_outputs / slot / 'result/result.json')
        assert hashlib.sha256(request['code'].encode()).hexdigest() == prior['code_sha256']
        measured = read_json(OUTPUTS / f'{slot}.json')
        assert measured['status'] == 'measured'
        security, functionality = measured['channels']['security'], measured['channels']['functionality']
        label = security['observation']['security_label'] if security['status'] == 'passed' else 'unknown'
        function = functionality['observation']['functionality'] if functionality['status'] == 'passed' else 'unknown'
        assert label in {'secure', 'insecure', 'unknown'} and function in {'pass', 'fail', 'unknown'}
        rows.append(dict(**identity, security=label, functionality=function, secure_yield=int(label == 'secure'),
                         functional_yield=int(function == 'pass'), joint_yield=int(label == 'secure' and function == 'pass'),
                         original_security=originals[slot]['security'], original_functionality=originals[slot]['functionality'],
                         **(dict(exception_contract_satisfied=security['observation']['exception_contract_satisfied'])
                            if privacy and security['status'] == 'passed' else {})))
    groups = defaultdict(list)
    for row in rows:
        groups[row['index'], row['candidate_slot'], row['arm']].append(row)
    effects = []
    for index in families:
        for candidate in (0, 2):
            arms = {}
            for arm in ('P', 'N', 'R', 'S', 'G'):
                group = groups[index, candidate if arm in ('P', 'N') else None, arm]
                assert len(group) == 3
                arms[arm] = {field: float(np.mean([row[field] for row in group]))
                             for field in ('secure_yield', 'functional_yield', 'joint_yield')}
            effects.append(dict(index=index, candidate_slot=candidate, arms=arms,
                P_minus_N=arms['P']['secure_yield']-arms['N']['secure_yield'],
                P_minus_R=arms['P']['secure_yield']-arms['R']['secure_yield']))
    summary = {str(index): dict(
        original_security=dict(Counter(row['original_security'] for row in rows if row['index'] == index)),
        revised_security=dict(Counter(row['security'] for row in rows if row['index'] == index)),
        revised_functionality=dict(Counter(row['functionality'] for row in rows if row['index'] == index)),
        transitions=dict(Counter(row['original_security']+'->'+row['security'] for row in rows if row['index'] == index)))
        for index in families}
    verified = dict(status='verified_exploratory_sensitivity', requests=len(rows), qualification_programs=len(families)*len(expected),
                    records=rows, effects=effects, summary=summary)
    destination = RESULTS / (prefix+'-verification')
    if destination.exists():
        verify_bundle(destination)
        assert read_json(destination / 'verification.json') == verified
    else:
        write_bundle(destination, {'verification.json': verified})
    print(dict(status='verified', summary=summary, effects=effects))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('freeze', 'verify'))
    parser.add_argument('--privacy', action='store_true')
    arguments = parser.parse_args()
    freeze(arguments.privacy) if arguments.action == 'freeze' else verify(arguments.privacy)
