import argparse
import importlib.util
import os
import signal
import socket
import subprocess
import sys
import time
from datetime import datetime, timezone
from importlib.metadata import version
from pathlib import Path

import requests

import prompt_mechanism_study.artifact_io as artifact_module
import prompt_mechanism_study.development.source_output_envelope as envelope_module
import prompt_mechanism_study.llm as transport_module
import prompt_mechanism_study.records as records_module
from prompt_mechanism_study.artifact_io import file_sha256, read_json, verify_bundle, write_bundle


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--runtime-name', required=True)
    parser.add_argument('--role', choices=('service-check', 'development', 'evaluation'), default='service-check')
    parser.add_argument('--prior-runtime', type=Path)
    parser.add_argument('--prior-inputs', type=Path)
    parser.add_argument('--preparation-name')
    parser.add_argument('--output-name')
    arguments = parser.parse_args()
    assert arguments.runtime_name.replace('-', '').isalnum()
    root = Path('/home/wsy/work/prompt-mechanism-study')
    inputs = root / 'inputs/graph-guided-20260929'
    results = root / 'results/graph-guided-20260929'
    for name in (arguments.preparation_name, arguments.output_name):
        assert name is None or name.replace('-', '').isalnum()
    preparation = inputs / (arguments.preparation_name or arguments.role + '-preparation')
    verify_bundle(preparation)
    protocol = read_json(preparation / 'protocol.json')
    generator = inputs / 'source_generation.py'
    worker = inputs / 'native_behavior.py'
    assert file_sha256(generator) == protocol['generation_implementation_sha256']
    assert file_sha256(worker) == protocol['native_worker_sha256']
    verify_bundle(inputs / 'model-identity')
    assert file_sha256(inputs / 'model-identity/manifest.json') == protocol['model_identity_manifest_sha256']
    with socket.socket() as probe:
        assert probe.connect_ex(('127.0.0.1', 18584)) != 0
    prior_seconds = 0
    prior_calls = 0
    assert bool(arguments.prior_runtime) == bool(arguments.prior_inputs)
    if arguments.prior_runtime:
        verify_bundle(arguments.prior_runtime / 'stopped')
        verify_bundle(arguments.prior_inputs)
        prior_protocol = read_json(arguments.prior_inputs / 'protocol.json')
        prior_stop = read_json(arguments.prior_runtime / 'stopped/runtime.json')
        prior_seconds = prior_stop['cumulative_service_seconds']
        prior_calls = prior_protocol['runtime_limits']['prior_generation_attempts']
        if (arguments.prior_runtime / 'ready').exists():
            prior_role = prior_protocol.get('experiment_role', 'service-check')
            prior_output = results / ('service-check' if prior_role == 'service-check' else prior_role + '-main')
            verify_bundle(prior_output / 'summary')
            dispatch = read_json(prior_output / 'summary/dispatch.json')
            prior_calls += dispatch['generation_attempts']
    expected_status = {'service-check': 'PREPARED_SERVICE_CHECK_NOT_RUNTIME_FROZEN',
        'development': 'F0_FROZEN_DEVELOPMENT_NOT_RUNTIME_FROZEN',
        'evaluation': 'F1_FROZEN_EVALUATION_NOT_RUNTIME_FROZEN'}[arguments.role]
    assert protocol['status'] == expected_status
    assert prior_calls + protocol['code_requests'] <= protocol['total_reserved_requests']
    service = results / arguments.runtime_name
    service.mkdir(parents=True, exist_ok=False)
    scratch = service / 'scratch'
    scratch.mkdir()
    rpc = root / 'results' / arguments.runtime_name
    assert len(str(rpc).encode()) + 37 <= 107
    rpc.mkdir(exist_ok=False)
    environment = dict(os.environ, CUDA_VISIBLE_DEVICES='0,1', HF_HUB_OFFLINE='1',
        TRANSFORMERS_OFFLINE='1', VLLM_DO_NOT_TRACK='1', TMPDIR=str(scratch), VLLM_RPC_BASE_PATH=str(rpc),
        VLLM_CACHE_ROOT=str(service / 'vllm-cache'), TRITON_CACHE_DIR=str(service / 'triton-cache'),
        TORCHINDUCTOR_CACHE_DIR=str(service / 'torch-cache'), CUDA_CACHE_PATH=str(service / 'cuda-cache'))
    command = [sys.executable, '-m', 'vllm.entrypoints.openai.api_server',
        '--model', '/home/ubuntu/RAID5/data/model_zoo/CodeLLMs/Qwen2.5-Coder-32B-Instruct',
        '--served-model-name', 'Qwen2.5-Coder-32B-Instruct', '--host', '127.0.0.1', '--port', '18584',
        '--tensor-parallel-size', '2', '--dtype', 'bfloat16', '--max-model-len', '32768',
        '--max-num-seqs', '1', '--gpu-memory-utilization', '0.60', '--enforce-eager',
        '--no-enable-prefix-caching', '--disable-custom-all-reduce']
    started = datetime.now(timezone.utc)
    protocol.update(status={'service-check': 'FROZEN_TSG_DISCOVERY_SERVICE_CHECK',
        'development': 'FROZEN_TSG_DISCOVERY_DEVELOPMENT',
        'evaluation': 'FROZEN_TSG_DISCOVERY_EVALUATION'}[arguments.role],
        experiment_role=arguments.role, preparation_status=expected_status,
        preparation_manifest_sha256=file_sha256(preparation / 'manifest.json'), runtime_command=command,
        runtime_implementations={name: dict(path=module.__file__, sha256=file_sha256(Path(module.__file__)))
            for name, module in [('artifact', artifact_module), ('code_envelope', envelope_module),
                                 ('transport', transport_module), ('records', records_module)]},
        runtime_versions={name: version(name) for name in ('vllm', 'torch', 'transformers',
                                                          'safetensors', 'markdown-it-py', 'requests')},
        runtime_environment={key: environment[key] for key in (
            'CUDA_VISIBLE_DEVICES', 'HF_HUB_OFFLINE', 'TRANSFORMERS_OFFLINE', 'VLLM_DO_NOT_TRACK',
            'TMPDIR', 'VLLM_RPC_BASE_PATH', 'VLLM_CACHE_ROOT', 'TRITON_CACHE_DIR', 'TORCHINDUCTOR_CACHE_DIR', 'CUDA_CACHE_PATH')},
        runtime_limits=dict(launch_record=protocol.pop('launch_record'),
            launch_record_sha256=protocol.pop('launch_record_sha256'),
            service_started_utc=started.isoformat(), prior_generation_attempts=prior_calls, prior_service_seconds=prior_seconds),
        batch_invariance='single sequence, eager execution, no prefix cache; no mathematical independence proof')
    frozen = inputs / (arguments.runtime_name + '-inputs')
    write_bundle(frozen, {'protocol.json': protocol, 'assignments.json': read_json(preparation / 'assignments.json')})
    spec = importlib.util.spec_from_file_location('discovery_generation', generator)
    assert spec is not None and spec.loader is not None
    generation = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(generation)
    print('SERVICE_INPUTS_FROZEN', flush=True)
    with (service / 'server.log').open('w', encoding='utf-8') as log:
        process = subprocess.Popen(command, cwd=root, env=environment, stdout=log,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        try:
            while True:
                if process.poll() is not None:
                    raise RuntimeError(f'模型服务启动失败：{process.returncode}')
                if (datetime.now(timezone.utc) - started).total_seconds() > 600:
                    raise TimeoutError('模型服务启动超过600秒')
                with socket.socket() as probe:
                    if probe.connect_ex(('127.0.0.1', 18584)) == 0:
                        break
                time.sleep(1)
            response = requests.get('http://127.0.0.1:18584/v1/models', timeout=10)
            response.raise_for_status()
            models = response.json()
            assert [row['id'] for row in models['data']] == ['Qwen2.5-Coder-32B-Instruct']
            write_bundle(service / 'ready', {'models.json': models,
                'runtime.json': dict(pid=process.pid, ready_utc=datetime.now(timezone.utc).isoformat(),
                    command=command, startup_seconds=(datetime.now(timezone.utc) - started).total_seconds())})
            print('MODEL_SERVICE_READY', flush=True)
            generation.run(frozen, results / (arguments.output_name or ('service-check' if arguments.role == 'service-check'
                                             else arguments.role + '-main')), worker)
        finally:
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGINT)
                process.wait(timeout=60)
            ended = datetime.now(timezone.utc)
            write_bundle(service / 'stopped', {'runtime.json': dict(started_utc=started.isoformat(),
                ended_utc=ended.isoformat(), service_seconds=(ended - started).total_seconds(),
                cumulative_service_seconds=prior_seconds + (ended - started).total_seconds(),
                exit_code=process.returncode, launcher_sha256=file_sha256(Path(__file__)),
                server_log_sha256=file_sha256(service / 'server.log'))})


if __name__ == '__main__':
    main()
