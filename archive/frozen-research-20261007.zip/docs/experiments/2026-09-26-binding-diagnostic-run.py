"""Thin runner for the frozen non-claim 27-call diagnostic. No code execution."""
import argparse
import hashlib
import json
import platform
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from prompt_mechanism_study.artifact_io import read_json, verify_bundle, write_bundle
from prompt_mechanism_study.development.representation_binding import representation_request, render_binding
from prompt_mechanism_study.llm import complete_chat

p=argparse.ArgumentParser()
p.add_argument("inputs",type=Path);p.add_argument("output",type=Path)
p.add_argument("--controls",type=Path)
a=p.parse_args()
manifest=verify_bundle(a.inputs)
protocol=read_json(a.inputs/"protocol.json")
if protocol.get('purpose') == 'author_bound_code_validation':
    from prompt_mechanism_study.development.representation_binding import run_author_generation_validation
    if a.controls is None: raise ValueError('qualified control results required')
    run_author_generation_validation(a.inputs, a.output, a.controls)
    sys.exit(0)
tasks={t["task_unit_id"]:t for t in read_json(a.inputs/"tasks.json")}
assignments=read_json(a.inputs/"assignments.json")
assert protocol["scientific_claim_allowed"] is False and len(assignments)==27
a.output.mkdir(parents=True,exist_ok=False)
write_bundle(a.output/"preoutcome",{"input_manifest.json":manifest,"assignments.json":assignments,
    "environment.json":{"python":sys.version,"platform":platform.platform(),"started_unix":time.time()}})

def run(item):
    name=f'{item["task_unit_id"][-12:]}-{item["method"]}'
    dest=a.output/name;dest.mkdir()
    task=tasks[item["task_unit_id"]]
    request=representation_request(task,item["method"])
    config={**protocol["config"],"seed":item["seed"]}
    result={**item,"started_unix":time.time()}
    def trace(kind,payload): (dest/f"{kind}.json").write_bytes(payload)
    try:
        raw=complete_chat(request,config,protocol["system_prompt"],trace=trace)
        (dest/"content.json").write_bytes(raw)
        try:
            parsed=json.loads(raw)
            target,status=render_binding(task,parsed)
        except (ValueError,TypeError):
            parsed=None;target=task["source_prompt"];status="INVALID_BINDING_FALLBACK"
        result.update(binding=parsed,render_status=status,target_prompt=target,
                      target_sha256=hashlib.sha256(target.encode()).hexdigest(),status="RETURNED")
    except Exception as error:
        # A response/transport failure is not a KEEP response and never an outcome zero.
        result.update(status="INFRASTRUCTURE_OR_ENVELOPE_MISSING",error=str(error))
    result["ended_unix"]=time.time()
    write_bundle(dest/"result",{"result.json":result})
    print(name,result["status"],result.get("render_status"),flush=True)
    return result

with ThreadPoolExecutor(max_workers=protocol["workers"]) as executor:
    results=list(executor.map(run,assignments))
comparisons=[]
for uid,task in tasks.items():
    by={r["method"]:r for r in results if r["task_unit_id"]==uid}
    comparable=all(by[m]["status"]=="RETURNED" for m in "FG")
    comparisons.append({"task_unit_id":uid,"cohort":task["cohort"],
       "fg_request_differs":by["F"].get("target_sha256")!=by["G"].get("target_sha256") if comparable else None})
usage={m:{"calls":0,"prompt_tokens":0,"completion_tokens":0} for m in "RFG"}
for row in results:
    path=a.output/f'{row["task_unit_id"][-12:]}-{row["method"]}'/"response.json"
    if path.exists():
        outer=read_json(path);u=outer.get("usage",{});bucket=usage[row["method"]]
        bucket["calls"]+=1
        for k in ("prompt_tokens","completion_tokens"):bucket[k]+=u.get(k,0)
summary={"scientific_claim_allowed":False,"returned":sum(r["status"]=="RETURNED" for r in results),
         "assigned":len(results),"comparisons":comparisons,"usage":usage,
         "main_generation_status":protocol["main_generation_status"],"ended_unix":time.time()}
write_bundle(a.output/"summary",{"summary.json":summary})
print(json.dumps(summary),flush=True)
