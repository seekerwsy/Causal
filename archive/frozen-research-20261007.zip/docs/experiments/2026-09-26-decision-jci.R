# Same frozen randomized matrix for JCI0/1/12; no graph-truth scores are inferred.
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args) == 2L, !file.exists(args[[2]]))
.libPaths(c(".codex-runtime/r-lib", .libPaths()))
dat <- read.csv(args[[1]], stringsAsFactors=FALSE)
labels <- c("C", "X", "Z", "Y")
keys <- unique(dat[c("scenario", "n_total", "seed")])
records <- list()
for (i in seq_len(nrow(keys))) {
  key <- keys[i, ]
  rows <- dat[dat$scenario == key$scenario & dat$n_total == key$n_total & dat$seed == key$seed, labels]
  stopifnot(nrow(rows) == key$n_total)
  for (mode in c("0", "1", "12")) {
    warns <- character()
    err <- ""
    amat <- tryCatch(withCallingHandlers(pcalg::fci(
      suffStat=list(dm=as.matrix(rows), nlev=rep(2L, 4L), adaptDF=FALSE),
      indepTest=pcalg::disCItest, alpha=.05, labels=labels,
      contextVars=1L, jci=mode, selectionBias=FALSE, NAdelete=FALSE,
      verbose=FALSE)@amat, warning=function(w) {
        warns <<- c(warns, conditionMessage(w)); invokeRestart("muffleWarning")
      }), error=function(e) { err <<- conditionMessage(e); NULL })
    records[[length(records)+1L]] <- data.frame(scenario=key$scenario, n_total=key$n_total,
      seed=key$seed, method=paste0("JCI", mode),
      adjacent=if (is.null(amat)) FALSE else (amat["C","Y"] != 0 || amat["Y","C"] != 0),
      matrix=if (is.null(amat)) "" else paste(as.vector(amat),collapse=";"),
      warnings=paste(unique(warns),collapse="|"), error=err)
  }
  if (i %% 150L == 0L) cat("searched",i,"/",nrow(keys),"matrices\n")
}
write.csv(do.call(rbind,records), args[[2]], row.names=FALSE)
cat("saved",length(records),"searches; pcalg",as.character(utils::packageVersion("pcalg")),"\n")
