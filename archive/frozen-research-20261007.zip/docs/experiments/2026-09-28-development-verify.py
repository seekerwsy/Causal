import hashlib
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path('data/method/graph-guided-20260928')
RESULTS = Path('results/graph-guided-20260928')
SECOND = len(sys.argv) == 2 and sys.argv[1] == 'second'
assert len(sys.argv) in (1, 2) and (len(sys.argv) == 1 or SECOND)
INPUTS = ROOT / ('development-execution-inputs-batch2' if SECOND else
                 'development-execution-inputs-v2')
OUTPUTS = RESULTS / ('development-second-seven-diagnostic' if SECOND else
                     'development-seven-task-diagnostic-v2')
INDICES = ((25, 36, 44, 107, 136, 156, 159) if SECOND else
           (35, 59, 103, 124, 135, 165, 174))


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def verify_manifest(directory):
    manifest = load(directory / 'manifest.json')
    for name, digest in manifest['files'].items():
        assert hashlib.sha256((directory / name).read_bytes()).hexdigest() == digest
    return hashlib.sha256((directory / 'manifest.json').read_bytes()).hexdigest()


def observation(result):
    if result['status'] != 'returned':
        return dict(secure_yield=0, security='unknown', functionality='unknown',
                    generation_status=result['status'])
    assert len(result['measurements']) == 1
    measurement = result['measurements'][0]['measurement']
    assert measurement['status'] == 'measured'
    channels = measurement['channels']
    security = (channels['security']['observation']['security_label']
                if channels['security']['status'] == 'passed' else 'unknown')
    functionality = (channels['functionality']['observation']['functionality']
                     if channels['functionality']['status'] == 'passed' else 'unknown')
    assert security in {'secure', 'insecure', 'unknown'}
    assert functionality in {'pass', 'fail', 'unknown'}
    return dict(secure_yield=int(security == 'secure'), security=security,
                functionality=functionality, generation_status='returned')


def main():
    input_hash = verify_manifest(INPUTS)
    protocol = load(INPUTS / 'protocol.json')
    assignments = load(INPUTS / 'assignments.json')
    assert protocol['status'] == 'FROZEN_GRAPH_GUIDED_DEVELOPMENT_DIAGNOSTIC'
    assert len(assignments) == protocol['code_requests'] == 182
    assert [row['slot'] for row in assignments] == [f'{index:04d}' for index in range(182)]
    assert Counter(row['index'] for row in assignments) == {index: 26 for index in INDICES}
    assert Counter(row['arm'] for row in assignments) == {'P': 84, 'N': 84, 'R': 14}
    cases = {}
    for index in sorted({row['index'] for row in assignments}):
        case_directory = ROOT / f'prepared/case-{index:04d}'
        verify_manifest(case_directory)
        cases[index] = load(case_directory / 'case.json')
    output_rows = load(OUTPUTS / 'summary/results.json')
    assert len(output_rows) == len(assignments)
    verify_manifest(OUTPUTS / 'summary')
    by_slot = {row['slot']: row for row in output_rows}
    assert len(by_slot) == len(assignments)
    records = []
    for assignment in assignments:
        slot = assignment['slot']
        case = cases[assignment['index']]
        assert assignment['task_unit_id'] == case['source']['task_unit_id']
        prompt = assignment['prompt']
        assert hashlib.sha256(prompt.encode()).hexdigest() == assignment['prompt_sha256']
        version = int(assignment['version'][1:]) - 1
        if assignment['arm'] == 'R':
            expected = '\n\n'.join((case['source']['prompt'], case['author_card']['interface'],
                                     case['author_card']['shared_realization_instructions'][version]))
        else:
            candidate = next(row for row in case['candidates']
                             if row['slot'] == assignment['candidate_slot'])
            expected = candidate['realizations'][version]['prompts'][assignment['arm']]
        assert prompt == expected
        directory = OUTPUTS / slot
        verify_manifest(directory / 'result')
        result = load(directory / 'result/result.json')
        assert result == by_slot[slot]
        for key in ('index', 'task_unit_id', 'candidate_slot', 'version', 'arm', 'seed',
                    'prompt_sha256'):
            assert result[key] == assignment[key]
        if result['status'] == 'returned':
            code = (directory / 'code.py').read_text(encoding='utf-8')
            assert hashlib.sha256(code.encode()).hexdigest() == result['code_sha256']
            request = load(directory / 'measurement-request.json')
            assert request['code'] == code
            assert request['entry_point'] == assignment['measurements'][0]['entry_point']
            assert request['tests'] == assignment['measurements'][0]['tests']
        records.append(dict(slot=slot, index=assignment['index'],
                            candidate_slot=assignment['candidate_slot'],
                            version=assignment['version'], arm=assignment['arm'],
                            **observation(result)))
    grouped = defaultdict(list)
    for row in records:
        grouped[row['index'], row['candidate_slot'], row['arm']].append(row)
    effects = []
    for index, case in cases.items():
        reference = grouped[index, None, 'R']
        assert len(reference) == 2
        reference_y = sum(row['secure_yield'] for row in reference) / 2
        for candidate in case['candidates']:
            slot = candidate['slot']
            treated, matched = grouped[index, slot, 'P'], grouped[index, slot, 'N']
            assert len(treated) == len(matched) == 2
            assert {row['version'] for row in treated} == {row['version'] for row in matched}
            p = sum(row['secure_yield'] for row in treated) / 2
            n = sum(row['secure_yield'] for row in matched) / 2
            effects.append(dict(index=index, slot=slot,
                                category=candidate['hypothesis']['category'],
                                operation=candidate['hypothesis']['operation'],
                                family=candidate['hypothesis']['family'],
                                P=p, N=n, R=reference_y, P_minus_N=p-n, P_minus_R=p-reference_y))
    assert len(effects) == 42
    destination = RESULTS / ('development-second-seven-independent-verification.json' if SECOND else
                             'development-seven-task-independent-verification.json')
    verified = dict(status='verified', input_manifest_sha256=input_hash,
                                           assignments=len(assignments),
                                           generation_statuses=dict(Counter(row['generation_status'] for row in records)),
                                           security_labels=dict(Counter(row['security'] for row in records)),
                                           functionality_labels=dict(Counter(row['functionality'] for row in records)),
                                           records=records, effects=effects)
    if destination.exists():
        assert load(destination) == verified
    else:
        destination.write_text(json.dumps(verified, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(dict(status='verified', assignments=len(assignments),
                          secure=sum(row['secure_yield'] for row in records), effects=len(effects),
                          output=str(destination))))


if __name__ == '__main__':
    main()
