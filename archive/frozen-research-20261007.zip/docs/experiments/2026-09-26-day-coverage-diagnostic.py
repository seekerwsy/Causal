"""Exploratory coverage-matched graph-gate diagnostic on frozen SCM decisions.

For each scenario and sample size, randomly thinning the direct stratum-RD
policy with probability q produces expected edit mass q*E[direct edit mass].
Set q to the observed graph gate edit mass divided by direct edit mass. The
result is a coverage-matched no-graph comparator; q is fitted post outcome
inspection, so this is descriptive, not a prospective policy evaluation.
"""
from __future__ import annotations

import csv
import json
import sys
from collections import defaultdict
from pathlib import Path


GRAPHS = ('FCI+strata-RD', 'GFCI+strata-RD', 'JCI12+strata-RD')
FIELDS = ('scenario', 'n_total', 'method', 'matrices', 'direct_edit_mass',
          'graph_edit_mass', 'thinning_probability', 'graph_gain',
          'matched_random_gain', 'selection_gain_at_matched_coverage',
          'graph_harmful_mass', 'matched_random_harmful_mass')


def main(repo: Path) -> None:
    source = repo / 'results/day-research-20260926/algorithm-new/decisions.json'
    target = repo / 'results/day-research-20260926/tables/coverage-matched.csv'
    decisions = json.loads(source.read_text(encoding='utf-8'))
    units = defaultdict(dict)
    for row in decisions:
        units[(row['scenario'], row['n_total'], row['seed'])][row['method']] = row
    assert len(units) == 1200 and all(len(methods) == 17 for methods in units.values())
    groups = defaultdict(list)
    for (scenario, n_total, _), methods in units.items():
        direct = methods['strata-RD']
        for name in GRAPHS:
            graph = methods[name]
            assert graph['action'] in (direct['action'], [0, 0, 0, 0])
            if graph['edit_mass']:
                assert graph['gain'] == direct['gain']
                assert graph['harmful_mass'] == direct['harmful_mass']
            groups[(scenario, n_total, name)].append((direct, graph))
    output = []
    for (scenario, n_total, name), pairs in sorted(groups.items()):
        assert len(pairs) == 50
        mean = lambda pos, key: sum(pair[pos][key] for pair in pairs) / len(pairs)
        direct_edit = mean(0, 'edit_mass')
        graph_edit = mean(1, 'edit_mass')
        q = graph_edit / direct_edit if direct_edit else 0.0
        assert 0 <= q <= 1 + 1e-12
        output.append(dict(scenario=scenario, n_total=n_total, method=name,
            matrices=len(pairs), direct_edit_mass=direct_edit,
            graph_edit_mass=graph_edit, thinning_probability=q,
            graph_gain=mean(1, 'gain'), matched_random_gain=q * mean(0, 'gain'),
            selection_gain_at_matched_coverage=mean(1, 'gain') - q * mean(0, 'gain'),
            graph_harmful_mass=mean(1, 'harmful_mass'),
            matched_random_harmful_mass=q * mean(0, 'harmful_mass')))
    assert len(output) == 72
    from io import StringIO
    stream = StringIO(newline='')
    writer = csv.DictWriter(stream, fieldnames=FIELDS, lineterminator='\n')
    writer.writeheader()
    writer.writerows(output)
    serialized = stream.getvalue()
    if target.exists():
        assert target.read_text(encoding='utf-8') == serialized, 'saved diagnostic changed'
    else:
        target.write_text(serialized, encoding='utf-8')
    print(json.dumps(dict(cells=len(output), source_units=len(units), output=str(target))))


if __name__ == '__main__':
    main(Path(sys.argv[1]).resolve())
