import argparse
import hashlib
import json
from pathlib import Path


ROOT = Path('data/method/graph-guided-20260928/measurement')
RESULTS = Path('results/graph-guided-20260928')
FAMILIES = {
    'xml_file_external_entity': ('', 'pass', 'secure'),
    'log_username': ('', 'pass', 'secure'),
    'ui_template': ('-v2', 'pass', 'secure'),
    'environment_template': ('', 'fail', 'unknown'),
    'filter_script_tags': ('', 'fail', 'unknown'),
    'local_redirect': ('', 'pass', 'secure'),
    'response_cookie': ('', 'pass', 'secure'),
    'json_payload': ('', 'pass', 'secure'),
    'static_download': ('', 'pass', 'secure'),
    'password_record': ('', 'pass', 'secure'),
    'greeting_html': ('', 'pass', 'secure'),
    'xml_string': ('', 'pass', 'unknown'),
    'image_upload_path': ('', 'pass', 'secure'),
    'conditional_log': ('', 'pass', 'secure'),
    'pdf_upload_path': ('', 'pass', 'secure'),
    'json_name_count': ('', 'pass', 'secure'),
    'login_session_cookie': ('', 'pass', 'secure'),
    'registration_hash': ('', 'pass', 'secure'),
    'secret_page_access': ('', 'pass', 'secure'),
    'database_login': ('', 'fail', 'secure'),
    'email_change_authorization': ('', 'pass', 'secure'),
    'token_login': ('', 'fail', 'secure'),
    'login_next_redirect': ('', 'pass', 'secure'),
}
HELDOUT_FAMILIES = {
    name: ('-heldout', 'fail' if name == 'decoded_email' else 'pass', 'secure')
    for name in ('signature_hash', 'subscription_access', 'forum_post_html', 'profile_html',
                 'arithmetic_query', 'blog_html', 'custom_header', 'password_algorithm',
                 'decoded_email', 'shell_arguments', 'command_allowlist', 'cdn_resource_url',
                 'profile_access', 'header_buffer', 'request_json_dict')
}
REMAINING_FAMILIES = {name: ('-remaining', 'pass', 'secure') for name in
                      ('patient_template', 'student_template', 'directory_template', 'receipt_template',
                       'performance_template', 'project_authorization', 'compile_only', 'sqlite_insert',
                       'variable_expression', 'limited_script', 'client_rate_limit')}
PERFORMANCE_FAMILIES = {name: ('-performance', 'fail' if name == 'password_regex_cost' else 'pass', 'secure')
                       for name in ('email_regex_cost', 'password_regex_cost', 'url_regex_cost', 'log_regex_cost')}


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def verify_family(name, suffix, vulnerable_function, overrestrict_security):
    inputs = ROOT / f'{name}-qualification-inputs{suffix}'
    outputs = RESULTS / f'{name}-qualification{suffix}'
    manifest = load(inputs / 'manifest.json')
    assert set(manifest['files']) == {f'{control}.json' for control in
                                     ('secure', 'vulnerable', 'reject_all', 'overrestrictive')}
    for filename, expected_hash in manifest['files'].items():
        assert hashlib.sha256((inputs / filename).read_bytes()).hexdigest() == expected_hash
    expected = {
        'secure': ('secure', 'pass'),
        'vulnerable': ('insecure', vulnerable_function),
        'reject_all': ('unknown', 'fail'),
        'overrestrictive': (overrestrict_security, 'fail'),
    }
    observed = {}
    for control, labels in expected.items():
        result = load(outputs / f'{control}.json')
        assert result['status'] == 'measured'
        assert result['channels']['security']['status'] == 'passed'
        assert result['channels']['functionality']['status'] == 'passed'
        security = result['channels']['security']['observation']['security_label']
        functionality = result['channels']['functionality']['observation']['functionality']
        assert (security, functionality) == labels, (name, control, security, functionality)
        observed[control] = dict(security=security, functionality=functionality,
                                 output_sha256=hashlib.sha256((outputs / f'{control}.json').read_bytes()).hexdigest())
    return dict(input_manifest_sha256=hashlib.sha256((inputs / 'manifest.json').read_bytes()).hexdigest(),
                controls=observed)


def main(heldout, remaining, performance, stream=False, download=False):
    assert int(heldout)+int(remaining)+int(performance)+int(stream)+int(download) <= 1
    selected = {'http_part_budget': ('-download', 'pass', 'secure')} if download else {'stream_total_budget': ('-stream', 'pass', 'secure')} if stream else PERFORMANCE_FAMILIES if performance else REMAINING_FAMILIES if remaining else HELDOUT_FAMILIES if heldout else FAMILIES
    families = {name: verify_family(name, *settings) for name, settings in selected.items()}
    output = RESULTS / ('download-measurement-qualification-independent-verification.json' if download else
                        'stream-measurement-qualification-independent-verification.json' if stream else
                        'performance-measurement-qualification-independent-verification.json' if performance else
                        'remaining-measurement-qualification-independent-verification.json' if remaining else
                        'heldout-measurement-qualification-independent-verification.json'
                        if heldout else 'measurement-qualification-independent-verification-v3.json')
    assert not output.exists()
    output.write_text(json.dumps(dict(status='verified', families=families,
                                      control_programs=sum(len(x['controls']) for x in families.values())),
                                 indent=2), encoding='utf-8')
    print(json.dumps(dict(status='verified', families=len(families), control_programs=sum(len(x['controls']) for x in families.values()),
                          output=str(output))))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--heldout', action='store_true')
    parser.add_argument('--remaining', action='store_true')
    parser.add_argument('--performance', action='store_true')
    parser.add_argument('--stream', action='store_true')
    parser.add_argument('--download', action='store_true')
    options = parser.parse_args()
    main(options.heldout, options.remaining, options.performance, options.stream, options.download)
