# Frozen day-study JCI12 search on the same new matrices as FCI and GFCI.
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args) == 2L, !file.exists(args[[2]]))
.libPaths(c(".codex-runtime/r-lib", .libPaths()))
dat <- read.csv(args[[1]], stringsAsFactors=FALSE)
labels <- c("C", "X", "Z", "Y")
keys <- unique(dat[c("scenario", "n_total", "seed")])
stopifnot(nrow(keys) == 1200L)
records <- vector("list", nrow(keys))
for (i in seq_len(nrow(keys))) {
  key <- keys[i, ]
  rows <- dat[dat$scenario == key$scenario & dat$n_total == key$n_total & dat$seed == key$seed, labels]
  stopifnot(nrow(rows) == key$n_total)
  warns <- character()
  err <- ""
  amat <- tryCatch(withCallingHandlers(pcalg::fci(
    suffStat=list(dm=as.matrix(rows), nlev=rep(2L, 4L), adaptDF=FALSE),
    indepTest=pcalg::disCItest, alpha=.05, labels=labels,
    contextVars=1L, jci="12", selectionBias=FALSE, NAdelete=FALSE,
    verbose=FALSE)@amat, warning=function(w) {
      warns <<- c(warns, conditionMessage(w)); invokeRestart("muffleWarning")
    }), error=function(e) { err <<- conditionMessage(e); NULL })
  records[[i]] <- data.frame(scenario=key$scenario, n_total=key$n_total,
    seed=key$seed, method="JCI12",
    adjacent=if (is.null(amat)) FALSE else (amat["C","Y"] != 0 || amat["Y","C"] != 0),
    matrix=if (is.null(amat)) "" else paste(as.vector(amat),collapse=";"),
    warnings=paste(unique(warns),collapse="|"), error=err)
  if (i %% 100L == 0L) cat("JCI12 matrices",i,"/",nrow(keys),"\n")
}
write.csv(do.call(rbind, records), args[[2]], row.names=FALSE)
cat("saved",length(records),"JCI12 searches\n")
