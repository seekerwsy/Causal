"""Traceable tables from frozen day-study inputs and raw assigned outcomes."""
import csv
import io
import json
import math
import statistics
import sys
from collections import defaultdict
from pathlib import Path

repo=Path(sys.argv[1]).resolve()
root=repo/'results/day-research-20260926'
panel=repo/'data/method/day-research-20260926/frozen/code-panel'
out=root/'tables'
out.mkdir(parents=True,exist_ok=True)
load=lambda path: json.loads(path.read_text(encoding='utf-8'))


def save(name,rows):
    assert rows
    stream=io.StringIO(newline='')
    with stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)
        encoded=stream.getvalue().encode('utf-8')
    target=out/name
    if target.exists():
        assert target.read_bytes()==encoded, f'saved table differs from raw replay: {name}'
    else:
        target.write_bytes(encoded)


alg=load(root/'algorithm-new/decisions.json')
groups=defaultdict(list)
by_seed={}
for item in alg:
    groups[(item['scenario'],item['n_total'],item['method'])].append(item)
    by_seed[(item['scenario'],item['n_total'],item['seed'],item['method'])]=item
rows=[]
for (scenario,n,method),reps in sorted(groups.items()):
    assert len(reps)==50
    values=[x['gain'] for x in reps]
    mean=statistics.mean(values)
    se=statistics.stdev(values)/math.sqrt(50)
    rows.append(dict(scenario=scenario,n_total=n,method=method,repetitions=50,
                     gain=mean,gain_mcse=se,gain_ci95_low=mean-1.96*se,
                     gain_ci95_high=mean+1.96*se,
                     edit_mass=statistics.mean(x['edit_mass'] for x in reps),
                     harmful_mass=statistics.mean(x['harmful_mass'] for x in reps),
                     regret=statistics.mean(x['regret'] for x in reps)))
save('algorithm.csv',rows)
comparisons=[]
for scenario in sorted({x['scenario'] for x in alg}):
    for n in (64,256,1024):
        for first,second in [('strata-LB-1.64','FCI+strata-RD'),
                             ('strata-LB-1.64','GFCI+strata-RD'),
                             ('strata-LB-1.64','JCI12+strata-RD'),
                             ('strata-RD','pooled-RD'),('honest-depth1','strata-RD')]:
            differences=[by_seed[(scenario,n,seed,first)]['gain']-
                         by_seed[(scenario,n,seed,second)]['gain'] for seed in range(9001,9051)]
            mean=statistics.mean(differences)
            se=statistics.stdev(differences)/math.sqrt(50)
            comparisons.append(dict(scenario=scenario,n_total=n,first=first,second=second,
                                    paired_gain_difference=mean,paired_mcse=se,
                                    ci95_low=mean-1.96*se,ci95_high=mean+1.96*se))
save('algorithm-paired.csv',comparisons)

tasks={task['id']:task for task in load(panel/'tasks.json')}
assigned=load(panel/'assignments.json')
result={row['slot']:row for row in load(root/'code-panel/summary/results.json')}
by_task_arm=defaultdict(list)
for slot in assigned:
    row=result[slot['slot']]
    task=tasks[slot['task_unit_id']]
    measured=row['measurement']
    if 'file_lifecycle' in task['measurement']:
        label=measured['security_label']; functionality=measured['functionality']
    else:
        label=measured['task_bound_witness_label']; functionality=measured['functionality_witness']
    by_task_arm[(slot['task_unit_id'],slot['arm'])].append(dict(label=label,
        valid=measured['code_valid'],functionality=functionality,
        yield_secure=int(measured['code_valid'] and label=='secure'),
        joint=int(measured['code_valid'] and label=='secure' and functionality=='pass')))
panel_rows=[]
for (task_id,arm),reps in sorted(by_task_arm.items()):
    task=tasks[task_id]
    assert len(reps)==2
    panel_rows.append(dict(task_unit_id=task_id,task_name=task['name'],source_kind=task['origin'],
                           family=task['family'],split=task['split'],arm=arm,assigned=2,
                           secure_yield=sum(r['yield_secure'] for r in reps)/2,
                           joint_success=sum(r['joint'] for r in reps)/2,
                           valid_count=sum(r['valid'] for r in reps),
                           secure_count=sum(r['label']=='secure' for r in reps),
                           insecure_count=sum(r['label']=='insecure' for r in reps),
                           unknown_count=sum(r['label']=='unknown' for r in reps),
                           functional_pass_count=sum(r['functionality']=='pass' for r in reps)))
save('code-panel.csv',panel_rows)

source_groups={
    'natural_adapted': lambda row: row['source_kind']=='exposed_natural_adapted',
    'synthetic_command': lambda row: row['source_kind']!='exposed_natural_adapted' and row['family']=='command_boundary',
    'synthetic_file': lambda row: row['family']=='file_lifecycle',
}
source_rows=[]
for name,predicate in source_groups.items():
    subset=[row for row in panel_rows if predicate(row)]
    task_ids={row['task_unit_id'] for row in subset}
    assert len(subset)==len(task_ids)*6
    arm_mean={arm:statistics.mean(row['secure_yield'] for row in subset if row['arm']==arm)
              for arm in ('R','N','S','G','P','H')}
    source_rows.append(dict(source_group=name,task_units=len(task_ids),
                            **{f'{arm}_yield':arm_mean[arm] for arm in ('R','N','S','G','P','H')},
                            P_minus_N=arm_mean['P']-arm_mean['N'],
                            H_minus_P=arm_mean['H']-arm_mean['P']))
save('code-by-source.csv',source_rows)

jci=load(root/'jci-query/decisions.json')
jgroups=defaultdict(list)
for item in jci: jgroups[(item['mechanism'],item['n_total'],item['method'])].append(item)
jrows=[]
for (mechanism,n,method),reps in sorted(jgroups.items()):
    jrows.append(dict(mechanism=mechanism,n_total=n,method=method,repetitions=len(reps),
                      direct_pool_count=sum(r['baseline']=='POOL_B' for r in reps),
                      jci_pool_count=sum(r['jci_consumer']=='POOL_B' for r in reps),
                      changed_count=sum(r['action_changed'] for r in reps),
                      cy_adjacent_count=sum(r['cy_adjacent'] is True for r in reps),
                      graph_unusable_count=sum(r['graph_unusable'] for r in reps)))
save('jci-query.csv',jrows)

tsg=load(root/'tsg-ablation/decisions.json')
save('tsg-ablation.csv',[dict(task_unit_id=r['task_unit_id'],split=r['split'],
    information=r['information'],action=r['action'],support=r['support'],
    observed_yield=r['observed_yield'],reason=r['reason']) for r in tsg])

print(json.dumps(dict(algorithm_rows=len(rows),paired_rows=len(comparisons),
                      panel_rows=len(panel_rows),jci_rows=len(jrows),tsg_rows=len(tsg))))
