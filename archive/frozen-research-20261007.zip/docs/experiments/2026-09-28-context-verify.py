import argparse
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path


root = Path('.').resolve()
parser = argparse.ArgumentParser()
parser.add_argument('--inputs', type=Path, default=Path('data/method/graph-guided-20260928/algorithm-inputs'))
parser.add_argument('--output', type=Path, default=Path('results/graph-guided-20260928/algorithm-main'))
arguments = parser.parse_args()
inputs = arguments.inputs.resolve()
output = arguments.output.resolve()
manifest = json.loads((inputs / 'manifest.json').read_text(encoding='utf-8'))
for name, digest in manifest['files'].items():
    assert hashlib.sha256((inputs / name).read_bytes()).hexdigest() == digest
matrices = json.loads((inputs / 'matrices.json').read_text(encoding='utf-8'))
source = {row['identity']: row for row in matrices}
records = [json.loads(line) for line in (output / 'searches.jsonl').read_text(encoding='utf-8').splitlines()]
assert len(source) == 320 and len(records) == 1280
identities = [(r['identity'], r['method']) for r in records]
assert len(set(identities)) == 1280
assert set(identities) == {(k, method) for k in source
                          for method in ('FCI_JCI0', 'FCI_JCI1', 'FCI_JCI12', 'GFCI')}
groups = defaultdict(list)
for record in records:
    matrix = source[record['identity']]
    assert matrix['n'] == len(matrix['rows']) == record['n']
    assert all(len(row) == 4 and set(row) <= {0, 1} for row in matrix['rows'])
    scenario = matrix['scenario']
    target = {frozenset(('X', 'Y')), frozenset(('Z', 'Y')),
              frozenset(('C', 'X' if scenario.startswith('soft') else 'Y'))}
    predicted = {frozenset((e[0], e[3])) for e in record['edges']}
    score = record['score']
    assert score['tp'] == len(target.intersection(predicted))
    assert score['fp'] == len(predicted.difference(target))
    assert score['fn'] == len(target.difference(predicted))
    expected_xy = ['ARROW' if scenario.endswith('latent') else 'TAIL', 'ARROW']
    xy = None
    for a, left, right, b in record['edges']:
        assert a in matrix['labels'] and b in matrix['labels'] and a != b
        assert left in {'CIRCLE', 'ARROW', 'TAIL'} and right in {'CIRCLE', 'ARROW', 'TAIL'}
        if a == 'X' and b == 'Y':
            xy = [left, right]
        elif a == 'Y' and b == 'X':
            xy = [right, left]
    assert score['xy_endpoints'] == xy
    assert score['exact_xy_endpoints'] == (xy == expected_xy)
    groups[scenario, record['n'], record['method']].append(record)
summary = []
for (scenario, n, method), rows in sorted(groups.items()):
    assert len(rows) == 20
    summary.append(dict(scenario=scenario, n=n, method=method, repetitions=len(rows),
                        complete_skeleton=sum(r['score']['fn'] == r['score']['fp'] == 0 for r in rows),
                        exact_xy=sum(r['score']['exact_xy_endpoints'] for r in rows),
                        xy_states=dict(Counter(str(r['score']['xy_endpoints']) for r in rows)),
                        ci_warning_runs=sum(bool(r.get('warnings')) for r in rows),
                        fixed_endpoint_error_runs=sum(r['score']['wrong_fixed_endpoints'] > 0 for r in rows)))
destination = output / 'independent-verification.json'
verified = dict(status='VERIFIED_COUNTS_AND_XY_ENDPOINTS', matrices=320, searches=1280, summary=summary)
if destination.exists():
    assert json.loads(destination.read_text(encoding='utf-8')) == verified
else:
    destination.write_text(json.dumps(verified, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'verified_searches': len(records), 'groups': len(summary)}))
for row in summary:
    if row['n'] == 1000:
        print(json.dumps(row))
