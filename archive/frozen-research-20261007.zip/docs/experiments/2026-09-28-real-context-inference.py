import json
from collections import defaultdict
from pathlib import Path

import numpy as np

from prompt_mechanism_study.artifact_io import read_json, verify_bundle, write_bundle


MATRICES = Path('data/method/graph-guided-20260928/real-context-matrices')
SEARCHES = Path('results/graph-guided-20260928/real-context-search-common-gap/bundle')
OUTPUT = Path('results/graph-guided-20260928/real-context-modifier-inference')


def effect(rows):
    cells = {}
    for c in (0, 1):
        for x in (0, 1):
            selected = [row for row in rows if row['C'] == c and row['X'] == x]
            if len({row['task_unit_id'] for row in selected}) < 2:
                return None
            cells[(c, x)] = sum(row['Y'] for row in selected)/len(selected)
    return (cells[(1, 1)]-cells[(0, 1)])-(cells[(1, 0)]-cells[(0, 0)])


def main():
    verify_bundle(MATRICES)
    verify_bundle(SEARCHES)
    matrices = read_json(MATRICES / 'matrices.json')
    summary = read_json(SEARCHES / 'summary.json')
    assert len(matrices) == 2 and len(summary) == 8
    by_category = {matrix['identity']: {row['task_unit_id']: row
                   for row in matrix['records']} for matrix in matrices}
    primary = matrices[0]['records']
    strata = defaultdict(list)
    for row in primary:
        strata[row['source_lineage_id']].append(row['task_unit_id'])
    rng = np.random.default_rng(20260930)
    draws = defaultdict(list)
    for _ in range(2000):
        sample = []
        for lineage in sorted(strata):
            source = sorted(strata[lineage])
            sample.extend(rng.choice(source, size=len(source), replace=True).tolist())
        for category, keyed in by_category.items():
            draws[category].append(effect([keyed[identity] for identity in sample
                                           if identity in keyed]))
    interactions = []
    for matrix in matrices:
        category = matrix['identity']
        values = [value for value in draws[category] if value is not None]
        point = effect(matrix['records'])
        assert point is not None
        interactions.append(dict(category=category, task_units=matrix['n'],
                                 point=point, valid_draws=len(values),
                                 interval_97_5=(np.quantile(values, [.0125, .9875]).tolist()
                                                if len(values) >= 1600 else None),
                                 status=('EXPLORATORY_INTERVAL' if len(values) >= 1600
                                         else 'INSUFFICIENT_JOINT_CELL_SUPPORT')))
    assert {row['action'] for row in summary} <= {'forbid_P', 'retain_common_selector'}
    write_bundle(OUTPUT, {'interactions.json': interactions,
                          'action_analysis.json': dict(status='BLOCKED_SELECTOR_NOT_FROZEN',
                            rule='Use actual frozen P-minus-R policy decisions; category nomination scores do not determine policy actions.'),
                          'protocol.json': dict(status='EXECUTED_EXPLORATORY',
                                                bootstrap_seed=20260930,
                                                draws=2000,
                                                interval='two_sided_97.5_percent_Bonferroni_for_two_categories')})
    print(json.dumps(dict(interactions=interactions, action_status='BLOCKED_SELECTOR_NOT_FROZEN')))


if __name__ == '__main__':
    main()
