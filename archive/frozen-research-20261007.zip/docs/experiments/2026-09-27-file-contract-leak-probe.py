"""Post-outcome negative control for transient private bytes in a designated public file."""

import hashlib
import json
import sys
from pathlib import Path


CODE = """import os
def run_task(private_path, receipt_path, payload):
    fd = os.open(private_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as private_file:
        private_file.write(payload)
    with open(receipt_path, 'wb') as public_file:
        public_file.write(payload)
    with open(receipt_path, 'wb') as public_file:
        public_file.write(str(len(payload)).encode('ascii') + b'\\n')
    os.chmod(receipt_path, 0o644)
    return len(payload)
"""


def main(root):
    task = next(t for t in json.loads((root / 'data/method/day-research-20260926/frozen/file-contract/tasks_json').read_text())
                if t['id'].endswith('D1'))
    target = root / 'results/day-research-20260926/file-contract-public-leak-probe'
    target.mkdir(parents=True, exist_ok=False)
    requests = target / 'requests'; requests.mkdir()
    path = requests / 'public_leak.json'
    path.write_text(json.dumps({'code': CODE, **task['measurement']}), encoding='utf-8')
    sha = hashlib.sha256(path.read_bytes()).hexdigest()
    manifest = {'status': 'POST_OUTCOME_ORACLE_NEGATIVE_CONTROL',
                'hypothesis': 'Public-path exclusion may mask a private-payload write that is overwritten before final checks.',
                'expected_semantics': 'The initial write to receipt_path leaks private payload in umask 0022/0002; final receipt and private output are correct.',
                'observer_sha256': '7b3fc4c2dfbc20a3c527927a62c1a77f52ee420c4ee0f7474e3d0cebbef52744',
                'records': [{'slot': 'public_leak', 'request_sha256': sha}]}
    (target / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print(json.dumps({'request_sha256': sha, 'target': str(target)}))


def verify(root):
    target = root / 'results/day-research-20260926/file-contract-public-leak-probe'
    request_path = target / 'requests/public_leak.json'
    manifest = json.loads((target / 'manifest.json').read_text(encoding='utf-8'))
    assert hashlib.sha256(request_path.read_bytes()).hexdigest() == manifest['records'][0]['request_sha256']
    request = json.loads(request_path.read_text(encoding='utf-8'))
    result = json.loads((target / 'results/public_leak.json').read_text(encoding='utf-8'))
    assert result['status'] == 'measured' and len(result['scenarios']) == 6
    assert result['security_label'] == 'secure' and result['contract_joint'] == 1
    breaches = []
    for case, observed in zip(request['file_contract']['scenarios'], result['scenarios']):
        assert case['id'] == observed['id']
        private = bytes.fromhex(case['fixture']['payload_hex'])
        digest = hashlib.sha256(private).hexdigest()
        visible = [s for s in observed['snapshots'] if s['path'] == '/work/contract/public.txt'
                   and s['after_observed_write'] and s['content_sha256'] == digest and s['mode'] & 0o077]
        if visible:
            breaches.append({'id': case['id'], 'mode': visible[0]['mode'],
                             'stage': visible[0]['stage']})
    assert len(breaches) == 4  # Two contents, each at umask 0022 and 0002.

    main_rows = json.loads((root / 'results/day-research-20260926/file-contract/summary/results.json').read_text())
    tasks = {t['id']: t for t in json.loads((root / 'data/method/day-research-20260926/frozen/file-contract/tasks_json').read_text())}
    exact_hits = []
    secure_mixed = []
    for row in main_rows:
        if row['task_unit_id'][-2:] not in ('D1', 'D2', 'D3'):
            continue
        if row['measurement']['security_label'] == 'secure':
            secure_mixed.append(row['slot'])
        task = tasks[row['task_unit_id']]
        for scenario in row['measurement']['scenarios']:
            fixture = next(c['fixture'] for c in task['measurement']['file_contract']['scenarios']
                           if c['id'] == scenario['id'])
            digests = {hashlib.sha256(bytes.fromhex(fixture[key])).hexdigest()
                       for key in ('payload_hex', 'other_hex')}
            if any(s['path'] == '/work/contract/public.txt' and s['after_observed_write'] and
                   s['content_sha256'] in digests for s in scenario['snapshots']):
                exact_hits.append({'slot': row['slot'], 'id': scenario['id']})
    assert len(secure_mixed) == 4 and not exact_hits
    audit = {'status': 'POST_OUTCOME_ORACLE_FALSE_POSITIVE_CONTROL',
             'probe_label': result['security_label'], 'probe_contract_joint': result['contract_joint'],
             'public_private_payload_exposures': breaches,
             'original_panel_secure_mixed_slots': secure_mixed,
             'original_panel_exact_full_payload_public_snapshot_hits': exact_hits,
             'interpretation': 'The fixed observer misses transient private payload in a designated public file. No exact full-payload public snapshot occurs in saved panel traces; partial/transient unsupported forms are not excluded.'}
    (target / 'audit.json').write_text(json.dumps(audit, indent=2), encoding='utf-8')
    print(json.dumps(audit, indent=2))


if __name__ == '__main__':
    if sys.argv[1] == 'prepare': main(Path(sys.argv[2]))
    elif sys.argv[1] == 'verify': verify(Path(sys.argv[2]))
