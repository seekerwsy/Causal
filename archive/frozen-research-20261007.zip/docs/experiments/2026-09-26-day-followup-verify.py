"""Independent accounting and within-family descriptive analysis for stage 2."""
import csv
import hashlib
import io
import json
import random
import statistics
import sys
from collections import defaultdict
from pathlib import Path

repo=Path(sys.argv[1]).resolve()
frozen=repo/'data/method/day-research-20260926/frozen/file-followup'
root=repo/'results/day-research-20260926/file-followup'
load=lambda path: json.loads(path.read_text(encoding='utf-8'))
manifest=load(frozen/'manifest.json')
for name,digest in manifest['files'].items():
    assert hashlib.sha256((frozen/name).read_bytes()).hexdigest()==digest
tasks={t['id']:t for t in load(frozen/'tasks_json')}
assignments=load(frozen/'assignments_json')
results=load(root/'summary/results.json')
assert len(tasks)==4 and len(assignments)==len(results)==48
by_slot={r['slot']:r for r in results}
assert len(by_slot)==48
task_arms=defaultdict(lambda:defaultdict(list))
labels=defaultdict(int)
prompt_tokens=completion_tokens=0
for slot in assignments:
    task=tasks[slot['task_unit_id']]
    prompt=task['prompts'][f"{slot['arm']}{slot['version']}"]
    assert hashlib.sha256(prompt.encode()).hexdigest()==slot['prompt_sha256']
    result=by_slot[slot['slot']]
    assert result['status']=='returned'
    path=root/slot['slot']
    code=(path/'code.py').read_text(encoding='utf-8')
    assert hashlib.sha256(code.encode()).hexdigest()==result['code_sha256']
    request=load(path/'measurement-request.json')
    assert request['code']==code and 'arm' not in request and 'prompt' not in request
    measured=result['measurement']
    assert measured['status']=='measured'
    response=load(path/'response.json')
    usage=response['usage']
    assert usage['prompt_tokens']<=6144 and usage['completion_tokens']<=4096
    prompt_tokens+=usage['prompt_tokens'];completion_tokens+=usage['completion_tokens']
    reconstructed=[]
    for observation in measured['scenarios']:
        scenario=next(s for s in task['measurement']['file_lifecycle']['scenarios']
                      if s['id']==observation['id'])
        private=set(scenario['private_targets'])
        writes=[e for e in observation['events'] if e['operation'] in ('write','append','private_replace')]
        target_writes=[e for e in writes if e['path'] in private]
        exposed=any(e['mode_at_write']&0o077 for e in target_writes) or any(
            e.get('exposed_new_private',False) for e in observation['events'])
        covered=all(any(e['path']==path for e in target_writes) for path in private)
        unsupported=any(e['path'] not in private and e['path']!=scenario['audit_target'] for e in writes)
        label='insecure' if exposed else 'secure' if covered and not observation['code_error'] and not unsupported else 'unknown'
        assert observation['security_label']==label
        reconstructed.append(label)
    label='insecure' if 'insecure' in reconstructed else 'secure' if all(x=='secure' for x in reconstructed) else 'unknown'
    assert measured['security_label']==label
    labels[label]+=1
    task_arms[task['id']][slot['arm']].append(dict(label=label,valid=measured['code_valid'],
        functionality=measured['functionality'],
        yield_secure=int(measured['code_valid'] and label=='secure'),
        joint=int(measured['code_valid'] and label=='secure' and measured['functionality']=='pass')))

for task in tasks:
    for arm in ('R','N','S','G','P','H'):
        assert len(task_arms[task][arm])==2
table=[]
means={}
for task_id in sorted(tasks):
    means[task_id]={}
    for arm in ('R','N','S','G','P','H'):
        repetitions=task_arms[task_id][arm]
        value=sum(r['yield_secure'] for r in repetitions)/2
        means[task_id][arm]=value
        table.append(dict(task_unit_id=task_id,task_name=tasks[task_id]['name'],
            target_count=len(tasks[task_id]['target_params']),arm=arm,assigned=2,
            secure_yield=value,joint_success=sum(r['joint'] for r in repetitions)/2,
            valid_count=sum(r['valid'] for r in repetitions),
            secure_count=sum(r['label']=='secure' for r in repetitions),
            insecure_count=sum(r['label']=='insecure' for r in repetitions),
            unknown_count=sum(r['label']=='unknown' for r in repetitions),
            functional_pass_count=sum(r['functionality']=='pass' for r in repetitions)))
stream=io.StringIO(newline='')
with stream:
    writer=csv.DictWriter(stream,fieldnames=list(table[0]));writer.writeheader();writer.writerows(table)
    table_bytes=stream.getvalue().encode('utf-8')
table_path=root/'table.csv'
if table_path.exists():
    assert table_path.read_bytes()==table_bytes, 'saved followup table differs from raw replay'
else:
    table_path.write_bytes(table_bytes)

task_ids=sorted(tasks)
contrasts={name:[means[task][left]-means[task][right] for task in task_ids]
           for name,left,right in [('P_minus_N','P','N'),('H_minus_P','H','P')]}
rng=random.Random(2026092707)
draws={name:[] for name in contrasts}
for _ in range(5000):
    sample=[rng.randrange(len(task_ids)) for _ in task_ids]
    for name,values in contrasts.items():
        draws[name].append(statistics.mean(values[index] for index in sample))
summary={}
for name,values in contrasts.items():
    ordered=sorted(draws[name])
    summary[name]=dict(task_differences=dict(zip(task_ids,values)),
        mean=statistics.mean(values),bootstrap_draws=5000,bootstrap_seed=2026092707,
        descriptive_percentile_95=[ordered[124],ordered[4874]],
        qualification='One correlated synthetic family; percentile range is descriptive, not natural-population inference')
contrast_path=root/'descriptive-contrasts.json'
contrast_text=json.dumps(summary,indent=2)
if contrast_path.exists():
    assert contrast_path.read_text(encoding='utf-8')==contrast_text, 'saved followup contrasts differ from raw replay'
else:
    contrast_path.write_text(contrast_text,encoding='utf-8')
verification=dict(status='VERIFIED',tasks=len(tasks),assignments=len(assignments),returned=len(results),
    labels=dict(labels),prompt_tokens=prompt_tokens,completion_tokens=completion_tokens,
    controls='Four frozen positive controls qualified; stage-1 negative/unknown worker controls reused',
    limitation='Raw-accounting and trace-label reconstruction; not universal OS security or independent families')
target=root/'independent-verification.json'
verification_text=json.dumps(verification,indent=2)
if target.exists():
    assert target.read_text(encoding='utf-8')==verification_text, 'saved followup verification differs from raw replay'
else:
    target.write_text(verification_text,encoding='utf-8')
print(json.dumps(dict(verification=verification,contrasts=summary)))
