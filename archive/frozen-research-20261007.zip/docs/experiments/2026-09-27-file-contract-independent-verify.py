"""Independent fixed-panel audit from frozen assignments and saved raw observations.

This checks finite recorded evidence and arithmetic, not universal Oracle accuracy.
It deliberately imports neither the generator nor the measurement implementation.
"""

import hashlib
import itertools
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np


ARMS = ('R', 'N', 'S', 'G', 'P', 'H')
ENDPOINTS = ('secure_yield', 'security_coverage', 'security_unknown',
             'ambient_violation', 'ambient_unknown', 'core_pass',
             'non_target_pass', 'basic_joint', 'contract_joint')


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def aggregate(labels):
    return ('invalid' if 'invalid' in labels else
            'insecure' if 'insecure' in labels else
            'secure' if all(x == 'secure' for x in labels) else 'unknown')


def triage(values):
    return 'fail' if 'fail' in values else 'pass' if all(x == 'pass' for x in values) else 'unknown'


def verify_scenario(s, expected_id, expected_umask, task):
    require((s['id'], s['initial_umask']) == (expected_id, expected_umask), 'scenario identity')
    require(s['ambient_violation'] == (s['initial_umask'] != s['final_umask']), 'ambient trace')
    public = {'/work/contract/public.txt'} if task['block'] == 'mixed' else set()
    target = {e['inode'] for e in s['events'] if e['operation'] == 'write' and
              e.get('units_written') and e.get('regular') and
              e['path'].startswith('/work/contract/') and e['path'] not in public}
    require(target == set(s['target_inodes']), 'private instance binding')
    written_paths = {x['path'] for x in s['snapshots'] if x['inode'] in target}
    minimum = 2 if task['id'][-2:] in ('A3', 'B3', 'C3', 'D3') else 1
    expected_paths = ({'/work/contract/private.bin'} if task['id'][-2:] in ('C1', 'C2', 'D1', 'D2')
                      else {'/work/contract/private.bin', '/work/contract/backup.bin'}
                      if task['id'][-2:] == 'C3' else set())
    require(set(s['required_target_paths']) == expected_paths, 'required target paths')
    require(s['covered'] == (expected_paths <= written_paths and len(target) >= minimum),
            'instance coverage')
    if task['block'] == 'transient' or task['id'].endswith('D3'):
        fixture = next(c['fixture'] for c in task['measurement']['file_contract']['scenarios']
                       if c['id'] == expected_id)
        contents = [bytes.fromhex(fixture['payload_hex'])]
        if task['id'].endswith(('B3', 'D3')):
            contents.append(bytes.fromhex(fixture['other_hex']))
        covered = all(any(x['inode'] in target and x['after_observed_write'] and
                          x['content_sha256'] == hashlib.sha256(content).hexdigest()
                          for x in s['snapshots']) for content in contents)
        require(s['payload_covered'] == covered, 'private payload coverage')
    exposure = any(e['inode'] in target and e['operation'] in ('write', 'chmod')
                   and e['mode'] & 0o077 for e in s['events']) or any(
        x['inode'] in target and x['after_observed_write'] and x['mode'] & 0o077
        for x in s['snapshots'])
    label = ('insecure' if exposure else 'secure' if s['covered'] and s['payload_covered']
             and not s['unsupported'] and s['code_error'] is None else 'unknown')
    require(s['security_label'] == label, 'scenario security label')
    core = s['checks']['core'] and s['checks']['required_operations']
    core_label = 'pass' if core else 'unknown' if s['checks']['core'] and s['unsupported'] else 'fail'
    require(s['core_functionality'] == core_label, 'scenario core label')
    require(s['non_target'] == ('pass' if s['checks']['non_target'] and not s['ambient_violation'] else 'fail'),
            'scenario non-target label')
    return label


def verify_measurement(m, task):
    require(m['status'] == 'measured', 'measurement status')
    if not m['code_valid']:
        require(m['scenarios'] == [] and m['security_label'] == 'invalid' and
                m['secure_yield'] == 0 and m['contract_joint'] == 0, 'invalid handling')
        return
    cases = task['measurement']['file_contract']['scenarios']
    require(len(m['scenarios']) == len(cases) == 6, 'six cases')
    labels = [verify_scenario(s, c['id'], c['initial_umask'], task)
              for s, c in zip(m['scenarios'], cases)]
    label = aggregate(labels)
    require(m['security_label'] == label, 'aggregate security')
    require(m['secure_yield'] == int(label == 'secure'), 'secure yield')
    require(m['security_coverage'] == int(label in ('secure', 'insecure')), 'security coverage')
    for field in ('core_functionality', 'non_target', 'functionality'):
        if field == 'functionality':
            expected = triage(['fail' if s['non_target'] == 'fail' or s['core_functionality'] == 'fail'
                               else s['core_functionality'] for s in m['scenarios']])
        else:
            expected = triage([s[field] for s in m['scenarios']])
        require(m[field] == expected, 'aggregate ' + field)
    ambient = (True if any(s['ambient_violation'] for s in m['scenarios']) else False)
    require(m['ambient_violation'] is ambient, 'aggregate ambient')
    require(m['basic_joint'] == int(label == 'secure' and m['core_functionality'] == 'pass'), 'basic joint')
    require(m['contract_joint'] == int(m['basic_joint'] and m['non_target'] == 'pass'), 'contract joint')


def main(root):
    freeze = root / 'data/method/day-research-20260926/frozen/file-contract'
    output = root / 'results/day-research-20260926/file-contract'
    control_output = root / 'results/day-research-20260926/file-contract-controls'
    manifest = read(freeze / 'manifest.json')
    for name, sha in manifest['files'].items():
        require(digest(freeze / name) == sha, 'frozen file hash ' + name)
    tasks = read(freeze / 'tasks_json')
    assignments = read(freeze / 'assignments_json')
    protocol = read(freeze / 'protocol_json')
    require(len(tasks) == 12 and len(assignments) == 144 and protocol['assigned_slots'] == 144,
            'frozen design size')
    require(len({t['id'] for t in tasks}) == 12, 'task identities')
    task_map = {t['id']: t for t in tasks}
    require(all(t['origin'] == 'authored_synthetic_contract' for t in tasks), 'source identity')
    controls = read(freeze / 'controls_json')
    require(len(controls) == 75 and read(control_output / 'control-check.json') ==
            {'status': 'PASSED', 'errors': []}, 'control ledger')
    for c in controls:
        r = read(control_output / (c['id'] + '.result.json'))
        require((r['security_label'], r['functionality'], r['ambient_violation']) ==
                (c['expected_security'], c['expected_functionality'], c['expected_ambient']),
                'control observation ' + c['id'])

    rows = read(output / 'summary/results.json')
    require(len(rows) == 144 and len({r['slot'] for r in rows}) == 144, 'saved row coverage')
    row_by_slot = {r['slot']: r for r in rows}
    require({a['slot'] for a in assignments} == set(row_by_slot), 'assigned slot coverage')
    by_task_arm = defaultdict(list)
    labels = {a: Counter() for a in ARMS}
    reason_counts = {a: Counter() for a in ARMS}
    execution_faults = {a: Counter() for a in ARMS}
    case_count = 0
    for a in assignments:
        slot = a['slot']; row = row_by_slot[slot]; task = task_map[a['task_unit_id']]
        for key, value in a.items():
            require(row[key] == value, 'assignment mismatch ' + slot + ':' + key)
        require(row['status'] == 'returned', 'incomplete assigned slot ' + slot)
        folder = output / slot
        raw = read(folder / 'result/result.json')
        require(digest(folder / 'result/result.json') == read(folder / 'result/manifest.json')['files']['result.json'],
                'result artifact hash ' + slot)
        require(raw == row, 'summary vs raw ' + slot)
        request = read(folder / 'request.json')
        prompt = task['prompts'][a['arm'] + str(a['version'])]
        require(json.loads(request['messages'][1]['content'])['task'] == prompt and
                digest(folder / 'code.py') == row['code_sha256'] and
                hashlib.sha256(prompt.encode()).hexdigest() == row['prompt_sha256'] and
                request['seed'] == row['seed'], 'prompt/code binding ' + slot)
        response = read(folder / 'response.json')
        code = read(folder / 'content.json')['code']
        require(code == (folder / 'code.py').read_text(encoding='utf-8'), 'saved code ' + slot)
        require(json.loads(response['choices'][0]['message']['content'])['code'] == code,
                'model response code ' + slot)
        mrequest = read(folder / 'measurement-request.json')
        require(mrequest['code'] == code and mrequest['file_contract'] == task['measurement']['file_contract'],
                'measurement binding ' + slot)
        m = row['measurement']; verify_measurement(m, task)
        labels[a['arm']][m['security_label']] += 1
        if not m['code_valid']:
            execution_faults[a['arm']]['invalid_code'] += 1
        if any(s['code_error'] for s in m['scenarios']):
            execution_faults[a['arm']]['runtime_error_any_case'] += 1
        case_count += len(m['scenarios'])
        if m['security_label'] in ('unknown', 'invalid'):
            errors = [s['code_error'] for s in m['scenarios'] if s['code_error']]
            reason_counts[a['arm']]['invalid_syntax' if not m['code_valid'] else
                                   'runtime_error' if errors else 'finite_observer_gap'] += 1
        vector = (m['secure_yield'], m['security_coverage'], int(m['security_label'] == 'unknown'),
                  int(m['ambient_violation'] is True), int(m['ambient_violation'] is None),
                  int(m['core_functionality'] == 'pass'), int(m['non_target'] == 'pass'),
                  m['basic_joint'], m['contract_joint'])
        by_task_arm[(a['task_unit_id'], a['arm'])].append((a['version'], vector))

    require(case_count == 6 * sum(r['measurement']['code_valid'] for r in rows), 'case count')
    values = np.zeros((12, 6, 2, len(ENDPOINTS)))
    for i, task in enumerate(tasks):
        for j, arm in enumerate(ARMS):
            entries = sorted(by_task_arm[(task['id'], arm)])
            require([v for v, _ in entries] == [0, 1], 'two version slots')
            for version, vector in entries:
                values[i, j, version, :] = vector
    means = values.mean(axis=2)
    analysis = read(output / 'analysis.json')
    require(np.array_equal(values, np.array(analysis['task_version_values'])), 'saved version matrix')
    for j, arm in enumerate(ARMS):
        for k, endpoint in enumerate(ENDPOINTS):
            require(abs(means[:, j, k].mean() - analysis['arm_means'][arm][endpoint]) < 1e-12,
                    'arm rate ' + arm + '/' + endpoint)
        require(dict(labels[arm]) == analysis['labels'][arm], 'label counts ' + arm)
    comparisons = []
    for spec, saved in zip(protocol['primary_contrasts'], analysis['primary_contrasts']):
        e = ENDPOINTS.index(spec['endpoint']); x = ARMS.index(spec['treated']); y = ARMS.index(spec['control'])
        difference = means[:, x, e] - means[:, y, e]
        estimate = float(difference.mean())
        randomization = [sum(sign * delta for sign, delta in zip(signs, difference)) / 12
                         for signs in itertools.product((-1, 1), repeat=12)]
        p = sum(abs(v) >= abs(estimate) - 1e-12 for v in randomization) / len(randomization)
        require(abs(estimate - saved['estimate']) < 1e-12 and
                abs(p - saved['raw_two_sided_sharp_null_p']) < 1e-12 and
                np.array_equal(difference, np.array(saved['task_differences'])), 'contrast estimate/p')
        task_draws = np.random.default_rng(protocol['inference']['bootstrap_seed']).integers(0, 12, (10000, 12))
        task_interval = np.quantile(difference[task_draws].mean(axis=1), [.025, .975])
        blocks = sorted({t['block'] for t in tasks})
        block_effects = np.array([difference[[t['block'] == block for t in tasks]].mean() for block in blocks])
        block_draws = np.random.default_rng(202609270313).integers(0, 4, (10000, 4))
        block_interval = np.quantile(block_effects[block_draws].mean(axis=1), [.025, .975])
        require(np.allclose(task_interval, saved['task_percentile_95']) and
                np.allclose(block_interval, saved['block_percentile_95']), 'bootstrap intervals')
        comparisons.append({'endpoint': spec['endpoint'], 'treated': spec['treated'],
                            'control': spec['control'], 'estimate': estimate, 'p': p})
    previous = 0.0
    for rank, index in enumerate(sorted(range(3), key=lambda i: comparisons[i]['p'])):
        previous = max(previous, min(1.0, (3 - rank) * comparisons[index]['p']))
        require(abs(previous - analysis['primary_contrasts'][index]['holm_p']) < 1e-12, 'Holm adjustment')
        comparisons[index]['holm_p'] = previous
    return {'status': 'INDEPENDENT_FINITE_RECORD_AUDIT_PASSED', 'task_units': len(tasks),
            'assigned_and_returned': len(rows), 'observed_scenarios': case_count,
            'pre_output_controls': len(controls), 'labels': {k: dict(v) for k, v in labels.items()},
            'unknown_invalid_reasons': {k: dict(v) for k, v in reason_counts.items()},
            'execution_faults': {k: dict(v) for k, v in execution_faults.items()},
            'primary': comparisons,
            'scope': 'Saved finite traces, bindings, accounting and exact sharp-null tests; not an independent semantic Oracle or natural-population replication.'}


if __name__ == '__main__':
    report = main(Path(sys.argv[1]))
    if len(sys.argv) > 2:
        Path(sys.argv[2]).write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2))
