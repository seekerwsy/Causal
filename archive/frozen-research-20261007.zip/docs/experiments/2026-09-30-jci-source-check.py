from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

from prompt_mechanism_study.artifact_io import file_sha256, read_json, write_bundle


POOL = Path('data/dataset-curation/research-candidate-pool-v4')
QUAL = Path('data/method/qwen37flash-qualification-source-review-candidates-v1')
OUTPUT = Path('data/method/jci-ridge-20260930/source-check')


def build():
    tasks = read_json(POOL / 'tasks.json')
    screening = {row['task_unit_id']: row for row in read_json(POOL / 'screening.json')}
    selections = [read_json(QUAL / f'qual-{role}-selection.json') for role in ('dev', 'accept')]
    protected_ids = {row['task_unit_id'] for choice in selections for row in choice['task_units']}
    protected_groups = {row['near_duplicate_group_id'] for choice in selections for row in choice['task_units']}
    protected_groups.update(row['near_duplicate_group_id'] for row in screening.values()
                            if row['decision'] == 'PRESERVE_PROTECTED_INPUT')
    python = [row for row in tasks if row['language'] == 'python']
    admitted = [row for row in python
                if screening[row['task_unit_id']]['decision'] == 'INCLUDED_RESEARCH_POOL'
                and row['task_unit_id'] not in protected_ids
                and row['near_duplicate_group_id'] not in protected_groups]
    counts = Counter(cwe for row in admitted for cwe in row['source_declared_cwe_ids'])
    assert counts, '没有可审查的 Python 来源'
    selected_cwe = sorted(counts, key=lambda key: (-counts[key], key))[0]
    candidates = [row for row in admitted if selected_cwe in row['source_declared_cwe_ids']]
    candidates.sort(key=lambda row: hashlib.sha256(
        ('jci-ridge-source-check-20260930:' + row['task_unit_id']).encode()).hexdigest())
    records = [dict(case_id=f'J{index:03d}', **row) for index, row in enumerate(candidates, 1)]
    inputs = [POOL / 'tasks.json', POOL / 'screening.json',
              QUAL / 'qual-dev-selection.json', QUAL / 'qual-accept-selection.json']
    metadata = {
        'status': 'OUTCOME_BLIND_BOUNDED_SOURCE_REVIEW',
        'authorization': '2026-09-30 owner requested readiness verification and implementation before a new goal',
        'scope': 'Existing candidate metadata only; review all admitted Python records in the largest declared CWE group once. No acquisition or result inspection.',
        'protection_rule': 'INCLUDED_RESEARCH_POOL; exclude concrete reserved IDs and near-duplicate groups including QUAL_DEV and QUAL_ACCEPT.',
        'evidence_level': 'Benchmark-sourced development preparation; no unseen-task or real-developer provenance claim.',
        'selection_rule': 'Largest eligible declared CWE count, lexical CWE tie; deterministic task identity hash order.',
        'python_identities': len(python),
        'admitted_python_identities': len(admitted),
        'declared_cwe_counts': dict(sorted(counts.items())),
        'selected_cwe': selected_cwe,
        'source_review_count': len(records),
        'source_counts': dict(Counter(row['source_lineage_id'] for row in records)),
        'endpoint_qualification': 'PENDING_MANUAL_SOURCE_REVIEW',
        'input_sha256': {path.as_posix(): file_sha256(path) for path in inputs},
    }
    write_bundle(OUTPUT, {'metadata.json': metadata, 'source-records.json': records})
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=('build', 'read'))
    parser.add_argument('--start', type=int, default=1)
    parser.add_argument('--count', type=int, default=15)
    args = parser.parse_args()
    if args.command == 'build':
        build()
    else:
        for row in read_json(OUTPUT / 'source-records.json')[args.start - 1:args.start - 1 + args.count]:
            print(json.dumps({key: row[key] for key in
                              ('case_id', 'task_unit_id', 'source_lineage_id', 'prompt')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
