import argparse
import ast
import hashlib
import json
from collections import defaultdict
from pathlib import Path


ROOT = Path('results/graph-guided-20260928')


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def verify(directory):
    for filename, expected in load(directory / 'manifest.json')['files'].items():
        assert hashlib.sha256((directory / filename).read_bytes()).hexdigest() == expected


def edges_by_pair(edges):
    answer = {}
    for a, a_end, b_end, b in edges:
        assert a in {'C', 'X', 'Y'} and b in {'C', 'X', 'Y'} and a != b
        assert a_end in {'TAIL', 'ARROW', 'CIRCLE'} and b_end in {'TAIL', 'ARROW', 'CIRCLE'}
        key = tuple(sorted((a, b)))
        assert key not in answer
        answer[key] = (a_end, b_end) if a < b else (b_end, a_end)
    return answer


def path_exists(edges):
    def walk(node, seen):
        if node == 'Y':
            return True
        for a, left, right, b in edges:
            if node == a and left != 'ARROW' and right != 'TAIL' and b not in seen:
                if walk(b, seen | {b}):
                    return True
            if node == b and right != 'ARROW' and left != 'TAIL' and a not in seen:
                if walk(a, seen | {a}):
                    return True
        return False
    return walk('C', {'C'})


def verify_background():
    common = ROOT / 'real-context-search-common-gap' / 'bundle'
    original = ROOT / 'real-context-search-full' / 'bundle'
    synthetic = Path('data/method/graph-guided-20260928/algorithm-inputs')
    for directory in (common, original, synthetic):
        verify(directory)
    common_protocol = load(common / 'protocol.json')
    original_protocol = load(original / 'protocol.json')
    synthetic_protocol = load(synthetic / 'protocol.json')
    python_worker = Path('docs/experiments/2026-09-28-real-context-search.py')
    r_worker = Path('docs/experiments/2026-09-28-real-context-search.R')
    algorithm_worker = Path('src/development/context_algorithms.py')
    assert hashlib.sha256(python_worker.read_bytes()).hexdigest() == common_protocol['python_sha256']
    assert hashlib.sha256(r_worker.read_bytes()).hexdigest() == common_protocol['r_worker_sha256']
    assert hashlib.sha256(algorithm_worker.read_bytes()).hexdigest() == synthetic_protocol['python_implementation_sha256']
    assert common_protocol['fixed_gap_cx'] is True
    assert common_protocol['executed_draws'] == original_protocol['executed_draws'] == 200

    configured = {}
    for path, function_name in ((python_worker, 'gfci_with_gap'), (algorithm_worker, 'gfci')):
        tree = ast.parse(path.read_text(encoding='utf-8'))
        function = next(node for node in tree.body
                        if isinstance(node, ast.FunctionDef) and node.name == function_name)
        calls = [node for node in ast.walk(function)
                 if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                 and isinstance(node.func.value, ast.Name) and node.func.value.id == 'search']
        names = [node.func.attr for node in calls]
        assert set(names) <= {'set_verbose', 'use_bdeu', 'use_g_square', 'set_forbidden',
                              'run_gfci', 'get_java'}
        forbidden = [[ast.literal_eval(argument) for argument in node.args]
                     for node in calls if node.func.attr == 'set_forbidden']
        configured[function_name] = dict(calls=names, forbidden_pairs=forbidden,
                                         source_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    assert configured['gfci_with_gap']['forbidden_pairs'] == [['C', 'X'], ['X', 'C']]
    assert configured['gfci']['forbidden_pairs'] == []
    result = dict(
        status='VERIFIED_FROZEN_SOURCE_CONFIGURATION', new_structure_searches=0,
        common_gap_searches=len(load(common / 'searches.json')),
        requirement='All real-data algorithms receive the pre-generation X-before-Y background knowledge.',
        common_gap_GFCI_explicit_Y_to_X_forbidden=False,
        common_background_requirement_complete=False,
        configured_functions=configured,
        common_gap_r_worker_sha256=common_protocol['r_worker_sha256'],
        original_run_source_identity=dict(
            python_sha256=original_protocol['python_sha256'],
            r_worker_sha256=original_protocol['r_worker_sha256'],
            matches_current_python=original_protocol['python_sha256'] == common_protocol['python_sha256'],
            matches_current_r=original_protocol['r_worker_sha256'] == common_protocol['r_worker_sha256']),
        interpretation='This checks configured source calls and frozen identities. It does not rerun orientation, repair a frozen search, or establish the outputs of a complete common temporal-knowledge comparison.')
    destination = ROOT / 'background-constraints-verification.json'
    if destination.exists():
        assert load(destination) == result
    else:
        destination.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(dict(status=result['status'], common_gap_searches=result['common_gap_searches'],
                          common_background_requirement_complete=False, new_structure_searches=0)))


def verify_repair():
    inputs = Path('data/method/graph-guided-20260928/repair-structure-inputs')
    output = ROOT / 'repair-structure/bundle'
    verify(inputs)
    verify(output)
    matrices = load(inputs / 'matrices.json')
    searches = load(output / 'searches.json')
    summaries = load(output / 'summary.json')
    assert len(matrices) == 84 and len(searches) == 3536
    methods = {'FCI_JCI0','FCI_JCI1','FCI_JCI12','GFCI'}
    groups = defaultdict(dict)
    for row in searches:
        assert row['method'] not in groups[row['identity']]
        groups[row['identity']][row['method']] = row
        graph = edges_by_pair(row['edges'])
        assert ('C','X') not in graph
        for pair in (('C','Y'),('X','Y')):
            if pair in graph:
                assert graph[pair][1] == 'ARROW'
        if row['method'] in {'FCI_JCI12','GFCI'} and ('C','Y') in graph:
            assert graph['C','Y'][0] == 'TAIL'
        assert row['possible_C_to_Y'] == path_exists(row['edges'])
        assert not row['valid'] or row['minimum_expected'] >= 5
    assert all(set(group) == methods for group in groups.values())
    assert len(groups) == 884
    for summary in summaries:
        rows = [r for r in searches if r['category'] == summary['category'] and r['method'] == summary['method']]
        bootstrap = [r for r in rows if r['draw'] != 'original']
        valid = [r for r in bootstrap if r['valid']]
        excluded = sum(not path_exists(r['edges']) for r in valid)
        assert summary['valid_bootstrap'] == len(valid) and summary['total_bootstrap'] == len(bootstrap)
        assert summary['excludes_path'] == excluded
        assert summary['action'] == ('forbid_P' if len(valid) >= 160 and excluded >= .8*len(valid) else 'retain_common_selector')
    changed = sum(edges_by_pair(g['FCI_JCI0']['edges']) != edges_by_pair(g['FCI_JCI1']['edges']) for g in groups.values())
    verified = dict(status='verified_background_and_saved_results',searches=3536,inputs=884,
        common_temporal_constraints_complete=True,X_Y_latent_confounding_not_forbidden=True,
        FCI0_JCI1_changed_inputs=changed,
        real_originals=[dict(category=r['category'],method=r['method'],edges=r['original']['edges'],
            valid_bootstrap=r['valid_bootstrap'],action=r['action']) for r in summaries if not r['category'].startswith('synthetic:')])
    destination = ROOT / 'repair-structure-independent-verification.json'
    if destination.exists():
        assert load(destination) == verified
    else:
        destination.write_text(json.dumps(verified,indent=2),encoding='utf-8')
    print(json.dumps(verified))


def main():
    outcomes = []
    for name, gap in (('real-context-search-full', False), ('real-context-search-common-gap', True)):
        directory = ROOT / name / 'bundle'
        verify(directory)
        searches = load(directory / 'searches.json')
        summaries = load(directory / 'summary.json')
        assert len(searches) == 1608 and len(summaries) == 8
        by_input = defaultdict(dict)
        by_group = defaultdict(list)
        for result in searches:
            assert result['method'] not in by_input[result['identity']]
            by_input[result['identity']][result['method']] = result
            by_group[result['category'], result['method']].append(result)
            edge_map = edges_by_pair(result['edges'])
            if gap:
                assert ('C', 'X') not in edge_map
            if result['failure'] is None:
                assert result['possible_C_to_Y'] == path_exists(result['edges'])
            assert result['valid'] == (not result['input_insufficient'] and not result['warnings']
                                        and result['failure'] is None)
        assert len(by_input) == 402
        for row in summaries:
            group = by_group[row['category'], row['method']]
            assert len(group) == 201
            valid = [result for result in group if result['draw'] != 'original' and result['valid']]
            excluded = sum(not path_exists(result['edges']) for result in valid)
            action = 'forbid_P' if len(valid) >= 160 and excluded >= .8*len(valid) else 'retain_common_selector'
            assert (row['valid_bootstrap'], row['excludes_possible_path'], row['action']) == (len(valid), excluded, action)
        changed, xy_changed = 0, 0
        for results in by_input.values():
            reference = edges_by_pair(results['FCI_JCI0']['edges'])
            altered = [edges_by_pair(results[method]['edges']) for method in ('FCI_JCI1', 'FCI_JCI12')]
            changed += any(value != reference for value in altered)
            xy_changed += any(value.get(('X', 'Y')) != reference.get(('X', 'Y')) for value in altered)
        outcomes.append(dict(run=name, searches=1608, inputs=402,
                             JCI_changed_graph_inputs=changed, JCI_changed_XY_inputs=xy_changed,
                             groups=[dict(category=row['category'], method=row['method'],
                                          valid=row['valid_bootstrap'], excludes=row['excludes_possible_path'],
                                          action=row['action']) for row in summaries]))
    policy_root = Path('data/method/graph-guided-20260928/heldout-policy-decisions')
    verify(policy_root)
    choices = load(policy_root / 'decisions.json')
    action_changes = {method: sum(row['choices']['tsg_ridge'] != row['choices'][f'tsg_ridge_plus_{method}']
                                  for row in choices)
                      for method in ('FCI_JCI0', 'FCI_JCI1', 'FCI_JCI12', 'GFCI')}
    destination = ROOT / 'real-context-independent-verification.json'
    verified = dict(status='verified', outcomes=outcomes, frozen_TSG_policy_action_changes=action_changes)
    if destination.exists():
        assert load(destination) == verified
    else:
        destination.write_text(json.dumps(verified, indent=2), encoding='utf-8')
    print(json.dumps(dict(status='verified', searches=3216,
                          JCI_XY_changes=[row['JCI_changed_XY_inputs'] for row in outcomes],
                          frozen_policy_action_changes=action_changes)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--background', action='store_true')
    parser.add_argument('--repair', action='store_true')
    arguments = parser.parse_args()
    if arguments.repair:
        verify_repair()
    elif arguments.background:
        verify_background()
    else:
        main()
