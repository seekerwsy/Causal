"""Freeze one source-only extension of the already exposed natural inventory.

Selection reads identities and lineage only; prompts and model outcomes are not
consulted. Screening happens only after the selection bundle has been saved.
"""
from __future__ import annotations

import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main(repo: Path) -> None:
    pool_path = repo / 'data/dataset-curation/research-candidate-pool-v4/tasks.json'
    prior_path = repo / 'data/method/local-baseline-screen-v1/inputs/tasks.json'
    output_dir = repo / 'data/method/day-research-20260926/frozen/natural-inventory'
    target = output_dir / 'selection.json'
    existing = json.loads(target.read_text(encoding='utf-8')) if target.exists() else None

    pool = json.loads(pool_path.read_text(encoding='utf-8'))
    prior = json.loads(prior_path.read_text(encoding='utf-8'))
    prior_ids = {row['task_unit_id'] for row in prior}
    assert len(prior_ids) == 42
    python = [row for row in pool if row['language'] == 'python']
    assert len(python) == 684
    assert len({row['task_unit_id'] for row in python}) == len(python)

    lineages = sorted({row['source_lineage_id'] for row in python})
    assert len(lineages) == 7
    quotas = {lineage: (8 if i < 5 else 7) for i, lineage in enumerate(lineages)}
    seed = '20260926-day-natural-inventory-v1'
    selected = []
    for lineage in lineages:
        remaining = [row for row in python if row['source_lineage_id'] == lineage
                     and row['task_unit_id'] not in prior_ids]
        assert len(remaining) >= quotas[lineage]
        ordered = sorted(remaining, key=lambda row: (
            hashlib.sha256(f"{seed}|{row['task_unit_id']}".encode()).hexdigest(),
            row['task_unit_id']))
        for row in ordered[:quotas[lineage]]:
            selected.append(dict(task_unit_id=row['task_unit_id'],
                                 source_lineage_id=lineage,
                                 source_prompt_sha256=row['prompt_sha256'],
                                 prior_42_task_exposure=False))

    assert len(selected) == 54 and len({row['task_unit_id'] for row in selected}) == 54
    screening_path = repo / 'data/dataset-curation/research-candidate-pool-v4/screening.json'
    protected_ids = {row['task_unit_id'] for row in json.loads(screening_path.read_text(encoding='utf-8'))
                     if row['decision'] == 'PRESERVE_PROTECTED_INPUT'}
    assert not protected_ids.intersection(row['task_unit_id'] for row in selected)
    bundle = dict(
        status='FROZEN_BEFORE_SOURCE_SCREENING_AND_NEW_MODEL_OUTPUTS',
        selected_utc=(existing['selected_utc'] if existing else
                      datetime.now(timezone.utc).isoformat()),
        evidence_role='bounded method-development source inventory, not formal discovery supplementation',
        existing_exposed_python_task_units=42,
        new_source_task_units=54,
        total_inspection_ceiling=96,
        source_pool='research-candidate-pool-v4, unprotected reviewed candidates only',
        source_pool_tasks_sha256=digest(pool_path),
        previous_42_tasks_sha256=digest(prior_path),
        selection_rule='Within each lineage, exclude prior 42 and sort by SHA256(seed|task_unit_id); first five alphabetical lineages contribute 8 each, last two 7 each; no replacement.',
        seed=seed,
        quotas=quotas,
        frozen_coverage_target='Find at least four distinct, source-usable natural task units with a prospectively qualifiable command or file-write endpoint; failure does not trigger replacement.',
        screening_rule='After freeze, inspect only selected original prompts for interpretable task, relevant operation/security boundary, observable non-target behavior, and endpoint feasibility; record source usability separately from intervention and Oracle qualification.',
        prohibited_selection_inputs=['prior code outcomes', 'prompt TSG relation support',
                                     'FCI/JCI/GFCI scores', 'selector ranks', 'paraphrases'],
        protected_evaluation_consumed=False,
        formal_role_assigned=False,
        selected=selected,
    )
    if existing:
        assert existing == bundle, 'saved natural inventory selection differs from source-only replay'
    else:
        output_dir.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(bundle, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(selected=len(selected), lineages=len(lineages),
                          total_inspection_ceiling=96, output=str(target))))


if __name__ == '__main__':
    main(Path(sys.argv[1]).resolve())
