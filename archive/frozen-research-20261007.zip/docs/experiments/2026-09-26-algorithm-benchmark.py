"""Exploratory, truth-known algorithm check; never a study selector or result.

Run with the repository Python environment after installing the official
py-tetrad interface at commit b967024e14e4918d282130b65ee39e6936f6a9e5.
The only independent rows here are simulated task units. No project task or
model outcome is read.
"""

import hashlib
import json
import platform
import sys
from importlib.metadata import version
from importlib.resources import files
from pathlib import Path

import numpy as np
import pandas as pd
from causallearn.search.ConstraintBased.FCI import fci
from pytetrad.tools.TetradSearch import TetradSearch


SCENARIOS = ("causal", "latent_null")
SIZES = (14, 24, 50, 200, 1000)
SEEDS = (11, 22, 33, 44, 55)
SYSTEM_TRUTH = {"X-Y", "Y-Z"}
POOLED_TRUTH = {"C-X", "X-Y", "Y-Z"}


def sigmoid(value):
    return 1 / (1 + np.exp(-value))


def bernoulli(rng, probability):
    return (rng.random(len(probability)) < probability).astype(int)


def make_rows(scenario, n, seed):
    rng = np.random.default_rng(seed)
    context = rng.binomial(1, 0.5, n)
    latent = rng.binomial(1, 0.5, n)
    nuisance = rng.binomial(1, 0.5, n)
    if scenario == "causal":
        factor = bernoulli(rng, sigmoid(-1.0 + 2.0 * context))
        outcome = bernoulli(rng, sigmoid(-2.0 + 2.0 * factor + 1.2 * nuisance))
    else:
        factor = bernoulli(rng, sigmoid(-1.0 + 2.0 * context + 1.5 * latent))
        outcome = bernoulli(rng, sigmoid(-2.0 + 1.8 * latent + 1.2 * nuisance))
    return pd.DataFrame({"C": context, "X": factor, "Z": nuisance, "Y": outcome})


def causal_learn_edges(frame):
    graph, _ = fci(
        frame.to_numpy(dtype=np.int64),
        independence_test_method="gsq",
        alpha=0.05,
        depth=-1,
        max_path_length=-1,
        background_knowledge=None,
        verbose=False,
        show_progress=False,
    )
    names = frame.columns.tolist()
    nodes = graph.get_nodes()
    edges = []
    for edge in graph.get_graph_edges():
        a = names[nodes.index(edge.get_node1())]
        b = names[nodes.index(edge.get_node2())]
        edges.append((a, str(edge.get_endpoint1()), str(edge.get_endpoint2()), b))
    return sorted(edges)


def tetrad_gfci_edges(frame, *, algorithm="gfci"):
    search = TetradSearch(frame)
    search.set_verbose(False)
    search.use_bdeu(sample_prior=10, structure_prior=0)
    search.use_g_square(alpha=0.05)
    if algorithm == "fci":
        search.run_fci(depth=-1, max_disc_path_length=-1)
    else:
        search.run_gfci(depth=-1, max_degree=-1, max_disc_path_length=-1)
    edges = []
    for edge in search.get_java().getEdges():
        edges.append((str(edge.getNode1().getName()), str(edge.getEndpoint1()),
                      str(edge.getEndpoint2()), str(edge.getNode2().getName())))
    return sorted(edges)


def skeleton_score(edges, truth, all_nodes):
    predicted = {"-".join(sorted((a, b))) for a, _, _, b in edges}
    all_pairs = {"-".join(sorted((a, b))) for i, a in enumerate(all_nodes)
                 for b in all_nodes[i + 1:]}
    assert predicted <= all_pairs
    return {"tp": len(predicted & truth), "fp": len(predicted - truth),
            "fn": len(truth - predicted), "predicted": sorted(predicted)}


def main(output):
    records = []
    datasets = []
    for scenario in SCENARIOS:
        for n in SIZES:
            for seed in SEEDS:
                rows = make_rows(scenario, n, seed)
                datasets.append(rows.assign(scenario=scenario, n_total=n, seed=seed))
                observational = rows.loc[rows.C == 0, ["X", "Z", "Y"]]
                for method, frame, truth in (
                    ("FCI_observational", observational, SYSTEM_TRUTH),
                    ("GFCI_observational", observational, SYSTEM_TRUTH),
                    ("FCI_JCI0_pooled", rows[["C", "X", "Z", "Y"]], POOLED_TRUTH),
                ):
                    try:
                        edges = (tetrad_gfci_edges(frame) if method.startswith("GFCI")
                                 else causal_learn_edges(frame))
                        score = skeleton_score(edges, truth, frame.columns.tolist())
                        record = dict(scenario=scenario, n_total=n, n_used=len(frame),
                                      seed=seed, method=method, edges=edges, **score)
                    except Exception as error:
                        record = dict(scenario=scenario, n_total=n, n_used=len(frame),
                                      seed=seed, method=method,
                                      error=f"{type(error).__name__}: {error}")
                    records.append(record)
                    if "error" in record:
                        print(f"{scenario} n={n} seed={seed} {method}: {record['error']}",
                              flush=True)
    jar_path = files("pytetrad").joinpath("resources", "tetrad-current.jar")
    with jar_path.open("rb") as jar:
        jar_sha256 = hashlib.file_digest(jar, "sha256").hexdigest()
    result = {
        "status": "EXPLORATORY_SYNTHETIC_ONLY",
        "environment": {"python": platform.python_version(),
                        "numpy": np.__version__, "causal_learn": version("causal-learn"),
                        "py_tetrad": version("py-tetrad"),
                        "py_tetrad_commit": "b967024e14e4918d282130b65ee39e6936f6a9e5",
                        "tetrad_jar_sha256": jar_sha256,
                        "platform": platform.platform()},
        "design": {"scenarios": SCENARIOS, "sizes": SIZES, "seeds": SEEDS,
                   "alpha": 0.05, "gfci_score": "BDeu, ESS=10, structure_prior=0",
                   "ci_test": "G-square", "jci": "JCI0 pooled context; no JCI1/2/3 background knowledge"},
        "records": records,
    }
    output_path = Path(output)
    Path(output).write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    pd.concat(datasets, ignore_index=True).to_csv(output_path.with_suffix(".csv"), index=False)
    print(f"wrote {len(records)} records to {output}", flush=True)


def repair_support(output):
    """Matched-backend new-seed comparison after the bounded repair validation.

    Proxy scores refer to the intended clean endpoint, not a claim that an
    algorithm ought to recover that graph from a different measured variable.
    """
    from prompt_mechanism_study.artifact_io import read_json, write_bundle
    root = Path(__file__).resolve().parents[2]
    frozen = root / 'data/method/command-binding-repair-20260926/frozen'
    design = read_json(frozen / 'protocol.json')['algorithm_scope']
    qualifications = read_json(root / 'results/command-binding-repair-20260926-runtime/qualification/results.json')
    assert len(qualifications) == 22 and all(r['passed'] for r in qualifications)
    generated = read_json(root / 'results/command-binding-repair-20260926-generation/summary/results.json')
    assert len(generated) == 12 and all(r['status'] == 'returned' for r in generated)
    out = Path(output)
    if out.exists() or out.with_suffix('.csv').exists(): raise FileExistsError(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    # Freeze the exact executed algorithm settings and producer before searching.
    write_bundle(out.parent / 'algorithm-freeze', {'design.json': design,
       'implementation.json': {'python_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'r_sha256': hashlib.sha256((Path(__file__).with_name('2026-09-26-jci-fci-benchmark.R')).read_bytes()).hexdigest(),
          'alpha': .05, 'GFCI_BDeu_ESS': 10, 'structure_prior': 0,
          'row_policy': 'all C,X,Z,Y rows identical across methods; no task repetitions',
          'proxy_interpretation': 'deviation from clean target graph, not recovery error for proxy graph'}})
    equality = []
    for a in range(4):
        for z in (0, 1):
            for u in (0, 1):
                x = int(a == 3)
                p_t = float(sigmoid(-2 + 2*x + 1.2*z + .8*u))
                p_a = float(sigmoid(-2 + 2*int(a == 3) + 1.2*z + .8*u))
                equality.append(dict(A=a, Z=z, U=u, X1=x, p_SCM_T=p_t, p_SCM_A=p_a))
    delta = float(np.mean([sigmoid(-2+2+1.2*z+.8*u)-sigmoid(-2+1.2*z+.8*u)
                          for z in (0,1) for u in (0,1)]))
    assert all(r['p_SCM_T'] == r['p_SCM_A'] for r in equality)
    counterexample = {'observational_state_probabilities': equality, 'max_observational_difference': 0,
        'do_X1_effect_fixed_A_NOOP_SCM_T': delta, 'do_X1_effect_fixed_A_NOOP_SCM_A': 0,
        'limitation': 'exact finite-state counterexample; policy ITT remains identified by randomized A'}
    records, datasets = [], []
    for scenario in design['scenarios']:
        for n in design['sizes']:
            for seed in design['seeds']:
                clean = make_rows(scenario, n, seed)
                rng = np.random.default_rng(seed + 20260926)
                corruption = rng.random(n) < np.where(clean.X.to_numpy() == 1,
                     design['proxy_false_positive_x1'], design['proxy_false_positive_x0'])
                for measurement in design['measurements']:
                    frame = clean.copy()
                    if measurement == 'proxy': frame['Y'] = np.maximum(frame.Y, corruption.astype(int))
                    label = scenario + '_' + measurement
                    datasets.append(frame.assign(scenario=label, n_total=n, seed=seed,
                                                  target_Y=clean.Y.to_numpy()))
                    for method in ('fci', 'gfci'):
                        try:
                            edges = tetrad_gfci_edges(frame, algorithm=method)
                            record = dict(scenario=label, n_total=n, n_used=n, seed=seed,
                                 method='Tetrad_'+method.upper(), edges=edges,
                                 target_truth_score=skeleton_score(edges, POOLED_TRUTH, frame.columns.tolist()))
                        except Exception as error:
                            record = dict(scenario=label,n_total=n,n_used=n,seed=seed,
                                 method='Tetrad_'+method.upper(),error=f'{type(error).__name__}: {error}')
                        records.append(record)
    jar = files('pytetrad').joinpath('resources','tetrad-current.jar')
    with jar.open('rb') as f: jar_hash=hashlib.file_digest(f,'sha256').hexdigest()
    pd.concat(datasets,ignore_index=True).to_csv(out.with_suffix('.csv'),index=False)
    out.write_text(json.dumps(dict(status='EXPLORATORY_MATCHED_BACKEND',design=design,
       environment=dict(python=platform.python_version(),numpy=np.__version__,py_tetrad=version('py-tetrad'),
                        tetrad_jar_sha256=jar_hash),counterexample=counterexample,records=records),indent=2),encoding='utf-8')
    print('saved',len(records),'same-backend searches and exact counterexample',flush=True)


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == '--repair-support':
        repair_support(sys.argv[2])
    elif len(sys.argv) == 2:
        if Path(sys.argv[1]).exists(): raise FileExistsError(sys.argv[1])
        main(sys.argv[1])
    else:
        raise SystemExit("usage: python benchmark.py [--repair-support] OUTPUT.json")
